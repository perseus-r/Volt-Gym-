import React, { useState, Suspense, lazy, useEffect } from 'react';
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { routerFutureConfig } from '@/utils/routerConfig';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { PageThemeProvider } from '@/contexts/PageThemeContext';
import { UIChromeProvider } from '@/contexts/UIChromeContext';
import { ProtectedRoute } from "@/components/ProtectedRoute";
import { AdminRoute } from "@/components/AdminRoute";
import { ProfileCompletionGuard } from "@/components/ProfileCompletionGuard";
import { isAdminEmail } from "@/lib/admin";
import { useUserRole } from "@/hooks/useUserRole";
import { useIsMobile } from "@/hooks/use-mobile";
import { useMobileExperience } from "@/hooks/useMobileExperience";
import { useWorkoutRAGIndexing } from "@/hooks/useWorkoutRAGIndexing";
import { useLoginTracking } from "@/hooks/useLoginTracking";
import SessionAutoQA from "@/components/SessionAutoQA";

import { AppNavigation } from "./components/navigation/AppNavigation";
import { useMobileSafeArea } from "@/hooks/useMobileSafeArea";
import { PageEntranceAnimation } from "./components/transitions/PageEntranceAnimation";
import { LanguageProvider } from "@/components/MultiLanguageSystem";
import { useAnalytics } from "@/hooks/useAnalytics";
import { errorLoggingService } from "@/services/ErrorLoggingService";
import { routePrefetcher } from "@/utils/routePrefetcher";

// PWA Components
import { OfflineIndicator } from "./components/pwa/OfflineIndicator";
import { UpdatePrompt } from "./components/pwa/UpdatePrompt";
import { DebugOverlay } from "./components/debug/DebugOverlay";
// Critical pages - loaded immediately
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import NotFound from "./pages/NotFound";

// Lazy loaded pages - loaded on demand
const HubDashboard = lazy(() => import("./pages/Hub/HubDashboard"));
const AdminDashboard = lazy(() => import("./pages/Admin/AdminDashboard"));
const TreinosPage = lazy(() => import("./pages/TreinosPage"));
const IACoachPage = lazy(() => import("./pages/IACoachPage"));
const ProgressoPage = lazy(() => import("./pages/ProgressoPage"));
const ProPage = lazy(() => import("./pages/ProPage"));
const ServicosPage = lazy(() => import("./pages/ServicosPage"));
const NutricaoPage = lazy(() => import("./pages/NutricaoPage"));
const ProSucessoPage = lazy(() => import("./pages/ProSucessoPage"));
const PremiumSucessoPage = lazy(() => import("./pages/PremiumSucessoPage"));
const AdminPanel = lazy(() => import("./pages/AdminPanel"));
const ProductManagerPage = lazy(() => import('./pages/ProductManagerPage'));
const AccountTypeSelection = lazy(() => import("./pages/AccountTypeSelection"));
const Onboarding = lazy(() => import("./pages/Onboarding"));
const OnboardingLinked = lazy(() => import("./pages/OnboardingLinked"));
const Settings = lazy(() => import("./pages/Settings"));
const ComunidadePage = lazy(() => import("./pages/ComunidadePage"));
const PerfilPage = lazy(() => import("./pages/PerfilPage"));
const SessionTester = lazy(() => import("./components/SessionTester").then(m => ({ default: m.SessionTester })));
const AllPagesTest = lazy(() => import("./components/AllPagesTest").then(m => ({ default: m.AllPagesTest })));
const LojaPage = lazy(() => import("./pages/LojaPage"));
const CheckoutSuccess = lazy(() => import("./pages/CheckoutSuccess"));
const ExerciciosPage = lazy(() => import("./pages/ExerciciosPage"));
const SharePage = lazy(() => import("./pages/SharePage"));
const DesafiosPage = lazy(() => import("./pages/DesafiosPage"));
const MinhasConsultasPage = lazy(() => import("./pages/MinhasConsultasPage"));
const ChatConsultaPage = lazy(() => import("./pages/ChatConsultaPage"));
const PTDashboard = lazy(() => import("./pages/PersonalTrainer/PTDashboard"));
const PTAthletesList = lazy(() => import("./pages/PersonalTrainer/PTAthletesList"));
const PTAthleteDetail = lazy(() => import("./pages/PersonalTrainer/PTAthleteDetail"));
const PTTemplates = lazy(() => import("./pages/PersonalTrainer/PTTemplates"));
const PTAIWorkoutBuilder = lazy(() => import("./pages/PersonalTrainer/PTAIWorkoutBuilder"));
const PTInviteAthlete = lazy(() => import("./pages/PersonalTrainer/PTInviteAthlete"));
const PTAICoachPage = lazy(() => import("./pages/PersonalTrainer/PTAICoachPage"));
const PTKnowledgeBase = lazy(() => import("./pages/PersonalTrainer/PTKnowledgeBase"));
const PTPricing = lazy(() => import("./pages/PersonalTrainer/PTPricing"));
const PTOnboarding = lazy(() => import("./pages/PersonalTrainer/PTOnboarding"));
const PTChat = lazy(() => import("./pages/PersonalTrainer/PTChat"));
const AthleteChat = lazy(() => import("./pages/Athlete/AthleteChat"));
const AthleteOnboarding = lazy(() => import("./pages/Athlete/AthleteOnboarding"));
const AthleteWorkoutView = lazy(() => import("./pages/Athlete/AthleteWorkoutView"));
const AssignedWorkoutExecution = lazy(() => import("./pages/Athlete/AssignedWorkoutExecution"));
const AthleteWorkouts = lazy(() => import("./pages/Athlete/AthleteWorkouts"));
const AthleteCoach = lazy(() => import("./pages/Athlete/AthleteCoach"));
const AthleteCheckinForm = lazy(() => import("./pages/Athlete/AthleteCheckinForm"));
const AcceptInvite = lazy(() => import("./pages/AcceptInvite"));
const InviteBySlug = lazy(() => import("./pages/InviteBySlug"));
const ShortLinkRedirect = lazy(() => import("./pages/ShortLinkRedirect"));
const WorkoutVideoDebug = lazy(() => import("./pages/Admin/WorkoutVideoDebug"));
const BulkVideoUpload = lazy(() => import("./pages/admin/BulkVideoUpload"));
const CompleteOnboardingWizard = lazy(() => import("./components/onboarding/CompleteOnboardingWizard"));

// Loading fallback component - Premium transition
import { SuspenseTransition } from './components/transitions/SuspenseTransition';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes - data considered fresh
      gcTime: 10 * 60 * 1000, // 10 minutes - cache retention
      refetchOnWindowFocus: false, // Don't refetch on tab focus
      refetchOnReconnect: false, // Don't refetch on reconnect
      retry: 1, // Only 1 retry on failure
      retryDelay: 500, // Fast retry
    },
  },
});

function AppLayoutWrapper({ children }: { children: React.ReactNode }) {
  const [activeView, setActiveView] = useState('dashboard');
  const { user } = useAuth();
  const location = useLocation();
  const { isMobile } = useMobileExperience();
  const { isAdmin: isAdminByRole } = useUserRole();
  const isAdminHybrid = isAdminByRole || isAdminEmail(user?.email || null);

  // Get page title from pathname
  const getPageTitle = (pathname: string) => {
    const titles: Record<string, string> = {
      '/dashboard': 'Dashboard',
      '/treinos': 'Treinos',
      '/exercicios': 'Exercícios',
      '/ia-coach': 'IA Coach',
      '/progresso': 'Progresso',
      '/nutricao': 'Nutrição',
      '/perfil': 'Perfil',
      '/loja': 'Loja',
      '/comunidade': 'Comunidade'
    };
    return titles[pathname] || 'Volt Gym';
  };

  // Removido console.log de produção

  if (isMobile) {
    return (
      <div 
        className="w-full h-full relative bg-background flex flex-col max-w-md mx-auto"
        style={{ 
          height: '100%',
          minHeight: '100%',
        }}
      >
        {/* Main content - scrollable area */}
        <main 
          className="flex-1 overflow-y-auto relative z-10"
          style={{ 
            paddingBottom: 'calc(64px + env(safe-area-inset-bottom, 0px) + var(--ios-toolbar-bottom, 0px))',
            WebkitOverflowScrolling: 'touch',
            overscrollBehaviorY: 'contain',
          }}
        >
          <PageEntranceAnimation>
            {children}
          </PageEntranceAnimation>
        </main>

        {/* Global Navigation - Menu Button + Drawer */}
        <AppNavigation />
      </div>
    );
  }

  // Desktop layout - no sidebar
  return (
    <div className="min-h-screen w-full bg-background">
      {/* Main content */}
      <main className="transition-all duration-300">
        {/* Minimal desktop header */}
        <div className="sticky top-0 z-30 bg-background/95 border-b border-border/30">
          <div className="flex items-center justify-between px-6 py-3">
            <div>
              <h1 className="text-lg font-semibold text-foreground">{getPageTitle(location.pathname)}</h1>
            </div>
          </div>
        </div>
        
        {/* Content - less padding */}
        <div className="p-4">
          <PageEntranceAnimation>
            {children}
          </PageEntranceAnimation>
        </div>
      </main>

      {/* Global Navigation - Menu Button + Drawer */}
      <AppNavigation />
    </div>
  );
}

// Component that uses hooks inside React context
function AppContent() {
  const location = useLocation();
  
  // Initialize mobile safe area CSS variables
  useMobileSafeArea();
  // Ativar indexação automática de treinos no RAG
  useWorkoutRAGIndexing();
  // Ativar tracking automático de login
  useLoginTracking();
  // Analytics tracking
  useAnalytics();
  
  // Initialize error logging and route prefetching
  useEffect(() => {
    errorLoggingService.init();
  }, []);
  
  // Prefetch routes based on current page
  useEffect(() => {
    routePrefetcher.prefetchForRoute(location.pathname);
  }, [location.pathname]);
  
  return (
    <>
      <SessionAutoQA />
      <Suspense fallback={<SuspenseTransition />}>
        <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/comecar" element={<AccountTypeSelection />} />
            {/* Redirects de rotas antigas */}
            <Route path="/account-type" element={<Navigate to="/comecar" replace />} />
            <Route path="/login" element={<Navigate to="/auth" replace />} />
            <Route path="/cadastro" element={<Navigate to="/comecar" replace />} />
              <Route path="/onboarding" element={
                <ProtectedRoute requiresProfile={false}>
                  <Onboarding />
                </ProtectedRoute>
              } />
              <Route path="/onboarding-linked" element={
                <ProtectedRoute requiresProfile={false}>
                  <OnboardingLinked />
                </ProtectedRoute>
              } />
              <Route path="/complete-profile" element={
                <ProtectedRoute requiresProfile={false}>
                  <CompleteOnboardingWizard />
                </ProtectedRoute>
              } />
              <Route path="/dashboard" element={
                <ProtectedRoute>
                  <ProfileCompletionGuard>
                    <AppLayoutWrapper>
                      <HubDashboard />
                    </AppLayoutWrapper>
                  </ProfileCompletionGuard>
                </ProtectedRoute>
              } />
              <Route path="/admin/dashboard" element={
                <AdminRoute>
                  <AppLayoutWrapper>
                    <AdminDashboard />
                  </AppLayoutWrapper>
                </AdminRoute>
              } />
              <Route path="/treinos" element={
                <ProtectedRoute>
                  <AppLayoutWrapper>
                    <TreinosPage />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/exercicios" element={
                <ProtectedRoute>
                  <AppLayoutWrapper>
                    <ExerciciosPage />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/ia-coach" element={
                <ProtectedRoute>
                  <ProfileCompletionGuard>
                    <AppLayoutWrapper>
                      <IACoachPage />
                    </AppLayoutWrapper>
                  </ProfileCompletionGuard>
                </ProtectedRoute>
              } />
              <Route path="/progresso" element={
                <ProtectedRoute>
                  <AppLayoutWrapper>
                    <ProgressoPage />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/share" element={
                <ProtectedRoute>
                  <AppLayoutWrapper>
                    <SharePage />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/desafios" element={
                <ProtectedRoute>
                  <AppLayoutWrapper>
                    <DesafiosPage />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/pro" element={
                <AppLayoutWrapper>
                  <ProPage />
                </AppLayoutWrapper>
              } />
        <Route path="/servicos" element={
          <AppLayoutWrapper>
            <ServicosPage />
          </AppLayoutWrapper>
        } />
        <Route path="/consultas" element={
          <ProtectedRoute>
            <AppLayoutWrapper>
              <MinhasConsultasPage />
            </AppLayoutWrapper>
          </ProtectedRoute>
        } />
        <Route path="/consultas/:appointmentId" element={
          <ProtectedRoute>
            <AppLayoutWrapper>
              <ChatConsultaPage />
            </AppLayoutWrapper>
          </ProtectedRoute>
        } />
              <Route path="/loja" element={
                <ProtectedRoute>
                  <AppLayoutWrapper>
                    <LojaPage />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/loja/sucesso" element={
                <ProtectedRoute>
                  <CheckoutSuccess />
                </ProtectedRoute>
              } />
              <Route path="/nutricao" element={
                <ProtectedRoute>
                  <ProfileCompletionGuard>
                    <AppLayoutWrapper>
                      <NutricaoPage />
                    </AppLayoutWrapper>
                  </ProfileCompletionGuard>
                </ProtectedRoute>
              } />
              <Route path="/pro/sucesso" element={
                <ProtectedRoute>
                  <AppLayoutWrapper>
                    <ProSucessoPage />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/premium/sucesso" element={
                <ProtectedRoute>
                  <AppLayoutWrapper>
                    <PremiumSucessoPage />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/admin" element={
                <AdminRoute>
                  <AppLayoutWrapper>
                    <AdminPanel />
                  </AppLayoutWrapper>
                </AdminRoute>
              } />
              <Route path="/admin/products" element={
                <AdminRoute>
                  <AppLayoutWrapper>
                    <ProductManagerPage />
                  </AppLayoutWrapper>
                </AdminRoute>
              } />
              <Route path="/debug/videos" element={
                <AdminRoute>
                  <WorkoutVideoDebug />
                </AdminRoute>
              } />
              <Route path="/admin/bulk-upload" element={
                <AdminRoute>
                  <BulkVideoUpload />
                </AdminRoute>
              } />
              <Route path="/settings" element={
                <ProtectedRoute>
                  <AppLayoutWrapper>
                    <Settings />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/comunidade" element={
                <AppLayoutWrapper>
                  <ComunidadePage />
                </AppLayoutWrapper>
              } />
              <Route path="/perfil" element={
                <ProtectedRoute>
                  <AppLayoutWrapper>
                    <PerfilPage />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/testes/sessao" element={
                <ProtectedRoute>
                  <AppLayoutWrapper>
                    <SessionTester />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/testes/completo" element={
                <ProtectedRoute>
                  <AppLayoutWrapper>
                    <AllPagesTest />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              
              {/* Personal Trainer Routes */}
              <Route path="/pt" element={
                <ProtectedRoute requiresProfile={false}>
                  <AppLayoutWrapper>
                    <PTDashboard />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/pt/athletes" element={
                <ProtectedRoute requiresProfile={false}>
                  <AppLayoutWrapper>
                    <PTAthletesList />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/pt/athletes/:athleteId" element={
                <ProtectedRoute requiresProfile={false}>
                  <AppLayoutWrapper>
                    <PTAthleteDetail />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/pt/templates" element={
                <ProtectedRoute requiresProfile={false}>
                  <AppLayoutWrapper>
                    <PTTemplates />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/pt/ai-builder" element={
                <ProtectedRoute requiresProfile={false}>
                  <AppLayoutWrapper>
                    <PTAIWorkoutBuilder />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/pt/ia-coach" element={
                <ProtectedRoute requiresProfile={false}>
                  <AppLayoutWrapper>
                    <PTAICoachPage />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/pt/knowledge-base" element={
                <ProtectedRoute requiresProfile={false}>
                  <AppLayoutWrapper>
                    <PTKnowledgeBase />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/pt/invite" element={
                <ProtectedRoute requiresProfile={false}>
                  <AppLayoutWrapper>
                    <PTInviteAthlete />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/pt/pricing" element={
                <AppLayoutWrapper>
                  <PTPricing />
                </AppLayoutWrapper>
              } />
              <Route path="/pt/onboarding" element={
                <ProtectedRoute requiresProfile={false}>
                  <PTOnboarding />
                </ProtectedRoute>
              } />
              <Route path="/pt/chat" element={
                <ProtectedRoute requiresProfile={false}>
                  <PTChat />
                </ProtectedRoute>
              } />
              <Route path="/pt/chat/:athleteId" element={
                <ProtectedRoute requiresProfile={false}>
                  <PTChat />
                </ProtectedRoute>
              } />
              <Route path="/chat-pt" element={
                <ProtectedRoute>
                  <AthleteChat />
                </ProtectedRoute>
              } />
              
              {/* Athlete Routes */}
              <Route path="/athlete/join/:token" element={<AthleteOnboarding />} />
              <Route path="/athlete/workouts" element={
                <ProtectedRoute>
                  <AppLayoutWrapper>
                    <AthleteWorkouts />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/athlete/workout/:workoutId" element={
                <ProtectedRoute>
                  <AppLayoutWrapper>
                    <AssignedWorkoutExecution />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/athlete/coach" element={
                <ProtectedRoute>
                  <AppLayoutWrapper>
                    <AthleteCoach />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/athlete/chat" element={
                <ProtectedRoute>
                  <AthleteChat />
                </ProtectedRoute>
              } />
              <Route path="/progress/checkin" element={
                <ProtectedRoute>
                  <AppLayoutWrapper>
                    <AthleteCheckinForm />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/athlete/workouts/:workoutId" element={
                <ProtectedRoute>
                  <AppLayoutWrapper>
                    <AthleteWorkoutView />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/treinos/assigned/:workoutId" element={
                <ProtectedRoute>
                  <AppLayoutWrapper>
                    <AssignedWorkoutExecution />
                  </AppLayoutWrapper>
                </ProtectedRoute>
              } />
              <Route path="/invite" element={<AcceptInvite />} />
              <Route path="/convite/:slug" element={<InviteBySlug />} />
              <Route path="/s/:code" element={<ShortLinkRedirect />} />
              
              <Route path="*" element={<NotFound />} />
            </Routes>
        </Suspense>
      </>
  );
}

const App = () => {
  if (process.env.NODE_ENV === 'development') {
    console.log("Volt Gym App rendering...");
  }
  
  return (
    <LanguageProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <AuthProvider>
            <UIChromeProvider>
              <Toaster />
              <Sonner />
              {/* PWA Components */}
              <OfflineIndicator />
              <UpdatePrompt />
              <Router future={routerFutureConfig}>
                <PageThemeProvider>
                  <AppContent />
                  {/* Debug Overlay - activated with ?debug=1 */}
                  <DebugOverlay />
                </PageThemeProvider>
              </Router>
            </UIChromeProvider>
          </AuthProvider>
        </TooltipProvider>
      </QueryClientProvider>
    </LanguageProvider>
  );
};

export default App;