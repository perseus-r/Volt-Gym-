import { useState, useEffect, createContext, useContext, ReactNode } from "react";
import { Globe, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";

interface Language {
  code: string;
  name: string;
  nativeName: string;
  flag: string;
  completion: number;
}

interface Translation {
  [key: string]: string | Translation;
}

interface LanguageContextType {
  currentLanguage: Language;
  t: (key: string) => string;
  changeLanguage: (code: string) => void;
  availableLanguages: Language[];
}

const SUPPORTED_LANGUAGES: Language[] = [
  { code: 'pt', name: 'Portuguese', nativeName: 'Português', flag: '🇧🇷', completion: 100 },
  { code: 'en', name: 'English', nativeName: 'English', flag: '🇺🇸', completion: 95 },
  { code: 'es', name: 'Spanish', nativeName: 'Español', flag: '🇪🇸', completion: 85 },
  { code: 'fr', name: 'French', nativeName: 'Français', flag: '🇫🇷', completion: 75 },
  { code: 'de', name: 'German', nativeName: 'Deutsch', flag: '🇩🇪', completion: 70 },
  { code: 'it', name: 'Italian', nativeName: 'Italiano', flag: '🇮🇹', completion: 65 }
];

// Translations object - expandable
const translations: { [key: string]: Translation } = {
  pt: {
    // Navegação
    'nav.main': 'PRINCIPAL',
    'nav.intelligence': 'INTELIGÊNCIA',
    'nav.resources': 'RECURSOS',
    'nav.social': 'SOCIAL',
    'nav.dashboard': 'Dashboard',
    'nav.workouts': 'Treinos',
    'nav.progress': 'Progresso',
    'nav.ia-coach': 'IA Coach',
    'nav.nutrition': 'Nutrição',
    'nav.exercises': 'Exercícios',
    'nav.community': 'Comunidade',
    'nav.shop': 'Loja',
    'nav.services': 'Serviços',
    'nav.consultations': 'Consultas',
    'nav.settings': 'Configurações',
    'nav.profile': 'Perfil',
    'nav.logout': 'Sair',
    'nav.home': 'Início',
    'nav.training': 'Treinar',
    'nav.more': 'Mais',
    'nav.coach': 'IA Coach',
    'nav.admin': 'Admin',
    
    // Descrições de navegação
    'nav.dashboard.desc': 'Visão geral dos treinos',
    'nav.workouts.desc': 'Seus treinos diários',
    'nav.progress.desc': 'Acompanhe sua evolução',
    'nav.ia-coach.desc': 'Assistente inteligente',
    'nav.nutrition.desc': 'Dashboard nutricional premium',
    'nav.exercises.desc': 'Biblioteca de exercícios',
    'nav.shop.desc': 'Produtos e suplementos',
    'nav.community.desc': 'Rede social fitness',
    'nav.services.desc': 'Consultorias e profissionais',
    'nav.consultations.desc': 'Suas conversas e agendamentos',
    'nav.settings.desc': 'Preferências do sistema',
    'nav.logout.desc': 'Fazer logout',
    
    // Saudações
    'greeting.morning': 'Bom dia',
    'greeting.afternoon': 'Boa tarde',
    'greeting.evening': 'Boa noite',
    
    // Dashboard
    'dashboard.title': 'Dashboard',
    'dashboard.weekly-goal': 'Meta Semanal',
    'dashboard.workouts-completed': 'Treinos Completados',
    'dashboard.start-workout': 'Iniciar Treino',
    'dashboard.today-workout': 'Treino de Hoje',
    'dashboard.consistency': 'Consistência',
    'dashboard.total-workouts': 'Total de Treinos',
    'dashboard.current-streak': 'Sequência Atual',
    'dashboard.your-stats': 'Suas Estatísticas',
    'dashboard.level': 'Nível',
    'dashboard.xp-total': 'XP Total',
    'dashboard.streak': 'Streak',
    'dashboard.workouts': 'Treinos',
    'dashboard.quick-actions': 'Ações Rápidas',
    'dashboard.weekly-progress': 'Progresso Semanal',
    'dashboard.recent-achievements': 'Conquistas Recentes',
    'dashboard.completed-of': 'de {goal} treinos completados',
    
    // Ações Rápidas
    'quick-actions.start-workout': 'Iniciar Treino',
    'quick-actions.start-now': 'Começar agora',
    'quick-actions.ia-coach': 'IA Coach',
    'quick-actions.create-workout': 'Criar treino',
    'quick-actions.nutrition': 'Nutrição',
    'quick-actions.track': 'Acompanhar',
    'quick-actions.progress': 'Progresso',
    'quick-actions.see-evolution': 'Ver evolução',
    
    // Treinos
    'workouts.create-new': 'Criar Novo Treino',
    'workouts.my-workouts': 'Meus Treinos',
    'workouts.templates': 'Modelos',
    'workouts.duration': 'Duração',
    'workouts.exercises': 'Exercícios',
    'workouts.difficulty': 'Dificuldade',
    'workouts.focus': 'Foco',
    'workouts.history': 'Histórico de Treinos',
    
    // Exercícios
    'exercise.sets': 'Séries',
    'exercise.reps': 'Repetições',
    'exercise.weight': 'Peso',
    'exercise.rest-time': 'Descanso',
    'exercise.completed': 'Concluído',
    
    // Ações Comuns
    'common.save': 'Salvar',
    'common.cancel': 'Cancelar',
    'common.delete': 'Deletar',
    'common.edit': 'Editar',
    'common.confirm': 'Confirmar',
    'common.close': 'Fechar',
    'common.back': 'Voltar',
    'common.next': 'Próximo',
    'common.loading': 'Carregando...',
    'common.exercises': 'exercícios',
    'common.search': 'Buscar...',
    
    // Header
    'header.intelligent-workouts': 'Treinos Inteligentes',
    'header.settings': 'Configurações',
    'header.manage-subscription': 'Gerenciar assinatura',
    'header.logout': 'Sair',
    
    // Treinos (expandido)
    'workouts.create-custom': 'Criar Treino Customizado',
    'workouts.quick-templates': 'Templates Rápidos',
    'workouts.exercises-count': 'exercícios',
    'workouts.tab.overview': 'Visão Geral',
    'workouts.tab.my-workouts': 'Meus Treinos',
    'workouts.tab.templates': 'Templates',
    'workouts.tab.analytics': 'Análise',
    'workouts.tab.calendar': 'Calendário',
    'workouts.stats.workouts': 'Treinos',
    'workouts.stats.streak': 'Sequência',
    'workouts.stats.level': 'Nível',
    'workouts.stats.volume': 'Volume',
    'workouts.stats.days': 'dias',
    'workouts.updated': 'Treinos atualizados!',
    
    // Progresso
    'progress.title': 'Seu Progresso',
    'progress.subtitle': 'Acompanhe sua evolução com métricas detalhadas e insights personalizados.',
    'progress.level-badge': 'Nível',
    'progress.tab.overview': 'Visão Geral',
    'progress.tab.analytics-ai': 'Analytics IA',
    'progress.tab.gamification': 'Gamification',
    'progress.tab.ranking': 'Ranking',
    'progress.tab.achievements': 'Conquistas',
    'progress.tab.health': 'Saúde',
    'progress.stats.workouts': 'Treinos',
    'progress.stats.level': 'Nível',
    'progress.stats.streak': 'Sequência',
    'progress.stats.weekly': 'Semanal',
    
    // IA Coach
    'coach.title': 'IA Coach',
    'coach.powered-by': 'Powered by AI',
    'coach.chats': 'Chats',
    'coach.saved-conversations': 'Conversas Salvas',
    'coach.your-coach': 'Seu treinador pessoal inteligente que te conhece. Coach personalizado com memória de conversas e criação automática de treinos!',
    'coach.objective': 'Objetivo',
    'coach.workouts': 'treinos',
    'coach.days': 'dias',
    
    // Nutrição
    'nutrition.title': 'Nutrição Premium',
    'nutrition.subtitle': 'Dashboard nutricional completo com IA',
    'nutrition.goals': 'Metas',
    'nutrition.add-meal': 'Adicionar\nRefeição',
    'nutrition.scan-food': 'Escanear\nComida',
    'nutrition.ai-chat': 'Chat IA',
    'nutrition.daily-plan': 'Plano do Dia',
    'nutrition.stats.calories': 'Calorias',
    'nutrition.stats.protein': 'Proteína',
    'nutrition.stats.hydration': 'Hidratação',
    'nutrition.stats.meals': 'Refeições',
    'nutrition.tab.dashboard': 'Dashboard',
    'nutrition.tab.scanner': 'Scanner',
    'nutrition.tab.meals': 'Refeições',
    'nutrition.tab.ai-coach': 'IA Coach',
    'nutrition.tab.tools': 'Ferramentas',
    
    // Sistema de Idioma
    'language.settings': 'Configurações de Idioma',
    'language.select': 'Selecionar Idioma',
    'language.changed': 'Idioma alterado com sucesso!',
    'language.update-note': 'As traduções são atualizadas regularmente pela comunidade',
    
    // Settings
    'settings.title': 'Configurações',
    'settings.profile': 'Perfil',
    'settings.notifications': 'Notificações',
    'settings.language': 'Idioma',
    'settings.data': 'Dados',
    'settings.filters': 'Filtros',
    
    // Admin
    'admin.title': 'Painel Admin',
    'admin.users': 'Usuários',
    'admin.stats': 'Estatísticas',
    
    // Bottom Nav (Mobile)
    'bottom-nav.home': 'Home',
    'bottom-nav.workouts': 'Treinos',
    'bottom-nav.progress': 'Progresso',
    'bottom-nav.ia-coach': 'IA Coach',
    'bottom-nav.profile': 'Perfil',
  },
  en: {
    // Navigation
    'nav.main': 'MAIN',
    'nav.intelligence': 'INTELLIGENCE',
    'nav.resources': 'RESOURCES',
    'nav.social': 'SOCIAL',
    'nav.dashboard': 'Dashboard',
    'nav.workouts': 'Workouts',
    'nav.progress': 'Progress',
    'nav.ia-coach': 'AI Coach',
    'nav.nutrition': 'Nutrition',
    'nav.exercises': 'Exercises',
    'nav.community': 'Community',
    'nav.shop': 'Shop',
    'nav.services': 'Services',
    'nav.consultations': 'Consultations',
    'nav.settings': 'Settings',
    'nav.profile': 'Profile',
    'nav.logout': 'Logout',
    'nav.home': 'Home',
    'nav.training': 'Train',
    'nav.more': 'More',
    'nav.coach': 'AI Coach',
    'nav.admin': 'Admin',
    
    // Navigation descriptions
    'nav.dashboard.desc': 'Workout overview',
    'nav.workouts.desc': 'Your daily workouts',
    'nav.progress.desc': 'Track your evolution',
    'nav.ia-coach.desc': 'Intelligent assistant',
    'nav.nutrition.desc': 'Premium nutrition dashboard',
    'nav.exercises.desc': 'Exercise library',
    'nav.shop.desc': 'Products and supplements',
    'nav.community.desc': 'Fitness social network',
    'nav.services.desc': 'Consultations and professionals',
    'nav.consultations.desc': 'Your conversations and appointments',
    'nav.settings.desc': 'System preferences',
    'nav.logout.desc': 'Sign out',
    
    // Greetings
    'greeting.morning': 'Good morning',
    'greeting.afternoon': 'Good afternoon',
    'greeting.evening': 'Good evening',
    
    // Dashboard
    'dashboard.title': 'Dashboard',
    'dashboard.weekly-goal': 'Weekly Goal',
    'dashboard.workouts-completed': 'Workouts Completed',
    'dashboard.start-workout': 'Start Workout',
    'dashboard.today-workout': "Today's Workout",
    'dashboard.consistency': 'Consistency',
    'dashboard.total-workouts': 'Total Workouts',
    'dashboard.current-streak': 'Current Streak',
    'dashboard.your-stats': 'Your Stats',
    'dashboard.level': 'Level',
    'dashboard.xp-total': 'Total XP',
    'dashboard.streak': 'Streak',
    'dashboard.workouts': 'Workouts',
    'dashboard.quick-actions': 'Quick Actions',
    'dashboard.weekly-progress': 'Weekly Progress',
    'dashboard.recent-achievements': 'Recent Achievements',
    'dashboard.completed-of': 'of {goal} workouts completed',
    
    // Quick Actions
    'quick-actions.start-workout': 'Start Workout',
    'quick-actions.start-now': 'Start now',
    'quick-actions.ia-coach': 'AI Coach',
    'quick-actions.create-workout': 'Create workout',
    'quick-actions.nutrition': 'Nutrition',
    'quick-actions.track': 'Track',
    'quick-actions.progress': 'Progress',
    'quick-actions.see-evolution': 'See evolution',
    
    // Workouts
    'workouts.create-new': 'Create New Workout',
    'workouts.my-workouts': 'My Workouts',
    'workouts.templates': 'Templates',
    'workouts.duration': 'Duration',
    'workouts.exercises': 'Exercises',
    'workouts.difficulty': 'Difficulty',
    'workouts.focus': 'Focus',
    'workouts.history': 'Workout History',
    
    // Exercises
    'exercise.sets': 'Sets',
    'exercise.reps': 'Reps',
    'exercise.weight': 'Weight',
    'exercise.rest-time': 'Rest Time',
    'exercise.completed': 'Completed',
    
    // Common Actions
    'common.save': 'Save',
    'common.cancel': 'Cancel',
    'common.delete': 'Delete',
    'common.edit': 'Edit',
    'common.confirm': 'Confirm',
    'common.close': 'Close',
    'common.back': 'Back',
    'common.next': 'Next',
    'common.loading': 'Loading...',
    'common.exercises': 'exercises',
    'common.search': 'Search...',
    
    // Header
    'header.intelligent-workouts': 'Intelligent Workouts',
    'header.settings': 'Settings',
    'header.manage-subscription': 'Manage subscription',
    'header.logout': 'Logout',
    
    // Workouts (expanded)
    'workouts.create-custom': 'Create Custom Workout',
    'workouts.quick-templates': 'Quick Templates',
    'workouts.exercises-count': 'exercises',
    'workouts.tab.overview': 'Overview',
    'workouts.tab.my-workouts': 'My Workouts',
    'workouts.tab.templates': 'Templates',
    'workouts.tab.analytics': 'Analytics',
    'workouts.tab.calendar': 'Calendar',
    'workouts.stats.workouts': 'Workouts',
    'workouts.stats.streak': 'Streak',
    'workouts.stats.level': 'Level',
    'workouts.stats.volume': 'Volume',
    'workouts.stats.days': 'days',
    'workouts.updated': 'Workouts updated!',
    
    // Progress
    'progress.title': 'Your Progress',
    'progress.subtitle': 'Track your evolution with detailed metrics and personalized insights.',
    'progress.level-badge': 'Level',
    'progress.tab.overview': 'Overview',
    'progress.tab.analytics-ai': 'AI Analytics',
    'progress.tab.gamification': 'Gamification',
    'progress.tab.ranking': 'Ranking',
    'progress.tab.achievements': 'Achievements',
    'progress.tab.health': 'Health',
    'progress.stats.workouts': 'Workouts',
    'progress.stats.level': 'Level',
    'progress.stats.streak': 'Streak',
    'progress.stats.weekly': 'Weekly',
    
    // AI Coach
    'coach.title': 'AI Coach',
    'coach.powered-by': 'Powered by AI',
    'coach.chats': 'Chats',
    'coach.saved-conversations': 'Saved Conversations',
    'coach.your-coach': 'Your intelligent personal trainer who knows you. Personalized coach with conversation memory and automatic workout creation!',
    'coach.objective': 'Goal',
    'coach.workouts': 'workouts',
    'coach.days': 'days',
    
    // Nutrition
    'nutrition.title': 'Premium Nutrition',
    'nutrition.subtitle': 'Complete AI-powered nutrition dashboard',
    'nutrition.goals': 'Goals',
    'nutrition.add-meal': 'Add\nMeal',
    'nutrition.scan-food': 'Scan\nFood',
    'nutrition.ai-chat': 'AI Chat',
    'nutrition.daily-plan': 'Daily Plan',
    'nutrition.stats.calories': 'Calories',
    'nutrition.stats.protein': 'Protein',
    'nutrition.stats.hydration': 'Hydration',
    'nutrition.stats.meals': 'Meals',
    'nutrition.tab.dashboard': 'Dashboard',
    'nutrition.tab.scanner': 'Scanner',
    'nutrition.tab.meals': 'Meals',
    'nutrition.tab.ai-coach': 'AI Coach',
    'nutrition.tab.tools': 'Tools',
    
    // Language System
    'language.settings': 'Language Settings',
    'language.select': 'Select Language',
    'language.changed': 'Language changed successfully!',
    'language.update-note': 'Translations are regularly updated by the community',
    
    // Settings
    'settings.title': 'Settings',
    'settings.profile': 'Profile',
    'settings.notifications': 'Notifications',
    'settings.language': 'Language',
    'settings.data': 'Data',
    'settings.filters': 'Filters',
    
    // Admin
    'admin.title': 'Admin Panel',
    'admin.users': 'Users',
    'admin.stats': 'Statistics',
    
    // Bottom Nav (Mobile)
    'bottom-nav.home': 'Home',
    'bottom-nav.workouts': 'Workouts',
    'bottom-nav.progress': 'Progress',
    'bottom-nav.ia-coach': 'AI Coach',
    'bottom-nav.profile': 'Profile',
  },
  es: {
    // Navegación
    'nav.main': 'PRINCIPAL',
    'nav.intelligence': 'INTELIGENCIA',
    'nav.resources': 'RECURSOS',
    'nav.social': 'SOCIAL',
    'nav.dashboard': 'Panel',
    'nav.workouts': 'Entrenamientos',
    'nav.progress': 'Progreso',
    'nav.ia-coach': 'Coach IA',
    'nav.nutrition': 'Nutrición',
    'nav.exercises': 'Ejercicios',
    'nav.community': 'Comunidad',
    'nav.shop': 'Tienda',
    'nav.services': 'Servicios',
    'nav.consultations': 'Consultas',
    'nav.settings': 'Configuración',
    'nav.profile': 'Perfil',
    'nav.logout': 'Salir',
    'nav.home': 'Inicio',
    'nav.training': 'Entrenar',
    'nav.more': 'Más',
    'nav.coach': 'Coach IA',
    'nav.admin': 'Admin',
    
    // Descripciones de navegación
    'nav.dashboard.desc': 'Resumen de entrenamientos',
    'nav.workouts.desc': 'Tus entrenamientos diarios',
    'nav.progress.desc': 'Sigue tu evolución',
    'nav.ia-coach.desc': 'Asistente inteligente',
    'nav.nutrition.desc': 'Panel nutricional premium',
    'nav.exercises.desc': 'Biblioteca de ejercicios',
    'nav.shop.desc': 'Productos y suplementos',
    'nav.community.desc': 'Red social fitness',
    'nav.services.desc': 'Consultoría y profesionales',
    'nav.consultations.desc': 'Tus conversaciones y citas',
    'nav.settings.desc': 'Preferencias del sistema',
    'nav.logout.desc': 'Cerrar sesión',
    
    // Común
    'common.save': 'Guardar',
    'common.cancel': 'Cancelar',
    'common.delete': 'Eliminar',
    'common.edit': 'Editar',
    'common.confirm': 'Confirmar',
    'common.close': 'Cerrar',
    'common.back': 'Volver',
    'common.next': 'Siguiente',
    'common.loading': 'Cargando...',
    'common.exercises': 'ejercicios',
    'common.search': 'Buscar...',
    
    // Sistema de Idioma
    'language.settings': 'Configuración de Idioma',
    'language.select': 'Seleccionar Idioma',
    'language.changed': '¡Idioma cambiado exitosamente!',
    'language.update-note': 'Las traducciones se actualizan regularmente por la comunidad',
    
    // Settings
    'settings.title': 'Configuración',
    'settings.profile': 'Perfil',
    'settings.notifications': 'Notificaciones',
    'settings.language': 'Idioma',
    'settings.data': 'Datos',
    'settings.filters': 'Filtros',
    
    // Admin
    'admin.title': 'Panel Admin',
    'admin.users': 'Usuarios',
    'admin.stats': 'Estadísticas',
  },
  fr: {
    // Navigation
    'nav.main': 'PRINCIPAL',
    'nav.intelligence': 'INTELLIGENCE',
    'nav.resources': 'RESSOURCES',
    'nav.social': 'SOCIAL',
    'nav.dashboard': 'Tableau de Bord',
    'nav.workouts': 'Entraînements',
    'nav.progress': 'Progrès',
    'nav.ia-coach': 'Coach IA',
    'nav.nutrition': 'Nutrition',
    'nav.exercises': 'Exercices',
    'nav.community': 'Communauté',
    'nav.shop': 'Boutique',
    'nav.services': 'Services',
    'nav.consultations': 'Consultations',
    'nav.settings': 'Paramètres',
    'nav.profile': 'Profil',
    'nav.logout': 'Déconnexion',
    'nav.home': 'Accueil',
    'nav.training': 'Entraîner',
    'nav.more': 'Plus',
    'nav.coach': 'Coach IA',
    'nav.admin': 'Admin',
    
    // Descriptions de navigation
    'nav.dashboard.desc': 'Aperçu des entraînements',
    'nav.workouts.desc': 'Vos entraînements quotidiens',
    'nav.progress.desc': 'Suivez votre évolution',
    'nav.ia-coach.desc': 'Assistant intelligent',
    'nav.nutrition.desc': 'Tableau de bord nutrition premium',
    'nav.exercises.desc': 'Bibliothèque d\'exercices',
    'nav.shop.desc': 'Produits et suppléments',
    'nav.community.desc': 'Réseau social fitness',
    'nav.services.desc': 'Consultations et professionnels',
    'nav.consultations.desc': 'Vos conversations et rendez-vous',
    'nav.settings.desc': 'Préférences du système',
    'nav.logout.desc': 'Se déconnecter',
    
    // Commun
    'common.save': 'Enregistrer',
    'common.cancel': 'Annuler',
    'common.delete': 'Supprimer',
    'common.edit': 'Modifier',
    'common.confirm': 'Confirmer',
    'common.close': 'Fermer',
    'common.back': 'Retour',
    'common.next': 'Suivant',
    'common.loading': 'Chargement...',
    'common.exercises': 'exercices',
    'common.search': 'Rechercher...',
    
    // Système de langue
    'language.settings': 'Paramètres de Langue',
    'language.select': 'Sélectionner la Langue',
    'language.changed': 'Langue changée avec succès!',
    'language.update-note': 'Les traductions sont régulièrement mises à jour par la communauté',
    
    // Paramètres
    'settings.title': 'Paramètres',
    'settings.profile': 'Profil',
    'settings.notifications': 'Notifications',
    'settings.language': 'Langue',
    'settings.data': 'Données',
    'settings.filters': 'Filtres',
    
    // Admin
    'admin.title': 'Panneau Admin',
    'admin.users': 'Utilisateurs',
    'admin.stats': 'Statistiques',
  },
  de: {
    // Navigation
    'nav.main': 'HAUPT',
    'nav.intelligence': 'INTELLIGENZ',
    'nav.resources': 'RESSOURCEN',
    'nav.social': 'SOZIAL',
    'nav.dashboard': 'Dashboard',
    'nav.workouts': 'Training',
    'nav.progress': 'Fortschritt',
    'nav.ia-coach': 'KI Coach',
    'nav.nutrition': 'Ernährung',
    'nav.exercises': 'Übungen',
    'nav.community': 'Community',
    'nav.shop': 'Shop',
    'nav.services': 'Dienste',
    'nav.consultations': 'Beratungen',
    'nav.settings': 'Einstellungen',
    'nav.profile': 'Profil',
    'nav.logout': 'Abmelden',
    'nav.home': 'Start',
    'nav.training': 'Trainieren',
    'nav.more': 'Mehr',
    'nav.coach': 'KI Coach',
    'nav.admin': 'Admin',
    
    // Navigationsbeschreibungen
    'nav.dashboard.desc': 'Trainingsübersicht',
    'nav.workouts.desc': 'Ihre täglichen Trainings',
    'nav.progress.desc': 'Verfolgen Sie Ihre Entwicklung',
    'nav.ia-coach.desc': 'Intelligenter Assistent',
    'nav.nutrition.desc': 'Premium Ernährungs-Dashboard',
    'nav.exercises.desc': 'Übungsbibliothek',
    'nav.shop.desc': 'Produkte und Nahrungsergänzungsmittel',
    'nav.community.desc': 'Fitness-Soziales Netzwerk',
    'nav.services.desc': 'Beratungen und Fachleute',
    'nav.consultations.desc': 'Ihre Gespräche und Termine',
    'nav.settings.desc': 'Systemeinstellungen',
    'nav.logout.desc': 'Abmelden',
    
    // Allgemein
    'common.save': 'Speichern',
    'common.cancel': 'Abbrechen',
    'common.delete': 'Löschen',
    'common.edit': 'Bearbeiten',
    'common.confirm': 'Bestätigen',
    'common.close': 'Schließen',
    'common.back': 'Zurück',
    'common.next': 'Weiter',
    'common.loading': 'Lädt...',
    'common.exercises': 'Übungen',
    'common.search': 'Suchen...',
    
    // Sprachsystem
    'language.settings': 'Spracheinstellungen',
    'language.select': 'Sprache Auswählen',
    'language.changed': 'Sprache erfolgreich geändert!',
    'language.update-note': 'Übersetzungen werden regelmäßig von der Community aktualisiert',
    
    // Einstellungen
    'settings.title': 'Einstellungen',
    'settings.profile': 'Profil',
    'settings.notifications': 'Benachrichtigungen',
    'settings.language': 'Sprache',
    'settings.data': 'Daten',
    'settings.filters': 'Filter',
    
    // Admin
    'admin.title': 'Admin-Panel',
    'admin.users': 'Benutzer',
    'admin.stats': 'Statistiken',
  },
  it: {
    // Navigazione
    'nav.main': 'PRINCIPALE',
    'nav.intelligence': 'INTELLIGENZA',
    'nav.resources': 'RISORSE',
    'nav.social': 'SOCIALE',
    'nav.dashboard': 'Dashboard',
    'nav.workouts': 'Allenamenti',
    'nav.progress': 'Progresso',
    'nav.ia-coach': 'Coach IA',
    'nav.nutrition': 'Nutrizione',
    'nav.exercises': 'Esercizi',
    'nav.community': 'Comunità',
    'nav.shop': 'Negozio',
    'nav.services': 'Servizi',
    'nav.consultations': 'Consultazioni',
    'nav.settings': 'Impostazioni',
    'nav.profile': 'Profilo',
    'nav.logout': 'Esci',
    'nav.home': 'Home',
    'nav.training': 'Allena',
    'nav.more': 'Altro',
    'nav.coach': 'Coach IA',
    'nav.admin': 'Admin',
    
    // Descrizioni di navigazione
    'nav.dashboard.desc': 'Panoramica allenamenti',
    'nav.workouts.desc': 'I tuoi allenamenti quotidiani',
    'nav.progress.desc': 'Segui la tua evoluzione',
    'nav.ia-coach.desc': 'Assistente intelligente',
    'nav.nutrition.desc': 'Dashboard nutrizione premium',
    'nav.exercises.desc': 'Biblioteca esercizi',
    'nav.shop.desc': 'Prodotti e integratori',
    'nav.community.desc': 'Social network fitness',
    'nav.services.desc': 'Consulenze e professionisti',
    'nav.consultations.desc': 'Le tue conversazioni e appuntamenti',
    'nav.settings.desc': 'Preferenze di sistema',
    'nav.logout.desc': 'Disconnetti',
    
    // Comune
    'common.save': 'Salva',
    'common.cancel': 'Annulla',
    'common.delete': 'Elimina',
    'common.edit': 'Modifica',
    'common.confirm': 'Conferma',
    'common.close': 'Chiudi',
    'common.back': 'Indietro',
    'common.next': 'Avanti',
    'common.loading': 'Caricamento...',
    'common.exercises': 'esercizi',
    'common.search': 'Cerca...',
    
    // Sistema lingua
    'language.settings': 'Impostazioni Lingua',
    'language.select': 'Seleziona Lingua',
    'language.changed': 'Lingua cambiata con successo!',
    'language.update-note': 'Le traduzioni sono aggiornate regolarmente dalla comunità',
    
    // Impostazioni
    'settings.title': 'Impostazioni',
    'settings.profile': 'Profilo',
    'settings.notifications': 'Notifiche',
    'settings.language': 'Lingua',
    'settings.data': 'Dati',
    'settings.filters': 'Filtri',
    
    // Admin
    'admin.title': 'Pannello Admin',
    'admin.users': 'Utenti',
    'admin.stats': 'Statistiche',
  }
};

const LanguageContext = createContext<LanguageContextType | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [currentLanguage, setCurrentLanguage] = useState<Language>(SUPPORTED_LANGUAGES[0]);

  useEffect(() => {
    // Load saved language
    const savedLanguageCode = localStorage.getItem('app_language') || 'pt';
    const savedLanguage = SUPPORTED_LANGUAGES.find(lang => lang.code === savedLanguageCode);
    if (savedLanguage) {
      setCurrentLanguage(savedLanguage);
    }

    // Listen for storage changes (cross-tab sync)
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'app_language' && e.newValue) {
        const newLanguage = SUPPORTED_LANGUAGES.find(l => l.code === e.newValue);
        if (newLanguage) {
          setCurrentLanguage(newLanguage);
        }
      }
    };
    
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const t = (key: string): string => {
    const keys = key.split('.');
    let value: any = translations[currentLanguage.code];
    
    for (const k of keys) {
      if (value && typeof value === 'object' && k in value) {
        value = value[k];
      } else {
        // Fallback to Portuguese if key not found
        value = translations['pt'][key] || key;
        break;
      }
    }
    
    return typeof value === 'string' ? value : key;
  };

  const changeLanguage = (code: string) => {
    const newLanguage = SUPPORTED_LANGUAGES.find(lang => lang.code === code);
    if (newLanguage) {
      setCurrentLanguage(newLanguage);
      localStorage.setItem('app_language', code);
      // Trigger app re-render
      window.dispatchEvent(new CustomEvent('languageChanged', { detail: code }));
    }
  };

  return (
    <LanguageContext.Provider value={{
      currentLanguage,
      t,
      changeLanguage,
      availableLanguages: SUPPORTED_LANGUAGES
    }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}

export function LanguageSelector() {
  const { currentLanguage, changeLanguage, availableLanguages, t } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);

  const handleLanguageSelect = (language: Language) => {
    changeLanguage(language.code);
    setIsOpen(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          size="sm"
          className="flex items-center gap-2"
        >
          <Globe className="h-4 w-4" />
          <span className="hidden md:inline">{currentLanguage.flag}</span>
          <span className="hidden lg:inline">{currentLanguage.nativeName}</span>
        </Button>
      </DialogTrigger>
      
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            {t('select-language')}
          </DialogTitle>
        </DialogHeader>
        
        <div className="grid gap-3">
          {availableLanguages.map((language) => (
            <Button
              key={language.code}
              variant={currentLanguage.code === language.code ? "default" : "ghost"}
              className="justify-start h-auto p-4"
              onClick={() => handleLanguageSelect(language)}
            >
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center gap-3">
                  <span className="text-xl">{language.flag}</span>
                  <div className="text-left">
                    <div className="font-medium">{language.nativeName}</div>
                    <div className="text-xs text-muted-foreground">{language.name}</div>
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  <Badge 
                    variant="outline" 
                    className="text-xs"
                  >
                    {language.completion}%
                  </Badge>
                  {currentLanguage.code === language.code && (
                    <Check className="h-4 w-4 text-accent" />
                  )}
                </div>
              </div>
            </Button>
          ))}
        </div>
        
        <div className="text-xs text-muted-foreground text-center pt-2">
          {t('language.update-note')}
        </div>
      </DialogContent>
    </Dialog>
  );
}

