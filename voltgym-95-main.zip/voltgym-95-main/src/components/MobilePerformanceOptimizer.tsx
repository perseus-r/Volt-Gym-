import React, { useEffect, useRef } from 'react';
import { useIsMobile } from '@/hooks/use-mobile';

/**
 * MobilePerformanceOptimizer - Lightweight component for mobile optimizations
 * Applies GPU acceleration, touch optimizations, and CSS containment
 */
export const MobilePerformanceOptimizer: React.FC = () => {
  const isMobile = useIsMobile();
  const initialized = useRef(false);

  useEffect(() => {
    if (!isMobile || initialized.current) return;
    initialized.current = true;

    const body = document.body;

    // Faster animations on mobile
    document.documentElement.style.setProperty('--animation-duration', '0.15s');
    
    // Prevent overscroll bounce
    body.style.overscrollBehavior = 'none';
    
    // Optimize touch events
    body.style.touchAction = 'manipulation';

    // Reduce motion for performance if user prefers
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) {
      document.documentElement.style.setProperty('--animation-duration', '0s');
    }

    return () => {
      body.style.overscrollBehavior = '';
      body.style.touchAction = '';
    };
  }, [isMobile]);

  return null;
};

export default MobilePerformanceOptimizer;