import React from 'react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, Copy, GitMerge, X } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export interface DuplicateInfo {
  isDuplicate: boolean;
  existingWorkout?: {
    id: string;
    name: string;
    focus?: string;
    completed_at?: string;
    total_volume?: number;
    exercises?: any[];
  };
  similarity: number;
}

interface DuplicateWorkoutDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  duplicateInfo: DuplicateInfo;
  newWorkoutName: string;
  onSaveAnyway: () => void;
  onMerge: () => void;
  onCancel: () => void;
}

export function DuplicateWorkoutDialog({
  open,
  onOpenChange,
  duplicateInfo,
  newWorkoutName,
  onSaveAnyway,
  onMerge,
  onCancel,
}: DuplicateWorkoutDialogProps) {
  const existing = duplicateInfo.existingWorkout;
  const similarityPercent = Math.round(duplicateInfo.similarity * 100);

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="max-w-md">
        <AlertDialogHeader>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 rounded-full bg-yellow-500/20">
              <AlertTriangle className="w-5 h-5 text-yellow-400" />
            </div>
            <AlertDialogTitle>Treino Similar Detectado</AlertDialogTitle>
          </div>
          <AlertDialogDescription className="space-y-3">
            <p>
              Você já fez um treino parecido hoje com{' '}
              <Badge variant="outline" className="text-yellow-400">
                {similarityPercent}% de similaridade
              </Badge>
            </p>
            
            {existing && (
              <div className="p-3 rounded-lg bg-surface border border-line/20">
                <div className="font-medium text-txt mb-1">
                  {existing.name || existing.focus}
                </div>
                <div className="text-sm text-txt-2 space-y-1">
                  {existing.completed_at && (
                    <div>
                      Feito às {format(new Date(existing.completed_at), 'HH:mm', { locale: ptBR })}
                    </div>
                  )}
                  {existing.total_volume && existing.total_volume > 0 && (
                    <div>Volume: {Math.round(existing.total_volume).toLocaleString()}kg</div>
                  )}
                  {existing.exercises && (
                    <div>{existing.exercises.length} exercícios</div>
                  )}
                </div>
              </div>
            )}

            <p className="text-txt-3">
              O que você gostaria de fazer?
            </p>
          </AlertDialogDescription>
        </AlertDialogHeader>

        <div className="flex flex-col gap-2 mt-4">
          <Button
            variant="outline"
            className="justify-start gap-3 h-auto py-3"
            onClick={() => {
              onSaveAnyway();
              onOpenChange(false);
            }}
          >
            <Copy className="w-4 h-4 text-accent" />
            <div className="text-left">
              <div className="font-medium">Salvar mesmo assim</div>
              <div className="text-xs text-txt-3">Registrar como treino separado</div>
            </div>
          </Button>

          <Button
            variant="outline"
            className="justify-start gap-3 h-auto py-3"
            onClick={() => {
              onMerge();
              onOpenChange(false);
            }}
          >
            <GitMerge className="w-4 h-4 text-green-400" />
            <div className="text-left">
              <div className="font-medium">Mesclar exercícios</div>
              <div className="text-xs text-txt-3">Adicionar ao treino existente</div>
            </div>
          </Button>

          <Button
            variant="ghost"
            className="justify-start gap-3 h-auto py-3 text-txt-3"
            onClick={() => {
              onCancel();
              onOpenChange(false);
            }}
          >
            <X className="w-4 h-4" />
            <div className="text-left">
              <div className="font-medium">Cancelar</div>
              <div className="text-xs">Não salvar este treino</div>
            </div>
          </Button>
        </div>
      </AlertDialogContent>
    </AlertDialog>
  );
}
