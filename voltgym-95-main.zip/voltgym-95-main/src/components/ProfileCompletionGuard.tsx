import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { AlertCircle } from 'lucide-react';
import { PageBuildingTransition } from './transitions/PageBuildingTransition';

interface ProfileCompletionGuardProps {
  children: React.ReactNode;
}

export function ProfileCompletionGuard({ children }: ProfileCompletionGuardProps) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [isProfileComplete, setIsProfileComplete] = useState<boolean | null>(null);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    if (!user) {
      setIsProfileComplete(null);
      return;
    }

    const checkProfileCompletion = async () => {
      try {
        // Verificar se o usuário é Personal Trainer
        const { data: roles } = await supabase
          .from('user_roles')
          .select('role')
          .eq('user_id', user.id);

        const isPT = roles?.some(r => r.role === 'personal_trainer');
        
        // Se for PT, não exigir perfil de atleta
        if (isPT) {
          setIsProfileComplete(true);
          return;
        }

        const { data: profile, error } = await supabase
          .from('profiles')
          .select('sexo, frequencia_treino, age, weight, height, goal, experience_level')
          .eq('user_id', user.id)
          .maybeSingle();

        if (error) {
          console.error('Error checking profile:', error);
          return;
        }

        // Verificar se todos os campos obrigatórios estão preenchidos
        const requiredFields = ['sexo', 'frequencia_treino', 'age', 'weight', 'height', 'goal', 'experience_level'];
        const isComplete = profile && requiredFields.every(field => {
          const value = profile[field as keyof typeof profile];
          return value !== null && value !== undefined && value !== '';
        });

        setIsProfileComplete(!!isComplete);

        // Se perfil incompleto e não está na página de onboarding, mostrar modal
        if (!isComplete && location.pathname !== '/onboarding') {
          setShowModal(true);
        }
      } catch (error) {
        console.error('Error in profile check:', error);
      }
    };

    checkProfileCompletion();
  }, [user, location.pathname]);

  const handleCompleteProfile = () => {
    setShowModal(false);
    navigate('/onboarding');
  };

  // Page building transition while checking profile
  if (isProfileComplete === null) {
    return <PageBuildingTransition />;
  }

  return (
    <>
      {children}
      
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="liquid-glass border-accent/20">
          <DialogHeader>
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 rounded-full bg-accent/20">
                <AlertCircle className="w-6 h-6 text-accent" />
              </div>
              <DialogTitle className="text-txt text-xl">Complete seu perfil</DialogTitle>
            </div>
            <DialogDescription className="text-txt-2">
              Para ter acesso total ao sistema personalizado de treinos e nutrição, você precisa completar algumas informações essenciais do seu perfil.
              <br /><br />
              Essas informações são necessárias para:
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>Cálculos nutricionais personalizados (TMB, TDEE, macros)</li>
                <li>Planejamento de treinos adequado ao seu nível</li>
                <li>IA Coach personalizada com seu nome e objetivos</li>
                <li>Melhores recomendações baseadas no seu perfil</li>
              </ul>
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-3 mt-6">
            <Button 
              variant="outline" 
              onClick={() => setShowModal(false)}
              className="border-line hover:bg-surface"
            >
              Depois
            </Button>
            <Button 
              onClick={handleCompleteProfile}
              className="bg-accent text-accent-ink hover:bg-accent/90"
            >
              Completar agora
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
