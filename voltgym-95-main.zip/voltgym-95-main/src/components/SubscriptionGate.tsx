import { ReactNode } from 'react';
import { useSubscription } from '@/hooks/useSubscription';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Crown, Lock } from 'lucide-react';
import { Link } from 'react-router-dom';

interface SubscriptionGateProps {
  children: ReactNode;
  feature: string;
  requiredPlan?: 'pro' | 'premium';
  fallback?: ReactNode;
}

const SubscriptionGate = ({ 
  children, 
  feature, 
  requiredPlan = 'pro',
  fallback 
}: SubscriptionGateProps) => {
  const { isPro, isPremium, loading } = useSubscription();

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-accent"></div>
      </div>
    );
  }

  // Verificar acesso baseado no plano requerido
  const hasAccess = requiredPlan === 'premium' 
    ? isPremium 
    : (isPro || isPremium);

  if (hasAccess) {
    return <>{children}</>;
  }

  if (fallback) {
    return <>{fallback}</>;
  }

  return (
    <Card className="glass-card p-8 text-center">
      <div className="flex items-center justify-center mb-6">
        <div className="w-16 h-16 rounded-full bg-accent/20 flex items-center justify-center">
          <Lock className="w-8 h-8 text-accent" />
        </div>
      </div>
      
      <h3 className="text-xl font-bold text-txt mb-4">
        {feature} é exclusivo do {requiredPlan === 'premium' ? 'Premium' : 'Pro'}
      </h3>
      
      <p className="text-txt-2 mb-6">
        Desbloqueie este recurso e muito mais com o VOLT {requiredPlan === 'premium' ? 'Premium' : 'Pro'}. 
        {requiredPlan === 'pro' && ' Comece seu trial de 3 dias grátis agora!'}
      </p>
      
      <Link to="/pricing">
        <Button className="volt-button">
          <Crown className="w-5 h-5 mr-2" />
          {requiredPlan === 'pro' ? 'Começar trial grátis' : 'Ver planos'}
        </Button>
      </Link>
    </Card>
  );
};

export default SubscriptionGate;
