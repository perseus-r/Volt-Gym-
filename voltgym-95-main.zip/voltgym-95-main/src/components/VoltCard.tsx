/**
 * VoltCard - Unified Card Component
 * 
 * This is the single source of truth for all card components.
 * VoltCardV2 and the old VoltCard have been deprecated and consolidated here.
 */
import React from 'react';
import { motion, HTMLMotionProps } from 'framer-motion';
import { cn } from '@/lib/utils';
import { AmbientLight } from './effects/AmbientLight';
import { cardVariants } from '@/utils/motion-variants';
import { haptic } from '@/utils/haptics';

export interface VoltCardProps extends Omit<HTMLMotionProps<'div'>, 'children'> {
  children: React.ReactNode;
  depth?: 0 | 1 | 2 | 3 | 4 | 5;
  interactive?: boolean;
  ambient?: boolean | 'accent' | 'purple' | 'blue' | 'green' | 'orange' | 'pink';
  glowIntensity?: 'none' | 'low' | 'medium' | 'high';
  variant?: 'default' | 'premium' | 'glass' | 'frosted' | 'solid' | 'success' | 'warning' | 'danger';
  hover?: boolean;
  glow?: boolean; // Legacy prop - maps to glowIntensity
  loading?: boolean;
  badge?: React.ReactNode;
  onClick?: () => void;
}

export function VoltCard({
  children,
  depth = 1,
  interactive = false,
  ambient = false,
  glowIntensity = 'none',
  variant = 'default',
  hover = false,
  glow = false,
  loading = false,
  badge,
  onClick,
  className,
  ...props
}: VoltCardProps) {
  // Legacy glow prop support
  const effectiveGlowIntensity = glow ? 'low' : glowIntensity;

  const handleClick = () => {
    if (interactive && onClick) {
      haptic.light();
      onClick();
    } else if (onClick) {
      onClick();
    }
  };

  const depthClass = `depth-${depth}`;
  
  const variantClasses = {
    default: '',
    premium: 'bg-black border border-accent/30 shadow-[0_0_40px_rgba(55,160,244,0.3),0_8px_24px_rgba(0,0,0,0.9)]',
    glass: 'bg-black/95 backdrop-blur-sm border border-accent/10 shadow-[0_8px_32px_rgba(0,0,0,0.8),0_0_0_1px_rgba(55,160,244,0.1)]',
    frosted: 'bg-black/90 backdrop-blur-md border border-accent/15',
    solid: 'bg-black border border-line/30',
    success: 'bg-gradient-to-br from-success/10 to-success/5 border-success/20 shadow-success/10',
    warning: 'bg-gradient-to-br from-warning/10 to-warning/5 border-warning/20 shadow-warning/10',
    danger: 'bg-gradient-to-br from-error/10 to-error/5 border-error/20 shadow-error/10',
  };

  const glowClasses = {
    none: '',
    low: 'shadow-[0_0_20px_hsl(var(--accent)/0.1)]',
    medium: 'shadow-[0_0_30px_hsl(var(--accent)/0.2)]',
    high: 'shadow-[0_0_50px_hsl(var(--accent)/0.3)]',
  };

  const getAmbientColor = (): 'accent' | 'purple' | 'blue' | 'green' | 'orange' | 'pink' => {
    if (typeof ambient === 'string') return ambient;
    return 'accent';
  };

  return (
    <motion.div
      className={cn(
        'rounded-custom overflow-hidden relative',
        depthClass,
        variantClasses[variant],
        glowClasses[effectiveGlowIntensity],
        interactive && 'depth-hover-lift cursor-pointer',
        hover && 'depth-hover-lift',
        loading && 'pointer-events-none opacity-60',
        className
      )}
      variants={cardVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      whileHover={
        interactive || hover
          ? {
              scale: 1.02,
              transition: { duration: 0.2, ease: [0.4, 0, 0.2, 1] },
            }
          : undefined
      }
      whileTap={
        interactive
          ? {
              scale: 0.98,
              transition: { duration: 0.1, ease: [0.4, 0, 0.2, 1] },
            }
          : undefined
      }
      onClick={handleClick}
      {...props}
    >
      {/* Loading skeleton overlay */}
      {loading && (
        <div 
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent animate-shimmer" 
          style={{
            backgroundSize: '200% 100%',
            animation: 'shimmer 2s infinite'
          }}
        />
      )}

      {/* Badge */}
      {badge && (
        <div className="absolute top-3 right-3 z-10">
          {badge}
        </div>
      )}

      {/* Ambient light effect */}
      {ambient && (
        <AmbientLight
          color={getAmbientColor()}
          intensity="low"
          size={300}
          position={{ top: '-50%', left: '-20%' }}
          reactive
        />
      )}

      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>

      {/* Interactive ripple overlay */}
      {interactive && (
        <motion.div
          className="absolute inset-0 bg-accent/5 pointer-events-none"
          initial={{ opacity: 0 }}
          whileHover={{ opacity: 1 }}
          transition={{ duration: 0.2 }}
        />
      )}
    </motion.div>
  );
}

// Preset card variants
export function VoltCardPremium({
  children,
  className,
  ...props
}: Omit<VoltCardProps, 'variant' | 'glowIntensity' | 'ambient'>) {
  return (
    <VoltCard
      variant="premium"
      glowIntensity="medium"
      ambient="accent"
      className={className}
      {...props}
    >
      {children}
    </VoltCard>
  );
}

export function VoltCardGlass({
  children,
  className,
  ...props
}: Omit<VoltCardProps, 'variant'>) {
  return (
    <VoltCard variant="glass" className={className} {...props}>
      {children}
    </VoltCard>
  );
}

export function VoltCardInteractive({
  children,
  className,
  onClick,
  ...props
}: Omit<VoltCardProps, 'interactive'>) {
  return (
    <VoltCard
      interactive
      depth={2}
      ambient="accent"
      glowIntensity="low"
      className={className}
      onClick={onClick}
      {...props}
    >
      {children}
    </VoltCard>
  );
}

export function VoltCardWarning({
  children,
  className,
  ...props
}: Omit<VoltCardProps, 'variant'>) {
  return (
    <VoltCard variant="warning" className={className} {...props}>
      {children}
    </VoltCard>
  );
}

export function VoltCardSuccess({
  children,
  className,
  ...props
}: Omit<VoltCardProps, 'variant'>) {
  return (
    <VoltCard variant="success" className={className} {...props}>
      {children}
    </VoltCard>
  );
}

// Legacy exports for backward compatibility
export { VoltCard as VoltCardV2 };
export { VoltCard as VoltCardV3 };
