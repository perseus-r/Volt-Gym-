import React from 'react';
import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PremiumBadgeProps {
  children: React.ReactNode;
  variant?: 'default' | 'success' | 'warning' | 'error' | 'info' | 'premium' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  icon?: LucideIcon;
  pulse?: boolean;
  glow?: boolean;
  className?: string;
  onClick?: () => void;
}

export function PremiumBadge({
  children,
  variant = 'default',
  size = 'md',
  icon: Icon,
  pulse = false,
  glow = false,
  className,
  onClick
}: PremiumBadgeProps) {
  const variantStyles = {
    default: 'bg-surface/80 text-txt-2 border-line',
    success: 'bg-success/10 text-success border-success/30',
    warning: 'bg-warning/10 text-warning border-warning/30',
    error: 'bg-error/10 text-error border-error/30',
    info: 'bg-accent/10 text-accent border-accent/30',
    premium: 'bg-gradient-to-r from-accent to-accent-2 text-accent-ink border-accent/50',
    outline: 'bg-transparent text-txt-2 border-line hover:border-accent/50',
  };

  const sizeStyles = {
    sm: 'px-2 py-1 text-xs gap-1',
    md: 'px-3 py-1.5 text-sm gap-1.5',
    lg: 'px-4 py-2 text-base gap-2',
  };

  const glowStyles = {
    default: '',
    success: 'shadow-lg shadow-success/30',
    warning: 'shadow-lg shadow-warning/30',
    error: 'shadow-lg shadow-error/30',
    info: 'shadow-lg shadow-accent/30',
    premium: 'shadow-xl shadow-accent/50',
    outline: '',
  };

  return (
    <motion.div
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      whileHover={onClick ? { scale: 1.05 } : {}}
      whileTap={onClick ? { scale: 0.95 } : {}}
      onClick={onClick}
      className={cn(
        // Base styles
        'inline-flex items-center justify-center',
        'font-semibold tracking-wide',
        'border rounded-full',
        'backdrop-blur-sm',
        'transition-all duration-200',
        
        // Variant styles
        variantStyles[variant],
        
        // Size styles
        sizeStyles[size],
        
        // Glow effect
        glow && glowStyles[variant],
        
        // Clickable
        onClick && 'cursor-pointer hover:brightness-110',
        
        className
      )}
    >
      {/* Icon */}
      {Icon && (
        <Icon className={cn(
          size === 'sm' && 'w-3 h-3',
          size === 'md' && 'w-4 h-4',
          size === 'lg' && 'w-5 h-5'
        )} />
      )}

      {/* Content */}
      <span>{children}</span>

      {/* Pulse animation */}
      {pulse && (
        <motion.span
          className={cn(
            'absolute inset-0 rounded-full',
            variant === 'success' && 'bg-success/20',
            variant === 'error' && 'bg-error/20',
            variant === 'warning' && 'bg-warning/20',
            variant === 'info' && 'bg-accent/20',
            variant === 'premium' && 'bg-accent/20'
          )}
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.5, 0, 0.5],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: 'easeInOut'
          }}
        />
      )}
    </motion.div>
  );
}
