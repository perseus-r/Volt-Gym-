import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface AmbientGlowProps {
  color?: 'accent' | 'purple' | 'blue' | 'green' | 'orange';
  top?: string;
  left?: string;
  right?: string;
  bottom?: string;
  size?: number;
  delay?: number;
  className?: string;
}

export function AmbientGlow({
  color = 'accent',
  top,
  left,
  right,
  bottom,
  size = 400,
  delay = 0,
  className
}: AmbientGlowProps) {
  const colorMap = {
    accent: 'rgba(55, 160, 244, 0.25)',
    purple: 'rgba(147, 51, 234, 0.2)',
    blue: 'rgba(59, 130, 246, 0.2)',
    green: 'rgba(34, 197, 94, 0.2)',
    orange: 'rgba(251, 146, 60, 0.25)'
  };

  return (
    <motion.div
      className={cn('absolute pointer-events-none', className)}
      style={{
        top,
        left,
        right,
        bottom,
        width: `${size}px`,
        height: `${size}px`,
        background: `radial-gradient(circle at center, ${colorMap[color]}, transparent 70%)`,
        filter: 'blur(80px)'
      }}
      animate={{
        scale: [1, 1.15, 1],
        opacity: [0.5, 0.8, 0.5]
      }}
      transition={{
        duration: 6,
        delay,
        repeat: Infinity,
        ease: 'easeInOut'
      }}
    />
  );
}
