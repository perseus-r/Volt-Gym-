import React from 'react';
import { LazyImage } from './LazyImage';
import { useIsMobile } from '@/hooks/use-mobile';

interface OptimizedImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  mobileSrc?: string;
  className?: string;
}

export const OptimizedImage = React.memo(({ 
  src, 
  mobileSrc, 
  alt, 
  className,
  ...props 
}: OptimizedImageProps) => {
  const isMobile = useIsMobile();
  const imageSrc = isMobile && mobileSrc ? mobileSrc : src;

  return (
    <LazyImage
      src={imageSrc}
      alt={alt}
      className={className}
      {...props}
    />
  );
});

OptimizedImage.displayName = 'OptimizedImage';
