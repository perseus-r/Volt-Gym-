import React from 'react';
import { CheckCircle2, XCircle } from 'lucide-react';

interface InlineValidationProps {
  value: string;
  type: 'email' | 'password' | 'text';
  showValidation?: boolean;
}

export const InlineValidation: React.FC<InlineValidationProps> = ({ 
  value, 
  type, 
  showValidation = true 
}) => {
  if (!showValidation || !value) return null;

  const isValid = () => {
    switch (type) {
      case 'email':
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
      case 'password':
        return value.length >= 6;
      case 'text':
        return value.length >= 2;
      default:
        return false;
    }
  };

  const valid = isValid();

  return (
    <div className="flex items-center gap-1.5 mt-1.5">
      {valid ? (
        <CheckCircle2 className="w-4 h-4 text-green-500" />
      ) : (
        <XCircle className="w-4 h-4 text-red-500" />
      )}
      <span className={`text-xs ${valid ? 'text-green-500' : 'text-red-500'}`}>
        {type === 'email' && (valid ? 'Email válido' : 'Email inválido')}
        {type === 'password' && (valid ? 'Senha aceita' : 'Mínimo 6 caracteres')}
        {type === 'text' && (valid ? 'OK' : 'Muito curto')}
      </span>
    </div>
  );
};
