import { motion } from 'framer-motion';
import { SkeletonPremium, SkeletonText } from '@/components/feedback/SkeletonPremium';

export function AuthSkeleton() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-bg via-surface to-bg flex items-center justify-center p-4">
      <motion.div 
        className="w-full max-w-md"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.4 }}
      >
        {/* Card principal */}
        <div className="backdrop-blur-xl bg-gradient-to-b from-white/10 to-white/5 border border-white/20 rounded-2xl shadow-xl p-8">
          
          {/* Header com logo */}
          <div className="text-center mb-8 space-y-4">
            {/* Logo skeleton */}
            <div className="flex justify-center">
              <SkeletonPremium 
                variant="rectangular" 
                width={80} 
                height={80} 
                className="rounded-2xl"
              />
            </div>
            
            {/* Título */}
            <div className="flex justify-center">
              <SkeletonText width={120} className="h-8" />
            </div>
            
            {/* Subtítulo */}
            <div className="flex justify-center">
              <SkeletonText width={180} className="h-4" />
            </div>
          </div>
          
          {/* Formulário skeleton */}
          <div className="space-y-6">
            {/* Input email */}
            <SkeletonPremium 
              variant="rectangular" 
              height={48} 
              className="w-full"
            />
            
            {/* Input senha */}
            <SkeletonPremium 
              variant="rectangular" 
              height={48} 
              className="w-full"
            />
            
            {/* Botão */}
            <SkeletonPremium 
              variant="rectangular" 
              height={56} 
              className="w-full bg-gradient-to-r from-accent/20 to-accent/10"
            />
          </div>
          
          {/* Card secundário */}
          <div className="mt-8">
            <SkeletonPremium 
              variant="rectangular" 
              height={80} 
              className="w-full"
            />
          </div>
        </div>
      </motion.div>
    </div>
  );
}
