import { motion } from 'framer-motion';
import { 
  Dumbbell, 
  Play, 
  TrendingUp, 
  Lightbulb, 
  Calendar,
  ChevronRight,
  Save,
  Eye
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { hapticLight } from '@/utils/haptics';

type ActionCardType = 'workout' | 'exercise' | 'summary' | 'tip' | 'schedule';

interface ActionCardProps {
  type: ActionCardType;
  title: string;
  description?: string;
  data?: Record<string, any>;
  onAction?: () => void;
  onSecondaryAction?: () => void;
}

export function ActionCard({
  type,
  title,
  description,
  data,
  onAction,
  onSecondaryAction,
}: ActionCardProps) {
  const getConfig = () => {
    switch (type) {
      case 'workout':
        return {
          icon: Dumbbell,
          gradient: 'from-emerald-500/20 to-teal-500/20',
          border: 'border-emerald-500/30',
          iconColor: 'text-emerald-400',
          primaryAction: 'Salvar Treino',
          secondaryAction: 'Ver detalhes',
          primaryIcon: Save,
          secondaryIcon: Eye,
        };
      case 'exercise':
        return {
          icon: Play,
          gradient: 'from-blue-500/20 to-indigo-500/20',
          border: 'border-blue-500/30',
          iconColor: 'text-blue-400',
          primaryAction: 'Ver exercício',
          secondaryAction: null,
          primaryIcon: ChevronRight,
          secondaryIcon: null,
        };
      case 'summary':
        return {
          icon: TrendingUp,
          gradient: 'from-violet-500/20 to-purple-500/20',
          border: 'border-violet-500/30',
          iconColor: 'text-violet-400',
          primaryAction: 'Ver progresso',
          secondaryAction: 'Compartilhar',
          primaryIcon: ChevronRight,
          secondaryIcon: null,
        };
      case 'tip':
        return {
          icon: Lightbulb,
          gradient: 'from-yellow-500/20 to-orange-500/20',
          border: 'border-yellow-500/30',
          iconColor: 'text-yellow-400',
          primaryAction: 'Aplicar',
          secondaryAction: null,
          primaryIcon: ChevronRight,
          secondaryIcon: null,
        };
      case 'schedule':
        return {
          icon: Calendar,
          gradient: 'from-pink-500/20 to-rose-500/20',
          border: 'border-pink-500/30',
          iconColor: 'text-pink-400',
          primaryAction: 'Agendar',
          secondaryAction: null,
          primaryIcon: ChevronRight,
          secondaryIcon: null,
        };
      default:
        return {
          icon: Dumbbell,
          gradient: 'from-primary/20 to-accent/20',
          border: 'border-primary/30',
          iconColor: 'text-primary',
          primaryAction: 'Ver mais',
          secondaryAction: null,
          primaryIcon: ChevronRight,
          secondaryIcon: null,
        };
    }
  };

  const config = getConfig();
  const Icon = config.icon;
  const PrimaryIcon = config.primaryIcon;
  const SecondaryIcon = config.secondaryIcon;

  const handlePrimary = () => {
    hapticLight();
    onAction?.();
  };

  const handleSecondary = () => {
    hapticLight();
    onSecondaryAction?.();
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      className={`relative overflow-hidden rounded-xl border ${config.border} p-4 my-2`}
    >
      {/* Background gradient */}
      <div className={`absolute inset-0 bg-gradient-to-br ${config.gradient}`} />
      
      {/* Glow */}
      <div className={`absolute -top-10 -right-10 w-20 h-20 ${config.gradient.replace('from-', 'bg-').split(' ')[0]} rounded-full blur-2xl opacity-50`} />

      <div className="relative">
        {/* Header */}
        <div className="flex items-start gap-3 mb-3">
          <div className={`w-10 h-10 rounded-xl bg-background/50 flex items-center justify-center ${config.iconColor}`}>
            <Icon className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="font-bold text-sm">{title}</h4>
            {description && (
              <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                {description}
              </p>
            )}
          </div>
        </div>

        {/* Workout preview data */}
        {type === 'workout' && data?.exercises && (
          <div className="mb-3 space-y-1.5">
            {data.exercises.slice(0, 3).map((ex: any, idx: number) => (
              <div 
                key={idx}
                className="flex items-center justify-between text-xs p-2 rounded-lg bg-background/30"
              >
                <span className="font-medium truncate flex-1">{ex.name}</span>
                <span className="text-muted-foreground ml-2">
                  {ex.sets}×{ex.reps}
                </span>
              </div>
            ))}
            {data.exercises.length > 3 && (
              <p className="text-xs text-muted-foreground text-center">
                +{data.exercises.length - 3} exercícios
              </p>
            )}
          </div>
        )}

        {/* Summary stats preview */}
        {type === 'summary' && data && (
          <div className="grid grid-cols-3 gap-2 mb-3">
            {data.stats?.slice(0, 3).map((stat: any, idx: number) => (
              <div 
                key={idx}
                className="text-center p-2 rounded-lg bg-background/30"
              >
                <p className="text-lg font-bold">{stat.value}</p>
                <p className="text-[10px] text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        )}

        {/* Tip content */}
        {type === 'tip' && data?.content && (
          <div className="mb-3 p-3 rounded-lg bg-background/30 text-xs">
            {data.content}
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-2">
          {config.secondaryAction && onSecondaryAction && SecondaryIcon && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleSecondary}
              className="flex-1 h-9 text-xs"
            >
              <SecondaryIcon className="w-3.5 h-3.5 mr-1.5" />
              {config.secondaryAction}
            </Button>
          )}
          <Button
            size="sm"
            onClick={handlePrimary}
            className={`flex-1 h-9 text-xs ${config.iconColor.replace('text-', 'bg-').replace('-400', '-500')} text-white hover:opacity-90`}
          >
            {config.primaryAction}
            {PrimaryIcon && <PrimaryIcon className="w-3.5 h-3.5 ml-1.5" />}
          </Button>
        </div>
      </div>
    </motion.div>
  );
}

// Utility function to detect action card type from AI message
export function detectActionCardType(message: string): ActionCardType | null {
  const lowerMessage = message.toLowerCase();
  
  if (lowerMessage.includes('treino') && (lowerMessage.includes('criar') || lowerMessage.includes('sugestão'))) {
    return 'workout';
  }
  if (lowerMessage.includes('exercício') && lowerMessage.includes('demonstração')) {
    return 'exercise';
  }
  if (lowerMessage.includes('resumo') || lowerMessage.includes('progresso semanal')) {
    return 'summary';
  }
  if (lowerMessage.includes('dica') || lowerMessage.includes('conselho')) {
    return 'tip';
  }
  if (lowerMessage.includes('agendar') || lowerMessage.includes('horário')) {
    return 'schedule';
  }
  
  return null;
}
