import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Share2, Send, Sparkles, Dumbbell, TrendingUp, Lightbulb, Apple, Calendar, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useIsMobile } from '@/hooks/use-mobile';
import { ActionCard, detectActionCardType } from './ActionCard';

interface ChatMessageProps {
  message: string;
  isAI?: boolean;
  timestamp?: string;
}

// Helper to get suggestion icon and color
function getSuggestionStyle(suggestion: string) {
  const lower = suggestion.toLowerCase();
  if (lower.includes('treino') || lower.includes('exercício')) {
    return { icon: Dumbbell, color: 'bg-primary/10 border-primary/30 text-primary' };
  }
  if (lower.includes('progresso') || lower.includes('análise') || lower.includes('evolução')) {
    return { icon: TrendingUp, color: 'bg-blue-500/10 border-blue-500/30 text-blue-500' };
  }
  if (lower.includes('dica') || lower.includes('sugestão') || lower.includes('conselho')) {
    return { icon: Lightbulb, color: 'bg-yellow-500/10 border-yellow-500/30 text-yellow-500' };
  }
  if (lower.includes('nutrição') || lower.includes('dieta') || lower.includes('alimentação')) {
    return { icon: Apple, color: 'bg-green-500/10 border-green-500/30 text-green-500' };
  }
  if (lower.includes('agenda') || lower.includes('horário') || lower.includes('semana')) {
    return { icon: Calendar, color: 'bg-cyan-500/10 border-cyan-500/30 text-cyan-500' };
  }
  return { icon: MessageCircle, color: 'bg-accent/10 border-accent/30 text-accent' };
}

function ImmersiveChatMessage({ 
  message, 
  isAI = false, 
  timestamp 
}: ChatMessageProps) {
  // Detect if message contains action card content
  const actionCardType = isAI ? detectActionCardType(message) : null;
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={`flex gap-3 ${isAI ? 'justify-start' : 'justify-end'}`}
    >
      {isAI && (
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-accent to-accent-2 flex items-center justify-center flex-shrink-0 shadow-lg shadow-accent/20">
          <Sparkles className="w-4 h-4 text-accent-ink" />
        </div>
      )}
      
      <div className={`max-w-[85%] md:max-w-[75%] ${isAI ? '' : ''}`}>
        <div
          className={`
            rounded-2xl px-4 py-3 relative
            ${isAI 
              ? 'bg-surface/60 text-txt border border-border/50' 
              : 'bg-gradient-to-br from-accent to-accent-2 text-accent-ink'
            }
          `}
        >
          <div className="relative z-10">
            {isAI ? (
              <ReactMarkdown 
                remarkPlugins={[remarkGfm]}
                className="text-sm leading-relaxed space-y-2 prose prose-invert prose-sm max-w-none"
                components={{
                  h1: ({node, ...props}) => <h1 className="text-lg font-bold text-txt mb-2" {...props} />,
                  h2: ({node, ...props}) => <h2 className="text-base font-semibold text-txt mb-2" {...props} />,
                  h3: ({node, ...props}) => <h3 className="text-sm font-semibold text-txt mb-1" {...props} />,
                  ul: ({node, ...props}) => <ul className="list-disc pl-4 space-y-1 my-2" {...props} />,
                  ol: ({node, ...props}) => <ol className="list-decimal pl-4 space-y-1 my-2" {...props} />,
                  li: ({node, ...props}) => <li className="text-txt-2" {...props} />,
                  strong: ({node, ...props}) => <strong className="text-txt font-semibold" {...props} />,
                  p: ({node, ...props}) => <p className="text-txt-2 mb-2 last:mb-0" {...props} />,
                  code: ({node, className, ...props}) => {
                    const isInline = !className;
                    return isInline ? (
                      <code className="rounded bg-background/60 px-1.5 py-0.5 text-accent text-xs" {...props} />
                    ) : (
                      <code className="rounded bg-background/60 px-3 py-2 block mt-2 text-xs overflow-x-auto" {...props} />
                    );
                  }
                }}
              >
                {message}
              </ReactMarkdown>
            ) : (
              <p className="text-sm leading-relaxed">{message}</p>
            )}
          </div>
          
          {/* Action Card if detected */}
          {actionCardType && (
            <div className="mt-3">
              <ActionCard
                type={actionCardType}
                title={actionCardType === 'workout' ? 'Treino Sugerido' : 
                       actionCardType === 'tip' ? 'Dica do Coach' :
                       actionCardType === 'summary' ? 'Resumo' : 'Ação'}
                description="Baseado na nossa conversa"
                onAction={() => {}}
              />
            </div>
          )}
        </div>
        
        {timestamp && (
          <p className={`text-[10px] mt-1 ${isAI ? 'text-txt-3' : 'text-txt-3 text-right'}`}>
            {timestamp}
          </p>
        )}
      </div>
      
      {!isAI && (
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary/20 to-primary/10 border border-primary/30 flex items-center justify-center flex-shrink-0">
          <span className="text-primary text-xs font-bold">EU</span>
        </div>
      )}
    </motion.div>
  );
}

interface ImmersiveChatInterfaceProps {
  messages: Array<{
    id: string;
    text: string;
    isAI: boolean;
    timestamp: string;
    hasShareButton?: boolean;
    workoutData?: any;
  }>;
  onSendMessage: (message: string) => void;
  isTyping?: boolean;
  onShareWorkout?: (workoutData: any) => void;
  placeholder?: string;
  suggestions?: string[];
  onSuggestionClick?: (suggestion: string) => void;
  showSuggestions?: boolean;
}

// Hook removed - no more bottom nav

// Hook para detectar altura do teclado via visualViewport (iOS-friendly)
function useKeyboardHeight() {
  const [keyboardHeight, setKeyboardHeight] = useState(0);
  
  useEffect(() => {
    if (typeof window === 'undefined' || !window.visualViewport) return;
    
    const viewport = window.visualViewport;
    
    const handleResize = () => {
      // Fórmula mais estável para iOS
      const height = Math.max(0, window.innerHeight - (viewport.height + viewport.offsetTop));
      setKeyboardHeight(height);
    };
    
    viewport.addEventListener('resize', handleResize);
    viewport.addEventListener('scroll', handleResize);
    handleResize(); // medir inicial
    
    return () => {
      viewport.removeEventListener('resize', handleResize);
      viewport.removeEventListener('scroll', handleResize);
    };
  }, []);
  
  return keyboardHeight;
}

export function ImmersiveChatInterface({ 
  messages, 
  onSendMessage, 
  isTyping = false,
  onShareWorkout,
  placeholder = "Digite sua mensagem...",
  suggestions = [],
  onSuggestionClick,
  showSuggestions = false
}: ImmersiveChatInterfaceProps) {
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const composerRef = useRef<HTMLDivElement>(null);
  const isMobile = useIsMobile();
  const keyboardHeight = useKeyboardHeight();
  const [composerHeight, setComposerHeight] = useState(80);
  
  // Medir altura do composer
  useEffect(() => {
    if (!composerRef.current) return;
    
    const measure = () => {
      if (composerRef.current) {
        setComposerHeight(composerRef.current.getBoundingClientRect().height);
      }
    };
    
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(composerRef.current);
    
    return () => observer.disconnect();
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [inputValue]);

  // Scroll quando teclado abre
  useEffect(() => {
    if (keyboardHeight > 0) {
      setTimeout(scrollToBottom, 100);
    }
  }, [keyboardHeight]);

  const handleSend = () => {
    if (inputValue.trim() && !isTyping) {
      onSendMessage(inputValue.trim());
      setInputValue('');
      if (textareaRef.current) {
        textareaRef.current.style.height = 'auto';
      }
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Padding extra para mensagens (composer é sticky agora, não fixed)
  const messagesPaddingBottom = 16;

  return (
    <div className="flex flex-col h-full w-full bg-background relative min-h-0">
      {/* Messages area - takes all available space */}
      <div 
        className="flex-1 overflow-y-auto min-h-0"
        style={{ paddingBottom: messagesPaddingBottom }}
      >
        {/* Empty state when no messages */}
        {messages.length === 0 && !isTyping && (
          <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
            <p>Digite sua primeira mensagem...</p>
          </div>
        )}
        <div className="max-w-3xl mx-auto px-4 py-6 space-y-4">
          <AnimatePresence mode="popLayout">
            {messages.map((msg) => (
              <div key={msg.id}>
                <ImmersiveChatMessage
                  message={msg.text}
                  isAI={msg.isAI}
                  timestamp={msg.timestamp}
                />
                
                {/* Share workout button */}
                {msg.hasShareButton && msg.workoutData && onShareWorkout && (
                  <motion.div 
                    className="ml-11 mt-2"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                  >
                    <Button 
                      onClick={() => onShareWorkout(msg.workoutData)}
                      className="bg-gradient-to-r from-accent to-accent-2 text-accent-ink hover:opacity-90 shadow-lg"
                      size="sm"
                    >
                      <Share2 className="w-4 h-4 mr-2" />
                      📸 Gerar Template para Story
                    </Button>
                  </motion.div>
                )}
              </div>
            ))}
          </AnimatePresence>
          
          {/* iMessage-style Typing Indicator */}
          {isTyping && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="flex gap-3 justify-start"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-accent to-accent-2 flex items-center justify-center flex-shrink-0 shadow-lg shadow-accent/20">
                <Sparkles className="w-4 h-4 text-accent-ink" />
              </div>
              
              {/* Bolha com 3 pontos pulsantes */}
              <div className="bg-surface/60 border border-border/50 rounded-2xl px-5 py-4">
                <div className="flex items-center gap-1.5">
                  {[0, 1, 2].map((i) => (
                    <motion.div
                      key={i}
                      className="w-2.5 h-2.5 rounded-full bg-accent"
                      animate={{
                        y: [0, -6, 0],
                        opacity: [0.4, 1, 0.4],
                        scale: [0.85, 1.1, 0.85],
                      }}
                      transition={{
                        duration: 0.6,
                        repeat: Infinity,
                        delay: i * 0.15,
                        ease: "easeInOut",
                      }}
                    />
                  ))}
                </div>
              </div>
            </motion.div>
          )}
          
          <div ref={messagesEndRef} className="h-4" />
        </div>
      </div>
      
      {/* Input area - sticky at bottom (more stable on iOS than fixed) */}
      <div 
        ref={composerRef}
        className="border-t-2 border-accent/30 bg-gradient-to-t from-background via-background to-background/95 backdrop-blur-xl shadow-[0_-4px_20px_rgba(0,0,0,0.25)] sticky bottom-0 z-[70]"
        style={{ 
          paddingBottom: 'calc(0.5rem + env(safe-area-inset-bottom, 0px))'
        }}
      >
        {/* Suggestion chips with icons above input */}
        {showSuggestions && suggestions.length > 0 && (
          <div className="px-4 py-2.5 overflow-x-auto scrollbar-hide border-b border-border/30">
            <div className="flex gap-2 whitespace-nowrap">
              {suggestions.map((suggestion, index) => {
                const style = getSuggestionStyle(suggestion);
                const Icon = style.icon;
                return (
                  <motion.button
                    key={index}
                    onClick={() => onSuggestionClick?.(suggestion)}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    whileTap={{ scale: 0.95 }}
                    className={`flex-shrink-0 flex items-center gap-1.5 px-4 py-2 ${style.color} border rounded-full text-xs font-medium transition-colors hover:opacity-80`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {suggestion}
                  </motion.button>
                );
              })}
            </div>
          </div>
        )}
        <div className="max-w-3xl mx-auto px-4 py-1.5">
          <div className="flex gap-3 items-end">
            <div className="flex-1 relative">
              <textarea
                ref={textareaRef}
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder={placeholder}
                rows={1}
                className="w-full bg-card border-2 border-accent/60 ring-1 ring-accent/20 rounded-2xl px-4 py-3 pr-14 text-base text-txt placeholder-txt/60 focus:outline-none focus:border-accent focus:ring-4 focus:ring-accent/30 focus:bg-card transition-all duration-200 resize-none min-h-[52px] max-h-[120px]"
                disabled={isTyping}
              />
              <motion.button
                onClick={handleSend}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="absolute right-2.5 bottom-2 w-10 h-10 bg-accent text-white rounded-xl flex items-center justify-center disabled:opacity-50 transition-all duration-200 shadow-lg shadow-accent/50"
                disabled={!inputValue.trim() || isTyping}
              >
                <Send className="w-5 h-5" />
              </motion.button>
            </div>
          </div>
          
          <p className="text-[10px] text-txt-3 text-center mt-1 opacity-70 hidden sm:block">
            Enter para enviar • Shift+Enter nova linha
          </p>
        </div>
      </div>
    </div>
  );
}
