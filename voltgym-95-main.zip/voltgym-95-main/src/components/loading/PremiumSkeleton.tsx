import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface PremiumSkeletonProps {
  variant?: 'card' | 'text' | 'circle' | 'button' | 'avatar' | 'line' | 'thumbnail';
  width?: string | number;
  height?: string | number;
  count?: number;
  className?: string;
  animate?: boolean;
}

export function PremiumSkeleton({
  variant = 'line',
  width,
  height,
  count = 1,
  className,
  animate = true,
}: PremiumSkeletonProps) {
  const variantStyles = {
    card: 'h-48 w-full rounded-custom',
    text: 'h-4 w-3/4 rounded-md',
    circle: 'h-12 w-12 rounded-full',
    button: 'h-10 w-24 rounded-custom',
    avatar: 'h-16 w-16 rounded-full',
    line: 'h-4 w-full rounded-md',
    thumbnail: 'h-32 w-32 rounded-lg',
  };

  const Skeleton = () => (
    <motion.div
      className={cn(
        'relative overflow-hidden',
        'bg-gradient-to-r from-surface/40 via-surface/60 to-surface/40',
        'border border-line/20',
        variantStyles[variant],
        className
      )}
      style={{
        width: width || undefined,
        height: height || undefined,
      }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      {/* Shimmer effect */}
      {animate && (
        <motion.div
          className="absolute inset-0 -translate-x-full"
          style={{
            background:
              'linear-gradient(90deg, transparent 0%, hsl(var(--accent) / 0.08) 50%, transparent 100%)',
          }}
          animate={{
            translateX: ['100%', '100%'],
          }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            ease: 'linear',
          }}
        />
      )}

      {/* Breathing pulse */}
      {animate && (
        <motion.div
          className="absolute inset-0 bg-accent/5"
          animate={{
            opacity: [0, 0.3, 0],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
      )}
    </motion.div>
  );

  if (count === 1) {
    return <Skeleton />;
  }

  return (
    <div className="space-y-3">
      {Array.from({ length: count }).map((_, index) => (
        <Skeleton key={index} />
      ))}
    </div>
  );
}

// Preset skeleton compositions
export function CardSkeleton() {
  return (
    <div className="depth-1 rounded-custom p-6 space-y-4">
      <div className="flex items-center gap-4">
        <PremiumSkeleton variant="avatar" />
        <div className="flex-1 space-y-2">
          <PremiumSkeleton variant="text" width="60%" />
          <PremiumSkeleton variant="text" width="40%" height={12} />
        </div>
      </div>
      <PremiumSkeleton variant="line" count={3} />
      <div className="flex gap-2">
        <PremiumSkeleton variant="button" />
        <PremiumSkeleton variant="button" />
      </div>
    </div>
  );
}

export function ListSkeleton({ items = 3 }: { items?: number }) {
  return (
    <div className="space-y-4">
      {Array.from({ length: items }).map((_, index) => (
        <motion.div
          key={index}
          className="depth-1 rounded-custom p-4 flex items-center gap-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.05 }}
        >
          <PremiumSkeleton variant="circle" width={48} height={48} />
          <div className="flex-1 space-y-2">
            <PremiumSkeleton variant="text" width="70%" />
            <PremiumSkeleton variant="text" width="50%" height={12} />
          </div>
          <PremiumSkeleton variant="button" width={80} />
        </motion.div>
      ))}
    </div>
  );
}

export function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="space-y-2">
        <PremiumSkeleton variant="text" width="40%" height={32} />
        <PremiumSkeleton variant="text" width="60%" height={16} />
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="depth-1 rounded-custom p-6 space-y-3">
            <PremiumSkeleton variant="text" width="50%" />
            <PremiumSkeleton variant="text" width="30%" height={28} />
          </div>
        ))}
      </div>

      {/* Content Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <CardSkeleton />
        <CardSkeleton />
      </div>
    </div>
  );
}

export function TableSkeleton({ rows = 5 }: { rows?: number }) {
  return (
    <div className="depth-1 rounded-custom overflow-hidden">
      {/* Header */}
      <div className="bg-surface/50 p-4 border-b border-line/20 flex gap-4">
        <PremiumSkeleton variant="text" width={120} />
        <PremiumSkeleton variant="text" width={200} />
        <PremiumSkeleton variant="text" width={100} />
      </div>

      {/* Rows */}
      {Array.from({ length: rows }).map((_, index) => (
        <div
          key={index}
          className="p-4 border-b border-line/10 last:border-0 flex gap-4"
        >
          <PremiumSkeleton variant="circle" width={32} height={32} />
          <PremiumSkeleton variant="text" width={200} />
          <PremiumSkeleton variant="text" width={100} />
          <PremiumSkeleton variant="button" width={80} />
        </div>
      ))}
    </div>
  );
}

export function ProfileSkeleton() {
  return (
    <div className="space-y-6">
      {/* Avatar & Header */}
      <div className="depth-1 rounded-custom p-8 flex flex-col md:flex-row gap-6 items-center md:items-start">
        <PremiumSkeleton variant="avatar" width={120} height={120} />
        <div className="flex-1 space-y-3 w-full">
          <PremiumSkeleton variant="text" width="40%" height={24} />
          <PremiumSkeleton variant="text" width="60%" height={16} />
          <div className="flex gap-2">
            <PremiumSkeleton variant="button" />
            <PremiumSkeleton variant="button" />
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="depth-1 rounded-custom p-4 space-y-2 text-center">
            <PremiumSkeleton variant="text" width="60%" height={20} className="mx-auto" />
            <PremiumSkeleton variant="text" width="40%" height={14} className="mx-auto" />
          </div>
        ))}
      </div>

      {/* Content */}
      <CardSkeleton />
    </div>
  );
}
