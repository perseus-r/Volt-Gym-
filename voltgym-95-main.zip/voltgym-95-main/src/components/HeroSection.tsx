import { Button } from "@/components/ui/button";
import { ArrowRight, Dumbbell, TrendingUp, Users } from "lucide-react";
import { Link } from "react-router-dom";

const HeroSection = () => {
  return (
    <section className="relative section-hero-compact flex items-center justify-center overflow-hidden electric-bg">
      {/* Fitness-focused background effects - hidden on mobile for performance */}
      <div className="absolute inset-0 opacity-10 hidden md:block">
        <div className="absolute top-20 left-20 w-48 h-48 bg-gradient-to-br from-red-500 to-accent rounded-full blur-2xl"></div>
        <div className="absolute bottom-20 right-20 w-64 h-64 bg-gradient-to-br from-accent to-primary rounded-full blur-2xl"></div>
      </div>
      
      {/* Content */}
      <div className="relative z-10 landing-container py-3 sm:py-4 md:py-12">
        <div className="grid lg:grid-cols-2 gap-4 lg:gap-10 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left order-2 lg:order-1">
            {/* Main Headline with Fitness Focus */}
            <div className="mb-3 sm:mb-4 md:mb-6">
              <div className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold tracking-wider mb-2 sm:mb-3">
                <span className="text-red-500">⚡</span><span className="text-white">VOLT</span>
              </div>
              <h1 className="text-base sm:text-lg lg:text-xl text-white/95 font-semibold leading-tight mb-1.5 sm:mb-2">
                Para Atletas e Personal Trainers
                <br />
                <span className="volt-text font-bold">IA que transforma treinos em resultados</span>
              </h1>
              <p className="text-xs sm:text-sm text-white/80 max-w-xl mx-auto lg:mx-0">
                <span className="text-accent font-bold">Atletas:</span> Treinos personalizados por IA.{' '}
                <span className="text-primary font-bold">Personal Trainers:</span> Gerencie até 100 atletas com IA.
              </p>
            </div>
            
            {/* Proof Points - Ultra Compact */}
            <div className="mb-3 sm:mb-4 md:mb-6">
              <div className="grid grid-cols-4 gap-1.5 sm:gap-2 mb-3">
                <div className="hero-stat-compact bg-red-500/15 border border-red-500/20 text-center">
                  <div className="hero-stat-value text-red-400">+47%</div>
                  <div className="hero-stat-label">Força</div>
                </div>
                <div className="hero-stat-compact bg-accent/15 border border-accent/20 text-center">
                  <div className="hero-stat-value text-accent">-65%</div>
                  <div className="hero-stat-label">Tempo</div>
                </div>
                <div className="hero-stat-compact bg-primary/15 border border-primary/20 text-center">
                  <div className="hero-stat-value text-primary">100%</div>
                  <div className="hero-stat-label">Científico</div>
                </div>
                <div className="hero-stat-compact bg-secondary/15 border border-secondary/20 text-center">
                  <div className="hero-stat-value text-secondary">24/7</div>
                  <div className="hero-stat-label">Coach</div>
                </div>
              </div>
              
              {/* Value Proposition Box - Compact */}
              <div className="bg-gradient-to-r from-red-500/15 via-accent/15 to-primary/15 border border-accent/30 rounded-lg sm:rounded-xl p-2.5 sm:p-3">
                <div className="text-center">
                  <div className="flex items-center justify-center gap-1.5 mb-1">
                    <div className="w-1 h-1 sm:w-1.5 sm:h-1.5 bg-red-500 rounded-full animate-pulse"></div>
                    <div className="text-white font-bold text-[10px] sm:text-xs">
                      🔥 ÚLTIMO DIA DA PROMOÇÃO
                    </div>
                    <div className="w-1 h-1 sm:w-1.5 sm:h-1.5 bg-red-500 rounded-full animate-pulse"></div>
                  </div>
                  <div className="volt-text font-bold text-xs sm:text-sm md:text-base mb-0.5">
                    3 DIAS PREMIUM TOTALMENTE GRÁTIS
                  </div>
                  <div className="text-white/80 text-[10px] sm:text-xs">
                    <span className="line-through text-white/50">R$ 297</span> → <span className="font-bold text-accent">R$ 0</span> • Sem cartão
                  </div>
                </div>
              </div>
            </div>
            
            {/* CTAs - Compact */}
            <div className="flex flex-col gap-2 justify-center lg:justify-start mb-3 sm:mb-4 md:mb-6 max-w-xs mx-auto lg:max-w-none lg:mx-0 lg:flex-row">
              <Link to="/auth" className="w-full lg:w-auto">
                <Button 
                  variant="hero" 
                  size="default" 
                  className="w-full text-xs sm:text-sm px-4 py-2.5 font-bold shadow-lg"
                  data-track="cta_hero_primary"
                >
                  🚀 COMEÇAR 3 DIAS GRÁTIS
                  <ArrowRight className="ml-1.5 w-3.5 h-3.5" />
                </Button>
              </Link>
              
              <Link to="/dashboard" className="w-full lg:w-auto">
                <Button 
                  variant="glass" 
                  size="default" 
                  className="w-full text-xs sm:text-sm px-4 py-2.5"
                  data-track="cta_hero_demo"
                >
                  ⚡ Ver demonstração
                </Button>
              </Link>
            </div>
            
            {/* Social Proof - Ultra Compact */}
            <div className="grid grid-cols-3 gap-1.5 sm:gap-2 text-center max-w-xs mx-auto lg:mx-0">
              <div className="bg-surface/80 border border-line/30 p-1.5 sm:p-2 rounded-lg">
                <div className="text-sm sm:text-lg font-bold volt-text">18K+</div>
                <div className="text-[10px] sm:text-xs text-white/80">Atletas</div>
              </div>
              <div className="bg-surface/80 border border-line/30 p-1.5 sm:p-2 rounded-lg">
                <div className="text-sm sm:text-lg font-bold volt-text">4.9⭐</div>
                <div className="text-[10px] sm:text-xs text-white/80">Nota</div>
              </div>
              <div className="bg-surface/80 border border-line/30 p-1.5 sm:p-2 rounded-lg">
                <div className="text-sm sm:text-lg font-bold volt-text">97%</div>
                <div className="text-[10px] sm:text-xs text-white/80">Recomendam</div>
              </div>
            </div>
          </div>
          
          {/* Right Content - Compact Benefit Cards - Hidden on small mobile */}
          <div className="space-y-2 sm:space-y-3 md:space-y-4 order-1 lg:order-2 hidden sm:block">
            {/* AI Personal Trainer */}
            <div className="feature-card-compact border-accent/20 group">
              <div className="flex items-start gap-2 sm:gap-3">
                <div className="p-1.5 sm:p-2 bg-accent/20 rounded-lg flex-shrink-0">
                  <Dumbbell className="w-4 h-4 sm:w-5 sm:h-5 text-accent" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm sm:text-base font-bold text-white mb-0.5 sm:mb-1">
                    🧠 IA Personal Exclusiva
                  </h3>
                  <p className="text-white/80 text-[10px] sm:text-xs leading-relaxed">
                    Aprende SEU corpo e cria treinos que evoluem com você.
                  </p>
                </div>
              </div>
            </div>
            
            {/* Resultados Científicos */}
            <div className="feature-card-compact border-primary/20 group">
              <div className="flex items-start gap-2 sm:gap-3">
                <div className="p-1.5 sm:p-2 bg-primary/20 rounded-lg flex-shrink-0">
                  <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm sm:text-base font-bold text-white mb-0.5 sm:mb-1">
                    📊 Resultados Comprovados
                  </h3>
                  <p className="text-white/80 text-[10px] sm:text-xs leading-relaxed">
                    +47% mais ganhos de força baseado em 18.000+ treinos.
                  </p>
                </div>
              </div>
            </div>
            
            {/* Comunidade Elite */}
            <div className="feature-card-compact border-secondary/20 group">
              <div className="flex items-start gap-2 sm:gap-3">
                <div className="p-1.5 sm:p-2 bg-secondary/20 rounded-lg flex-shrink-0">
                  <Users className="w-4 h-4 sm:w-5 sm:h-5 text-secondary" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm sm:text-base font-bold text-white mb-0.5 sm:mb-1">
                    🏆 Comunidade de Campeões
                  </h3>
                  <p className="text-white/80 text-[10px] sm:text-xs leading-relaxed">
                    18K+ atletas compartilhando conquistas e motivação.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Scroll indicator - hidden on mobile */}
      <div className="absolute bottom-4 md:bottom-8 left-1/2 transform -translate-x-1/2 hidden md:block">
        <div className="w-5 h-8 border-2 border-white/40 rounded-full flex justify-center">
          <div className="w-1 h-2 bg-white/60 rounded-full mt-1.5 animate-bounce" />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
