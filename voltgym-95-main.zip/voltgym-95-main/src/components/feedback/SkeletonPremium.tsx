import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface SkeletonPremiumProps {
  className?: string;
  variant?: 'text' | 'circular' | 'rectangular';
  width?: string | number;
  height?: string | number;
  animate?: boolean;
}

export function SkeletonPremium({
  className,
  variant = 'rectangular',
  width,
  height,
  animate = true,
}: SkeletonPremiumProps) {
  const variantStyles = {
    text: 'rounded-md h-4',
    circular: 'rounded-full',
    rectangular: 'rounded-xl',
  };

  return (
    <motion.div
      className={cn(
        'relative overflow-hidden',
        'bg-gradient-to-r from-surface/50 via-surface/80 to-surface/50',
        variantStyles[variant],
        className
      )}
      style={{
        width,
        height: variant === 'text' ? undefined : height,
      }}
      animate={
        animate
          ? {
              opacity: [0.5, 0.8, 0.5],
            }
          : undefined
      }
      transition={{
        duration: 2,
        repeat: Infinity,
        ease: "easeInOut",
      }}
    >
      {/* Shimmer effect */}
      {animate && (
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent"
          animate={{
            x: ['-100%', '100%'],
          }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
            ease: 'linear',
          }}
          style={{
            backgroundSize: '200% 100%',
          }}
        />
      )}
    </motion.div>
  );
}

// Pre-configured skeleton variants
export function SkeletonText({ className, ...props }: Omit<SkeletonPremiumProps, 'variant'>) {
  return <SkeletonPremium variant="text" className={className} {...props} />;
}

export function SkeletonCircle({ size = 40, className, ...props }: Omit<SkeletonPremiumProps, 'variant'> & { size?: number }) {
  return (
    <SkeletonPremium
      variant="circular"
      width={size}
      height={size}
      className={className}
      {...props}
    />
  );
}

export function SkeletonCard({ className, ...props }: Omit<SkeletonPremiumProps, 'variant'>) {
  return (
    <div className={cn('p-6 space-y-4', className)}>
      <div className="flex items-center gap-4">
        <SkeletonCircle size={48} />
        <div className="flex-1 space-y-2">
          <SkeletonText width="60%" />
          <SkeletonText width="40%" />
        </div>
      </div>
      <SkeletonPremium variant="rectangular" height={120} {...props} />
      <div className="space-y-2">
        <SkeletonText width="100%" />
        <SkeletonText width="80%" />
      </div>
    </div>
  );
}
