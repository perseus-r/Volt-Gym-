import { motion, AnimatePresence } from 'framer-motion';
import { X, Zap, Calendar, Trophy, TrendingUp } from 'lucide-react';
import { VoltCard } from '@/components/VoltCard';
import { VoltButton } from '@/components/VoltButton';
import { useState, useEffect } from 'react';

export function WelcomeGuide() {
  const [show, setShow] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    const hasSeenGuide = localStorage.getItem('volt_seen_welcome_guide');
    if (!hasSeenGuide) {
      setShow(true);
    }
  }, []);

  const steps = [
    {
      icon: Zap,
      title: 'Bem-vindo ao VOLT!',
      description: 'Seu treinador pessoal com IA está pronto para transformar seu corpo em 28 dias.',
      action: 'Começar Tour'
    },
    {
      icon: Calendar,
      title: 'Programa 28 Dias',
      description: 'Seu plano personalizado está ativo. Cada treino foi criado especialmente para você.',
      action: 'Ver Programa'
    },
    {
      icon: Trophy,
      title: 'Sistema de Conquistas',
      description: 'Complete treinos, ganhe XP e suba de nível. Mantenha seu streak ativo!',
      action: 'Ver Conquistas'
    },
    {
      icon: TrendingUp,
      title: 'Pronto para Começar?',
      description: 'Explore o dashboard e inicie seu primeiro treino quando quiser.',
      action: 'Fechar'
    }
  ];

  const handleNext = () => {
    if (currentStep === steps.length - 1) {
      localStorage.setItem('volt_seen_welcome_guide', 'true');
      setShow(false);
    } else {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handleSkip = () => {
    localStorage.setItem('volt_seen_welcome_guide', 'true');
    setShow(false);
  };

  if (!show) return null;

  const step = steps[currentStep];
  const Icon = step.icon;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
        onClick={handleSkip}
      >
        <motion.div
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.9, y: 20 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-lg"
        >
          <VoltCard variant="premium" className="p-8 relative" glow>
            {/* Close button */}
            <button
              onClick={handleSkip}
              className="absolute top-4 right-4 p-2 rounded-xl bg-surface/50 hover:bg-surface transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Icon */}
            <div className="flex justify-center mb-6">
              <div className="p-4 rounded-2xl bg-accent/20 border border-accent/30">
                <Icon className="w-12 h-12 text-accent" />
              </div>
            </div>

            {/* Content */}
            <div className="text-center mb-8">
              <h2 className="text-2xl md:text-3xl font-bold mb-3">
                {step.title}
              </h2>
              <p className="text-txt-2 text-lg">
                {step.description}
              </p>
            </div>

            {/* Progress dots */}
            <div className="flex justify-center gap-2 mb-6">
              {steps.map((_, idx) => (
                <div
                  key={idx}
                  className={`h-2 rounded-full transition-all duration-300 ${
                    idx === currentStep 
                      ? 'w-8 bg-accent' 
                      : 'w-2 bg-surface'
                  }`}
                />
              ))}
            </div>

            {/* Actions */}
            <div className="flex gap-3">
              {currentStep > 0 && (
                <VoltButton
                  variant="outline"
                  onClick={() => setCurrentStep(prev => prev - 1)}
                  className="flex-1"
                >
                  Voltar
                </VoltButton>
              )}
              <VoltButton
                onClick={handleNext}
                className="flex-1"
              >
                {step.action}
              </VoltButton>
            </div>

            {/* Skip link */}
            {currentStep < steps.length - 1 && (
              <button
                onClick={handleSkip}
                className="w-full mt-4 text-sm text-txt-3 hover:text-txt-2 transition-colors"
              >
                Pular tour
              </button>
            )}
          </VoltCard>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}