import { Trophy, Users, ChevronRight, Flame } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { useChallenges } from '@/hooks/useChallenges';

export function ChallengesWidget() {
  const navigate = useNavigate();
  const { activeChallenges, invitations, loading } = useChallenges();

  const pendingCount = invitations.length;
  const activeCount = activeChallenges.length;

  if (loading) {
    return (
      <Card className="liquid-glass animate-pulse">
        <CardContent className="p-4 h-24" />
      </Card>
    );
  }

  return (
    <Card 
      className="liquid-glass cursor-pointer hover:scale-[1.02] transition-transform"
      onClick={() => navigate('/desafios')}
    >
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-yellow-500 to-amber-500 flex items-center justify-center">
              <Trophy className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-txt">Desafios</h3>
              <p className="text-xs text-txt-3">Compete e evolua</p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-txt-3" />
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="flex items-center gap-2 p-2 rounded-lg bg-accent/10">
            <Flame className="w-4 h-4 text-accent" />
            <span className="text-sm text-txt">
              {activeCount} {activeCount === 1 ? 'ativo' : 'ativos'}
            </span>
          </div>
          
          {pendingCount > 0 && (
            <div className="flex items-center gap-2 p-2 rounded-lg bg-warning/10">
              <Users className="w-4 h-4 text-warning" />
              <span className="text-sm text-txt">
                {pendingCount} {pendingCount === 1 ? 'convite' : 'convites'}
              </span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
