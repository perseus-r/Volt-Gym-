import { useState } from 'react';
import { TrendingDown, Target, TrendingUp, Check } from 'lucide-react';
import { VoltCard } from './VoltCard';
import { VoltButton } from './VoltButton';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { motion } from 'framer-motion';
import type { NutritionGoal } from '@/types/nutrition';

interface NutritionGoalSelectorProps {
  currentGoal?: string;
  userId: string;
  onGoalSelected?: (goal: string) => void;
}

const goals: NutritionGoal[] = [
  {
    id: 'cut',
    title: 'Definição (Cut)',
    subtitle: 'Déficit de 15% • Perder gordura',
    multiplier: 0.85
  },
  {
    id: 'maintenance',
    title: 'Manutenção',
    subtitle: 'TDEE exato • Manter peso',
    multiplier: 1.0
  },
  {
    id: 'bulk',
    title: 'Ganho de Massa',
    subtitle: 'Superávit de 12% • Construir músculo',
    multiplier: 1.12
  }
];

const getGoalIcon = (goalId: string) => {
  switch (goalId) {
    case 'cut':
      return TrendingDown;
    case 'maintenance':
      return Target;
    case 'bulk':
      return TrendingUp;
    default:
      return Target;
  }
};

export function NutritionGoalSelector({ 
  currentGoal, 
  userId,
  onGoalSelected 
}: NutritionGoalSelectorProps) {
  const [selectedGoal, setSelectedGoal] = useState<string>(currentGoal || 'maintenance');
  const [isLoading, setIsLoading] = useState(false);

  const handleSaveGoal = async () => {
    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ goal: selectedGoal })
        .eq('user_id', userId);

      if (error) throw error;

      toast.success('Objetivo atualizado com sucesso!');
      onGoalSelected?.(selectedGoal);
    } catch (error) {
      console.error('Error updating goal:', error);
      toast.error('Erro ao atualizar objetivo');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold text-txt">Qual é seu objetivo nutricional?</h2>
        <p className="text-txt-2">
          Escolha seu objetivo para calcularmos suas metas de calorias e macros automaticamente
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {goals.map((goal, index) => {
          const Icon = getGoalIcon(goal.id);
          const isSelected = selectedGoal === goal.id;

          return (
            <motion.div
              key={goal.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <VoltCard
                onClick={() => setSelectedGoal(goal.id)}
                className={`
                  p-6 cursor-pointer transition-all relative
                  ${isSelected 
                    ? 'ring-2 ring-accent shadow-accent/30 bg-accent/5' 
                    : 'hover:border-accent/50'
                  }
                `}
              >
                {isSelected && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute top-4 right-4"
                  >
                    <div className="w-6 h-6 bg-accent rounded-full flex items-center justify-center">
                      <Check className="w-4 h-4 text-background" />
                    </div>
                  </motion.div>
                )}

                <div className="flex flex-col items-center text-center space-y-3">
                  <div className={`
                    w-16 h-16 rounded-full flex items-center justify-center
                    ${goal.id === 'cut' ? 'bg-gradient-to-br from-red-500 to-pink-500' : ''}
                    ${goal.id === 'maintenance' ? 'bg-gradient-to-br from-blue-500 to-cyan-500' : ''}
                    ${goal.id === 'bulk' ? 'bg-gradient-to-br from-green-500 to-emerald-500' : ''}
                  `}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>

                  <div>
                    <h3 className="font-bold text-lg text-txt mb-1">{goal.title}</h3>
                    <p className="text-sm text-txt-2">{goal.subtitle}</p>
                  </div>

                  <div className="pt-2">
                    <span className="text-sm font-medium text-accent">
                      {goal.multiplier === 1 ? '100%' : `${Math.round(goal.multiplier * 100)}%`} TDEE
                    </span>
                  </div>
                </div>
              </VoltCard>
            </motion.div>
          );
        })}
      </div>

      {currentGoal !== selectedGoal && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex justify-center pt-4"
        >
          <VoltButton
            onClick={handleSaveGoal}
            disabled={isLoading}
            className="min-w-[200px]"
          >
            {isLoading ? 'Salvando...' : 'Salvar Objetivo'}
          </VoltButton>
        </motion.div>
      )}

      <div className="mt-8 p-4 bg-surface/30 rounded-xl border border-line/30">
        <h4 className="font-semibold text-txt mb-2">ℹ️ Como funciona?</h4>
        <ul className="text-sm text-txt-2 space-y-1">
          <li>• <strong>Cut:</strong> Déficit calórico para queimar gordura mantendo músculo</li>
          <li>• <strong>Manutenção:</strong> Calorias exatas para manter peso atual</li>
          <li>• <strong>Bulk:</strong> Superávit controlado para ganhar massa muscular magra</li>
        </ul>
      </div>
    </div>
  );
}
