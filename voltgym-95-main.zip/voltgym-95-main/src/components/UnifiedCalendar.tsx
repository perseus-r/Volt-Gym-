import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { CalendarIcon, Dumbbell, Apple, Droplets } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { getWorkoutHistory, HistoryEntry } from '@/lib/storage';
import { unifiedDataService } from '@/services/UnifiedDataService';
import { format, isSameDay, startOfMonth, endOfMonth, eachDayOfInterval } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface UnifiedDayData {
  date: Date;
  workouts: HistoryEntry[];
  nutrition: {
    calories: number;
    protein: number;
  };
  hydration: number;
  hasData: boolean;
}

export function UnifiedCalendar({ className = "" }: { className?: string }) {
  const { user } = useAuth();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [calendarData, setCalendarData] = useState<UnifiedDayData[]>([]);
  const [selectedDay, setSelectedDay] = useState<UnifiedDayData | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [currentMonth, setCurrentMonth] = useState(new Date());

  useEffect(() => {
    if (user) {
      loadCalendarData();
    }
  }, [user, currentMonth]);

  const loadCalendarData = async () => {
    try {
      // Load workout data
      const localHistory = getWorkoutHistory(user?.id || 'demo');
      const supabaseHistory = await unifiedDataService.getWorkoutHistory(100);
      
      const allWorkouts = [...localHistory];
      supabaseHistory.forEach(session => {
        const existsInLocal = localHistory.some(local => 
          Math.abs(new Date(local.ts).getTime() - new Date(session.started_at).getTime()) < 60000
        );
        
        if (!existsInLocal) {
          allWorkouts.push({
            ts: session.started_at || session.completed_at || '',
            user: session.user_id,
            focus: session.focus,
            items: (session.exercises || []).map((ex: any) => ({
              name: ex.name || 'Exercício',
              carga: ex.weight || 0,
              rpe: ex.rpe || 0,
              nota: ex.notes || ''
            }))
          });
        }
      });

      // Group by date
      const dataByDate = new Map<string, UnifiedDayData>();
      
      allWorkouts.forEach(workout => {
        const dateKey = format(new Date(workout.ts), 'yyyy-MM-dd');
        if (!dataByDate.has(dateKey)) {
          dataByDate.set(dateKey, {
            date: new Date(workout.ts),
            workouts: [],
            nutrition: { calories: 0, protein: 0 },
            hydration: 0,
            hasData: false
          });
        }
        const dayData = dataByDate.get(dateKey)!;
        dayData.workouts.push(workout);
        dayData.hasData = true;
      });

      // Load nutrition data (mock for now)
      // TODO: Integrate with nutrition_foods table
      
      // Create calendar data for current month
      const monthStart = startOfMonth(currentMonth);
      const monthEnd = endOfMonth(currentMonth);
      const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

      const unified: UnifiedDayData[] = daysInMonth.map(date => {
        const dateKey = format(date, 'yyyy-MM-dd');
        return dataByDate.get(dateKey) || {
          date,
          workouts: [],
          nutrition: { calories: 0, protein: 0 },
          hydration: 0,
          hasData: false
        };
      });

      setCalendarData(unified);
    } catch (error) {
      console.error('Error loading calendar data:', error);
    }
  };

  const getDayForDate = (date: Date): UnifiedDayData | undefined => {
    return calendarData.find(day => isSameDay(day.date, date));
  };

  const handleDateSelect = (date: Date | undefined) => {
    if (!date) return;
    
    setSelectedDate(date);
    const dayData = getDayForDate(date);
    
    if (dayData && dayData.hasData) {
      setSelectedDay(dayData);
      setIsDetailModalOpen(true);
    }
  };

  const getDayClass = (date: Date) => {
    const day = getDayForDate(date);
    if (!day || !day.hasData) return '';
    
    // Multi-type indicator
    if (day.workouts.length > 0) return 'bg-accent/30 text-accent border border-accent/50';
    return 'bg-green-500/20 text-green-400';
  };

  return (
    <div className={`space-y-4 ${className}`}>
      <Card className="glass-card p-6">
        <div className="flex items-center gap-3 mb-6">
          <CalendarIcon className="w-6 h-6 text-accent" />
          <h2 className="text-xl font-bold text-txt">Calendário Unificado</h2>
          <Badge className="bg-accent/20 text-accent">
            {format(currentMonth, 'MMMM yyyy', { locale: ptBR })}
          </Badge>
        </div>

        <Calendar
          mode="single"
          selected={selectedDate}
          onSelect={handleDateSelect}
          month={currentMonth}
          onMonthChange={setCurrentMonth}
          className="rounded-md border-0"
          modifiers={{
            hasData: calendarData
              .filter(day => day.hasData)
              .map(day => day.date)
          }}
          modifiersClassNames={{
            hasData: "relative after:absolute after:bottom-1 after:left-1/2 after:transform after:-translate-x-1/2 after:flex after:gap-0.5"
          }}
          locale={ptBR}
        />

        <div className="mt-6 p-4 bg-surface/30 rounded-lg">
          <h3 className="text-sm font-semibold text-txt mb-2">Legenda:</h3>
          <div className="flex flex-wrap gap-4 text-xs">
            <div className="flex items-center gap-2">
              <Dumbbell className="w-4 h-4 text-accent" />
              <span className="text-txt-2">Treino</span>
            </div>
            <div className="flex items-center gap-2">
              <Apple className="w-4 h-4 text-green-400" />
              <span className="text-txt-2">Nutrição</span>
            </div>
            <div className="flex items-center gap-2">
              <Droplets className="w-4 h-4 text-blue-400" />
              <span className="text-txt-2">Hidratação</span>
            </div>
          </div>
        </div>
      </Card>

      {/* Day Detail Modal */}
      <Dialog open={isDetailModalOpen} onOpenChange={setIsDetailModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <CalendarIcon className="w-6 h-6 text-accent" />
              {selectedDay && format(selectedDay.date, "d 'de' MMMM, yyyy", { locale: ptBR })}
            </DialogTitle>
          </DialogHeader>

          {selectedDay && (
            <div className="space-y-4">
              {/* Workouts */}
              {selectedDay.workouts.length > 0 && (
                <div>
                  <h3 className="font-semibold text-txt mb-2 flex items-center gap-2">
                    <Dumbbell className="w-4 h-4 text-accent" />
                    Treinos ({selectedDay.workouts.length})
                  </h3>
                  {selectedDay.workouts.map((workout, index) => (
                    <Card key={index} className="p-3 bg-surface/50 mb-2">
                      <div className="font-medium text-txt">{workout.focus}</div>
                      <div className="text-sm text-txt-2">{workout.items.length} exercícios</div>
                    </Card>
                  ))}
                </div>
              )}

              {/* Nutrition */}
              {selectedDay.nutrition.calories > 0 && (
                <div>
                  <h3 className="font-semibold text-txt mb-2 flex items-center gap-2">
                    <Apple className="w-4 h-4 text-green-400" />
                    Nutrição
                  </h3>
                  <Card className="p-3 bg-surface/50">
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <span className="text-txt-2">Calorias:</span>
                        <span className="ml-2 text-txt font-semibold">{selectedDay.nutrition.calories} kcal</span>
                      </div>
                      <div>
                        <span className="text-txt-2">Proteína:</span>
                        <span className="ml-2 text-txt font-semibold">{selectedDay.nutrition.protein}g</span>
                      </div>
                    </div>
                  </Card>
                </div>
              )}

              {/* Hydration */}
              {selectedDay.hydration > 0 && (
                <div>
                  <h3 className="font-semibold text-txt mb-2 flex items-center gap-2">
                    <Droplets className="w-4 h-4 text-blue-400" />
                    Hidratação
                  </h3>
                  <Card className="p-3 bg-surface/50">
                    <div className="text-sm">
                      <span className="text-txt font-semibold">{selectedDay.hydration}ml</span>
                      <span className="ml-2 text-txt-2">consumidos</span>
                    </div>
                  </Card>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
