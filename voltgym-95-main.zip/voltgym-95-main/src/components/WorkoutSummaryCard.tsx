import React from 'react';
import { motion } from 'framer-motion';
import { Dumbbell, Clock, TrendingUp, Zap, Download, Trophy, Target, Award } from 'lucide-react';
import { Button } from '@/components/ui/button';
import html2canvas from 'html2canvas';
import { toast } from 'sonner';

interface WorkoutSummaryCardProps {
  workout: {
    name: string;
    focus: string;
    duration_minutes: number;
    total_volume: number;
    exercises: Array<{
      name: string;
      sets: number;
      reps: number | string;
      weight?: number;
    }>;
    completed_at: string;
  };
  onClose: () => void;
}

export function WorkoutSummaryCard({ workout, onClose }: WorkoutSummaryCardProps) {
  const cardRef = React.useRef<HTMLDivElement>(null);

  const handleExportImage = async () => {
    if (!cardRef.current) return;

    try {
      toast.loading('Gerando imagem...');
      
      const canvas = await html2canvas(cardRef.current, {
        backgroundColor: '#0a0a0a',
        scale: 2,
        logging: false
      });

      // Convert to blob and download
      canvas.toBlob((blob) => {
        if (blob) {
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          link.download = `volt-treino-${Date.now()}.png`;
          link.click();
          URL.revokeObjectURL(url);
          toast.success('Imagem salva! Compartilhe no Instagram 📸');
        }
      });
    } catch (error) {
      console.error('Error generating image:', error);
      toast.error('Erro ao gerar imagem');
    }
  };

  const topExercises = workout.exercises.slice(0, 3);
  const level = Math.floor(workout.total_volume / 1000) + 1;

  return (
    <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="max-w-lg w-full space-y-4">
        {/* Share Card - Strava-inspired */}
        <motion.div
          ref={cardRef}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="relative overflow-hidden rounded-2xl bg-card text-txt"
        >
          {/* Header with gradient accent */}
          <div className="relative h-32 bg-gradient-primary overflow-hidden">
            <div className="absolute inset-0 opacity-20">
              <div className="absolute inset-0" style={{
                backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(255,255,255,.05) 10px, rgba(255,255,255,.05) 20px)'
              }} />
            </div>
            <div className="relative h-full flex items-end p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/90 backdrop-blur rounded-xl flex items-center justify-center">
                  <Zap className="w-6 h-6 text-accent" strokeWidth={2.5} />
                </div>
                <div className="text-white">
                  <div className="text-2xl font-black tracking-tight">VOLT GYM</div>
                  <div className="text-xs font-medium opacity-90">Treino Completo</div>
                </div>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="p-6 bg-white">
            {/* Workout Title */}
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-txt mb-1">{workout.name}</h2>
              <p className="text-txt-2 text-sm font-medium">{workout.focus}</p>
              <p className="text-txt-3 text-xs mt-1">
                {new Date(workout.completed_at).toLocaleDateString('pt-BR', { 
                  weekday: 'long', 
                  day: 'numeric', 
                  month: 'long',
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </p>
            </div>

            {/* Main Stats - Strava style */}
            <div className="grid grid-cols-3 gap-3 mb-6">
              <div className="text-center p-4 bg-gray-50 rounded-xl border border-gray-100">
                <Clock className="w-5 h-5 mx-auto mb-1.5 text-orange-500" strokeWidth={2} />
                <div className="text-2xl font-bold text-gray-900">{workout.duration_minutes}</div>
                <div className="text-xs text-gray-500 font-medium mt-0.5">minutos</div>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-xl border border-gray-100">
                <Dumbbell className="w-5 h-5 mx-auto mb-1.5 text-orange-500" strokeWidth={2} />
                <div className="text-2xl font-bold text-gray-900">{workout.exercises.length}</div>
                <div className="text-xs text-gray-500 font-medium mt-0.5">exercícios</div>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-xl border border-gray-100">
                <TrendingUp className="w-5 h-5 mx-auto mb-1.5 text-orange-500" strokeWidth={2} />
                <div className="text-2xl font-bold text-gray-900">{Math.round(workout.total_volume)}</div>
                <div className="text-xs text-gray-500 font-medium mt-0.5">kg total</div>
              </div>
            </div>

            {/* Exercise List - Strava style */}
            <div className="mb-6">
              <div className="flex items-center gap-2 mb-3">
                <Target className="w-4 h-4 text-gray-700" />
                <h3 className="font-bold text-sm text-gray-900">Exercícios Principais</h3>
              </div>
              <div className="space-y-2">
                {topExercises.map((ex, i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-surface rounded-lg border border-line">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center">
                        <span className="text-sm font-bold text-accent">{i + 1}</span>
                      </div>
                      <span className="font-semibold text-txt text-sm">{ex.name}</span>
                    </div>
                    <span className="text-txt-2 text-sm font-medium">{ex.sets}×{ex.reps} @ {ex.weight}kg</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Achievement Badge */}
            <div className="flex items-center justify-between p-4 rounded-xl border border-line bg-surface mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-accent flex items-center justify-center">
                  <Award className="w-5 h-5 text-accent-ink" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-txt-2">Nível de Treino</div>
                  <div className="text-lg font-bold text-txt">Level {level}</div>
                </div>
              </div>
              <Trophy className="w-8 h-8 text-accent" />
            </div>

            {/* Footer CTA */}
            <div className="text-center pt-4 border-t border-gray-100">
              <p className="text-xs text-gray-500 mb-1">Supere seus limites com</p>
              <p className="text-xl font-black text-gray-900">VOLT GYM</p>
              <p className="text-xs text-gray-400 mt-1">💪 Transforme seu corpo</p>
            </div>
          </div>
        </motion.div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-3">
          <Button
            onClick={handleExportImage}
            className="bg-gradient-to-r from-accent to-primary text-accent-ink font-semibold h-14 shadow-lg"
          >
            <Download className="w-5 h-5 mr-2" />
            Salvar Imagem
          </Button>
          <Button
            onClick={onClose}
            variant="outline"
            className="h-14 border-white/30 text-white hover:bg-white/10 font-semibold"
          >
            Fechar
          </Button>
        </div>

        <p className="text-center text-sm text-white/70">
          Publique nos Stories e marque <span className="font-bold text-accent">@voltgym</span> • #voltgym #workout
        </p>
      </div>
    </div>
  );
}