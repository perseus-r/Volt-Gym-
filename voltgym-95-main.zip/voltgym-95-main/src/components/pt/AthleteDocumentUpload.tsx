import React, { useState, useEffect } from 'react';
import { Upload, File, Trash2, Loader2, FileText, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';

interface AthleteDocumentUploadProps {
  athleteId: string;
  athleteName: string;
}

interface Document {
  id: string;
  file_name: string;
  file_type: string;
  file_url: string;
  created_at: string;
  indexed_at: string | null;
}

export function AthleteDocumentUpload({ athleteId, athleteName }: AthleteDocumentUploadProps) {
  const { user } = useAuth();
  const [documents, setDocuments] = useState<Document[]>([]);
  const [uploading, setUploading] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDocuments();
  }, [athleteId]);

  const loadDocuments = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('athlete_documents')
        .select('*')
        .eq('athlete_user_id', athleteId)
        .eq('coach_user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setDocuments(data || []);
    } catch (error) {
      console.error('Error loading documents:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;

    // Validate file type
    const allowedTypes = [
      'application/pdf',
      'text/csv',
      'text/plain',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    ];

    if (!allowedTypes.includes(file.type)) {
      toast.error('Tipo de arquivo não suportado. Use PDF, CSV, Excel ou texto.');
      return;
    }

    // Max 10MB
    if (file.size > 10 * 1024 * 1024) {
      toast.error('Arquivo muito grande. Máximo 10MB.');
      return;
    }

    setUploading(true);

    try {
      // Upload to storage
      const filePath = `${user.id}/${athleteId}/${Date.now()}_${file.name}`;
      const { error: uploadError } = await supabase.storage
        .from('athlete-checkins')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('athlete-checkins')
        .getPublicUrl(filePath);

      // Extract text from file (simple extraction for text/csv)
      let extractedText = '';
      if (file.type === 'text/plain' || file.type === 'text/csv') {
        extractedText = await file.text();
      }

      // Save to database
      const { data, error: dbError } = await supabase
        .from('athlete_documents')
        .insert({
          athlete_user_id: athleteId,
          coach_user_id: user.id,
          file_name: file.name,
          file_type: file.type,
          file_url: publicUrl,
          file_size: file.size,
          extracted_text: extractedText.substring(0, 50000), // Limit text size
          indexed_at: extractedText ? new Date().toISOString() : null
        })
        .select()
        .single();

      if (dbError) throw dbError;

      setDocuments(prev => [data, ...prev]);
      toast.success('Documento enviado com sucesso!');

    } catch (error: any) {
      console.error('Error uploading document:', error);
      toast.error(error.message || 'Erro ao enviar documento');
    } finally {
      setUploading(false);
      // Reset input
      e.target.value = '';
    }
  };

  const handleDelete = async (doc: Document) => {
    try {
      const { error } = await supabase
        .from('athlete_documents')
        .delete()
        .eq('id', doc.id);

      if (error) throw error;

      setDocuments(prev => prev.filter(d => d.id !== doc.id));
      toast.success('Documento removido');
    } catch (error) {
      console.error('Error deleting document:', error);
      toast.error('Erro ao remover documento');
    }
  };

  const getFileIcon = (type: string) => {
    if (type.includes('pdf')) return '📄';
    if (type.includes('excel') || type.includes('spreadsheet') || type.includes('csv')) return '📊';
    return '📝';
  };

  return (
    <div className="space-y-4">
      {/* Upload button */}
      <label className={cn(
        "flex flex-col items-center justify-center w-full h-24 border-2 border-dashed rounded-xl cursor-pointer transition-colors",
        uploading 
          ? "border-accent/50 bg-accent/5" 
          : "border-border hover:border-accent/50 hover:bg-secondary/30"
      )}>
        <div className="flex flex-col items-center justify-center pt-2 pb-2">
          {uploading ? (
            <>
              <Loader2 className="w-6 h-6 mb-1 text-accent animate-spin" />
              <p className="text-xs text-muted-foreground">Enviando...</p>
            </>
          ) : (
            <>
              <Upload className="w-6 h-6 mb-1 text-muted-foreground" />
              <p className="text-xs text-muted-foreground text-center px-2">
                PDF, Excel, CSV ou texto
              </p>
            </>
          )}
        </div>
        <input 
          type="file" 
          className="hidden" 
          onChange={handleUpload}
          accept=".pdf,.csv,.xlsx,.xls,.txt"
          disabled={uploading}
        />
      </label>

      {/* Documents list */}
      {loading ? (
        <div className="flex items-center justify-center py-4">
          <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
        </div>
      ) : documents.length > 0 ? (
        <div className="space-y-2">
          {documents.map(doc => (
            <div 
              key={doc.id}
              className="flex items-center gap-2 p-2 rounded-lg bg-secondary/30 border border-border/50"
            >
              <span className="text-lg">{getFileIcon(doc.file_type)}</span>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium truncate text-foreground">{doc.file_name}</p>
                <div className="flex items-center gap-1">
                  {doc.indexed_at ? (
                    <span className="text-[10px] text-success flex items-center gap-0.5">
                      <CheckCircle className="w-2.5 h-2.5" />
                      Indexado
                    </span>
                  ) : (
                    <span className="text-[10px] text-muted-foreground">Pendente</span>
                  )}
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 text-destructive hover:text-destructive"
                onClick={() => handleDelete(doc)}
              >
                <Trash2 className="w-3 h-3" />
              </Button>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-xs text-muted-foreground text-center py-2">
          Nenhum documento enviado para {athleteName}
        </p>
      )}
    </div>
  );
}
