import { useState } from 'react';
import { MobileCardAllBlack } from '@/components/mobile/MobileComponentsPremium';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Camera, Upload } from 'lucide-react';
import { useAthleteCheckins } from '@/hooks/useAthleteCheckins';

interface CheckinFormProps {
  athleteUserId: string;
  coachUserId: string;
  onComplete: () => void;
}

export function CheckinForm({ athleteUserId, coachUserId, onComplete }: CheckinFormProps) {
  const { createCheckin, uploadPhoto } = useAthleteCheckins(athleteUserId, coachUserId);
  const [submitting, setSubmitting] = useState(false);
  const [photos, setPhotos] = useState<File[]>([]);
  const [formData, setFormData] = useState({
    weight_kg: '',
    body_fat_percentage: '',
    chest: '',
    waist: '',
    arms: '',
    thighs: '',
    subjective_feedback: ''
  });

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setPhotos(Array.from(e.target.files).slice(0, 4)); // Max 4 photos
    }
  };

  const handleSubmit = async () => {
    setSubmitting(true);
    try {
      const photoUrls: string[] = [];
      
      // Upload photos
      for (const photo of photos) {
        const url = await uploadPhoto(athleteUserId, coachUserId, photo);
        photoUrls.push(url);
      }

      // Create checkin
      await createCheckin({
        weight_kg: formData.weight_kg ? parseFloat(formData.weight_kg) : null,
        body_fat_percentage: formData.body_fat_percentage ? parseFloat(formData.body_fat_percentage) : null,
        measurements: {
          chest: parseFloat(formData.chest) || 0,
          waist: parseFloat(formData.waist) || 0,
          arms: parseFloat(formData.arms) || 0,
          thighs: parseFloat(formData.thighs) || 0
        },
        progress_photos: photoUrls,
        subjective_feedback: formData.subjective_feedback
      });

      onComplete();
    } catch (error) {
      console.error('Error submitting checkin:', error);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <MobileCardAllBlack variant="elevated" className="p-6">
      <h3 className="text-lg font-bold mb-6">Novo Check-in</h3>
      
      <div className="space-y-6">
        {/* Weight & Body Fat */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="weight">Peso (kg)</Label>
            <Input
              id="weight"
              type="number"
              step="0.1"
              value={formData.weight_kg}
              onChange={(e) => setFormData({ ...formData, weight_kg: e.target.value })}
              placeholder="70.5"
            />
          </div>
          <div>
            <Label htmlFor="bodyfat">% Gordura</Label>
            <Input
              id="bodyfat"
              type="number"
              step="0.1"
              value={formData.body_fat_percentage}
              onChange={(e) => setFormData({ ...formData, body_fat_percentage: e.target.value })}
              placeholder="15.0"
            />
          </div>
        </div>

        {/* Measurements */}
        <div>
          <h4 className="font-medium mb-3">Medidas (cm)</h4>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="chest">Peito</Label>
              <Input
                id="chest"
                type="number"
                step="0.5"
                value={formData.chest}
                onChange={(e) => setFormData({ ...formData, chest: e.target.value })}
                placeholder="100"
              />
            </div>
            <div>
              <Label htmlFor="waist">Cintura</Label>
              <Input
                id="waist"
                type="number"
                step="0.5"
                value={formData.waist}
                onChange={(e) => setFormData({ ...formData, waist: e.target.value })}
                placeholder="80"
              />
            </div>
            <div>
              <Label htmlFor="arms">Braços</Label>
              <Input
                id="arms"
                type="number"
                step="0.5"
                value={formData.arms}
                onChange={(e) => setFormData({ ...formData, arms: e.target.value })}
                placeholder="38"
              />
            </div>
            <div>
              <Label htmlFor="thighs">Coxas</Label>
              <Input
                id="thighs"
                type="number"
                step="0.5"
                value={formData.thighs}
                onChange={(e) => setFormData({ ...formData, thighs: e.target.value })}
                placeholder="60"
              />
            </div>
          </div>
        </div>

        {/* Photos */}
        <div>
          <Label htmlFor="photos" className="mb-2 block">
            Fotos de Progresso (máx. 4)
          </Label>
          <div className="flex items-center gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => document.getElementById('photos')?.click()}
              className="flex-1"
            >
              <Camera className="w-4 h-4 mr-2" />
              {photos.length > 0 ? `${photos.length} foto(s) selecionada(s)` : 'Adicionar Fotos'}
            </Button>
            <input
              id="photos"
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={handlePhotoChange}
            />
          </div>
        </div>

        {/* Feedback */}
        <div>
          <Label htmlFor="feedback">Como você está se sentindo?</Label>
          <Textarea
            id="feedback"
            value={formData.subjective_feedback}
            onChange={(e) => setFormData({ ...formData, subjective_feedback: e.target.value })}
            placeholder="Descreva como está sua energia, motivação, qualidade do sono..."
            rows={4}
          />
        </div>

        <Button
          onClick={handleSubmit}
          disabled={submitting || !formData.weight_kg}
          className="w-full"
        >
          {submitting ? 'Enviando...' : 'Enviar Check-in'}
        </Button>
      </div>
    </MobileCardAllBlack>
  );
}
