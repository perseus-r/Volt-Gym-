import { useEffect, useState } from 'react';
import { MobileCardAllBlack } from '@/components/mobile/MobileComponentsPremium';
import { ProgressionAnalyticsService } from '@/services/ProgressionAnalyticsService';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { TrendingUp, Activity } from 'lucide-react';

interface PTProgressionChartsProps {
  athleteUserId: string;
}

export function PTProgressionCharts({ athleteUserId }: PTProgressionChartsProps) {
  const [weeklyData, setWeeklyData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [athleteUserId]);

  const loadData = async () => {
    setLoading(true);
    try {
      const data = await ProgressionAnalyticsService.getWeeklyProgression(athleteUserId, 12);
      setWeeklyData(data);
    } catch (error) {
      console.error('Error loading progression data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-accent"></div>
      </div>
    );
  }

  const totalVolume = weeklyData.reduce((sum, w) => sum + w.totalVolume, 0);
  const avgRpe = weeklyData.length > 0 
    ? (weeklyData.reduce((sum, w) => sum + w.avgRpe, 0) / weeklyData.length).toFixed(1)
    : 0;

  return (
    <div className="space-y-4">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <MobileCardAllBlack variant="elevated" className="p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-accent" />
            </div>
            <div>
              <p className="text-txt-3 text-sm">Volume Total (12 semanas)</p>
              <p className="text-2xl font-bold">{totalVolume.toLocaleString()} kg</p>
            </div>
          </div>
        </MobileCardAllBlack>

        <MobileCardAllBlack variant="elevated" className="p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-warning/20 flex items-center justify-center">
              <Activity className="w-5 h-5 text-warning" />
            </div>
            <div>
              <p className="text-txt-3 text-sm">RPE Médio</p>
              <p className="text-2xl font-bold">{avgRpe}</p>
            </div>
          </div>
        </MobileCardAllBlack>
      </div>

      {/* Volume Chart */}
      <MobileCardAllBlack variant="elevated" className="p-6">
        <h3 className="text-lg font-bold mb-4">Evolução de Volume Semanal</h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={weeklyData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis 
              dataKey="week" 
              stroke="hsl(var(--txt-3))"
              tick={{ fill: 'hsl(var(--txt-3))' }}
            />
            <YAxis 
              stroke="hsl(var(--txt-3))"
              tick={{ fill: 'hsl(var(--txt-3))' }}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'hsl(var(--background))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '8px'
              }}
            />
            <Legend />
            <Line 
              type="monotone" 
              dataKey="totalVolume" 
              stroke="hsl(var(--accent))" 
              strokeWidth={2}
              name="Volume (kg)"
              dot={{ fill: 'hsl(var(--accent))' }}
            />
          </LineChart>
        </ResponsiveContainer>
      </MobileCardAllBlack>

      {/* RPE Chart */}
      <MobileCardAllBlack variant="elevated" className="p-6">
        <h3 className="text-lg font-bold mb-4">RPE Médio por Semana</h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={weeklyData}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis 
              dataKey="week" 
              stroke="hsl(var(--txt-3))"
              tick={{ fill: 'hsl(var(--txt-3))' }}
            />
            <YAxis 
              domain={[0, 10]}
              stroke="hsl(var(--txt-3))"
              tick={{ fill: 'hsl(var(--txt-3))' }}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'hsl(var(--background))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '8px'
              }}
            />
            <Legend />
            <Line 
              type="monotone" 
              dataKey="avgRpe" 
              stroke="hsl(var(--warning))" 
              strokeWidth={2}
              name="RPE Médio"
              dot={{ fill: 'hsl(var(--warning))' }}
            />
          </LineChart>
        </ResponsiveContainer>
      </MobileCardAllBlack>
    </div>
  );
}
