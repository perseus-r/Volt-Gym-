import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Badge } from '@/components/ui/badge';
import { format, isSameDay, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Calendar as CalendarIcon, Plus } from 'lucide-react';
import { AssignedWorkout } from '@/hooks/useAssignedWorkouts';
import { cn } from '@/lib/utils';

interface PTAthleteCalendarProps {
  workouts: AssignedWorkout[];
  onAssignClick: () => void;
  onWorkoutClick: (workout: AssignedWorkout) => void;
}

export function PTAthleteCalendar({ workouts, onAssignClick, onWorkoutClick }: PTAthleteCalendarProps) {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());

  const getWorkoutsForDate = (date: Date) => {
    return workouts.filter(w => {
      if (!w.scheduled_date) return false;
      return isSameDay(parseISO(w.scheduled_date), date);
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-500/20 text-green-600 border-green-500/30';
      case 'pending':
        return 'bg-yellow-500/20 text-yellow-600 border-yellow-500/30';
      case 'skipped':
        return 'bg-red-500/20 text-red-600 border-red-500/30';
      default:
        return 'bg-muted';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Completo';
      case 'pending':
        return 'Pendente';
      case 'skipped':
        return 'Não Realizado';
      default:
        return status;
    }
  };

  const selectedDateWorkouts = selectedDate ? getWorkoutsForDate(selectedDate) : [];

  const modifiers = {
    hasWorkout: (date: Date) => {
      return workouts.some(w => {
        if (!w.scheduled_date) return false;
        return isSameDay(parseISO(w.scheduled_date), date);
      });
    },
    completed: (date: Date) => {
      return workouts.some(w => {
        if (!w.scheduled_date) return false;
        return isSameDay(parseISO(w.scheduled_date), date) && w.status === 'completed';
      });
    },
    pending: (date: Date) => {
      return workouts.some(w => {
        if (!w.scheduled_date) return false;
        return isSameDay(parseISO(w.scheduled_date), date) && w.status === 'pending';
      });
    },
  };

  const modifiersStyles = {
    completed: { backgroundColor: 'hsl(var(--success) / 0.2)' },
    pending: { backgroundColor: 'hsl(var(--warning) / 0.2)' },
    hasWorkout: { fontWeight: 'bold' },
  };

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <CalendarIcon className="h-5 w-5" />
              Calendário de Treinos
            </CardTitle>
            <Button size="sm" onClick={onAssignClick}>
              <Plus className="h-4 w-4 mr-2" />
              Atribuir
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Calendar
            mode="single"
            selected={selectedDate}
            onSelect={setSelectedDate}
            locale={ptBR}
            modifiers={modifiers}
            modifiersStyles={modifiersStyles}
            className="rounded-md border"
          />
          
          <div className="mt-4 flex flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-full bg-green-500/20 border border-green-500/30" />
              <span className="text-sm text-muted-foreground">Completo</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-full bg-yellow-500/20 border border-yellow-500/30" />
              <span className="text-sm text-muted-foreground">Pendente</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>
            {selectedDate ? format(selectedDate, "d 'de' MMMM", { locale: ptBR }) : 'Selecione uma data'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {selectedDateWorkouts.length === 0 ? (
            <p className="text-muted-foreground text-sm">Nenhum treino programado para este dia</p>
          ) : (
            <div className="space-y-3">
              {selectedDateWorkouts.map((workout) => (
                <button
                  key={workout.id}
                  onClick={() => onWorkoutClick(workout)}
                  className="w-full text-left p-3 rounded-lg border bg-card hover:bg-accent transition-colors"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <div className="font-medium">Treino Atribuído</div>
                      {workout.pt_notes && (
                        <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                          {workout.pt_notes}
                        </p>
                      )}
                    </div>
                    <Badge className={cn('shrink-0', getStatusColor(workout.status))}>
                      {getStatusLabel(workout.status)}
                    </Badge>
                  </div>
                </button>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
