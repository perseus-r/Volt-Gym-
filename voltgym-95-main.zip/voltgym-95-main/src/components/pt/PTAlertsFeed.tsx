import { AlertTriangle, AlertCircle, Info, ChevronRight } from 'lucide-react';
import { usePTAlerts } from '@/hooks/usePTAlerts';
import { MobileCardAllBlack } from '@/components/mobile/MobileComponentsPremium';
import { useNavigate } from 'react-router-dom';

interface PTAlertsFeedProps {
  coachUserId: string;
}

export function PTAlertsFeed({ coachUserId }: PTAlertsFeedProps) {
  const { alerts, loading } = usePTAlerts(coachUserId);
  const navigate = useNavigate();

  const getAlertIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <AlertTriangle className="w-5 h-5 text-red-500" />;
      case 'warning':
        return <AlertCircle className="w-5 h-5 text-yellow-500" />;
      default:
        return <Info className="w-5 h-5 text-blue-500" />;
    }
  };

  const getAlertBgColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'bg-red-500/10 border-red-500/20 hover:border-red-500/40';
      case 'warning':
        return 'bg-yellow-500/10 border-yellow-500/20 hover:border-yellow-500/40';
      default:
        return 'bg-blue-500/10 border-blue-500/20 hover:border-blue-500/40';
    }
  };

  const getAlertLabel = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'Crítico';
      case 'warning':
        return 'Atenção';
      default:
        return 'Info';
    }
  };

  if (loading) {
    return (
      <MobileCardAllBlack variant="elevated" className="p-6">
        <h3 className="text-lg font-bold mb-4">Alertas Inteligentes</h3>
        <div className="text-center py-4">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-accent mx-auto"></div>
        </div>
      </MobileCardAllBlack>
    );
  }

  const criticalCount = alerts.filter(a => a.severity === 'critical').length;
  const warningCount = alerts.filter(a => a.severity === 'warning').length;

  return (
    <MobileCardAllBlack variant="elevated" className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold">Alertas Inteligentes</h3>
        {alerts.length > 0 && (
          <div className="flex items-center gap-2">
            {criticalCount > 0 && (
              <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                {criticalCount}
              </span>
            )}
            {warningCount > 0 && (
              <span className="bg-yellow-500 text-black text-xs font-bold px-2 py-1 rounded-full">
                {warningCount}
              </span>
            )}
          </div>
        )}
      </div>

      {alerts.length === 0 ? (
        <div className="text-center py-6">
          <Info className="w-12 h-12 text-green-500 mx-auto mb-2 opacity-50" />
          <p className="text-txt-3 text-sm">Tudo certo! Nenhum alerta no momento.</p>
        </div>
      ) : (
        <div className="space-y-3 max-h-96 overflow-y-auto">
          {alerts.slice(0, 10).map((alert) => (
            <div
              key={alert.id}
              className={`p-4 rounded-lg border transition-all cursor-pointer group ${getAlertBgColor(alert.severity)}`}
              onClick={() => navigate(`/pt/athletes/${alert.athlete_id}`)}
            >
              <div className="flex items-start gap-3">
                <div className="mt-0.5">
                  {getAlertIcon(alert.severity)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <p className="font-bold text-sm group-hover:text-accent transition-colors">
                      {alert.athlete_name}
                    </p>
                    <span className="text-xs text-txt-3 px-2 py-0.5 bg-surface rounded-full">
                      {getAlertLabel(alert.severity)}
                    </span>
                  </div>
                  <p className="text-sm text-txt-2">{alert.message}</p>
                  
                  {alert.type === 'low_adherence' && (
                    <p className="text-xs text-txt-3 mt-2">
                      💡 Considere entrar em contato ou ajustar o plano de treinos
                    </p>
                  )}
                  {alert.type === 'inactive' && (
                    <p className="text-xs text-txt-3 mt-2">
                      💡 Envie uma mensagem motivacional ou ajuste as metas
                    </p>
                  )}
                  {alert.type === 'abandoned_workout' && (
                    <p className="text-xs text-txt-3 mt-2">
                      💡 Verifique se houve algum problema ou dificuldade
                    </p>
                  )}
                </div>
                <ChevronRight className="w-5 h-5 text-txt-3 group-hover:text-accent transition-colors" />
              </div>
            </div>
          ))}
        </div>
      )}

      {alerts.length > 10 && (
        <div className="mt-4 pt-4 border-t border-line/30 text-center">
          <p className="text-xs text-txt-3">
            Mostrando 10 de {alerts.length} alertas
          </p>
        </div>
      )}
    </MobileCardAllBlack>
  );
}
