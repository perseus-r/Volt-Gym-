import React from 'react';
import { useAthletes, Athlete } from '@/hooks/useAthletes';
import { Loader2, User, CheckCircle2 } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

interface PTAthleteSelectorProps {
  selectedAthlete: Athlete | null;
  onSelectAthlete: (athlete: Athlete | null) => void;
}

export function PTAthleteSelector({ selectedAthlete, onSelectAthlete }: PTAthleteSelectorProps) {
  const { athletes, loading } = useAthletes();

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="w-6 h-6 animate-spin text-accent" />
      </div>
    );
  }

  if (athletes.length === 0) {
    return (
      <div className="text-center py-8">
        <User className="w-10 h-10 text-muted-foreground/50 mx-auto mb-2" />
        <p className="text-sm text-muted-foreground">Nenhum atleta vinculado</p>
        <p className="text-xs text-muted-foreground mt-1">
          Convide atletas para começar
        </p>
      </div>
    );
  }

  return (
    <ScrollArea className="h-[400px] pr-2">
      <div className="space-y-2">
        {athletes.map((athlete) => (
          <button
            key={athlete.id}
            onClick={() => onSelectAthlete(selectedAthlete?.id === athlete.id ? null : athlete)}
            className={cn(
              "w-full p-3 rounded-xl flex items-center gap-3 transition-all",
              "border border-border/50 hover:border-accent/50",
              selectedAthlete?.id === athlete.id 
                ? "bg-accent/10 border-accent" 
                : "bg-secondary/30 hover:bg-secondary/50"
            )}
          >
            {/* Avatar */}
            <div className={cn(
              "w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold shrink-0",
              selectedAthlete?.id === athlete.id
                ? "bg-accent text-accent-foreground"
                : "bg-muted text-muted-foreground"
            )}>
              {athlete.avatar_url ? (
                <img 
                  src={athlete.avatar_url} 
                  alt={athlete.display_name || 'Atleta'} 
                  className="w-full h-full rounded-full object-cover"
                />
              ) : (
                athlete.display_name?.[0]?.toUpperCase() || 'A'
              )}
            </div>

            {/* Info */}
            <div className="flex-1 text-left min-w-0">
              <p className={cn(
                "font-medium text-sm truncate",
                selectedAthlete?.id === athlete.id ? "text-accent" : "text-foreground"
              )}>
                {athlete.display_name || 'Atleta'}
              </p>
              <p className="text-xs text-muted-foreground truncate">
                {athlete.total_workouts_completed} treinos • {Math.round(athlete.adherence_rate)}% aderência
              </p>
            </div>

            {/* Check */}
            {selectedAthlete?.id === athlete.id && (
              <CheckCircle2 className="w-5 h-5 text-accent shrink-0" />
            )}
          </button>
        ))}
      </div>
    </ScrollArea>
  );
}
