import { useEffect, useState } from 'react';
import { MobileCardAllBlack } from '@/components/mobile/MobileComponentsPremium';
import { supabase } from '@/integrations/supabase/client';
import { Calendar } from 'lucide-react';

interface TrainingHeatMapProps {
  athleteUserId: string;
}

export function TrainingHeatMap({ athleteUserId }: TrainingHeatMapProps) {
  const [activityData, setActivityData] = useState<Map<string, number>>(new Map());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadActivityData();
  }, [athleteUserId]);

  const loadActivityData = async () => {
    setLoading(true);
    try {
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - 90); // Last 90 days

      const { data: sessions } = await supabase
        .from('workout_sessions')
        .select('completed_at, total_volume')
        .eq('user_id', athleteUserId)
        .gte('completed_at', startDate.toISOString())
        .not('completed_at', 'is', null);

      const activityMap = new Map<string, number>();
      
      sessions?.forEach(session => {
        const date = new Date(session.completed_at).toISOString().split('T')[0];
        const current = activityMap.get(date) || 0;
        activityMap.set(date, current + (session.total_volume || 0));
      });

      setActivityData(activityMap);
    } catch (error) {
      console.error('Error loading activity data:', error);
    } finally {
      setLoading(false);
    }
  };

  const generateCalendarDays = () => {
    const days = [];
    const today = new Date();
    
    for (let i = 89; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const dateString = date.toISOString().split('T')[0];
      const volume = activityData.get(dateString) || 0;
      
      days.push({
        date: dateString,
        volume,
        day: date.getDate(),
        month: date.getMonth()
      });
    }
    
    return days;
  };

  const getIntensityClass = (volume: number): string => {
    if (volume === 0) return 'bg-surface-2';
    if (volume < 2000) return 'bg-success/30';
    if (volume < 5000) return 'bg-success/60';
    return 'bg-success';
  };

  const days = generateCalendarDays();
  const weeks = [];
  for (let i = 0; i < days.length; i += 7) {
    weeks.push(days.slice(i, i + 7));
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-accent"></div>
      </div>
    );
  }

  const totalWorkouts = Array.from(activityData.values()).filter(v => v > 0).length;
  const currentStreak = calculateStreak();

  function calculateStreak(): number {
    let streak = 0;
    const today = new Date();
    
    for (let i = 0; i < 90; i++) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const dateString = date.toISOString().split('T')[0];
      
      if (activityData.get(dateString)) {
        streak++;
      } else if (i > 0) {
        break;
      }
    }
    
    return streak;
  }

  return (
    <MobileCardAllBlack variant="elevated" className="p-6">
      <div className="flex items-center gap-2 mb-4">
        <Calendar className="w-5 h-5 text-accent" />
        <h3 className="text-lg font-bold">Mapa de Atividade (90 dias)</h3>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div>
          <p className="text-txt-3 text-sm">Total de Treinos</p>
          <p className="text-2xl font-bold">{totalWorkouts}</p>
        </div>
        <div>
          <p className="text-txt-3 text-sm">Streak Atual</p>
          <p className="text-2xl font-bold">{currentStreak} dias</p>
        </div>
      </div>

      <div className="overflow-x-auto">
        <div className="inline-flex flex-col gap-1">
          {weeks.map((week, weekIndex) => (
            <div key={weekIndex} className="flex gap-1">
              {week.map((day, dayIndex) => (
                <div
                  key={dayIndex}
                  className={`w-3 h-3 rounded-sm ${getIntensityClass(day.volume)} transition-colors`}
                  title={`${day.date}: ${day.volume > 0 ? `${day.volume}kg` : 'Sem treino'}`}
                />
              ))}
            </div>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-4 mt-4 text-sm text-txt-3">
        <span>Menos</span>
        <div className="flex gap-1">
          <div className="w-3 h-3 rounded-sm bg-surface-2" />
          <div className="w-3 h-3 rounded-sm bg-success/30" />
          <div className="w-3 h-3 rounded-sm bg-success/60" />
          <div className="w-3 h-3 rounded-sm bg-success" />
        </div>
        <span>Mais</span>
      </div>
    </MobileCardAllBlack>
  );
}
