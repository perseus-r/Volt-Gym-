import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Sparkles, ChevronRight, ChevronLeft, Loader2, Check,
  Target, Dumbbell, Clock, AlertTriangle, Heart, Brain
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Progress } from '@/components/ui/progress';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useTrainerKnowledgeBase, NewKnowledgeItem } from '@/hooks/useTrainerKnowledgeBase';

interface QuickSetupWizardProps {
  onComplete: () => void;
}

interface WizardAnswers {
  methodology: string;
  periodization: string;
  progressionStyle: string;
  volumeApproach: string;
  exercisePreferences: string;
  injuryApproach: string;
  coachingPhilosophy: string;
  specialNotes: string;
}

const STEPS = [
  { id: 'methodology', title: 'Metodologia', icon: Target },
  { id: 'periodization', title: 'Periodização', icon: Clock },
  { id: 'progression', title: 'Progressão', icon: ChevronRight },
  { id: 'exercises', title: 'Exercícios', icon: Dumbbell },
  { id: 'injuries', title: 'Lesões', icon: AlertTriangle },
  { id: 'philosophy', title: 'Filosofia', icon: Heart },
  { id: 'notes', title: 'Notas', icon: Brain },
];

export default function QuickSetupWizard({ onComplete }: QuickSetupWizardProps) {
  const { addItem } = useTrainerKnowledgeBase();
  const [currentStep, setCurrentStep] = useState(0);
  const [isGenerating, setIsGenerating] = useState(false);
  const [answers, setAnswers] = useState<WizardAnswers>({
    methodology: '',
    periodization: '',
    progressionStyle: '',
    volumeApproach: '',
    exercisePreferences: '',
    injuryApproach: '',
    coachingPhilosophy: '',
    specialNotes: '',
  });

  const progress = ((currentStep + 1) / STEPS.length) * 100;

  const updateAnswer = (key: keyof WizardAnswers, value: string) => {
    setAnswers(prev => ({ ...prev, [key]: value }));
  };

  const canProceed = () => {
    switch (currentStep) {
      case 0: return answers.methodology !== '';
      case 1: return answers.periodization !== '';
      case 2: return answers.progressionStyle !== '';
      case 3: return answers.exercisePreferences !== '';
      case 4: return answers.injuryApproach !== '';
      case 5: return answers.coachingPhilosophy !== '';
      case 6: return true; // Notes are optional
      default: return true;
    }
  };

  const generateKnowledgeBase = async () => {
    setIsGenerating(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('generate-knowledge-base', {
        body: { answers }
      });

      if (error) throw error;

      const generatedItems: NewKnowledgeItem[] = data.items || [];
      
      // Add each generated item
      for (const item of generatedItems) {
        await addItem({
          document_type: item.document_type,
          title: item.title,
          content: item.content,
          tags: item.tags || [],
          priority: item.priority || 2,
          is_active: true
        });
      }

      toast.success(`${generatedItems.length} itens criados na base de conhecimento!`);
      onComplete();
    } catch (error) {
      console.error('Error generating knowledge base:', error);
      toast.error('Erro ao gerar base de conhecimento. Tente novamente.');
    } finally {
      setIsGenerating(false);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Qual sua principal metodologia de treino?</h3>
            <RadioGroup value={answers.methodology} onValueChange={(v) => updateAnswer('methodology', v)}>
              <div className="grid gap-3">
                {[
                  { value: 'bodybuilding', label: 'Bodybuilding/Hipertrofia', desc: 'Foco em ganho de massa muscular e estética' },
                  { value: 'powerlifting', label: 'Powerlifting/Força', desc: 'Foco em força máxima nos básicos' },
                  { value: 'functional', label: 'Funcional/CrossFit', desc: 'Treino variado com foco em capacidade funcional' },
                  { value: 'hybrid', label: 'Híbrido/Misto', desc: 'Combinação de força e hipertrofia' },
                  { value: 'sport_specific', label: 'Específico para Esporte', desc: 'Performance atlética para modalidades específicas' },
                ].map(opt => (
                  <Label key={opt.value} className="flex items-start gap-3 p-3 rounded-lg border cursor-pointer hover:bg-muted/50 transition-colors [&:has([data-state=checked])]:border-primary [&:has([data-state=checked])]:bg-primary/5">
                    <RadioGroupItem value={opt.value} className="mt-1" />
                    <div>
                      <div className="font-medium">{opt.label}</div>
                      <div className="text-sm text-muted-foreground">{opt.desc}</div>
                    </div>
                  </Label>
                ))}
              </div>
            </RadioGroup>
          </div>
        );

      case 1:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Como você organiza a periodização?</h3>
            <RadioGroup value={answers.periodization} onValueChange={(v) => updateAnswer('periodization', v)}>
              <div className="grid gap-3">
                {[
                  { value: 'linear', label: 'Periodização Linear', desc: 'Progressão gradual de volume/intensidade ao longo das semanas' },
                  { value: 'undulating_daily', label: 'Ondulada Diária (DUP)', desc: 'Variação de estímulos dentro da mesma semana' },
                  { value: 'undulating_weekly', label: 'Ondulada Semanal', desc: 'Cada semana com foco diferente' },
                  { value: 'block', label: 'Periodização em Blocos', desc: 'Fases distintas de acumulação, transmutação e realização' },
                  { value: 'autoregulated', label: 'Autorregulada (RPE/RIR)', desc: 'Ajuste baseado na percepção de esforço do dia' },
                ].map(opt => (
                  <Label key={opt.value} className="flex items-start gap-3 p-3 rounded-lg border cursor-pointer hover:bg-muted/50 transition-colors [&:has([data-state=checked])]:border-primary [&:has([data-state=checked])]:bg-primary/5">
                    <RadioGroupItem value={opt.value} className="mt-1" />
                    <div>
                      <div className="font-medium">{opt.label}</div>
                      <div className="text-sm text-muted-foreground">{opt.desc}</div>
                    </div>
                  </Label>
                ))}
              </div>
            </RadioGroup>
          </div>
        );

      case 2:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Como você prefere progredir a carga?</h3>
            <RadioGroup value={answers.progressionStyle} onValueChange={(v) => updateAnswer('progressionStyle', v)}>
              <div className="grid gap-3">
                {[
                  { value: 'double', label: 'Dupla Progressão', desc: 'Primeiro aumenta reps, depois carga (ex: 3x8-12)' },
                  { value: 'linear_load', label: 'Progressão Linear de Carga', desc: 'Adiciona peso fixo a cada sessão/semana' },
                  { value: 'rpe_based', label: 'Baseada em RPE', desc: 'Ajusta carga para manter RPE alvo' },
                  { value: 'percentage', label: 'Baseada em Percentual', desc: 'Trabalha com % do 1RM' },
                  { value: 'volume_first', label: 'Volume Primeiro', desc: 'Aumenta séries/reps antes de carga' },
                ].map(opt => (
                  <Label key={opt.value} className="flex items-start gap-3 p-3 rounded-lg border cursor-pointer hover:bg-muted/50 transition-colors [&:has([data-state=checked])]:border-primary [&:has([data-state=checked])]:bg-primary/5">
                    <RadioGroupItem value={opt.value} className="mt-1" />
                    <div>
                      <div className="font-medium">{opt.label}</div>
                      <div className="text-sm text-muted-foreground">{opt.desc}</div>
                    </div>
                  </Label>
                ))}
              </div>
            </RadioGroup>

            <div className="pt-4">
              <Label>Volume semanal preferido por grupo muscular:</Label>
              <RadioGroup 
                value={answers.volumeApproach} 
                onValueChange={(v) => updateAnswer('volumeApproach', v)}
                className="mt-2"
              >
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { value: 'low', label: '6-10 séries' },
                    { value: 'moderate', label: '10-15 séries' },
                    { value: 'high', label: '15-20 séries' },
                    { value: 'very_high', label: '20+ séries' },
                  ].map(opt => (
                    <Label key={opt.value} className="flex items-center gap-2 p-2 rounded border cursor-pointer hover:bg-muted/50 [&:has([data-state=checked])]:border-primary">
                      <RadioGroupItem value={opt.value} />
                      <span className="text-sm">{opt.label}</span>
                    </Label>
                  ))}
                </div>
              </RadioGroup>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Quais exercícios você prioriza?</h3>
            <p className="text-sm text-muted-foreground">
              Descreva seus exercícios favoritos por grupo muscular ou estilo de treino
            </p>
            <Textarea
              value={answers.exercisePreferences}
              onChange={(e) => updateAnswer('exercisePreferences', e.target.value)}
              placeholder={`Ex:
- Peito: Supino com halteres (mais ativação), cross-over no final
- Costas: Remada curvada pronada, pull-down pegada neutra
- Pernas: Agachamento livre, leg press 45°, stiff romeno
- Ombros: Desenvolvimento sentado, elevação lateral com pegada neutra
- Braços: Rosca direta, tríceps corda...`}
              className="min-h-[200px]"
            />
          </div>
        );

      case 4:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Como você lida com lesões e limitações?</h3>
            <RadioGroup value={answers.injuryApproach} onValueChange={(v) => updateAnswer('injuryApproach', v)}>
              <div className="grid gap-3">
                {[
                  { value: 'conservative', label: 'Conservador', desc: 'Para completamente o exercício problemático até recuperação total' },
                  { value: 'modified', label: 'Modificado', desc: 'Adapta exercícios para trabalhar ao redor da lesão' },
                  { value: 'preventive', label: 'Preventivo', desc: 'Foco em pré-hab e trabalho corretivo antes de intensificar' },
                  { value: 'collaborative', label: 'Colaborativo', desc: 'Trabalha em conjunto com fisioterapeuta/médico' },
                ].map(opt => (
                  <Label key={opt.value} className="flex items-start gap-3 p-3 rounded-lg border cursor-pointer hover:bg-muted/50 transition-colors [&:has([data-state=checked])]:border-primary [&:has([data-state=checked])]:bg-primary/5">
                    <RadioGroupItem value={opt.value} className="mt-1" />
                    <div>
                      <div className="font-medium">{opt.label}</div>
                      <div className="text-sm text-muted-foreground">{opt.desc}</div>
                    </div>
                  </Label>
                ))}
              </div>
            </RadioGroup>
          </div>
        );

      case 5:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Qual sua filosofia de coaching?</h3>
            <p className="text-sm text-muted-foreground">
              Descreva o que você acredita ser mais importante no trabalho com atletas
            </p>
            <Textarea
              value={answers.coachingPhilosophy}
              onChange={(e) => updateAnswer('coachingPhilosophy', e.target.value)}
              placeholder={`Ex:
- Acredito em treino sustentável a longo prazo
- Priorizo técnica antes de carga
- Educação do aluno para autonomia
- Comunicação clara sobre expectativas
- Adaptação ao estilo de vida do aluno
- Monitoramento de sinais de overtraining...`}
              className="min-h-[180px]"
            />
          </div>
        );

      case 6:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Notas adicionais (opcional)</h3>
            <p className="text-sm text-muted-foreground">
              Algo mais que a IA deveria saber sobre seu estilo de trabalho?
            </p>
            <Textarea
              value={answers.specialNotes}
              onChange={(e) => updateAnswer('specialNotes', e.target.value)}
              placeholder={`Ex:
- Prefiro treinos de no máximo 60 minutos
- Uso muito supersets para otimizar tempo
- Gosto de incluir cardio HIIT no final
- Sempre incluo trabalho de core
- Não prescrevo exercícios em máquinas específicas que nem todos têm acesso...`}
              className="min-h-[150px]"
            />

            {/* Summary */}
            <Card className="bg-muted/50">
              <CardContent className="py-4">
                <h4 className="font-medium mb-2">Resumo das suas respostas:</h4>
                <div className="text-sm space-y-1 text-muted-foreground">
                  <p>• Metodologia: {answers.methodology || '-'}</p>
                  <p>• Periodização: {answers.periodization || '-'}</p>
                  <p>• Progressão: {answers.progressionStyle || '-'}</p>
                  <p>• Abordagem lesões: {answers.injuryApproach || '-'}</p>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Progress */}
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Passo {currentStep + 1} de {STEPS.length}</span>
          <span className="font-medium">{STEPS[currentStep].title}</span>
        </div>
        <Progress value={progress} className="h-2" />
        
        {/* Step indicators */}
        <div className="flex justify-between mt-4">
          {STEPS.map((step, index) => {
            const Icon = step.icon;
            const isCompleted = index < currentStep;
            const isCurrent = index === currentStep;
            
            return (
              <div 
                key={step.id}
                className={`flex flex-col items-center gap-1 ${
                  isCurrent ? 'text-primary' : isCompleted ? 'text-green-500' : 'text-muted-foreground'
                }`}
              >
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  isCurrent ? 'bg-primary/20' : isCompleted ? 'bg-green-500/20' : 'bg-muted'
                }`}>
                  {isCompleted ? <Check className="h-4 w-4" /> : <Icon className="h-4 w-4" />}
                </div>
                <span className="text-xs hidden sm:block">{step.title}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.2 }}
        >
          {renderStep()}
        </motion.div>
      </AnimatePresence>

      {/* Navigation */}
      <div className="flex justify-between pt-4">
        <Button
          variant="outline"
          onClick={() => setCurrentStep(prev => prev - 1)}
          disabled={currentStep === 0}
        >
          <ChevronLeft className="h-4 w-4 mr-1" />
          Anterior
        </Button>

        {currentStep < STEPS.length - 1 ? (
          <Button
            onClick={() => setCurrentStep(prev => prev + 1)}
            disabled={!canProceed()}
          >
            Próximo
            <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        ) : (
          <Button
            onClick={generateKnowledgeBase}
            disabled={isGenerating}
            className="gap-2"
          >
            {isGenerating ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Gerando...
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4" />
                Gerar Base de Conhecimento
              </>
            )}
          </Button>
        )}
      </div>
    </div>
  );
}
