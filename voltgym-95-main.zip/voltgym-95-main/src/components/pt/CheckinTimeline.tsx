import { MobileCardAllBlack } from '@/components/mobile/MobileComponentsPremium';
import { AthleteCheckin } from '@/hooks/useAthleteCheckins';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Calendar, TrendingDown, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState } from 'react';
import { Textarea } from '@/components/ui/textarea';

interface CheckinTimelineProps {
  checkins: AthleteCheckin[];
  isCoach?: boolean;
  onUpdateAnalysis?: (checkinId: string, analysis: string) => void;
}

export function CheckinTimeline({ checkins, isCoach, onUpdateAnalysis }: CheckinTimelineProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState('');

  const weightData = checkins
    .filter(c => c.weight_kg)
    .map(c => ({
      date: new Date(c.checkin_date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }),
      weight: c.weight_kg
    }))
    .reverse();

  const calculateWeightChange = () => {
    if (checkins.length < 2) return null;
    const latest = checkins[0].weight_kg || 0;
    const first = checkins[checkins.length - 1].weight_kg || 0;
    const change = latest - first;
    return {
      value: Math.abs(change).toFixed(1),
      isIncrease: change > 0
    };
  };

  const weightChange = calculateWeightChange();

  const handleSaveAnalysis = (checkinId: string) => {
    if (onUpdateAnalysis) {
      onUpdateAnalysis(checkinId, analysis);
      setEditingId(null);
      setAnalysis('');
    }
  };

  return (
    <div className="space-y-4">
      {/* Weight Chart */}
      {weightData.length > 1 && (
        <MobileCardAllBlack variant="elevated" className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold">Evolução de Peso</h3>
            {weightChange && (
              <div className="flex items-center gap-1 text-sm">
                {weightChange.isIncrease ? (
                  <TrendingUp className="w-4 h-4 text-accent" />
                ) : (
                  <TrendingDown className="w-4 h-4 text-success" />
                )}
                <span className={weightChange.isIncrease ? 'text-accent' : 'text-success'}>
                  {weightChange.isIncrease ? '+' : '-'}{weightChange.value}kg
                </span>
              </div>
            )}
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={weightData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="date" 
                stroke="hsl(var(--txt-3))"
                tick={{ fill: 'hsl(var(--txt-3))' }}
              />
              <YAxis 
                stroke="hsl(var(--txt-3))"
                tick={{ fill: 'hsl(var(--txt-3))' }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--background))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="weight" 
                stroke="hsl(var(--accent))" 
                strokeWidth={2}
                dot={{ fill: 'hsl(var(--accent))' }}
              />
            </LineChart>
          </ResponsiveContainer>
        </MobileCardAllBlack>
      )}

      {/* Checkins List */}
      <div className="space-y-3">
        {checkins.map((checkin) => (
          <MobileCardAllBlack key={checkin.id} variant="elevated" className="p-4">
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-accent" />
                <span className="font-medium">
                  {new Date(checkin.checkin_date).toLocaleDateString('pt-BR')}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-sm mb-3">
              {checkin.weight_kg && (
                <div>
                  <p className="text-txt-3">Peso</p>
                  <p className="font-bold">{checkin.weight_kg} kg</p>
                </div>
              )}
              {checkin.body_fat_percentage && (
                <div>
                  <p className="text-txt-3">% Gordura</p>
                  <p className="font-bold">{checkin.body_fat_percentage}%</p>
                </div>
              )}
            </div>

            {checkin.measurements && Object.keys(checkin.measurements).length > 0 && (
              <div className="mb-3">
                <p className="text-txt-3 text-sm mb-2">Medidas (cm)</p>
                <div className="grid grid-cols-4 gap-2 text-sm">
                  {Object.entries(checkin.measurements).map(([key, value]) => (
                    <div key={key}>
                      <p className="text-txt-3 capitalize">{key}</p>
                      <p className="font-medium">{value}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {checkin.subjective_feedback && (
              <div className="mb-3">
                <p className="text-txt-3 text-sm">Feedback do Aluno</p>
                <p className="text-sm mt-1">{checkin.subjective_feedback}</p>
              </div>
            )}

            {/* PT Analysis Section */}
            {isCoach && (
              <div className="border-t border-border pt-3 mt-3">
                {editingId === checkin.id ? (
                  <div className="space-y-2">
                    <Textarea
                      value={analysis}
                      onChange={(e) => setAnalysis(e.target.value)}
                      placeholder="Adicione sua análise sobre este check-in..."
                      rows={3}
                    />
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={() => handleSaveAnalysis(checkin.id)}
                      >
                        Salvar
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          setEditingId(null);
                          setAnalysis('');
                        }}
                      >
                        Cancelar
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    {checkin.pt_analysis ? (
                      <div>
                        <p className="text-txt-3 text-sm">Análise do PT</p>
                        <p className="text-sm mt-1">{checkin.pt_analysis}</p>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            setEditingId(checkin.id);
                            setAnalysis(checkin.pt_analysis || '');
                          }}
                          className="mt-2"
                        >
                          Editar Análise
                        </Button>
                      </div>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setEditingId(checkin.id)}
                      >
                        Adicionar Análise
                      </Button>
                    )}
                  </>
                )}
              </div>
            )}
          </MobileCardAllBlack>
        ))}
      </div>
    </div>
  );
}
