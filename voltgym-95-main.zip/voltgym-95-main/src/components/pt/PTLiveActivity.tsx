import { Activity, Clock } from 'lucide-react';
import { usePTLiveActivity } from '@/hooks/usePTLiveActivity';
import { MobileCardAllBlack } from '@/components/mobile/MobileComponentsPremium';
import { useNavigate } from 'react-router-dom';

interface PTLiveActivityProps {
  coachUserId: string;
}

export function PTLiveActivity({ coachUserId }: PTLiveActivityProps) {
  const { liveSessions, loading } = usePTLiveActivity(coachUserId);
  const navigate = useNavigate();

  const getTimeSince = (startedAt: string) => {
    const start = new Date(startedAt);
    const now = new Date();
    const diffMinutes = Math.floor((now.getTime() - start.getTime()) / (1000 * 60));
    
    if (diffMinutes < 60) return `${diffMinutes}min`;
    const hours = Math.floor(diffMinutes / 60);
    const minutes = diffMinutes % 60;
    return `${hours}h ${minutes}min`;
  };

  if (loading) {
    return (
      <MobileCardAllBlack variant="elevated" className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Activity className="w-5 h-5 text-green-500 animate-pulse" />
          <h3 className="text-lg font-bold">Atividade ao Vivo</h3>
        </div>
        <div className="text-center py-4">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-accent mx-auto"></div>
        </div>
      </MobileCardAllBlack>
    );
  }

  return (
    <MobileCardAllBlack variant="elevated" className="p-6">
      <div className="flex items-center gap-2 mb-4">
        <Activity className="w-5 h-5 text-green-500" />
        <h3 className="text-lg font-bold">Atividade ao Vivo</h3>
        {liveSessions.length > 0 && (
          <span className="ml-auto bg-green-500 text-black text-xs font-bold px-2 py-1 rounded-full">
            {liveSessions.length} {liveSessions.length === 1 ? 'ativo' : 'ativos'}
          </span>
        )}
      </div>

      {liveSessions.length === 0 ? (
        <div className="text-center py-6">
          <p className="text-txt-3 text-sm">Nenhum aluno treinando no momento</p>
        </div>
      ) : (
        <div className="space-y-3">
          {liveSessions.map((session) => (
            <div
              key={session.session_id}
              className="p-4 bg-surface rounded-lg border border-green-500/20 hover:border-green-500/40 transition-all cursor-pointer group"
              onClick={() => navigate(`/pt/athletes/${session.athlete_id}`)}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <p className="font-bold text-sm group-hover:text-accent transition-colors">
                    {session.athlete_name}
                  </p>
                  <p className="text-xs text-txt-3 truncate">{session.workout_name}</p>
                </div>
                <div className="flex items-center gap-1 text-xs text-green-500">
                  <Clock className="w-3 h-3" />
                  {getTimeSince(session.started_at)}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <div className="flex-1 bg-surface-dark rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-green-500 to-accent h-full transition-all duration-300"
                    style={{
                      width: `${(session.exercises_completed / session.total_exercises) * 100}%`
                    }}
                  />
                </div>
                <span className="text-xs text-txt-3 whitespace-nowrap">
                  {session.exercises_completed}/{session.total_exercises}
                </span>
              </div>

              {session.current_exercise && (
                <p className="text-xs text-txt-3 mt-2">
                  Exercício atual: <span className="text-txt-1">{session.current_exercise}</span>
                </p>
              )}
            </div>
          ))}
        </div>
      )}

      <div className="mt-4 pt-4 border-t border-line/30">
        <p className="text-xs text-txt-3 text-center">
          Atualizado automaticamente a cada 30 segundos
        </p>
      </div>
    </MobileCardAllBlack>
  );
}
