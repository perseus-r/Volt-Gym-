import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Star, Trophy, Clock, Dumbbell, Flame } from 'lucide-react';
import { cn } from '@/lib/utils';

interface WorkoutStats {
  durationMinutes: number;
  exercisesCount: number;
  completedCount: number;
  avgRpe: number;
}

interface WorkoutFeedbackDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (feedback: { rating: number; comment: string }) => Promise<void>;
  title?: string;
  stats?: WorkoutStats;
  loading?: boolean;
}

const ratingLabels: Record<number, string> = {
  1: 'Muito difícil',
  2: 'Difícil',
  3: 'Adequado',
  4: 'Bom',
  5: 'Excelente',
};

export function WorkoutFeedbackDialog({
  open,
  onOpenChange,
  onSubmit,
  title = 'Como foi o treino?',
  stats,
  loading = false,
}: WorkoutFeedbackDialogProps) {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [comment, setComment] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (rating === 0) return;

    setSubmitting(true);
    try {
      await onSubmit({ rating, comment });
      
      // Reset form
      setRating(0);
      setComment('');
      onOpenChange(false);
    } catch (error) {
      console.error('Error submitting feedback:', error);
    } finally {
      setSubmitting(false);
    }
  };

  const displayRating = hoveredRating || rating;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] bg-surface border-border">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-accent" />
            {title}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Stats Section */}
          {stats && (
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="bg-bg/50 rounded-lg p-3">
                <Clock className="h-4 w-4 mx-auto mb-1 text-accent" />
                <p className="text-2xl font-bold text-accent">{stats.durationMinutes}</p>
                <p className="text-xs text-muted-foreground">minutos</p>
              </div>
              <div className="bg-bg/50 rounded-lg p-3">
                <Dumbbell className="h-4 w-4 mx-auto mb-1 text-accent" />
                <p className="text-2xl font-bold text-accent">{stats.completedCount}/{stats.exercisesCount}</p>
                <p className="text-xs text-muted-foreground">exercícios</p>
              </div>
              <div className="bg-bg/50 rounded-lg p-3">
                <Flame className="h-4 w-4 mx-auto mb-1 text-accent" />
                <p className="text-2xl font-bold text-accent">{stats.avgRpe.toFixed(1)}</p>
                <p className="text-xs text-muted-foreground">RPE médio</p>
              </div>
            </div>
          )}

          {/* Rating Section */}
          <div className="space-y-3">
            <Label>Avaliação</Label>
            <div className="flex gap-2 justify-center">
              {[1, 2, 3, 4, 5].map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setRating(value)}
                  onMouseEnter={() => setHoveredRating(value)}
                  onMouseLeave={() => setHoveredRating(0)}
                  className="transition-transform hover:scale-110 focus:outline-none"
                >
                  <Star
                    className={cn(
                      'h-10 w-10 transition-colors',
                      displayRating >= value
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-muted-foreground'
                    )}
                  />
                </button>
              ))}
            </div>
            {displayRating > 0 && (
              <p className="text-center text-sm text-muted-foreground">
                {ratingLabels[displayRating]}
              </p>
            )}
          </div>

          {/* Comment Section */}
          <div className="space-y-2">
            <Label htmlFor="comment">Feedback para o personal (opcional)</Label>
            <Textarea
              id="comment"
              placeholder="Como você se sentiu? Algum exercício muito pesado ou leve?"
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={3}
              className="bg-bg/50 border-border"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button 
            onClick={handleSubmit} 
            disabled={rating === 0 || submitting || loading}
            className="bg-accent hover:bg-accent/90"
          >
            {submitting || loading ? 'Salvando...' : 'Concluir Treino'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}