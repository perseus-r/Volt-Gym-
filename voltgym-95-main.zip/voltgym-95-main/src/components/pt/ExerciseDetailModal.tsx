import { useEffect, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { ProgressionAnalyticsService } from '@/services/ProgressionAnalyticsService';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { TrendingUp, Lightbulb } from 'lucide-react';
import { MobileCardAllBlack } from '@/components/mobile/MobileComponentsPremium';

interface ExerciseDetailModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  athleteUserId: string;
  exerciseId: string;
  exerciseName: string;
}

export function ExerciseDetailModal({
  open,
  onOpenChange,
  athleteUserId,
  exerciseId,
  exerciseName
}: ExerciseDetailModalProps) {
  const [progression, setProgression] = useState<any[]>([]);
  const [rpeDistribution, setRpeDistribution] = useState<any[]>([]);
  const [suggestion, setSuggestion] = useState<{ weight: number; reason: string } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (open && exerciseId) {
      loadData();
    }
  }, [open, exerciseId, athleteUserId]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [prog, rpe] = await Promise.all([
        ProgressionAnalyticsService.getExerciseProgression(athleteUserId, exerciseId, 12),
        ProgressionAnalyticsService.getRPEDistribution(athleteUserId, exerciseId)
      ]);

      setProgression(prog);
      setRpeDistribution(rpe);

      if (prog.length > 0) {
        const sug = ProgressionAnalyticsService.suggestNextLoad(prog);
        setSuggestion(sug);
      }
    } catch (error) {
      console.error('Error loading exercise details:', error);
    } finally {
      setLoading(false);
    }
  };

  // Group progression by date for better visualization
  const chartData = progression.reduce((acc: any[], curr) => {
    const date = new Date(curr.date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
    const existing = acc.find(item => item.date === date);
    
    if (existing) {
      existing.maxWeight = Math.max(existing.maxWeight, curr.weight);
      existing.totalVolume += curr.volume;
    } else {
      acc.push({
        date,
        maxWeight: curr.weight,
        totalVolume: curr.volume,
        rpe: curr.rpe
      });
    }
    
    return acc;
  }, []);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">{exerciseName}</DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center p-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-accent"></div>
          </div>
        ) : (
          <div className="space-y-6">
            {/* AI Suggestion */}
            {suggestion && suggestion.weight > 0 && (
              <MobileCardAllBlack variant="elevated" className="p-4 bg-accent/10">
                <div className="flex items-start gap-3">
                  <Lightbulb className="w-5 h-5 text-accent mt-1" />
                  <div>
                    <h4 className="font-bold mb-1">Sugestão de IA</h4>
                    <p className="text-txt-2">
                      Próxima sessão: <span className="font-bold text-accent">{suggestion.weight}kg</span>
                    </p>
                    <p className="text-sm text-txt-3 mt-1">{suggestion.reason}</p>
                  </div>
                </div>
              </MobileCardAllBlack>
            )}

            {/* Weight Progression Chart */}
            <MobileCardAllBlack variant="elevated" className="p-6">
              <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-accent" />
                Evolução de Carga (12 semanas)
              </h3>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="date" 
                    stroke="hsl(var(--txt-3))"
                    tick={{ fill: 'hsl(var(--txt-3))' }}
                  />
                  <YAxis 
                    stroke="hsl(var(--txt-3))"
                    tick={{ fill: 'hsl(var(--txt-3))' }}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(var(--background))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="maxWeight" 
                    stroke="hsl(var(--accent))" 
                    strokeWidth={2}
                    name="Carga Máxima (kg)"
                    dot={{ fill: 'hsl(var(--accent))' }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </MobileCardAllBlack>

            {/* RPE Distribution */}
            {rpeDistribution.length > 0 && (
              <MobileCardAllBlack variant="elevated" className="p-6">
                <h3 className="text-lg font-bold mb-4">Distribuição de RPE</h3>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={rpeDistribution}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="rpe" 
                      stroke="hsl(var(--txt-3))"
                      tick={{ fill: 'hsl(var(--txt-3))' }}
                      label={{ value: 'RPE', position: 'insideBottom', offset: -5 }}
                    />
                    <YAxis 
                      stroke="hsl(var(--txt-3))"
                      tick={{ fill: 'hsl(var(--txt-3))' }}
                      label={{ value: 'Frequência (%)', angle: -90, position: 'insideLeft' }}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--background))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px'
                      }}
                    />
                    <Bar 
                      dataKey="percentage" 
                      fill="hsl(var(--warning))" 
                      name="Frequência (%)"
                    />
                  </BarChart>
                </ResponsiveContainer>
              </MobileCardAllBlack>
            )}

            {/* Stats Summary */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <MobileCardAllBlack variant="elevated" className="p-4">
                <p className="text-txt-3 text-sm">Sessões</p>
                <p className="text-2xl font-bold">{chartData.length}</p>
              </MobileCardAllBlack>
              <MobileCardAllBlack variant="elevated" className="p-4">
                <p className="text-txt-3 text-sm">Carga Máxima</p>
                <p className="text-2xl font-bold">
                  {Math.max(...progression.map(p => p.weight))}kg
                </p>
              </MobileCardAllBlack>
              <MobileCardAllBlack variant="elevated" className="p-4">
                <p className="text-txt-3 text-sm">Volume Total</p>
                <p className="text-2xl font-bold">
                  {progression.reduce((sum, p) => sum + p.volume, 0).toLocaleString()}kg
                </p>
              </MobileCardAllBlack>
              <MobileCardAllBlack variant="elevated" className="p-4">
                <p className="text-txt-3 text-sm">RPE Médio</p>
                <p className="text-2xl font-bold">
                  {(progression.reduce((sum, p) => sum + p.rpe, 0) / progression.length).toFixed(1)}
                </p>
              </MobileCardAllBlack>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
