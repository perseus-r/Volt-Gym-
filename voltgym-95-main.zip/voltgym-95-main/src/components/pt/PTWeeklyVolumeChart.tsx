import { BarChart, TrendingUp, TrendingDown } from 'lucide-react';
import { usePTWeeklyStats } from '@/hooks/usePTWeeklyStats';
import { MobileCardAllBlack } from '@/components/mobile/MobileComponentsPremium';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

interface PTWeeklyVolumeChartProps {
  coachUserId: string;
}

export function PTWeeklyVolumeChart({ coachUserId }: PTWeeklyVolumeChartProps) {
  const { stats, loading } = usePTWeeklyStats(coachUserId);

  if (loading) {
    return (
      <MobileCardAllBlack variant="elevated" className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <BarChart className="w-5 h-5 text-accent" />
          <h3 className="text-lg font-bold">Volume Semanal</h3>
        </div>
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-accent mx-auto"></div>
        </div>
      </MobileCardAllBlack>
    );
  }

  if (!stats) return null;

  const formatVolume = (value: number) => {
    if (value >= 1000) return `${(value / 1000).toFixed(1)}t`;
    return `${Math.round(value)}kg`;
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return `${date.getDate()}/${date.getMonth() + 1}`;
  };

  const isPositiveChange = stats.volume_change_percent >= 0;

  return (
    <MobileCardAllBlack variant="elevated" className="p-6">
      <div className="flex items-center gap-2 mb-4">
        <BarChart className="w-5 h-5 text-accent" />
        <h3 className="text-lg font-bold">Volume Semanal Agregado</h3>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="p-4 bg-surface rounded-lg">
          <p className="text-xs text-txt-3 mb-1">Esta Semana</p>
          <p className="text-2xl font-bold text-accent">{formatVolume(stats.current_week_volume)}</p>
          <p className="text-xs text-txt-3 mt-1">{stats.current_week_sessions} treinos</p>
        </div>
        <div className="p-4 bg-surface rounded-lg">
          <p className="text-xs text-txt-3 mb-1">Semana Passada</p>
          <p className="text-2xl font-bold">{formatVolume(stats.last_week_volume)}</p>
          <p className="text-xs text-txt-3 mt-1">{stats.last_week_sessions} treinos</p>
        </div>
      </div>

      <div className="mb-6">
        <div className={`flex items-center gap-2 p-3 rounded-lg ${
          isPositiveChange ? 'bg-green-500/10' : 'bg-red-500/10'
        }`}>
          {isPositiveChange ? (
            <TrendingUp className="w-5 h-5 text-green-500" />
          ) : (
            <TrendingDown className="w-5 h-5 text-red-500" />
          )}
          <div className="flex-1">
            <p className="text-sm font-bold">
              {isPositiveChange ? '+' : ''}{stats.volume_change_percent.toFixed(1)}%
            </p>
            <p className="text-xs text-txt-3">vs semana anterior</p>
          </div>
        </div>
      </div>

      {stats.weekly_data.length > 0 && (
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={stats.weekly_data}>
              <XAxis 
                dataKey="week_start" 
                tickFormatter={formatDate}
                stroke="hsl(var(--txt-3))"
                fontSize={12}
              />
              <YAxis 
                tickFormatter={formatVolume}
                stroke="hsl(var(--txt-3))"
                fontSize={12}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(var(--surface))',
                  border: '1px solid hsl(var(--line))',
                  borderRadius: '8px',
                  color: 'hsl(var(--txt-1))'
                }}
                formatter={(value: number) => [formatVolume(value), 'Volume']}
                labelFormatter={(label) => `Semana de ${formatDate(label)}`}
              />
              <Line
                type="monotone"
                dataKey="total_volume"
                stroke="hsl(var(--accent))"
                strokeWidth={2}
                dot={{ fill: 'hsl(var(--accent))', r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </MobileCardAllBlack>
  );
}
