import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { CalendarIcon, Plus, Trash2, Dumbbell, FileText, Sparkles, Check } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { usePTTemplates, PTTemplate } from '@/hooks/usePTTemplates';
import { supabase } from '@/integrations/supabase/client';

interface Exercise {
  name: string;
  sets: number;
  reps: string;
  weight?: number;
  rest_seconds?: number;
  notes?: string;
}

interface AssignWorkoutDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  athleteUserId: string;
  athleteName: string;
  personalTrainerId: string;
  onAssign: (assignment: {
    athlete_user_id: string;
    personal_trainer_id: string;
    template_id?: string;
    scheduled_date?: string;
    expiration_date?: string;
    pt_notes?: string;
    exercises_completed?: any;
  }) => Promise<void>;
}

export function AssignWorkoutDialog({
  open,
  onOpenChange,
  athleteUserId,
  athleteName,
  personalTrainerId,
  onAssign,
}: AssignWorkoutDialogProps) {
  const [tab, setTab] = useState<string>('template');
  const [scheduledDate, setScheduledDate] = useState<Date>();
  const [expirationDate, setExpirationDate] = useState<Date>();
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  
  // Template selection
  const { templates, loading: templatesLoading } = usePTTemplates();
  const [selectedTemplate, setSelectedTemplate] = useState<PTTemplate | null>(null);
  
  // Custom workout
  const [workoutName, setWorkoutName] = useState('');
  const [exercises, setExercises] = useState<Exercise[]>([
    { name: '', sets: 3, reps: '10-12' }
  ]);

  const addExercise = () => {
    setExercises([...exercises, { name: '', sets: 3, reps: '10-12' }]);
  };

  const removeExercise = (index: number) => {
    setExercises(exercises.filter((_, i) => i !== index));
  };

  const updateExercise = (index: number, field: keyof Exercise, value: any) => {
    const updated = [...exercises];
    updated[index] = { ...updated[index], [field]: value };
    setExercises(updated);
  };

  const getExercisesArray = (template: PTTemplate): Exercise[] => {
    if (!template.exercises) return [];
    if (Array.isArray(template.exercises)) {
      return (template.exercises as unknown as Exercise[]).map(ex => ({
        name: String((ex as any).name || ''),
        sets: Number((ex as any).sets) || 3,
        reps: String((ex as any).reps || '10'),
        weight: (ex as any).weight ? Number((ex as any).weight) : undefined,
        rest_seconds: (ex as any).rest_seconds ? Number((ex as any).rest_seconds) : undefined,
        notes: (ex as any).notes ? String((ex as any).notes) : undefined
      }));
    }
    return [];
  };

  const incrementTimesAssigned = async (templateId: string) => {
    try {
      const template = templates.find(t => t.id === templateId);
      if (!template) return;

      await supabase
        .from('workout_templates_pt')
        .update({ times_assigned: (template.times_assigned || 0) + 1 })
        .eq('id', templateId);
    } catch (error) {
      console.error('Error incrementing times_assigned:', error);
    }
  };

  const handleAssign = async () => {
    setLoading(true);
    try {
      let exercisesData: Exercise[] = [];
      let templateId: string | undefined;

      if (tab === 'template' && selectedTemplate) {
        exercisesData = getExercisesArray(selectedTemplate);
        templateId = selectedTemplate.id;
        await incrementTimesAssigned(selectedTemplate.id);
      } else if (tab === 'custom') {
        // Validate custom exercises
        const validExercises = exercises.filter(e => e.name.trim());
        if (validExercises.length === 0) {
          setLoading(false);
          return;
        }
        exercisesData = validExercises;
      }

      await onAssign({
        athlete_user_id: athleteUserId,
        personal_trainer_id: personalTrainerId,
        template_id: templateId,
        scheduled_date: scheduledDate ? format(scheduledDate, 'yyyy-MM-dd') : undefined,
        expiration_date: expirationDate ? format(expirationDate, 'yyyy-MM-dd') : undefined,
        pt_notes: notes || (tab === 'custom' ? workoutName : selectedTemplate?.name) || undefined,
        exercises_completed: exercisesData.map(e => ({
          ...e,
          completed: false
        }))
      });
      
      // Reset form
      setScheduledDate(undefined);
      setExpirationDate(undefined);
      setNotes('');
      setSelectedTemplate(null);
      setWorkoutName('');
      setExercises([{ name: '', sets: 3, reps: '10-12' }]);
      onOpenChange(false);
    } catch (error) {
      console.error('Error assigning workout:', error);
    } finally {
      setLoading(false);
    }
  };

  const canAssign = () => {
    if (tab === 'template') return !!selectedTemplate;
    if (tab === 'custom') return exercises.some(e => e.name.trim());
    return false;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Dumbbell className="w-5 h-5 text-primary" />
            Atribuir Treino para {athleteName}
          </DialogTitle>
        </DialogHeader>

        <Tabs value={tab} onValueChange={setTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="template" className="gap-2">
              <FileText className="w-4 h-4" />
              Usar Template
            </TabsTrigger>
            <TabsTrigger value="custom" className="gap-2">
              <Sparkles className="w-4 h-4" />
              Criar Treino
            </TabsTrigger>
          </TabsList>

          <TabsContent value="template" className="space-y-4">
            <div className="space-y-2">
              <Label>Selecione um Template</Label>
              {templatesLoading ? (
                <div className="flex items-center justify-center p-8">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
                </div>
              ) : templates.length === 0 ? (
                <div className="text-center p-6 bg-muted/50 rounded-lg">
                  <FileText className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-sm text-muted-foreground">Nenhum template criado ainda</p>
                  <Button 
                    variant="link" 
                    size="sm"
                    onClick={() => setTab('custom')}
                  >
                    Criar treino personalizado
                  </Button>
                </div>
              ) : (
                <ScrollArea className="h-[200px] pr-4">
                  <div className="space-y-2">
                    {templates.map((template) => {
                      const exercisesArr = getExercisesArray(template);
                      return (
                        <div
                          key={template.id}
                          onClick={() => setSelectedTemplate(template)}
                          className={cn(
                            'p-3 rounded-lg border cursor-pointer transition-all',
                            selectedTemplate?.id === template.id
                              ? 'border-primary bg-primary/10'
                              : 'border-border hover:border-primary/50 hover:bg-muted/50'
                          )}
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2">
                                <p className="font-medium">{template.name}</p>
                                {selectedTemplate?.id === template.id && (
                                  <Check className="w-4 h-4 text-primary" />
                                )}
                              </div>
                              <p className="text-xs text-muted-foreground mt-1">
                                {exercisesArr.length} exercícios
                                {template.estimated_duration && ` • ${template.estimated_duration}min`}
                              </p>
                            </div>
                            <div className="flex flex-wrap gap-1">
                              {template.difficulty_level && (
                                <Badge variant="outline" className="text-xs">
                                  {template.difficulty_level}
                                </Badge>
                              )}
                              {template.category && (
                                <Badge variant="secondary" className="text-xs">
                                  {template.category}
                                </Badge>
                              )}
                            </div>
                          </div>
                          {template.description && (
                            <p className="text-xs text-muted-foreground mt-2 line-clamp-2">
                              {template.description}
                            </p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </ScrollArea>
              )}
            </div>

            {selectedTemplate && (
              <div className="p-3 bg-muted/50 rounded-lg">
                <p className="text-sm font-medium mb-2">Exercícios do Template:</p>
                <div className="space-y-1">
                  {getExercisesArray(selectedTemplate).slice(0, 5).map((ex, i) => (
                    <p key={i} className="text-xs text-muted-foreground">
                      • {ex.name} - {ex.sets}x{ex.reps}
                    </p>
                  ))}
                  {getExercisesArray(selectedTemplate).length > 5 && (
                    <p className="text-xs text-primary">
                      + {getExercisesArray(selectedTemplate).length - 5} mais...
                    </p>
                  )}
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="custom" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="workoutName">Nome do Treino</Label>
              <Input
                id="workoutName"
                placeholder="Ex: Treino A - Peito e Tríceps"
                value={workoutName}
                onChange={(e) => setWorkoutName(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Exercícios</Label>
                <Button variant="ghost" size="sm" onClick={addExercise}>
                  <Plus className="w-4 h-4 mr-1" />
                  Adicionar
                </Button>
              </div>
              
              <ScrollArea className="h-[200px] pr-4">
                <div className="space-y-3">
                  {exercises.map((exercise, index) => (
                    <div key={index} className="flex items-start gap-2 p-3 bg-muted/50 rounded-lg">
                      <div className="flex-1 space-y-2">
                        <Input
                          placeholder="Nome do exercício"
                          value={exercise.name}
                          onChange={(e) => updateExercise(index, 'name', e.target.value)}
                        />
                        <div className="grid grid-cols-3 gap-2">
                          <div>
                            <Label className="text-xs">Séries</Label>
                            <Input
                              type="number"
                              min={1}
                              value={exercise.sets}
                              onChange={(e) => updateExercise(index, 'sets', parseInt(e.target.value) || 1)}
                            />
                          </div>
                          <div>
                            <Label className="text-xs">Reps</Label>
                            <Input
                              placeholder="10-12"
                              value={exercise.reps}
                              onChange={(e) => updateExercise(index, 'reps', e.target.value)}
                            />
                          </div>
                          <div>
                            <Label className="text-xs">Peso (kg)</Label>
                            <Input
                              type="number"
                              placeholder="0"
                              value={exercise.weight || ''}
                              onChange={(e) => updateExercise(index, 'weight', parseFloat(e.target.value) || undefined)}
                            />
                          </div>
                        </div>
                      </div>
                      {exercises.length > 1 && (
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeExercise(index)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </TabsContent>
        </Tabs>

        {/* Common fields */}
        <div className="space-y-4 pt-4 border-t">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Data Programada</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      'w-full justify-start text-left font-normal',
                      !scheduledDate && 'text-muted-foreground'
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {scheduledDate ? format(scheduledDate, 'dd/MM/yyyy', { locale: ptBR }) : 'Selecionar'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={scheduledDate}
                    onSelect={setScheduledDate}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label>Validade (opcional)</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      'w-full justify-start text-left font-normal',
                      !expirationDate && 'text-muted-foreground'
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {expirationDate ? format(expirationDate, 'dd/MM/yyyy', { locale: ptBR }) : 'Sem limite'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={expirationDate}
                    onSelect={setExpirationDate}
                    initialFocus
                    disabled={(date) => scheduledDate ? date < scheduledDate : false}
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notas para o Aluno</Label>
            <Textarea
              id="notes"
              placeholder="Ex: Foque na técnica hoje, reduza 10% a carga se sentir dor..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button onClick={handleAssign} disabled={loading || !canAssign()}>
            {loading ? 'Atribuindo...' : 'Atribuir Treino'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
