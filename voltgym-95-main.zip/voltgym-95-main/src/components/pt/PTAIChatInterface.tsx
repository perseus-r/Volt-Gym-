import React, { useState, useRef, useEffect } from 'react';
import { Send, Loader2, Bot, User, Sparkles, Copy, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Athlete } from '@/hooks/useAthletes';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import ReactMarkdown from 'react-markdown';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  workoutData?: any;
}

interface PTAIChatInterfaceProps {
  athlete: Athlete;
}

interface AthleteContext {
  profile: any;
  recentWorkouts: any[];
  stats: {
    totalWorkouts: number;
    totalVolume: number;
    avgDuration: number;
  };
}

export function PTAIChatInterface({ athlete }: PTAIChatInterfaceProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [athleteContext, setAthleteContext] = useState<AthleteContext | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Fetch athlete context (profile + workout history)
  useEffect(() => {
    const fetchAthleteContext = async () => {
      if (!athlete.user_id) return;

      try {
        // Buscar perfil do atleta
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('user_id', athlete.user_id)
          .single();

        // Buscar histórico de treinos
        const { data: sessions } = await supabase
          .from('workout_sessions')
          .select(`
            id, name, focus, completed_at, duration_minutes, total_volume,
            exercise_logs(notes, completed)
          `)
          .eq('user_id', athlete.user_id)
          .order('completed_at', { ascending: false })
          .limit(15);

        const recentWorkouts = (sessions || []).map(s => ({
          name: s.name || s.focus,
          date: s.completed_at,
          duration: s.duration_minutes,
          volume: s.total_volume,
          exercises: s.exercise_logs?.map((e: any) => e.notes).filter(Boolean) || []
        }));

        const totalVolume = recentWorkouts.reduce((sum, w) => sum + (w.volume || 0), 0);
        const avgDuration = recentWorkouts.length > 0
          ? Math.round(recentWorkouts.reduce((sum, w) => sum + (w.duration || 0), 0) / recentWorkouts.length)
          : 0;

        setAthleteContext({
          profile,
          recentWorkouts,
          stats: {
            totalWorkouts: profile?.total_workouts || recentWorkouts.length,
            totalVolume,
            avgDuration
          }
        });
      } catch (error) {
        console.error('Error fetching athlete context:', error);
      }
    };

    fetchAthleteContext();
  }, [athlete.user_id]);

  // Initial greeting with context
  useEffect(() => {
    const contextInfo = athleteContext?.profile 
      ? `\n\n📊 **Dados do Atleta:**
- Objetivo: ${athleteContext.profile.goal || 'Não definido'}
- Nível: ${athleteContext.profile.experience_level || 'Não definido'}
- Total de treinos: ${athleteContext.stats.totalWorkouts}
- Duração média: ${athleteContext.stats.avgDuration}min`
      : '';

    setMessages([{
      id: 'welcome',
      role: 'assistant',
      content: `Olá! Sou seu assistente de IA para criar treinos personalizados. Estou analisando o perfil de **${athlete.display_name || 'seu atleta'}**.${contextInfo}

Como posso ajudar? Algumas sugestões:
- "Crie um treino de peito focado em hipertrofia"
- "Monte uma programação semanal de 5 dias"
- "Analise o progresso recente e sugira ajustes"
- "Crie um treino adaptado para dor no ombro"`,
      timestamp: new Date()
    }]);
  }, [athlete.id, athleteContext]);

  // Auto scroll
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        throw new Error('Not authenticated');
      }

      const response = await fetch(
        `https://osvicgbgrmyogazdbllj.supabase.co/functions/v1/pt-ai-coach`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({
            message: input,
            athleteId: athlete.user_id,
            conversationHistory: messages.filter(m => m.id !== 'welcome').map(m => ({
              role: m.role,
              content: m.content
            })),
            // Incluir contexto completo do atleta
            athleteContext: athleteContext ? {
              profile: {
                name: athlete.display_name,
                goal: athleteContext.profile?.goal,
                experience: athleteContext.profile?.experience_level,
                age: athleteContext.profile?.age,
                weight: athleteContext.profile?.weight,
                height: athleteContext.profile?.height
              },
              recentWorkouts: athleteContext.recentWorkouts,
              stats: athleteContext.stats
            } : null
          })
        }
      );

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'AI request failed');
      }

      const data = await response.json();

      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.response,
        timestamp: new Date(),
        workoutData: data.workoutData
      };

      setMessages(prev => [...prev, aiMessage]);

    } catch (error: any) {
      console.error('Error sending message:', error);
      toast.error(error.message || 'Erro ao enviar mensagem');
      
      // Add error message
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'Desculpe, ocorreu um erro ao processar sua mensagem. Por favor, tente novamente.',
        timestamp: new Date()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const copyToClipboard = (content: string) => {
    navigator.clipboard.writeText(content);
    toast.success('Copiado para a área de transferência');
  };

  return (
    <div className="flex flex-col h-full min-h-[450px]">
      {/* Messages */}
      <ScrollArea className="flex-1 pr-4" ref={scrollRef}>
        <div className="space-y-4 pb-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={cn(
                "flex gap-3",
                message.role === 'user' ? "justify-end" : "justify-start"
              )}
            >
              {message.role === 'assistant' && (
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-accent flex items-center justify-center shrink-0">
                  <Bot className="w-4 h-4 text-white" />
                </div>
              )}

              <div
                className={cn(
                  "max-w-[80%] rounded-2xl px-4 py-3",
                  message.role === 'user'
                    ? "bg-accent text-accent-foreground"
                    : "bg-secondary/50 text-foreground"
                )}
              >
                {message.role === 'assistant' ? (
                  <div className="prose prose-sm prose-invert max-w-none">
                    <ReactMarkdown>{message.content}</ReactMarkdown>
                  </div>
                ) : (
                  <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                )}

                {/* Workout Actions */}
                {message.workoutData && (
                  <div className="mt-3 pt-3 border-t border-border/50 flex gap-2">
                    <Button 
                      size="sm" 
                      variant="secondary"
                      onClick={() => copyToClipboard(JSON.stringify(message.workoutData, null, 2))}
                    >
                      <Copy className="w-3 h-3 mr-1" />
                      Copiar
                    </Button>
                    <Button size="sm" variant="secondary">
                      <Download className="w-3 h-3 mr-1" />
                      Salvar Template
                    </Button>
                  </div>
                )}

                {/* Copy button for assistant messages */}
                {message.role === 'assistant' && message.id !== 'welcome' && (
                  <button
                    onClick={() => copyToClipboard(message.content)}
                    className="mt-2 text-xs text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" />
                    Copiar
                  </button>
                )}
              </div>

              {message.role === 'user' && (
                <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center shrink-0">
                  <User className="w-4 h-4 text-muted-foreground" />
                </div>
              )}
            </div>
          ))}

          {/* Loading */}
          {isLoading && (
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-accent flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div className="bg-secondary/50 rounded-2xl px-4 py-3">
                <div className="flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin text-accent" />
                  <span className="text-sm text-muted-foreground">Gerando resposta...</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="mt-4 pt-4 border-t border-border/50">
        <div className="flex gap-2">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={`Peça um treino para ${athlete.display_name || 'seu atleta'}...`}
            className="flex-1 min-h-[60px] max-h-[120px] resize-none bg-secondary/30 border-border/50"
            disabled={isLoading}
          />
          <Button 
            onClick={sendMessage} 
            disabled={!input.trim() || isLoading}
            className="h-[60px] px-4"
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Send className="w-5 h-5" />
            )}
          </Button>
        </div>
        <p className="text-xs text-muted-foreground mt-2 flex items-center gap-1">
          <Sparkles className="w-3 h-3" />
          IA tem acesso ao histórico completo do atleta
        </p>
      </div>
    </div>
  );
}
