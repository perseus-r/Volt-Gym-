import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Calendar, Camera, Weight, Ruler } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

interface CheckinRequestDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  athleteName: string;
  athleteUserId: string;
  trainerName: string;
  onRequest: () => void;
}

export function CheckinRequestDialog({
  open,
  onOpenChange,
  athleteName,
  athleteUserId,
  trainerName,
  onRequest
}: CheckinRequestDialogProps) {
  const [note, setNote] = useState('');
  const [sending, setSending] = useState(false);

  const handleRequest = async () => {
    setSending(true);
    try {
      // Inserir notificação para o atleta na tabela user_notifications
      const { error } = await supabase
        .from('user_notifications')
        .insert({
          user_id: athleteUserId,
          type: 'checkin_request',
          title: 'Solicitação de Check-in',
          message: `Seu personal ${trainerName} solicitou um check-in.${note ? ` Mensagem: ${note}` : ''}`,
          action_label: 'Fazer Check-in',
          action_data: { route: '/progress/checkin' },
          read: false,
        });

      if (error) {
        console.error('Error inserting notification:', error);
        throw error;
      }

      onRequest();
      toast.success(`Solicitação de check-in enviada para ${athleteName}`);
      onOpenChange(false);
      setNote('');
    } catch (error) {
      console.error('Error sending checkin request:', error);
      toast.error('Erro ao enviar solicitação');
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Solicitar Check-in</DialogTitle>
          <DialogDescription>
            Envie uma solicitação de check-in para {athleteName}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="bg-surface-2 rounded-lg p-4 space-y-3">
            <h4 className="font-medium text-sm">O aluno deverá preencher:</h4>
            <div className="space-y-2 text-sm text-txt-3">
              <div className="flex items-center gap-2">
                <Weight className="w-4 h-4 text-accent" />
                <span>Peso atual</span>
              </div>
              <div className="flex items-center gap-2">
                <Ruler className="w-4 h-4 text-accent" />
                <span>Medidas corporais</span>
              </div>
              <div className="flex items-center gap-2">
                <Camera className="w-4 h-4 text-accent" />
                <span>Fotos de progresso</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-accent" />
                <span>Como está se sentindo</span>
              </div>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">
              Mensagem para o aluno (opcional)
            </label>
            <Textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Ex: Vamos fazer um check-in para avaliar seu progresso..."
              rows={3}
            />
          </div>

          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1"
            >
              Cancelar
            </Button>
            <Button
              onClick={handleRequest}
              disabled={sending}
              className="flex-1"
            >
              {sending ? 'Enviando...' : 'Enviar Solicitação'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
