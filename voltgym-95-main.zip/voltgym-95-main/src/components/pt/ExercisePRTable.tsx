import { useEffect, useState } from 'react';
import { MobileCardAllBlack } from '@/components/mobile/MobileComponentsPremium';
import { ProgressionAnalyticsService } from '@/services/ProgressionAnalyticsService';
import { Trophy, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface ExercisePRTableProps {
  athleteUserId: string;
  onExerciseClick: (exerciseId: string, exerciseName: string) => void;
}

export function ExercisePRTable({ athleteUserId, onExerciseClick }: ExercisePRTableProps) {
  const [records, setRecords] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadRecords();
  }, [athleteUserId]);

  const loadRecords = async () => {
    setLoading(true);
    try {
      const data = await ProgressionAnalyticsService.getPersonalRecords(athleteUserId);
      setRecords(data);
    } catch (error) {
      console.error('Error loading PRs:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-accent"></div>
      </div>
    );
  }

  return (
    <MobileCardAllBlack variant="elevated" className="p-6">
      <div className="flex items-center gap-2 mb-4">
        <Trophy className="w-5 h-5 text-accent" />
        <h3 className="text-lg font-bold">Recordes Pessoais (Top 10)</h3>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-border">
              <th className="text-left py-3 px-2 text-sm font-medium text-txt-3">Exercício</th>
              <th className="text-center py-3 px-2 text-sm font-medium text-txt-3">Melhor Carga</th>
              <th className="text-center py-3 px-2 text-sm font-medium text-txt-3">Data</th>
              <th className="text-center py-3 px-2 text-sm font-medium text-txt-3">Progresso</th>
              <th className="text-right py-3 px-2 text-sm font-medium text-txt-3">Ações</th>
            </tr>
          </thead>
          <tbody>
            {records.map((record, index) => (
              <tr key={record.exerciseId} className="border-b border-border/50">
                <td className="py-3 px-2">
                  <div className="flex items-center gap-2">
                    {index < 3 && (
                      <span className="text-xl">
                        {index === 0 ? '🥇' : index === 1 ? '🥈' : '🥉'}
                      </span>
                    )}
                    <span className="font-medium">{record.exerciseName}</span>
                  </div>
                </td>
                <td className="py-3 px-2 text-center font-bold">
                  {record.bestWeight}kg × {record.bestReps}
                </td>
                <td className="py-3 px-2 text-center text-txt-3">
                  {new Date(record.date).toLocaleDateString('pt-BR')}
                </td>
                <td className="py-3 px-2 text-center">
                  <div className="flex items-center justify-center gap-1">
                    <TrendingUp className="w-4 h-4 text-success" />
                    <span className="text-success font-bold">
                      +{record.percentageIncrease}%
                    </span>
                  </div>
                </td>
                <td className="py-3 px-2 text-right">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onExerciseClick(record.exerciseId, record.exerciseName)}
                  >
                    Ver Detalhes
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {records.length === 0 && (
          <div className="text-center py-8 text-txt-3">
            Nenhum recorde registrado ainda
          </div>
        )}
      </div>
    </MobileCardAllBlack>
  );
}
