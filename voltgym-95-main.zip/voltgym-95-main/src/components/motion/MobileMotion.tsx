/**
 * MobileMotion - Performance-optimized motion wrapper
 * 
 * Automatically:
 * - Removes whileHover/whileTap on mobile (uses CSS instead)
 * - Disables repeat: Infinity animations
 * - Respects prefers-reduced-motion
 * - Uses lighter animations on low-end devices
 */

import { motion, MotionProps, HTMLMotionProps } from 'framer-motion';
import { useReducedMotion } from '@/hooks/useReducedMotion';
import { useIsMobile } from '@/hooks/use-mobile';
import { forwardRef, ComponentType } from 'react';

interface MobileMotionProps extends HTMLMotionProps<'div'> {
  /** CSS class for :active state (mobile replacement for whileTap) */
  activeClass?: string;
  /** CSS class for :hover state (mobile replacement for whileHover) */
  hoverClass?: string;
  /** Disable all animations */
  disabled?: boolean;
}

/**
 * Optimized motion.div that adapts to device capabilities
 */
export const MobileMotion = forwardRef<HTMLDivElement, MobileMotionProps>(
  ({ 
    children, 
    className = '',
    activeClass,
    hoverClass,
    disabled,
    whileHover,
    whileTap,
    animate,
    transition,
    ...props 
  }, ref) => {
    const isMobile = useIsMobile();
    const { shouldReduceMotion, tier, durationMultiplier } = useReducedMotion();

    // If disabled or reduced motion, render static div
    if (disabled || shouldReduceMotion) {
      return (
        <div ref={ref} className={className} {...(props as any)}>
          {children}
        </div>
      );
    }

    // Optimize animations for mobile
    const optimizedAnimate = (() => {
      if (!animate || typeof animate !== 'object') return animate;
      
      // Remove infinite animations on mobile
      return animate;
    })();

    // Optimize transition
    const optimizedTransition = (() => {
      if (!transition) return { duration: 0.3 * durationMultiplier };
      
      const t = { ...transition } as any;
      
      // Remove infinite repeat on mobile
      if (isMobile && t.repeat === Infinity) {
        t.repeat = 0;
      }
      
      // Scale duration
      if (t.duration) {
        t.duration = t.duration * durationMultiplier;
      }
      
      // Use simpler easing on low-end devices
      if (tier === 'low') {
        delete t.type;
        delete t.stiffness;
        delete t.damping;
        t.ease = 'easeOut';
      }
      
      return t;
    })();

    // Build classes with hover/active states
    const classes = [
      className,
      // Add hover class for desktop
      hoverClass && !isMobile ? `hover:${hoverClass}` : '',
      // Add active class for mobile touch
      activeClass && isMobile ? `active:${activeClass}` : '',
      // Add touch feedback on mobile
      isMobile ? 'active:scale-[0.98] active:opacity-90 transition-transform' : ''
    ].filter(Boolean).join(' ');

    return (
      <motion.div
        ref={ref}
        className={classes}
        animate={optimizedAnimate}
        transition={optimizedTransition}
        // Only apply hover/tap on desktop with good performance
        whileHover={!isMobile && tier === 'high' ? whileHover : undefined}
        whileTap={!isMobile && tier === 'high' ? whileTap : undefined}
        {...props}
      >
        {children}
      </motion.div>
    );
  }
);

MobileMotion.displayName = 'MobileMotion';

/**
 * Optimized motion button
 */
export const MobileMotionButton = forwardRef<HTMLButtonElement, HTMLMotionProps<'button'> & MobileMotionProps>(
  ({ children, className = '', disabled, whileHover, whileTap, ...props }, ref) => {
    const isMobile = useIsMobile();
    const { shouldReduceMotion, tier } = useReducedMotion();

    if (disabled || shouldReduceMotion) {
      return (
        <button ref={ref} className={className} {...(props as any)}>
          {children}
        </button>
      );
    }

    const classes = [
      className,
      isMobile ? 'active:scale-[0.97] transition-transform duration-100' : ''
    ].filter(Boolean).join(' ');

    return (
      <motion.button
        ref={ref}
        className={classes}
        whileHover={!isMobile && tier === 'high' ? (whileHover ?? { scale: 1.02 }) : undefined}
        whileTap={!isMobile && tier === 'high' ? (whileTap ?? { scale: 0.98 }) : undefined}
        {...props}
      >
        {children}
      </motion.button>
    );
  }
);

MobileMotionButton.displayName = 'MobileMotionButton';

/**
 * Hook to get optimized animation props
 */
export function useMobileAnimationProps(baseProps: MotionProps = {}): MotionProps {
  const isMobile = useIsMobile();
  const { shouldReduceMotion, durationMultiplier, tier } = useReducedMotion();

  if (shouldReduceMotion) {
    return {
      initial: false,
      animate: {},
      transition: { duration: 0 }
    };
  }

  const { whileHover, whileTap, transition, ...rest } = baseProps;

  return {
    ...rest,
    whileHover: !isMobile && tier === 'high' ? whileHover : undefined,
    whileTap: !isMobile && tier === 'high' ? whileTap : undefined,
    transition: {
      ...transition,
      duration: ((transition as any)?.duration ?? 0.3) * durationMultiplier,
      repeat: isMobile ? 0 : (transition as any)?.repeat,
    }
  };
}

export default MobileMotion;
