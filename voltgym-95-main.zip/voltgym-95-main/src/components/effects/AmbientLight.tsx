import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface AmbientLightProps {
  color?: 'accent' | 'purple' | 'blue' | 'green' | 'orange' | 'pink';
  intensity?: 'low' | 'medium' | 'high';
  size?: number;
  position?: {
    top?: string;
    left?: string;
    right?: string;
    bottom?: string;
  };
  reactive?: boolean; // Changes on hover
  className?: string;
}

export function AmbientLight({
  color = 'accent',
  intensity = 'medium',
  size = 400,
  position = { top: '-20%', left: '-10%' },
  reactive = false,
  className
}: AmbientLightProps) {
  const colorMap = {
    accent: 'hsl(var(--accent) / 0.3)',
    purple: 'hsl(var(--accent-2) / 0.25)',
    blue: 'hsl(var(--electric-blue) / 0.25)',
    green: 'hsl(142 76% 36% / 0.2)',
    orange: 'hsl(24 95% 53% / 0.25)',
    pink: 'hsl(330 85% 60% / 0.2)',
  };

  const intensityMap = {
    low: 0.5,
    medium: 0.7,
    high: 1,
  };

  const blurMap = {
    low: '60px',
    medium: '80px',
    high: '100px',
  };

  return (
    <motion.div
      className={cn('absolute pointer-events-none rounded-full', className)}
      style={{
        ...position,
        width: `${size}px`,
        height: `${size}px`,
        background: `radial-gradient(circle at center, ${colorMap[color]}, transparent 70%)`,
        filter: `blur(${blurMap[intensity]})`,
      }}
      initial={{
        scale: 1,
        opacity: intensityMap[intensity],
      }}
      animate={{
        scale: [1, 1.2, 1],
        opacity: reactive 
          ? [intensityMap[intensity], intensityMap[intensity] * 1.3, intensityMap[intensity]]
          : intensityMap[intensity],
      }}
      transition={{
        duration: 8,
        repeat: Infinity,
        ease: 'easeInOut',
      }}
    />
  );
}

// Multiple lights composition
interface AmbientLightsProps {
  className?: string;
  children?: React.ReactNode;
}

export function AmbientLights({ className, children }: AmbientLightsProps) {
  return (
    <div className={cn('relative', className)}>
      {/* Background lights */}
      <AmbientLight 
        color="accent" 
        intensity="medium" 
        size={500} 
        position={{ top: '-20%', left: '-10%' }}
      />
      <AmbientLight 
        color="purple" 
        intensity="low" 
        size={400} 
        position={{ bottom: '-10%', right: '-5%' }}
      />
      <AmbientLight 
        color="blue" 
        intensity="low" 
        size={300} 
        position={{ top: '40%', right: '-10%' }}
      />
      
      {/* Content */}
      {children}
    </div>
  );
}

// Reactive light that follows mouse (optional enhancement)
export function ReactiveAmbientLight({ color = 'accent', intensity = 'medium' }: Pick<AmbientLightProps, 'color' | 'intensity'>) {
  const [mousePosition, setMousePosition] = React.useState({ x: 0, y: 0 });
  const [isHovering, setIsHovering] = React.useState(false);

  React.useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const colorMap = {
    accent: 'hsl(var(--accent) / 0.2)',
    purple: 'hsl(var(--accent-2) / 0.18)',
    blue: 'hsl(var(--electric-blue) / 0.18)',
    green: 'hsl(142 76% 36% / 0.15)',
    orange: 'hsl(24 95% 53% / 0.18)',
    pink: 'hsl(330 85% 60% / 0.15)',
  };

  const intensityScale = {
    low: 250,
    medium: 350,
    high: 450,
  };

  return (
    <motion.div
      className="fixed pointer-events-none z-0"
      style={{
        width: `${intensityScale[intensity]}px`,
        height: `${intensityScale[intensity]}px`,
        background: `radial-gradient(circle at center, ${colorMap[color]}, transparent 70%)`,
        filter: 'blur(80px)',
        left: mousePosition.x - intensityScale[intensity] / 2,
        top: mousePosition.y - intensityScale[intensity] / 2,
      }}
      animate={{
        opacity: isHovering ? 0.8 : 0.4,
        scale: isHovering ? 1.2 : 1,
      }}
      transition={{
        opacity: { duration: 0.3 },
        scale: { duration: 0.3 },
      }}
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
    />
  );
}
