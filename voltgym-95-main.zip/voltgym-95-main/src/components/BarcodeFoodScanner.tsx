import { useState, useEffect, useRef } from 'react';
import { Camera, X, Loader2 } from 'lucide-react';
import { VoltButton } from './VoltButton';
import { VoltCard } from './VoltCard';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';
import { Html5Qrcode, Html5QrcodeSupportedFormats } from 'html5-qrcode';

interface ScannedFood {
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  barcode: string;
}

interface BarcodeFoodScannerProps {
  onScan: (food: ScannedFood) => void;
  onClose: () => void;
}

export function BarcodeFoodScanner({ onScan, onClose }: BarcodeFoodScannerProps) {
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [scannerStarted, setScannerStarted] = useState(false);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    startScanner();
    
    return () => {
      stopScanner();
    };
  }, []);

  const startScanner = async () => {
    try {
      // Check camera permission
      const devices = await Html5Qrcode.getCameras();
      
      if (!devices || devices.length === 0) {
        setHasPermission(false);
        toast.error('Nenhuma câmera encontrada');
        return;
      }
      
      setHasPermission(true);
      
      // Initialize scanner
      scannerRef.current = new Html5Qrcode('barcode-scanner-container', {
        formatsToSupport: [
          Html5QrcodeSupportedFormats.EAN_13,
          Html5QrcodeSupportedFormats.EAN_8,
          Html5QrcodeSupportedFormats.UPC_A,
          Html5QrcodeSupportedFormats.UPC_E,
          Html5QrcodeSupportedFormats.CODE_128,
          Html5QrcodeSupportedFormats.CODE_39,
        ],
        verbose: false,
      });

      await scannerRef.current.start(
        { facingMode: 'environment' },
        {
          fps: 10,
          qrbox: { width: 250, height: 150 },
        },
        handleBarCodeScanned,
        () => {} // ignore errors during scanning
      );
      
      setScannerStarted(true);
    } catch (error) {
      console.error('Scanner error:', error);
      setHasPermission(false);
      toast.error('Erro ao acessar a câmera. Verifique as permissões.');
    }
  };

  const stopScanner = async () => {
    try {
      if (scannerRef.current && scannerStarted) {
        await scannerRef.current.stop();
        scannerRef.current.clear();
      }
    } catch (error) {
      console.error('Error stopping scanner:', error);
    }
  };

  const handleBarCodeScanned = async (barcode: string) => {
    if (isLoading) return;

    setIsLoading(true);
    
    // Stop scanner while processing
    await stopScanner();

    try {
      // Buscar no Open Food Facts API
      const response = await fetch(
        `https://world.openfoodfacts.org/api/v0/product/${barcode}.json`
      );
      const data = await response.json();

      if (data.status === 1) {
        const product = data.product;
        const nutriments = product.nutriments;

        const food: ScannedFood = {
          name: product.product_name || 'Produto sem nome',
          calories: Math.round(nutriments['energy-kcal_100g'] || 0),
          protein: Math.round(nutriments.proteins_100g || 0),
          carbs: Math.round(nutriments.carbohydrates_100g || 0),
          fat: Math.round(nutriments.fat_100g || 0),
          barcode
        };

        toast.success(`Produto encontrado: ${food.name}`);
        onScan(food);
        onClose();
      } else {
        toast.error('Produto não encontrado no banco de dados Open Food Facts');
        // Restart scanner
        await startScanner();
      }
    } catch (error) {
      console.error('Barcode scan error:', error);
      toast.error('Erro ao buscar informações do produto');
      // Restart scanner
      await startScanner();
    } finally {
      setIsLoading(false);
    }
  };

  // Demo mode para testing
  const handleManualInput = () => {
    const testBarcode = '7896005206706'; // Exemplo: Whey Protein brasileiro
    handleBarCodeScanned(testBarcode);
  };

  const handleClose = async () => {
    await stopScanner();
    onClose();
  };

  if (hasPermission === null) {
    return (
      <VoltCard className="p-8 text-center">
        <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-accent" />
        <p className="text-txt-2">Iniciando câmera...</p>
      </VoltCard>
    );
  }

  if (hasPermission === false) {
    return (
      <VoltCard className="p-8 text-center space-y-4">
        <Camera className="w-12 h-12 mx-auto text-txt-2" />
        <div>
          <h3 className="font-bold text-txt mb-2">Permissão Negada</h3>
          <p className="text-sm text-txt-2">
            Precisamos de acesso à câmera para escanear códigos de barras.
            Por favor, habilite nas configurações do dispositivo.
          </p>
        </div>
        <div className="flex gap-2 justify-center">
          <VoltButton onClick={handleClose} variant="secondary">Voltar</VoltButton>
          <VoltButton onClick={handleManualInput}>Testar Demo</VoltButton>
        </div>
      </VoltCard>
    );
  }

  return (
    <div className="relative">
      {/* Camera View */}
      <div className="relative aspect-[4/3] bg-black rounded-xl overflow-hidden">
        <div 
          id="barcode-scanner-container" 
          ref={containerRef}
          className="w-full h-full"
        />

        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 z-10 w-10 h-10 bg-black/50 rounded-full flex items-center justify-center backdrop-blur-sm"
        >
          <X className="w-5 h-5 text-white" />
        </button>
      </div>

      {/* Status */}
      <AnimatePresence>
        {isLoading && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mt-4 p-4 bg-accent/10 rounded-xl border border-accent/30 text-center"
          >
            <Loader2 className="w-5 h-5 animate-spin mx-auto mb-2 text-accent" />
            <p className="text-sm text-txt">Buscando informações do produto...</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Instructions & Demo Button */}
      <div className="mt-4 space-y-3">
        <p className="text-center text-sm text-txt-2">
          Posicione o código de barras dentro do quadrado
        </p>

        <VoltButton
          onClick={handleManualInput}
          variant="secondary"
          className="w-full"
          disabled={isLoading}
        >
          🧪 Testar com código exemplo
        </VoltButton>
      </div>
    </div>
  );
}
