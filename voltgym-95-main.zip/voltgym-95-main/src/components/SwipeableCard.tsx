import React, { useState } from 'react';
import { motion, PanInfo, useMotionValue, useTransform } from 'framer-motion';
import { Trash2, Share2, Edit3 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useVibration } from '@/hooks/useVibration';

interface SwipeAction {
  icon: React.ReactNode;
  label: string;
  color: string;
  onAction: () => void;
}

interface SwipeableCardProps {
  children: React.ReactNode;
  leftAction?: SwipeAction;
  rightAction?: SwipeAction;
  threshold?: number;
  className?: string;
}

export function SwipeableCard({
  children,
  leftAction,
  rightAction,
  threshold = 100,
  className
}: SwipeableCardProps) {
  const [isDragging, setIsDragging] = useState(false);
  const { vibratePulse } = useVibration();
  const x = useMotionValue(0);
  
  const opacity = useTransform(x, [-threshold, 0, threshold], [1, 0, 1]);
  const scale = useTransform(x, [-threshold, 0, threshold], [1.1, 1, 1.1]);

  const handleDragStart = () => {
    setIsDragging(true);
  };

  const handleDragEnd = (_: any, info: PanInfo) => {
    setIsDragging(false);
    const offset = info.offset.x;

    if (Math.abs(offset) >= threshold) {
      vibratePulse();
      
      if (offset > 0 && leftAction) {
        leftAction.onAction();
      } else if (offset < 0 && rightAction) {
        rightAction.onAction();
      }
    }

    x.set(0);
  };

  return (
    <div className="relative overflow-hidden">
      {/* Left action background */}
      {leftAction && (
        <motion.div
          className={cn(
            'absolute left-0 top-0 bottom-0 w-24 flex items-center justify-start pl-6',
            leftAction.color
          )}
          style={{ opacity, scale }}
        >
          {leftAction.icon}
        </motion.div>
      )}

      {/* Right action background */}
      {rightAction && (
        <motion.div
          className={cn(
            'absolute right-0 top-0 bottom-0 w-24 flex items-center justify-end pr-6',
            rightAction.color
          )}
          style={{ opacity, scale }}
        >
          {rightAction.icon}
        </motion.div>
      )}

      {/* Card content */}
      <motion.div
        drag="x"
        dragDirectionLock
        dragConstraints={{ left: 0, right: 0 }}
        dragElastic={0.2}
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
        style={{ x }}
        className={cn(
          'relative z-10 bg-bg',
          isDragging && 'cursor-grabbing',
          className
        )}
      >
        {children}
      </motion.div>
    </div>
  );
}

// Preset actions
export const deleteAction: SwipeAction = {
  icon: <Trash2 className="w-6 h-6 text-white" />,
  label: 'Deletar',
  color: 'bg-error',
  onAction: () => console.log('Delete')
};

export const shareAction: SwipeAction = {
  icon: <Share2 className="w-6 h-6 text-white" />,
  label: 'Compartilhar',
  color: 'bg-accent',
  onAction: () => console.log('Share')
};

export const editAction: SwipeAction = {
  icon: <Edit3 className="w-6 h-6 text-white" />,
  label: 'Editar',
  color: 'bg-warning',
  onAction: () => console.log('Edit')
};
