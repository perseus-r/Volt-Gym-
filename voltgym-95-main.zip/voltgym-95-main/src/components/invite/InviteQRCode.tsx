import { QRCodeSVG } from 'qrcode.react';
import { Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface InviteQRCodeProps {
  url: string;
  size?: number;
}

export default function InviteQRCode({ url, size = 180 }: InviteQRCodeProps) {
  const handleDownload = () => {
    const svg = document.getElementById('invite-qr-code');
    if (!svg) return;

    const svgData = new XMLSerializer().serializeToString(svg);
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();

    img.onload = () => {
      canvas.width = size * 2;
      canvas.height = size * 2;
      ctx?.fillRect(0, 0, canvas.width, canvas.height);
      ctx!.fillStyle = 'white';
      ctx?.fillRect(0, 0, canvas.width, canvas.height);
      ctx?.drawImage(img, 0, 0, canvas.width, canvas.height);
      
      const pngUrl = canvas.toDataURL('image/png');
      const downloadLink = document.createElement('a');
      downloadLink.href = pngUrl;
      downloadLink.download = 'convite-qrcode.png';
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      
      toast.success('QR Code baixado!');
    };

    img.src = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgData)));
  };

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="p-4 bg-white rounded-xl shadow-sm">
        <QRCodeSVG
          id="invite-qr-code"
          value={url}
          size={size}
          level="H"
          includeMargin={false}
        />
      </div>
      <Button
        variant="outline"
        size="sm"
        onClick={handleDownload}
        className="gap-2"
        data-qr-download
      >
        <Download className="w-4 h-4" />
        Baixar QR Code
      </Button>
    </div>
  );
}
