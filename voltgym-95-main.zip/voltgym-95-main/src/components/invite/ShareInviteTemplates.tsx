import { useState } from 'react';
import { Copy, Check, MessageCircle, Instagram, Share2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface ShareInviteTemplatesProps {
  inviteUrl: string;
  brandName: string;
}

export default function ShareInviteTemplates({ inviteUrl, brandName }: ShareInviteTemplatesProps) {
  const [copiedTemplate, setCopiedTemplate] = useState<string | null>(null);

  const templates = {
    whatsapp: {
      icon: MessageCircle,
      label: 'WhatsApp',
      color: '#25D366',
      message: `🏋️ *Convite para Treinar!*

Olá! Você foi convidado para treinar com ${brandName}.

📲 Acesse: ${inviteUrl}

Vamos juntos alcançar seus objetivos! 💪`
    },
    instagram: {
      icon: Instagram,
      label: 'Instagram',
      color: '#E4405F',
      message: `🔥 Comece a treinar comigo!

Link: ${inviteUrl}

#fitness #treino #personaltrainer`
    },
    generic: {
      icon: Share2,
      label: 'Geral',
      color: 'hsl(var(--accent))',
      message: `Convite para treinar com ${brandName}

Acesse: ${inviteUrl}`
    }
  };

  const handleCopy = async (templateKey: string, message: string) => {
    try {
      await navigator.clipboard.writeText(message);
      setCopiedTemplate(templateKey);
      toast.success('Mensagem copiada!');
      
      setTimeout(() => setCopiedTemplate(null), 2000);
    } catch (err) {
      toast.error('Erro ao copiar');
    }
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(inviteUrl);
      toast.success('Link copiado!');
    } catch (err) {
      toast.error('Erro ao copiar');
    }
  };

  const handleWhatsAppShare = () => {
    const message = encodeURIComponent(templates.whatsapp.message);
    window.open(`https://wa.me/?text=${message}`, '_blank');
  };

  return (
    <div className="space-y-4">
      {/* Link direto */}
      <div className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
        <input
          type="text"
          value={inviteUrl}
          readOnly
          className="flex-1 bg-transparent text-sm font-mono outline-none"
        />
        <Button size="sm" variant="outline" onClick={handleCopyLink}>
          <Copy className="w-4 h-4" />
        </Button>
      </div>

      {/* Templates de compartilhamento */}
      <div className="grid grid-cols-1 gap-3">
        {Object.entries(templates).map(([key, template]) => {
          const Icon = template.icon;
          const isCopied = copiedTemplate === key;
          
          return (
            <div 
              key={key}
              className="p-4 rounded-lg border border-border bg-card"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div 
                    className="w-8 h-8 rounded-full flex items-center justify-center"
                    style={{ backgroundColor: `${template.color}20` }}
                  >
                    <Icon className="w-4 h-4" style={{ color: template.color }} />
                  </div>
                  <span className="font-medium text-sm">{template.label}</span>
                </div>
                <div className="flex gap-2">
                  {key === 'whatsapp' && (
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={handleWhatsAppShare}
                      className="text-xs"
                    >
                      Abrir WhatsApp
                    </Button>
                  )}
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => handleCopy(key, template.message)}
                    className="text-xs"
                  >
                    {isCopied ? (
                      <>
                        <Check className="w-3 h-3 mr-1" />
                        Copiado
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3 mr-1" />
                        Copiar
                      </>
                    )}
                  </Button>
                </div>
              </div>
              <pre className="text-xs text-muted-foreground whitespace-pre-wrap bg-muted/30 p-3 rounded-md">
                {template.message}
              </pre>
            </div>
          );
        })}
      </div>
    </div>
  );
}
