import { useState, useEffect } from 'react';
import { Check, X, Loader2, Save } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { logger } from '@/utils/logger';
import ShortenedLinkDisplay from './ShortenedLinkDisplay';

interface SlugConfigFormProps {
  currentSlug?: string | null;
  onSlugSaved?: (slug: string) => void;
}

export default function SlugConfigForm({ currentSlug, onSlugSaved }: SlugConfigFormProps) {
  const { user } = useAuth();
  const [slug, setSlug] = useState(currentSlug || '');
  const [isAvailable, setIsAvailable] = useState<boolean | null>(null);
  const [checking, setChecking] = useState(false);
  const [saving, setSaving] = useState(false);

  const baseUrl = window.location.origin;

  // Sincronizar quando currentSlug muda (ex: após carregar do banco)
  useEffect(() => {
    logger.log('SlugConfigForm: currentSlug changed:', currentSlug);
    if (currentSlug) {
      setSlug(currentSlug);
    }
  }, [currentSlug]);

  // Debug logging
  useEffect(() => {
    logger.log('SlugConfigForm state:', { slug, currentSlug, isAvailable, checking, saving, user: user?.id });
  }, [slug, currentSlug, isAvailable, checking, saving, user]);

  // Formatar slug: minúsculas, remover espaços, apenas letras/números/hífens
  const formatSlug = (value: string) => {
    return value
      .toLowerCase()
      .replace(/\s+/g, '-')
      .replace(/[^a-z0-9-]/g, '')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '');
  };

  // Verificar disponibilidade com debounce
  useEffect(() => {
    const formattedSlug = formatSlug(slug);
    
    if (formattedSlug.length < 3) {
      setIsAvailable(null);
      return;
    }

    // Se é o mesmo slug atual, está disponível
    if (currentSlug && formattedSlug === currentSlug.toLowerCase()) {
      setIsAvailable(true);
      return;
    }

    const timer = setTimeout(async () => {
      setChecking(true);
      
      try {
        const { data, error } = await supabase
          .from('personal_trainer_profiles')
          .select('id')
          .eq('invite_slug', formattedSlug)
          .maybeSingle();

        if (error) throw error;
        setIsAvailable(!data);
      } catch (err) {
        logger.error('Error checking slug:', err);
        setIsAvailable(null);
      } finally {
        setChecking(false);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [slug, currentSlug]);

  const handleSave = async () => {
    const formattedSlug = formatSlug(slug);
    
    if (formattedSlug.length < 3) {
      toast.error('O slug deve ter no mínimo 3 caracteres');
      return;
    }

    if (!isAvailable) {
      toast.error('Este slug não está disponível');
      return;
    }

    setSaving(true);

    try {
      const { error } = await supabase
        .from('personal_trainer_profiles')
        .update({ invite_slug: formattedSlug })
        .eq('user_id', user?.id);

      if (error) throw error;

      toast.success('Link personalizado salvo!');
      onSlugSaved?.(formattedSlug);
    } catch (err) {
      logger.error('Error saving slug:', err);
      toast.error('Erro ao salvar link');
    } finally {
      setSaving(false);
    }
  };

  const formattedSlug = formatSlug(slug);
  const fullUrl = `${baseUrl}/convite/${formattedSlug}`;
  const canSave = formattedSlug.length >= 3 && isAvailable && formattedSlug !== currentSlug?.toLowerCase();

  return (
    <div className="space-y-4">
      <div>
        <Label className="text-sm font-medium mb-2 block">
          Digite seu identificador personalizado
        </Label>
        <p className="text-xs text-muted-foreground mb-3">
          Exemplo: joao-fitness, personal-maria, etc.
        </p>
        
        <div className="flex items-center gap-2">
          <div className="flex-1 flex items-center bg-secondary border border-border rounded-lg overflow-hidden">
            <span className="px-3 py-2.5 text-sm text-muted-foreground bg-muted border-r border-border">
              /convite/
            </span>
            <Input
              value={slug}
              onChange={(e) => {
                logger.log('SlugConfigForm: Input changed:', e.target.value);
                setSlug(e.target.value);
              }}
              onFocus={() => logger.log('SlugConfigForm: Input focused')}
              placeholder="seu-nome"
              className="border-0 bg-transparent text-foreground placeholder:text-muted-foreground focus-visible:ring-0 focus-visible:ring-offset-0"
            />
            <div className="px-3">
              {checking ? (
                <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
              ) : isAvailable === true ? (
                <Check className="w-4 h-4 text-success" />
              ) : isAvailable === false ? (
                <X className="w-4 h-4 text-destructive" />
              ) : null}
            </div>
          </div>
          <Button
            onClick={handleSave}
            disabled={!canSave || saving}
            size="sm"
          >
            {saving ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Save className="w-4 h-4" />
            )}
          </Button>
        </div>
      </div>

      {/* Status */}
      <div className="text-xs">
        {formattedSlug.length > 0 && formattedSlug.length < 3 && (
          <p className="text-warning">Mínimo 3 caracteres</p>
        )}
        {isAvailable === false && (
          <p className="text-destructive">Este link já está em uso</p>
        )}
        {isAvailable === true && formattedSlug.length >= 3 && (
          <p className="text-success">Disponível!</p>
        )}
      </div>

      {/* Shortened Link & QR Code */}
      {formattedSlug.length >= 3 && (
        <ShortenedLinkDisplay originalUrl={fullUrl} slug={formattedSlug} />
      )}
    </div>
  );
}
