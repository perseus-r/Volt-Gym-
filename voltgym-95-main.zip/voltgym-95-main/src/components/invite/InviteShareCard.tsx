import { useState } from 'react';
import { Share2, MessageCircle, Download, ChevronDown, ChevronUp, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import InviteQRCode from './InviteQRCode';

interface InviteShareCardProps {
  url: string;
  trainerName?: string;
}

export default function InviteShareCard({ url, trainerName }: InviteShareCardProps) {
  const [showLink, setShowLink] = useState(false);
  const [copied, setCopied] = useState(false);

  const shareText = trainerName 
    ? `Você foi convidado para treinar com ${trainerName}! 💪`
    : 'Você foi convidado para treinar! 💪';

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Convite para Treinar',
          text: shareText,
          url: url
        });
        toast.success('Compartilhado!');
      } catch (err) {
        // User cancelled or share failed - fallback to copy
        if ((err as Error).name !== 'AbortError') {
          handleCopy();
        }
      }
    } else {
      // Fallback for desktop
      handleCopy();
    }
  };

  const handleWhatsApp = () => {
    const message = encodeURIComponent(`${shareText}\n\n${url}`);
    window.open(`https://wa.me/?text=${message}`, '_blank');
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(url);
    setCopied(true);
    toast.success('Link copiado!');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-6 bg-secondary/30 border border-border rounded-2xl">
      {/* Header */}
      <div className="text-center mb-6">
        <h3 className="text-lg font-semibold text-foreground">
          Compartilhe seu Convite
        </h3>
        <p className="text-sm text-muted-foreground mt-1">
          Use o QR Code ou compartilhe diretamente
        </p>
      </div>

      {/* QR Code - Large and prominent */}
      <div className="flex justify-center mb-6">
        <InviteQRCode url={url} size={200} />
      </div>

      {/* Main action buttons */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <Button 
          onClick={handleNativeShare}
          className="h-12 gap-2 text-sm font-medium"
          variant="default"
        >
          <Share2 className="w-5 h-5" />
          Compartilhar
        </Button>
        <Button 
          onClick={handleWhatsApp}
          className="h-12 gap-2 text-sm font-medium bg-[#25D366] hover:bg-[#20BD5A] text-white"
        >
          <MessageCircle className="w-5 h-5" />
          WhatsApp
        </Button>
      </div>

      {/* Secondary action - Download QR */}
      <Button
        variant="outline"
        onClick={() => {
          const downloadBtn = document.querySelector('[data-qr-download]') as HTMLButtonElement;
          downloadBtn?.click();
        }}
        className="w-full h-11 gap-2 text-sm"
      >
        <Download className="w-4 h-4" />
        Baixar QR Code
      </Button>

      {/* Toggle to show/hide link */}
      <button
        onClick={() => setShowLink(!showLink)}
        className="w-full mt-4 flex items-center justify-center gap-2 py-2 text-xs text-muted-foreground hover:text-foreground transition-colors"
      >
        {showLink ? (
          <>
            <ChevronUp className="w-4 h-4" />
            Ocultar link
          </>
        ) : (
          <>
            <ChevronDown className="w-4 h-4" />
            Ver link completo
          </>
        )}
      </button>

      {/* Collapsible link section */}
      {showLink && (
        <div className="mt-2 p-3 bg-background/50 border border-border rounded-lg">
          <div className="flex items-center gap-2">
            <p className="flex-1 text-xs font-mono text-muted-foreground break-all">
              {url}
            </p>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleCopy}
              className="shrink-0 h-8 w-8 p-0"
            >
              {copied ? (
                <Check className="w-4 h-4 text-green-500" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
