import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import InviteShareCard from './InviteShareCard';

interface ShortenedLinkDisplayProps {
  originalUrl: string;
  slug: string;
}

interface ShortLinkRecord {
  code: string;
}

// Generate a random short code
function generateShortCode(length = 6): string {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

export default function ShortenedLinkDisplay({ originalUrl, slug }: ShortenedLinkDisplayProps) {
  const [shortUrl, setShortUrl] = useState<string | null>(null);
  const { user } = useAuth();

  // Auto-create or fetch existing short link on mount
  useEffect(() => {
    async function getOrCreateShortLink() {
      if (!user || !slug || slug.length < 3) return;
      
      // Check for existing short link
      const { data } = await supabase
        .from('short_links' as any)
        .select('code')
        .eq('trainer_id', user.id)
        .eq('original_url', originalUrl)
        .single() as { data: ShortLinkRecord | null; error: any };

      if (data?.code) {
        setShortUrl(`${window.location.origin}/s/${data.code}`);
        return;
      }

      // Auto-create new short link
      let code = generateShortCode();
      let attempts = 0;
      
      while (attempts < 5) {
        const { data: existing } = await supabase
          .from('short_links' as any)
          .select('code')
          .eq('code', code)
          .single() as { data: ShortLinkRecord | null; error: any };
        
        if (!existing) break;
        code = generateShortCode();
        attempts++;
      }

      const { error } = await supabase
        .from('short_links' as any)
        .insert({
          code,
          original_url: originalUrl,
          trainer_id: user.id
        });

      if (!error) {
        setShortUrl(`${window.location.origin}/s/${code}`);
      }
    }

    getOrCreateShortLink();
  }, [user, originalUrl, slug]);

  // Don't render if slug is not configured
  if (!slug || slug.length < 3) return null;

  // Use short URL if available, otherwise fall back to original
  const displayUrl = shortUrl || originalUrl;

  return <InviteShareCard url={displayUrl} />;
}
