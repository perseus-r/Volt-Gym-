import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useProfileCheck } from '@/hooks/useProfileCheck';
import { PageBuildingTransition } from './transitions/PageBuildingTransition';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiresProfile?: boolean;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ 
  children, 
  requiresProfile = true 
}) => {
  const { user, loading: authLoading } = useAuth();
  const { profileComplete, loading: profileLoading } = useProfileCheck();

  // Page building transition while loading
  if (authLoading || (requiresProfile && profileLoading)) {
    return <PageBuildingTransition />;
  }

  // No user - redirect to auth
  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  // Profile incomplete - redirect to onboarding
  if (requiresProfile && profileComplete === false) {
    return <Navigate to="/onboarding" replace />;
  }

  // All checks passed
  return <>{children}</>;
};