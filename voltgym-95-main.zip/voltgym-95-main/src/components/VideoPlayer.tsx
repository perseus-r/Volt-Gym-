import React, { useState, useRef } from 'react';
import { Play, Dumbbell, Pause, Volume2, VolumeX } from 'lucide-react';

interface VideoPlayerProps {
  url: string | null;
  title?: string;
  className?: string;
  aspectRatio?: 'video' | 'square' | '4/3';
  fallbackThumbnail?: string | null;
  clickToPlay?: boolean;
  autoPlay?: boolean;
  loop?: boolean;
  muted?: boolean;
  onLoad?: () => void;
  onError?: () => void;
}

type VideoType = 'youtube' | 'direct' | 'unknown';

function detectVideoType(url: string | null): VideoType {
  if (!url) return 'unknown';
  
  // YouTube patterns
  if (url.match(/(?:youtube\.com|youtu\.be)/i)) {
    return 'youtube';
  }
  
  // Direct video patterns (mp4, webm, ogg, etc.)
  if (url.match(/\.(mp4|webm|ogg|mov)(\?|$)/i) || url.includes('video')) {
    return 'direct';
  }
  
  return 'unknown';
}

function getYouTubeEmbedUrl(url: string | null): string | null {
  if (!url) return null;
  const match = url.match(
    /(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/
  );
  return match ? `https://www.youtube.com/embed/${match[1]}` : null;
}

function getYouTubeThumbnail(url: string | null): string | null {
  if (!url) return null;
  const match = url.match(
    /(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/
  );
  return match ? `https://img.youtube.com/vi/${match[1]}/hqdefault.jpg` : null;
}

export function VideoPlayer({ 
  url, 
  title = 'Video', 
  className = '',
  aspectRatio = 'video',
  fallbackThumbnail,
  clickToPlay = true,
  autoPlay = true,
  loop = true,
  muted: mutedProp = true,
  onLoad,
  onError,
}: VideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(!clickToPlay);
  const [isMuted, setIsMuted] = useState(mutedProp);
  const videoRef = useRef<HTMLVideoElement>(null);
  
  const videoType = detectVideoType(url);
  const embedUrl = getYouTubeEmbedUrl(url);
  const youtubeThumbnail = getYouTubeThumbnail(url);
  
  const aspectClasses = {
    'video': 'aspect-video',
    'square': 'aspect-square',
    '4/3': 'aspect-[4/3]'
  };

  const handlePlayClick = () => {
    setIsPlaying(true);
  };

  const handleVideoClick = () => {
    if (videoRef.current) {
      if (videoRef.current.paused) {
        videoRef.current.play();
      } else {
        videoRef.current.pause();
      }
    }
  };

  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsMuted(!isMuted);
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
    }
  };

  // No valid URL - show fallback
  if (!url || (videoType === 'youtube' && !embedUrl)) {
    return (
      <div className={`${aspectClasses[aspectRatio]} bg-muted rounded-lg flex items-center justify-center ${className}`}>
        {fallbackThumbnail ? (
          <img 
            src={fallbackThumbnail} 
            alt={title} 
            className="w-full h-full object-cover rounded-lg"
          />
        ) : (
          <Dumbbell className="h-12 w-12 text-muted-foreground" />
        )}
      </div>
    );
  }

  // YouTube video
  if (videoType === 'youtube') {
    // Click-to-play overlay for YouTube
    if (clickToPlay && !isPlaying) {
      const thumbnail = youtubeThumbnail || fallbackThumbnail;
      return (
        <div 
          className={`${aspectClasses[aspectRatio]} rounded-lg overflow-hidden relative cursor-pointer group ${className}`}
          onClick={handlePlayClick}
        >
          {thumbnail ? (
            <img 
              src={thumbnail} 
              alt={title} 
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-muted flex items-center justify-center">
              <Dumbbell className="h-12 w-12 text-muted-foreground" />
            </div>
          )}
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center group-hover:bg-black/50 transition-colors">
            <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
              <Play className="w-8 h-8 text-primary-foreground ml-1" fill="currentColor" />
            </div>
          </div>
        </div>
      );
    }

    // YouTube iframe
    return (
      <div className={`${aspectClasses[aspectRatio]} rounded-lg overflow-hidden ${className}`}>
        <iframe
          src={`${embedUrl}?autoplay=1&mute=1`}
          title={title}
          className="w-full h-full"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
          loading="lazy"
        />
      </div>
    );
  }

  // Direct video (MP4, WebM, etc.)
  if (videoType === 'direct') {
    // Click-to-play overlay for direct video
    if (clickToPlay && !isPlaying) {
      return (
        <div 
          className={`${aspectClasses[aspectRatio]} rounded-lg overflow-hidden relative cursor-pointer group ${className}`}
          onClick={handlePlayClick}
        >
          {fallbackThumbnail ? (
            <img 
              src={fallbackThumbnail} 
              alt={title} 
              className="w-full h-full object-cover"
            />
          ) : (
            <video 
              src={url}
              className="w-full h-full object-cover"
              muted
              playsInline
              preload="metadata"
            />
          )}
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center group-hover:bg-black/50 transition-colors">
            <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
              <Play className="w-8 h-8 text-primary-foreground ml-1" fill="currentColor" />
            </div>
          </div>
        </div>
      );
    }

    // HTML5 video player
    return (
      <div className={`${aspectClasses[aspectRatio]} rounded-lg overflow-hidden relative ${className}`}>
        <video
          ref={videoRef}
          src={url}
          className="w-full h-full object-cover cursor-pointer"
          autoPlay={autoPlay}
          muted={isMuted}
          loop={loop}
          playsInline
          onClick={handleVideoClick}
          onLoadedData={onLoad}
          onError={onError}
        />
        <button
          onClick={toggleMute}
          className="absolute bottom-3 right-3 w-10 h-10 rounded-full bg-black/60 flex items-center justify-center hover:bg-black/80 transition-colors"
        >
          {isMuted ? (
            <VolumeX className="w-5 h-5 text-white" />
          ) : (
            <Volume2 className="w-5 h-5 text-white" />
          )}
        </button>
      </div>
    );
  }

  // Unknown video type - try as direct video
  return (
    <div className={`${aspectClasses[aspectRatio]} bg-muted rounded-lg flex items-center justify-center ${className}`}>
      <Dumbbell className="h-12 w-12 text-muted-foreground" />
    </div>
  );
}
