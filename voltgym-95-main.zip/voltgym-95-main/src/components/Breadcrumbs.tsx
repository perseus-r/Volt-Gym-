import { ChevronRight, Home } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';

export function Breadcrumbs() {
  const location = useLocation();
  
  const pathSegments = location.pathname.split('/').filter(Boolean);
  
  const breadcrumbLabels: Record<string, string> = {
    'pt': 'Personal Trainer',
    'admin': 'Administração',
    'athlete': 'Atleta',
    'athletes': 'Alunos',
    'invite': 'Convidar',
    'templates': 'Templates',
    'analytics': 'Analytics',
    'dashboard': 'Dashboard',
    'workouts': 'Treinos',
    'settings': 'Configurações'
  };

  if (pathSegments.length === 0) return null;

  return (
    <nav className="flex items-center gap-2 text-sm mb-6">
      <Link 
        to="/dashboard" 
        className="flex items-center gap-1 text-txt-3 hover:text-accent transition-colors"
      >
        <Home className="w-4 h-4" />
        <span>Home</span>
      </Link>
      
      {pathSegments.map((segment, index) => {
        const path = '/' + pathSegments.slice(0, index + 1).join('/');
        const isLast = index === pathSegments.length - 1;
        const label = breadcrumbLabels[segment] || segment;

        return (
          <div key={path} className="flex items-center gap-2">
            <ChevronRight className="w-4 h-4 text-txt-3" />
            {isLast ? (
              <span className="text-accent font-medium">{label}</span>
            ) : (
              <Link 
                to={path} 
                className="text-txt-3 hover:text-accent transition-colors"
              >
                {label}
              </Link>
            )}
          </div>
        );
      })}
    </nav>
  );
}
