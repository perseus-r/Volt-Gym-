import React from 'react';
import { motion } from 'framer-motion';
import { LucideIcon } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { scaleVariants, staggerContainer, listItemVariants } from '@/utils/motion-variants';
import { logger } from '@/utils/logger';

interface PremiumEmptyStateProps {
  icon?: LucideIcon;
  title: string;
  description: string;
  action?: {
    label: string;
    onClick: () => void;
    icon?: LucideIcon;
  };
  suggestions?: string[];
  className?: string;
  variant?: 'default' | 'minimal' | 'illustrated';
}

export function PremiumEmptyState({
  icon: Icon,
  title,
  description,
  action,
  suggestions,
  className,
  variant = 'default',
}: PremiumEmptyStateProps) {
  return (
    <motion.div
      className={cn(
        'flex flex-col items-center justify-center text-center px-6 py-12 md:py-16',
        variant === 'default' && 'depth-1 rounded-custom',
        className
      )}
      variants={scaleVariants}
      initial="initial"
      animate="animate"
    >
      {/* Icon with glow */}
      {Icon && (
        <motion.div
          className="relative mb-6"
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{
            type: 'spring',
            stiffness: 260,
            damping: 20,
            delay: 0.1,
          }}
        >
          <div className="absolute inset-0 bg-accent/20 blur-3xl rounded-full" />
          <div className="relative w-20 h-20 md:w-24 md:h-24 rounded-full bg-gradient-primary flex items-center justify-center shadow-glow">
            <Icon className="w-10 h-10 md:w-12 md:h-12 text-accent-ink" strokeWidth={1.5} />
          </div>
        </motion.div>
      )}

      {/* Title */}
      <motion.h3
        className="text-2xl md:text-3xl font-bold text-txt mb-3"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        {title}
      </motion.h3>

      {/* Description */}
      <motion.p
        className="text-txt-2 text-base md:text-lg max-w-md mb-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        {description}
      </motion.p>

      {/* Action Button */}
      {action && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.4 }}
        >
          <Button
            onClick={action.onClick}
            size="lg"
            className="shadow-glow hover:shadow-[0_0_50px_hsl(var(--accent)/0.4)]"
          >
            {action.icon && <action.icon className="w-5 h-5" />}
            {action.label}
          </Button>
        </motion.div>
      )}

      {/* Suggestions */}
      {suggestions && suggestions.length > 0 && (
        <motion.div
          className="mt-10 w-full max-w-lg"
          variants={staggerContainer}
          initial="initial"
          animate="animate"
        >
          <p className="text-sm font-semibold text-txt-2 mb-4">Sugestões:</p>
          <div className="space-y-2">
            {suggestions.map((suggestion, index) => (
              <motion.div
                key={index}
                className="depth-1 rounded-lg px-4 py-3 text-left text-sm text-txt-2 hover:bg-surface/80 transition-colors cursor-default"
                variants={listItemVariants}
                whileHover={{ scale: 1.02, x: 4 }}
              >
                <span className="text-accent mr-2">•</span>
                {suggestion}
              </motion.div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Floating particles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(3)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-accent/30 rounded-full blur-sm"
            style={{
              left: `${20 + i * 30}%`,
              top: `${30 + i * 20}%`,
            }}
            animate={{
              y: [-20, 20, -20],
              opacity: [0.2, 0.5, 0.2],
            }}
            transition={{
              duration: 3 + i,
              repeat: Infinity,
              ease: 'easeInOut',
              delay: i * 0.5,
            }}
          />
        ))}
      </div>
    </motion.div>
  );
}

// Preset empty states
export function EmptyWorkouts() {
  const { Dumbbell } = require('lucide-react');
  
  return (
    <PremiumEmptyState
      icon={Dumbbell}
      title="Nenhum treino criado"
      description="Comece sua jornada criando seu primeiro treino personalizado com nossa IA Coach."
      action={{
        label: 'Criar Primeiro Treino',
        onClick: () => logger.log('Navigate to create workout'),
      }}
      suggestions={[
        'Use a IA para gerar treinos baseados nos seus objetivos',
        'Escolha entre templates prontos para iniciantes',
        'Importe treinos da comunidade',
      ]}
    />
  );
}

export function EmptyProgress() {
  const { TrendingUp } = require('lucide-react');
  
  return (
    <PremiumEmptyState
      icon={TrendingUp}
      title="Sem dados de progresso"
      description="Complete seu primeiro treino para começar a acompanhar sua evolução."
      suggestions={[
        'Registre seus treinos diariamente',
        'Tire fotos de progresso semanalmente',
        'Monitore suas métricas de performance',
      ]}
    />
  );
}

export function EmptyNutrition() {
  const { Apple } = require('lucide-react');
  
  return (
    <PremiumEmptyState
      icon={Apple}
      title="Plano nutricional não configurado"
      description="Configure seu plano alimentar para otimizar seus resultados."
      action={{
        label: 'Configurar Nutrição',
        onClick: () => logger.log('Navigate to nutrition setup'),
      }}
      suggestions={[
        'Calcule suas necessidades calóricas',
        'Defina suas macros ideais',
        'Receba sugestões de refeições',
      ]}
    />
  );
}

export function EmptyCommunity() {
  const { Users } = require('lucide-react');
  
  return (
    <PremiumEmptyState
      icon={Users}
      title="Nenhuma publicação ainda"
      description="Seja o primeiro a compartilhar sua jornada com a comunidade VoltGym."
      action={{
        label: 'Fazer Primeira Publicação',
        onClick: () => logger.log('Create post'),
      }}
      suggestions={[
        'Compartilhe seu progresso',
        'Inspire outros atletas',
        'Receba feedback da comunidade',
      ]}
    />
  );
}

export function EmptySearch({ searchTerm }: { searchTerm: string }) {
  const { Search } = require('lucide-react');
  
  return (
    <PremiumEmptyState
      icon={Search}
      title="Nenhum resultado encontrado"
      description={`Não encontramos nada para "${searchTerm}". Tente buscar com outros termos.`}
      suggestions={[
        'Verifique a ortografia',
        'Use termos mais gerais',
        'Tente sinônimos ou palavras relacionadas',
      ]}
      variant="minimal"
    />
  );
}
