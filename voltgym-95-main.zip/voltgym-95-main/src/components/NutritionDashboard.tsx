import React, { useState, useEffect, useCallback, useMemo } from "react";
import { motion } from "framer-motion";
import { Camera, Plus, TrendingUp, Utensils, Flame, Activity } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Progress } from "./ui/progress";

interface NutritionGoals {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

interface DailyIntake {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

interface NutritionLog {
  id: string;
  meal_type: string;
  food_name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  created_at: string;
}

export const NutritionDashboard = React.memo(function NutritionDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [goals, setGoals] = useState<NutritionGoals>({
    calories: 2000,
    protein: 150,
    carbs: 200,
    fat: 60
  });
  const [dailyIntake, setDailyIntake] = useState<DailyIntake>({
    calories: 0,
    protein: 0,
    carbs: 0,
    fat: 0
  });
  const [todayLogs, setTodayLogs] = useState<NutritionLog[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showManualEntry, setShowManualEntry] = useState(false);

  useEffect(() => {
    if (!user) return;
    loadTodayNutrition();
    calculateGoals();
  }, [user]);

  const calculateGoals = async () => {
    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('weight, height, age, goal')
        .eq('user_id', user!.id)
        .single();

      if (!profile) return;

      // Calcular TMB e TDEE via função do banco
      const { data: tmbData } = await supabase.rpc('calculate_tmb', {
        weight_kg: profile.weight || 70,
        height_cm: profile.height || 175,
        age_years: profile.age || 25,
        sex: 'M' // TODO: pegar do perfil
      });

      const { data: tdeeData } = await supabase.rpc('calculate_tdee', {
        tmb: tmbData,
        activity_level: 'moderate'
      });

      const tdee = tdeeData || 2000;

      // Ajustar calorias baseado no objetivo
      let calorieGoal = tdee;
      if (profile.goal === 'gordura') calorieGoal -= 500; // Déficit
      if (profile.goal === 'massa') calorieGoal += 300; // Superávit

      // Calcular macros (40/30/30 para hipertrofia, 35/40/25 para cutting)
      const isBuilding = profile.goal === 'massa';
      const proteinCals = calorieGoal * (isBuilding ? 0.30 : 0.40);
      const carbsCals = calorieGoal * (isBuilding ? 0.40 : 0.35);
      const fatCals = calorieGoal * (isBuilding ? 0.30 : 0.25);

      setGoals({
        calories: Math.round(calorieGoal),
        protein: Math.round(proteinCals / 4), // 4 cal/g
        carbs: Math.round(carbsCals / 4),
        fat: Math.round(fatCals / 9) // 9 cal/g
      });
    } catch (error) {
      console.error('Error calculating goals:', error);
    }
  };

  const loadTodayNutrition = async () => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const { data, error } = await supabase
        .from('nutrition_logs')
        .select('*')
        .eq('user_id', user!.id)
        .eq('date', today)
        .order('created_at', { ascending: false });

      if (error) throw error;

      setTodayLogs(data || []);

      // Calcular totais
      const totals = (data || []).reduce((acc, log) => ({
        calories: acc.calories + log.calories,
        protein: acc.protein + log.protein,
        carbs: acc.carbs + log.carbs,
        fat: acc.fat + log.fat
      }), { calories: 0, protein: 0, carbs: 0, fat: 0 });

      setDailyIntake(totals);
    } catch (error) {
      console.error('Error loading nutrition:', error);
    }
  };

  const handlePhotoScan = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsAnalyzing(true);
    try {
      // Convert to base64
      const reader = new FileReader();
      reader.readAsDataURL(file);
      
      reader.onload = async () => {
        const base64 = reader.result as string;

        const { data, error } = await supabase.functions.invoke('nutrition-vision-analyzer', {
          body: {
            photo: base64,
            userId: user!.id,
            mealType: 'snack'
          }
        });

        if (error) throw error;

        toast({
          title: "Refeição Analisada!",
          description: `${data.nutrition.foodName} adicionado com ${data.nutrition.confidence * 100}% de confiança.`,
        });

        await loadTodayNutrition();
      };
    } catch (error) {
      console.error('Error scanning food:', error);
      toast({
        title: "Erro",
        description: "Não foi possível analisar a foto. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getPercentage = (current: number, goal: number) => {
    return Math.min((current / goal) * 100, 100);
  };

  const mealTypeLabels = {
    breakfast: '☀️ Café',
    lunch: '🍽️ Almoço',
    dinner: '🌙 Jantar',
    snack: '🍎 Lanche'
  };

  return (
    <div className="space-y-4">
      {/* Goals Overview */}
      <Card className="p-6 bg-surface/50 border-border">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
            <Flame className="h-5 w-5 text-accent" />
            Meta Diária
          </h3>
          <Button size="sm" variant="outline" onClick={() => setShowManualEntry(!showManualEntry)}>
            <Plus className="h-4 w-4 mr-1" />
            Adicionar
          </Button>
        </div>

        {/* Macro Rings */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {/* Calories */}
          <div className="text-center">
            <div className="relative inline-flex items-center justify-center">
              <svg className="w-24 h-24 transform -rotate-90">
                <circle
                  cx="48"
                  cy="48"
                  r="42"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="transparent"
                  className="text-muted"
                />
                <circle
                  cx="48"
                  cy="48"
                  r="42"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="transparent"
                  strokeDasharray={`${2 * Math.PI * 42}`}
                  strokeDashoffset={`${2 * Math.PI * 42 * (1 - getPercentage(dailyIntake.calories, goals.calories) / 100)}`}
                  className="text-accent transition-all duration-500"
                />
              </svg>
              <div className="absolute text-center">
                <div className="text-lg font-bold text-foreground">{dailyIntake.calories}</div>
                <div className="text-xs text-muted-foreground">/{goals.calories}</div>
              </div>
            </div>
            <div className="mt-2 text-sm text-muted-foreground">Calorias</div>
          </div>

          {/* Protein */}
          <div className="text-center">
            <div className="relative inline-flex items-center justify-center">
              <svg className="w-24 h-24 transform -rotate-90">
                <circle cx="48" cy="48" r="42" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-muted" />
                <circle
                  cx="48" cy="48" r="42" stroke="currentColor" strokeWidth="8" fill="transparent"
                  strokeDasharray={`${2 * Math.PI * 42}`}
                  strokeDashoffset={`${2 * Math.PI * 42 * (1 - getPercentage(dailyIntake.protein, goals.protein) / 100)}`}
                  className="text-blue-500 transition-all duration-500"
                />
              </svg>
              <div className="absolute text-center">
                <div className="text-lg font-bold text-foreground">{dailyIntake.protein}</div>
                <div className="text-xs text-muted-foreground">/{goals.protein}g</div>
              </div>
            </div>
            <div className="mt-2 text-sm text-muted-foreground">Proteína</div>
          </div>

          {/* Carbs */}
          <div className="text-center">
            <div className="relative inline-flex items-center justify-center">
              <svg className="w-24 h-24 transform -rotate-90">
                <circle cx="48" cy="48" r="42" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-muted" />
                <circle
                  cx="48" cy="48" r="42" stroke="currentColor" strokeWidth="8" fill="transparent"
                  strokeDasharray={`${2 * Math.PI * 42}`}
                  strokeDashoffset={`${2 * Math.PI * 42 * (1 - getPercentage(dailyIntake.carbs, goals.carbs) / 100)}`}
                  className="text-green-500 transition-all duration-500"
                />
              </svg>
              <div className="absolute text-center">
                <div className="text-lg font-bold text-foreground">{dailyIntake.carbs}</div>
                <div className="text-xs text-muted-foreground">/{goals.carbs}g</div>
              </div>
            </div>
            <div className="mt-2 text-sm text-muted-foreground">Carboidratos</div>
          </div>

          {/* Fat */}
          <div className="text-center">
            <div className="relative inline-flex items-center justify-center">
              <svg className="w-24 h-24 transform -rotate-90">
                <circle cx="48" cy="48" r="42" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-muted" />
                <circle
                  cx="48" cy="48" r="42" stroke="currentColor" strokeWidth="8" fill="transparent"
                  strokeDasharray={`${2 * Math.PI * 42}`}
                  strokeDashoffset={`${2 * Math.PI * 42 * (1 - getPercentage(dailyIntake.fat, goals.fat) / 100)}`}
                  className="text-yellow-500 transition-all duration-500"
                />
              </svg>
              <div className="absolute text-center">
                <div className="text-lg font-bold text-foreground">{dailyIntake.fat}</div>
                <div className="text-xs text-muted-foreground">/{goals.fat}g</div>
              </div>
            </div>
            <div className="mt-2 text-sm text-muted-foreground">Gordura</div>
          </div>
        </div>
      </Card>

      {/* Photo Scan */}
      <Card className="p-6 bg-surface/50 border-border">
        <div className="text-center space-y-4">
          <div className="p-4 rounded-full bg-accent/10 w-16 h-16 mx-auto flex items-center justify-center">
            <Camera className="h-8 w-8 text-accent" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-2">
              Escanear Refeição com IA
            </h3>
            <p className="text-sm text-muted-foreground mb-4">
              Tire uma foto da sua comida e a IA calculará os macros automaticamente
            </p>
            <label htmlFor="food-photo">
              <input
                id="food-photo"
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={handlePhotoScan}
                disabled={isAnalyzing}
              />
              <Button asChild disabled={isAnalyzing} className="bg-gradient-to-r from-accent to-accent-2">
                <span>
                  {isAnalyzing ? (
                    <>
                      <Activity className="h-4 w-4 mr-2 animate-spin" />
                      Analisando...
                    </>
                  ) : (
                    <>
                      <Camera className="h-4 w-4 mr-2" />
                      Tirar Foto
                    </>
                  )}
                </span>
              </Button>
            </label>
          </div>
        </div>
      </Card>

      {/* Today's Meals */}
      {todayLogs.length > 0 && (
        <Card className="p-6 bg-surface/50 border-border">
          <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
            <Utensils className="h-5 w-5 text-accent" />
            Refeições de Hoje
          </h3>
          <div className="space-y-3">
            {todayLogs.map((log) => (
              <div
                key={log.id}
                className="flex items-center justify-between p-3 rounded-lg bg-background/50 border border-border/50"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm">{mealTypeLabels[log.meal_type as keyof typeof mealTypeLabels]}</span>
                    <span className="text-sm font-medium text-foreground">{log.food_name}</span>
                  </div>
                  <div className="flex gap-4 text-xs text-muted-foreground">
                    <span>{log.calories} cal</span>
                    <span>P: {log.protein}g</span>
                    <span>C: {log.carbs}g</span>
                    <span>G: {log.fat}g</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
});