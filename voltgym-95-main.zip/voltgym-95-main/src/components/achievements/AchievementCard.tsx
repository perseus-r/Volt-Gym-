import React from 'react';
import { motion } from 'framer-motion';
import { Lock, Check } from 'lucide-react';
import { Achievement, AchievementRarity } from '@/services/AchievementService';
import { cn } from '@/lib/utils';

interface AchievementCardProps {
  achievement: Achievement;
  onClick?: () => void;
  showProgress?: boolean;
  compact?: boolean;
}

const rarityConfig: Record<AchievementRarity, {
  border: string;
  bg: string;
  glow: string;
  badge: string;
  badgeText: string;
}> = {
  common: {
    border: 'border-muted-foreground/30',
    bg: 'bg-muted/20',
    glow: '',
    badge: 'bg-muted text-muted-foreground',
    badgeText: 'Comum'
  },
  rare: {
    border: 'border-blue-500/50',
    bg: 'bg-blue-500/10',
    glow: 'shadow-[0_0_15px_rgba(59,130,246,0.3)]',
    badge: 'bg-blue-500/20 text-blue-400',
    badgeText: 'Raro'
  },
  epic: {
    border: 'border-purple-500/50',
    bg: 'bg-purple-500/10',
    glow: 'shadow-[0_0_20px_rgba(139,92,246,0.4)]',
    badge: 'bg-purple-500/20 text-purple-400',
    badgeText: 'Épico'
  },
  legendary: {
    border: 'border-amber-500/50',
    bg: 'bg-gradient-to-br from-amber-500/20 to-orange-500/20',
    glow: 'shadow-[0_0_25px_rgba(245,158,11,0.5)]',
    badge: 'bg-gradient-to-r from-amber-500 to-orange-500 text-white',
    badgeText: 'Lendário'
  }
};

export function AchievementCard({ 
  achievement, 
  onClick,
  showProgress = true,
  compact = false
}: AchievementCardProps) {
  const config = rarityConfig[achievement.rarity];
  const progressPercent = (achievement.progress / achievement.maxProgress) * 100;
  const isSecret = achievement.isSecret && !achievement.isUnlocked;

  if (compact) {
    return (
      <motion.div
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={onClick}
        className={cn(
          'relative flex items-center gap-3 p-3 rounded-xl border transition-all cursor-pointer',
          achievement.isUnlocked 
            ? `${config.border} ${config.bg} ${config.glow}` 
            : 'border-border/50 bg-muted/30 opacity-60'
        )}
      >
        <div className={cn(
          'w-10 h-10 rounded-full flex items-center justify-center text-xl',
          achievement.isUnlocked ? config.bg : 'bg-muted'
        )}>
          {isSecret ? '❓' : achievement.icon || '🏆'}
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-medium text-sm truncate">
            {isSecret ? '???' : achievement.title}
          </p>
          {showProgress && !achievement.isUnlocked && (
            <div className="w-full h-1 bg-muted rounded-full mt-1 overflow-hidden">
              <motion.div
                className="h-full bg-primary rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${progressPercent}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
          )}
        </div>
        {achievement.isUnlocked && (
          <Check className="w-4 h-4 text-green-500" />
        )}
      </motion.div>
    );
  }

  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -2 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={cn(
        'relative overflow-hidden rounded-2xl border-2 p-4 cursor-pointer transition-all group',
        achievement.isUnlocked 
          ? `${config.border} ${config.bg} ${config.glow}` 
          : 'border-border/50 bg-card/50'
      )}
    >
      {/* Shimmer effect on hover */}
      <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/10 to-transparent" />

      {/* Rarity badge */}
      <div className="absolute top-2 right-2">
        <span className={cn(
          'text-[10px] font-bold uppercase px-2 py-0.5 rounded-full',
          config.badge
        )}>
          {config.badgeText}
        </span>
      </div>

      {/* Locked overlay for secrets */}
      {isSecret && (
        <div className="absolute inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center z-10">
          <div className="text-center">
            <Lock className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">Conquista Secreta</p>
          </div>
        </div>
      )}

      <div className="flex items-start gap-4">
        {/* Icon */}
        <motion.div 
          className={cn(
            'w-14 h-14 rounded-xl flex items-center justify-center text-2xl shrink-0',
            achievement.isUnlocked 
              ? config.bg 
              : 'bg-muted'
          )}
          animate={!achievement.isUnlocked ? {
            scale: [1, 1.05, 1],
            opacity: [0.5, 0.7, 0.5]
          } : {}}
          transition={{ 
            duration: 2, 
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          {isSecret ? '❓' : achievement.icon || '🏆'}
        </motion.div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <h3 className={cn(
            'font-bold text-base mb-1',
            !achievement.isUnlocked && 'text-muted-foreground'
          )}>
            {isSecret ? '???' : achievement.title}
          </h3>
          <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
            {isSecret ? 'Complete ações específicas para desbloquear' : achievement.description}
          </p>

          {/* Progress bar */}
          {showProgress && !achievement.isUnlocked && !isSecret && (
            <div className="space-y-1">
              <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                <motion.div
                  className="h-full rounded-full bg-gradient-to-r from-primary to-primary/70"
                  initial={{ width: 0 }}
                  animate={{ width: `${progressPercent}%` }}
                  transition={{ duration: 0.8, ease: "easeOut" }}
                />
              </div>
              <p className="text-xs text-muted-foreground text-right">
                {achievement.progress} / {achievement.maxProgress}
              </p>
            </div>
          )}

          {/* XP reward */}
          <div className="flex items-center justify-between mt-2">
            <span className={cn(
              'text-xs font-medium',
              achievement.isUnlocked ? 'text-green-500' : 'text-muted-foreground'
            )}>
              +{achievement.xpReward} XP
            </span>
            {achievement.isUnlocked && achievement.unlockedAt && (
              <span className="text-xs text-muted-foreground">
                {new Date(achievement.unlockedAt).toLocaleDateString('pt-BR')}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Unlock checkmark */}
      {achievement.isUnlocked && (
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="absolute bottom-2 right-2"
        >
          <div className="w-6 h-6 rounded-full bg-green-500 flex items-center justify-center">
            <Check className="w-4 h-4 text-white" />
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}
