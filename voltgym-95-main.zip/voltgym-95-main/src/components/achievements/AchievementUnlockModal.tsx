import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Share2, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Achievement, AchievementRarity } from '@/services/AchievementService';
import { Button } from '@/components/ui/button';
import { hapticSuccess, hapticHeavy } from '@/utils/haptics';
import { cn } from '@/lib/utils';

interface AchievementUnlockModalProps {
  achievement: Achievement | null;
  onClose: () => void;
  onShare?: () => void;
}

const rarityColors: Record<AchievementRarity, {
  primary: string;
  secondary: string;
  glow: string;
  confettiColors: string[];
}> = {
  common: {
    primary: 'from-gray-400 to-gray-500',
    secondary: 'text-gray-400',
    glow: 'shadow-[0_0_60px_rgba(156,163,175,0.4)]',
    confettiColors: ['#9CA3AF', '#6B7280', '#4B5563']
  },
  rare: {
    primary: 'from-blue-400 to-blue-600',
    secondary: 'text-blue-400',
    glow: 'shadow-[0_0_80px_rgba(59,130,246,0.5)]',
    confettiColors: ['#3B82F6', '#60A5FA', '#93C5FD']
  },
  epic: {
    primary: 'from-purple-400 to-purple-600',
    secondary: 'text-purple-400',
    glow: 'shadow-[0_0_100px_rgba(139,92,246,0.6)]',
    confettiColors: ['#8B5CF6', '#A78BFA', '#C4B5FD']
  },
  legendary: {
    primary: 'from-amber-400 via-orange-500 to-red-500',
    secondary: 'text-amber-400',
    glow: 'shadow-[0_0_120px_rgba(245,158,11,0.7)]',
    confettiColors: ['#F59E0B', '#F97316', '#EF4444', '#FBBF24']
  }
};

function triggerConfetti(rarity: AchievementRarity) {
  const colors = rarityColors[rarity].confettiColors;
  const intensity = {
    common: 1,
    rare: 1.5,
    epic: 2,
    legendary: 3
  }[rarity];

  // Main burst
  confetti({
    particleCount: 50 * intensity,
    spread: 60,
    origin: { y: 0.6 },
    colors
  });

  // Side cannons for epic+
  if (rarity === 'epic' || rarity === 'legendary') {
    setTimeout(() => {
      confetti({
        particleCount: 30 * intensity,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors
      });
      confetti({
        particleCount: 30 * intensity,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors
      });
    }, 200);
  }

  // Stars for legendary
  if (rarity === 'legendary') {
    setTimeout(() => {
      confetti({
        particleCount: 20,
        spread: 360,
        ticks: 100,
        gravity: 0.2,
        decay: 0.94,
        startVelocity: 30,
        shapes: ['star'],
        colors: ['#FFD700', '#FFA500', '#FF6347']
      });
    }, 400);
  }
}

export function AchievementUnlockModal({ 
  achievement, 
  onClose,
  onShare 
}: AchievementUnlockModalProps) {
  const [xpAnimated, setXpAnimated] = useState(0);

  useEffect(() => {
    if (achievement) {
      // Trigger haptics
      if (achievement.rarity === 'legendary') {
        hapticHeavy();
      } else {
        hapticSuccess();
      }

      // Trigger confetti
      triggerConfetti(achievement.rarity);

      // Animate XP
      const duration = 1500;
      const startTime = Date.now();
      const animate = () => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration, 1);
        setXpAnimated(Math.floor(progress * achievement.xpReward));
        if (progress < 1) {
          requestAnimationFrame(animate);
        }
      };
      requestAnimationFrame(animate);

      // Auto dismiss after 8 seconds
      const timer = setTimeout(onClose, 8000);
      return () => clearTimeout(timer);
    }
  }, [achievement, onClose]);

  if (!achievement) return null;

  const colors = rarityColors[achievement.rarity];

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.5, opacity: 0, y: 50 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.5, opacity: 0, y: 50 }}
          transition={{ type: 'spring', damping: 20, stiffness: 300 }}
          onClick={(e) => e.stopPropagation()}
          className={cn(
            'relative w-full max-w-sm bg-card rounded-3xl p-6 border-2',
            colors.glow
          )}
          style={{
            borderImage: `linear-gradient(135deg, ${colors.confettiColors.join(', ')}) 1`
          }}
        >
          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1 rounded-full hover:bg-muted transition-colors"
          >
            <X className="w-5 h-5 text-muted-foreground" />
          </button>

          {/* Sparkles decoration */}
          <motion.div
            animate={{ 
              rotate: 360,
              scale: [1, 1.1, 1]
            }}
            transition={{ 
              rotate: { duration: 10, repeat: Infinity, ease: 'linear' },
              scale: { duration: 2, repeat: Infinity }
            }}
            className="absolute -top-6 left-1/2 -translate-x-1/2"
          >
            <Sparkles className={cn('w-12 h-12', colors.secondary)} />
          </motion.div>

          {/* Header */}
          <div className="text-center mt-4 mb-6">
            <motion.p
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className={cn('text-sm font-medium uppercase tracking-wider', colors.secondary)}
            >
              Conquista Desbloqueada!
            </motion.p>
          </div>

          {/* Achievement icon */}
          <motion.div
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: 'spring', damping: 12, delay: 0.3 }}
            className={cn(
              'w-24 h-24 mx-auto rounded-2xl flex items-center justify-center text-5xl mb-4',
              `bg-gradient-to-br ${colors.primary}`
            )}
          >
            {achievement.icon || '🏆'}
          </motion.div>

          {/* Title & Description */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="text-center mb-6"
          >
            <h2 className="text-2xl font-bold mb-2">{achievement.title}</h2>
            <p className="text-muted-foreground">{achievement.description}</p>
          </motion.div>

          {/* XP Animation */}
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.7 }}
            className="text-center mb-6"
          >
            <div className={cn(
              'inline-flex items-center gap-2 px-4 py-2 rounded-full',
              `bg-gradient-to-r ${colors.primary}`
            )}>
              <Sparkles className="w-5 h-5 text-white" />
              <span className="text-xl font-bold text-white">
                +{xpAnimated} XP
              </span>
            </div>
          </motion.div>

          {/* Rarity badge */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.9 }}
            className="text-center mb-6"
          >
            <span className={cn(
              'text-xs font-bold uppercase px-3 py-1 rounded-full',
              `bg-gradient-to-r ${colors.primary} text-white`
            )}>
              {achievement.rarity === 'common' && 'Comum'}
              {achievement.rarity === 'rare' && 'Raro'}
              {achievement.rarity === 'epic' && 'Épico'}
              {achievement.rarity === 'legendary' && 'Lendário'}
            </span>
          </motion.div>

          {/* Actions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.1 }}
            className="flex gap-3"
          >
            {onShare && (
              <Button
                variant="outline"
                className="flex-1"
                onClick={onShare}
              >
                <Share2 className="w-4 h-4 mr-2" />
                Compartilhar
              </Button>
            )}
            <Button
              className={cn(
                'flex-1',
                `bg-gradient-to-r ${colors.primary} hover:opacity-90`
              )}
              onClick={onClose}
            >
              Continuar
            </Button>
          </motion.div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
