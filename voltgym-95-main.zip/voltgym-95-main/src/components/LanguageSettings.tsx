import { useState } from "react";
import { Globe } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useLanguage } from "@/components/MultiLanguageSystem";

interface LanguageSettingsProps {
  className?: string;
}

export function LanguageSettings({ className = "" }: LanguageSettingsProps) {
  const { currentLanguage, changeLanguage, availableLanguages, t } = useLanguage();
  const [isLoading, setIsLoading] = useState(false);

  const handleLanguageChange = async (languageCode: string) => {
    setIsLoading(true);
    
    try {
      changeLanguage(languageCode);
      const selectedLang = availableLanguages.find(lang => lang.code === languageCode);
      
      toast.success(`✅ ${selectedLang?.nativeName}`, {
        description: t('language.changed')
      });
    } catch (error) {
      toast.error("Erro ao alterar idioma");
      console.error("Language change error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className={`glass-card p-4 ${className}`}>
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center">
          <Globe className="w-5 h-5 text-accent" />
        </div>
        <div>
          <h3 className="font-semibold text-txt">{t('language.settings')}</h3>
          <p className="text-sm text-txt-2">{t('language.select')}</p>
        </div>
      </div>

      <div className="space-y-3">
        <Select 
          value={currentLanguage.code} 
          onValueChange={handleLanguageChange}
          disabled={isLoading}
        >
          <SelectTrigger className="w-full bg-input-bg border-input-border">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-surface border-line z-50">
            {availableLanguages.map((lang) => (
              <SelectItem key={lang.code} value={lang.code}>
                <div className="flex items-center gap-2 justify-between w-full">
                  <div className="flex items-center gap-2">
                    <span>{lang.flag}</span>
                    <span>{lang.nativeName}</span>
                  </div>
                  <Badge variant="outline" className="ml-2 text-xs">
                    {lang.completion}%
                  </Badge>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <div className="text-xs text-txt-3 bg-surface/50 p-3 rounded-lg">
          <p className="font-medium mb-1">ℹ️ {t('common.loading').replace('...', '')}:</p>
          <p>{t('language.update-note')}</p>
        </div>
      </div>
    </Card>
  );
}