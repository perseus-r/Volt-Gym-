import { motion, AnimatePresence } from 'framer-motion';
import { useState, useEffect } from 'react';
import { Clock, Zap, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

interface UrgencyBannerProps {
  show: boolean;
}

export default function UrgencyBanner({ show }: UrgencyBannerProps) {
  const navigate = useNavigate();
  const [isVisible, setIsVisible] = useState(true);
  const [timeLeft, setTimeLeft] = useState({
    hours: 23,
    minutes: 59,
    seconds: 59
  });

  // Countdown timer
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return prev;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  if (!show || !isVisible) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: -100, opacity: 0 }}
        transition={{ duration: 0.3 }}
        className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-r from-accent via-accent-2 to-accent shadow-lg"
      >
        <div className="container-custom px-4">
          <div className="flex items-center justify-between py-3 gap-4">
            {/* Left: Message */}
            <div className="flex items-center gap-3 flex-1">
              <div className="hidden sm:flex items-center gap-2 px-3 py-1 bg-white/20 rounded-full">
                <Zap className="w-4 h-4 text-accent-ink" />
                <span className="text-xs font-bold text-accent-ink">OFERTA LIMITADA</span>
              </div>
              <p className="text-sm md:text-base font-medium text-accent-ink">
                <span className="hidden sm:inline">🔥 </span>
                Últimas <span className="font-bold">47 vagas</span> para trial gratuito de 3 dias
              </p>
            </div>

            {/* Center: Countdown */}
            <div className="hidden md:flex items-center gap-2">
              <Clock className="w-4 h-4 text-accent-ink" />
              <div className="flex items-center gap-1 font-mono font-bold text-accent-ink">
                <span className="bg-white/20 px-2 py-1 rounded">
                  {String(timeLeft.hours).padStart(2, '0')}
                </span>
                <span>:</span>
                <span className="bg-white/20 px-2 py-1 rounded">
                  {String(timeLeft.minutes).padStart(2, '0')}
                </span>
                <span>:</span>
                <span className="bg-white/20 px-2 py-1 rounded">
                  {String(timeLeft.seconds).padStart(2, '0')}
                </span>
              </div>
            </div>

            {/* Right: CTA + Close */}
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                onClick={() => navigate('/comecar')}
                className="bg-accent-ink text-accent font-bold hover:bg-accent-ink/90 whitespace-nowrap"
              >
                Garantir Vaga
              </Button>
              <button
                onClick={() => setIsVisible(false)}
                className="p-1 hover:bg-white/20 rounded transition-colors"
              >
                <X className="w-4 h-4 text-accent-ink" />
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
