import { ReactNode, useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronUp } from 'lucide-react';
import { useMobileExperience } from '@/hooks/useMobileExperience';

interface MobileLandingWrapperProps {
  children: ReactNode;
}

/**
 * Wrapper global para landing page mobile
 * - Safe areas (notch, home indicator)
 * - Scroll behavior otimizado
 * - Scroll-to-top button
 * - Touch optimizations
 */
export function MobileLandingWrapper({ children }: MobileLandingWrapperProps) {
  const { isMobile, safeAreaTop, safeAreaBottom } = useMobileExperience();
  const [scrollY, setScrollY] = useState(0);
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    // Minimal mobile optimizations - avoid conflicts
    if (isMobile) {
      // Touch momentum iOS only
      (document.body.style as any).webkitOverflowScrolling = 'touch';
    }

    // Scroll listener (throttled)
    let ticking = false;
    const handleScroll = () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          setScrollY(window.scrollY);
          setShowScrollTop(window.scrollY > 500);
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });

    return () => {
      window.removeEventListener('scroll', handleScroll);
      if (isMobile) {
        (document.body.style as any).webkitOverflowScrolling = '';
      }
    };
  }, [isMobile]);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <div className="min-h-full w-full max-w-lg mx-auto md:max-w-none">
      {children}

      {/* Scroll to top button - mobile only - smaller */}
      <AnimatePresence>
        {isMobile && showScrollTop && (
          <motion.button
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={scrollToTop}
            className="fixed right-3 z-50 w-10 h-10 rounded-full bg-accent text-accent-ink shadow-glow flex items-center justify-center touch-manipulation active:scale-95 transition-transform"
            style={{
              bottom: 'calc(80px + env(safe-area-inset-bottom, 0px) + var(--ios-toolbar-bottom, 0px) + 12px)'
            }}
          >
            <ChevronUp className="w-5 h-5" />
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}
