import { motion } from 'framer-motion';
import { Frown, Lightbulb, Trophy, ArrowRight } from 'lucide-react';
import { useMobileExperience } from '@/hooks/useMobileExperience';

const stories = [
  {
    icon: Frown,
    step: '01',
    title: 'A Frustração',
    emotion: 'Você já sentiu isso?',
    quote: '"Gastei R$ 15.000 em personal trainer no ano passado e não vi diferença no espelho."',
    person: '— História real de 73% dos nossos usuários antes do VOLT',
    color: 'error',
    gradient: 'from-error/20 to-error/5'
  },
  {
    icon: Lightbulb,
    step: '02', 
    title: 'A Descoberta',
    emotion: 'E se existisse outra forma?',
    quote: '"Descobri que a IA pode analisar meu corpo, treino e rotina para criar algo realmente personalizado."',
    person: '— O momento da virada',
    color: 'warning',
    gradient: 'from-warning/20 to-warning/5'
  },
  {
    icon: Trophy,
    step: '03',
    title: 'A Transformação',
    emotion: 'Resultados reais em 28 dias',
    quote: '"Em 4 semanas, tive mais resultados que em 1 ano de academia sem direção. Perdi 6kg e ganhei definição."',
    person: '— Resultado médio dos usuários VOLT',
    color: 'success',
    gradient: 'from-success/20 to-success/5'
  }
];

export default function StorytellingSection() {
  const { isMobile } = useMobileExperience();

  return (
    <section className="py-20 md:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-surface/50 via-bg to-surface/50" />
      
      {/* Animated background elements */}
      <motion.div 
        className="absolute top-1/4 left-1/4 w-64 h-64 bg-accent/10 rounded-full blur-[100px]"
        animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.5, 0.3] }}
        transition={{ duration: 8, repeat: Infinity }}
      />

      <div className="container-custom relative z-10 px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-2 rounded-full bg-accent/10 text-accent text-sm font-medium mb-6">
            Uma história que você conhece
          </span>
          <h2 className="text-3xl md:text-5xl font-bold mb-4">
            Do Fracasso ao{' '}
            <span className="bg-gradient-lightning bg-clip-text text-transparent">
              Corpo dos Sonhos
            </span>
          </h2>
          <p className="text-lg text-txt-2 max-w-2xl mx-auto">
            Essa jornada é mais comum do que você imagina. E a solução está mais perto do que você pensa.
          </p>
        </motion.div>

        {/* Timeline */}
        <div className="relative">
          {/* Connection line - desktop only */}
          {!isMobile && (
            <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-error via-warning to-success -translate-y-1/2 hidden md:block" />
          )}

          <div className="grid md:grid-cols-3 gap-8 md:gap-12">
            {stories.map((story, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: idx * 0.2 }}
                className="relative"
              >
                {/* Step indicator */}
                <div className={`absolute -top-4 left-6 md:left-1/2 md:-translate-x-1/2 md:-top-8 z-10`}>
                  <div className={`w-16 h-16 rounded-full bg-${story.color} flex items-center justify-center shadow-lg`}>
                    <story.icon className="w-7 h-7 text-bg" />
                  </div>
                </div>

                {/* Card */}
                <div className={`bg-gradient-to-br ${story.gradient} backdrop-blur-sm border border-line/50 rounded-3xl p-8 pt-16 md:pt-14 h-full hover:border-${story.color}/50 transition-all duration-300`}>
                  <span className={`text-${story.color} text-sm font-bold tracking-wider`}>
                    PASSO {story.step}
                  </span>
                  <h3 className="text-2xl font-bold mt-2 mb-3">{story.title}</h3>
                  <p className="text-txt-2 text-sm mb-4">{story.emotion}</p>
                  
                  {/* Quote */}
                  <blockquote className="relative pl-4 border-l-2 border-line/50">
                    <p className="text-txt italic leading-relaxed mb-3">
                      {story.quote}
                    </p>
                    <cite className="text-txt-3 text-xs not-italic">
                      {story.person}
                    </cite>
                  </blockquote>
                </div>

                {/* Arrow connector - mobile */}
                {idx < stories.length - 1 && isMobile && (
                  <div className="flex justify-center my-4">
                    <ArrowRight className="w-6 h-6 text-txt-3 rotate-90" />
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="text-center mt-16"
        >
          <p className="text-xl text-txt-2 mb-2">
            Pronto para escrever <span className="text-accent font-semibold">sua história de sucesso</span>?
          </p>
          <p className="text-txt-3">
            Mais de 12.000 pessoas já transformaram suas vidas com VOLT
          </p>
        </motion.div>
      </div>
    </section>
  );
}
