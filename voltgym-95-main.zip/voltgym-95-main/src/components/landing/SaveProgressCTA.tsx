import { motion, AnimatePresence } from 'framer-motion';
import { 
  CheckCircle, 
  ArrowRight, 
  Sparkles,
  Target,
  Dumbbell,
  Calendar
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { useLandingProgress } from '@/hooks/useLandingProgress';
import { useMobileExperience } from '@/hooks/useMobileExperience';

const objetivoLabels: Record<string, string> = {
  massa: 'Ganhar Massa',
  definicao: 'Definir Corpo',
  forca: 'Ficar Forte',
  saude: 'Saúde Geral'
};

const nivelLabels: Record<string, string> = {
  iniciante: 'Iniciante',
  intermediario: 'Intermediário',
  avancado: 'Avançado'
};

export const SaveProgressCTA = () => {
  const navigate = useNavigate();
  const { isMobile } = useMobileExperience();
  const { progress, isComplete, getProgressPercentage } = useLandingProgress();
  const progressPercent = getProgressPercentage();

  if (!progress.hasInteracted) return null;

  return (
    <section className="py-16 md:py-20 bg-gradient-to-b from-muted/30 to-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-2xl mx-auto"
        >
          <div className="bg-card rounded-2xl border border-border overflow-hidden shadow-xl">
            {/* Progress Header */}
            <div className="p-6 bg-gradient-to-r from-accent/10 to-primary/10 border-b border-border">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-lg">Seu Progresso</h3>
                <span className="text-sm text-accent font-medium">{progressPercent}% completo</span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-accent to-primary"
                  initial={{ width: 0 }}
                  animate={{ width: `${progressPercent}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
            </div>

            {/* Saved Choices */}
            <div className="p-6">
              <AnimatePresence mode="popLayout">
                {progress.objetivo && (
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="flex items-center gap-3 mb-3"
                  >
                    <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                      <Target className="w-5 h-5 text-blue-500" />
                    </div>
                    <div className="flex-1">
                      <p className="text-xs text-muted-foreground">Objetivo</p>
                      <p className="font-medium">{objetivoLabels[progress.objetivo]}</p>
                    </div>
                    <CheckCircle className="w-5 h-5 text-green-500" />
                  </motion.div>
                )}

                {progress.nivel && (
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.1 }}
                    className="flex items-center gap-3 mb-3"
                  >
                    <div className="w-10 h-10 rounded-full bg-purple-500/10 flex items-center justify-center">
                      <Dumbbell className="w-5 h-5 text-purple-500" />
                    </div>
                    <div className="flex-1">
                      <p className="text-xs text-muted-foreground">Nível</p>
                      <p className="font-medium">{nivelLabels[progress.nivel]}</p>
                    </div>
                    <CheckCircle className="w-5 h-5 text-green-500" />
                  </motion.div>
                )}

                {progress.frequencia && (
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.2 }}
                    className="flex items-center gap-3 mb-3"
                  >
                    <div className="w-10 h-10 rounded-full bg-orange-500/10 flex items-center justify-center">
                      <Calendar className="w-5 h-5 text-orange-500" />
                    </div>
                    <div className="flex-1">
                      <p className="text-xs text-muted-foreground">Frequência</p>
                      <p className="font-medium">{progress.frequencia}x por semana</p>
                    </div>
                    <CheckCircle className="w-5 h-5 text-green-500" />
                  </motion.div>
                )}

                {progress.workoutPreviewSeen && (
                  <motion.div
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 }}
                    className="flex items-center gap-3 mb-3"
                  >
                    <div className="w-10 h-10 rounded-full bg-green-500/10 flex items-center justify-center">
                      <Sparkles className="w-5 h-5 text-green-500" />
                    </div>
                    <div className="flex-1">
                      <p className="text-xs text-muted-foreground">Treino Demo</p>
                      <p className="font-medium">Experimentado!</p>
                    </div>
                    <CheckCircle className="w-5 h-5 text-green-500" />
                  </motion.div>
                )}
              </AnimatePresence>

              {!isComplete && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="mt-4 p-3 bg-muted/50 rounded-lg"
                >
                  <p className="text-sm text-muted-foreground">
                    Complete o quiz acima para desbloquear seu dashboard personalizado!
                  </p>
                </motion.div>
              )}
            </div>

            {/* CTA */}
            <div className="p-6 bg-gradient-to-r from-accent/5 to-primary/5 border-t border-border">
              <div className={`flex ${isMobile ? 'flex-col' : 'flex-row'} items-center gap-4`}>
                <div className="flex-1 text-center sm:text-left">
                  <p className="font-bold mb-1">
                    {isComplete 
                      ? '🎉 Perfil completo!' 
                      : 'Salve seu progresso'}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {isComplete 
                      ? 'Crie sua conta em 10 segundos e comece agora' 
                      : 'Suas escolhas serão transferidas automaticamente'}
                  </p>
                </div>
                <Button 
                  onClick={() => navigate('/auth')}
                  size="lg"
                  className="w-full sm:w-auto bg-gradient-to-r from-accent to-primary hover:opacity-90"
                >
                  {isComplete ? 'Criar Conta Grátis' : 'Salvar e Continuar'}
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default SaveProgressCTA;
