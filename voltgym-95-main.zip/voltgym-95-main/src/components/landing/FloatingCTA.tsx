import { motion, AnimatePresence } from 'framer-motion';
import { Zap, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { useMobileExperience } from '@/hooks/useMobileExperience';

interface FloatingCTAProps {
  show: boolean;
}

export default function FloatingCTA({ show }: FloatingCTAProps) {
  const navigate = useNavigate();
  const { isMobile } = useMobileExperience();

  if (!show) return null;

  // Mobile: Bottom bar
  if (isMobile) {
    return (
      <AnimatePresence>
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed bottom-0 left-0 right-0 z-40 bg-gradient-to-t from-bg via-bg/95 to-transparent p-4 pb-6 safe-area-bottom"
        >
          <Button
            size="lg"
            onClick={() => navigate('/comecar')}
            className="w-full bg-gradient-to-r from-accent to-accent-2 text-accent-ink font-bold py-6 text-lg rounded-2xl shadow-glow hover:shadow-glow-lg transition-all duration-300 active:scale-95"
          >
            <Zap className="w-5 h-5 mr-2" />
            Começar 3 Dias Grátis
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
          <p className="text-center text-xs text-txt-3 mt-2">
            Sem cartão de crédito • Cancele quando quiser
          </p>
        </motion.div>
      </AnimatePresence>
    );
  }

  // Desktop: Side button
  return (
    <AnimatePresence>
      <motion.div
        initial={{ x: 100, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        exit={{ x: 100, opacity: 0 }}
        transition={{ duration: 0.3 }}
        className="fixed right-6 bottom-8 z-40"
      >
        <motion.div
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <Button
            size="lg"
            onClick={() => navigate('/comecar')}
            className="bg-gradient-to-r from-accent to-accent-2 text-accent-ink font-bold px-6 py-6 text-lg rounded-2xl shadow-glow hover:shadow-glow-lg transition-all duration-300 group"
          >
            <Zap className="w-5 h-5 mr-2 group-hover:animate-pulse" />
            Começar Grátis
            <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
        </motion.div>
        
        {/* Pulse ring */}
        <div className="absolute inset-0 rounded-2xl bg-accent/30 animate-ping opacity-20 pointer-events-none" />
      </motion.div>
    </AnimatePresence>
  );
}
