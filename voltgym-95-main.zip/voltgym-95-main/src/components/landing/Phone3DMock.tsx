import React, { useRef, useState, useMemo } from 'react';
import { useReducedMotion } from '@/hooks/useReducedMotion';
import { useIsMobile } from '@/hooks/use-mobile';

interface Phone3DMockProps {
  children: React.ReactNode;
  className?: string;
  intensity?: number;
}

/**
 * Phone 3D Mock - Optimized for mobile performance
 * - Disables gyroscope on mobile (battery + performance)
 * - Uses CSS transforms instead of Framer Motion on low-end devices
 * - Reduces intensity on mobile
 */
const Phone3DMock: React.FC<Phone3DMockProps> = ({ 
  children, 
  className = '',
  intensity = 15 
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [transform, setTransform] = useState({ rotateX: 0, rotateY: 0 });
  const { shouldReduceMotion, tier } = useReducedMotion();
  const isMobile = useIsMobile();
  
  // Reduce intensity on mobile/low-end devices
  const effectiveIntensity = useMemo(() => {
    if (shouldReduceMotion) return 0;
    if (isMobile || tier === 'low') return intensity * 0.3;
    if (tier === 'medium') return intensity * 0.6;
    return intensity;
  }, [shouldReduceMotion, isMobile, tier, intensity]);
  
  // Handle mouse move - only on desktop with good performance
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (isMobile || shouldReduceMotion || effectiveIntensity === 0) return;
    if (!containerRef.current) return;
    
    const rect = containerRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    
    const normalizedX = (e.clientX - centerX) / rect.width;
    const normalizedY = (e.clientY - centerY) / rect.height;
    
    setTransform({
      rotateX: normalizedY * -effectiveIntensity,
      rotateY: normalizedX * effectiveIntensity,
    });
  };
  
  const handleMouseLeave = () => {
    setTransform({ rotateX: 0, rotateY: 0 });
  };
  
  // Static version for mobile/reduced motion
  if (shouldReduceMotion || isMobile) {
    return (
      <div className={className}>
        <div className="relative rounded-[2.5rem] bg-gradient-to-br from-zinc-800 via-zinc-900 to-black p-2 shadow-2xl">
          <div className="absolute inset-0 rounded-[2.5rem] bg-gradient-to-br from-white/20 via-transparent to-white/5 pointer-events-none" />
          <div className="relative rounded-[2rem] bg-black overflow-hidden">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-24 h-6 bg-black rounded-b-2xl z-20" />
            <div className="relative aspect-[9/19.5] bg-background overflow-hidden">
              {children}
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div
      ref={containerRef}
      className={className}
      style={{ perspective: '1000px' }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
    >
      <div
        className="relative transition-transform duration-150 ease-out"
        style={{
          transform: `rotateX(${transform.rotateX}deg) rotateY(${transform.rotateY}deg)`,
          transformStyle: 'preserve-3d',
        }}
      >
        {/* Simplified shadow - no motion values */}
        <div 
          className="absolute inset-0 rounded-[2.5rem] bg-black/20 blur-xl -z-10"
          style={{
            transform: `translate(${transform.rotateY * 0.5}px, ${-transform.rotateX * 0.5}px) scale(0.95)`,
          }}
        />
        
        {/* Phone frame */}
        <div className="relative rounded-[2.5rem] bg-gradient-to-br from-zinc-800 via-zinc-900 to-black p-2 shadow-2xl">
          <div className="absolute inset-0 rounded-[2.5rem] bg-gradient-to-br from-white/20 via-transparent to-white/5 pointer-events-none" />
          
          <div className="relative rounded-[2rem] bg-black overflow-hidden">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-24 h-6 bg-black rounded-b-2xl z-20" />
            
            <div className="relative aspect-[9/19.5] bg-background overflow-hidden">
              {children}
            </div>
          </div>
          
          {/* Side buttons */}
          <div className="absolute right-[-3px] top-24 w-1 h-12 bg-zinc-700 rounded-r-sm" />
          <div className="absolute right-[-3px] top-40 w-1 h-8 bg-zinc-700 rounded-r-sm" />
          <div className="absolute left-[-3px] top-28 w-1 h-16 bg-zinc-700 rounded-l-sm" />
        </div>
      </div>
    </div>
  );
};

export default Phone3DMock;
