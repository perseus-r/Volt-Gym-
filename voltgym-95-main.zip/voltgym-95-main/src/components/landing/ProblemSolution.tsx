import { motion } from 'framer-motion';
import { X, Check, TrendingUp } from 'lucide-react';
import { Stagger, Item } from '@/components/animations/Stagger';
import { useMobileExperience } from '@/hooks/useMobileExperience';

export default function ProblemSolution() {
  const { isMobile } = useMobileExperience();
  
  const comparisons = [
    {
      problem: 'Personal trainer caro',
      problemCost: 'R$ 4.800/mês',
      solution: 'IA Coach personalizada',
      solutionCost: 'R$ 99/mês',
      result: '-95% de economia',
      impact: 'high'
    },
    {
      problem: 'Nutricionista presencial complexo',
      problemCost: 'R$ 800/mês',
      solution: 'IA Nutri + foto de refeição',
      solutionCost: 'R$ 148/mês',
      result: 'Contagem automática',
      impact: 'high'
    },
    {
      problem: 'Planilhas bagunçadas',
      problemCost: 'Confuso',
      solution: 'Dashboard inteligente',
      solutionCost: 'Grátis',
      result: 'Progresso visual',
      impact: 'medium'
    },
    {
      problem: 'Treino genérico da internet',
      problemCost: 'Sem resultados',
      solution: 'Plano 28 dias IA adaptativo',
      solutionCost: 'Incluído',
      result: '2.5x melhora em força',
      impact: 'high'
    }
  ];

  return (
    <section className="py-20 md:py-32 relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 bg-gradient-to-b from-bg via-surface/50 to-bg" />
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-error/10 rounded-full blur-[120px]" />
      <div className="absolute top-1/2 right-0 w-96 h-96 bg-success/10 rounded-full blur-[120px]" />

      <div className="container-custom relative z-10 px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            De R$ 4.800 para{' '}
            <span className="bg-gradient-lightning bg-clip-text text-transparent">R$ 99</span>
          </h2>
          <p className="text-xl text-txt-2 max-w-2xl mx-auto">
            Mesmos resultados. 95% mais barato. Tecnologia que realmente funciona.
          </p>
        </motion.div>

        {/* Mobile: Horizontal scroll snap | Desktop: Grid */}
        {isMobile ? (
          <div className="horizontal-scroll gap-4 px-4 snap-scroll-x pb-2">
            {comparisons.map((item, idx) => (
              <div 
                key={idx}
                className="snap-item min-w-[280px] max-w-[280px] bg-gradient-glass backdrop-blur-sm border border-line/50 rounded-2xl p-6 touch-button"
              >
                {/* Problem */}
                <div className="mb-6 pb-6 border-b border-line/30">
                  <div className="flex items-start gap-3 mb-2">
                    <X className="w-5 h-5 text-error mt-0.5 shrink-0" />
                    <div>
                      <p className="font-semibold text-txt-2 mb-1">{item.problem}</p>
                      <p className="text-sm text-error">{item.problemCost}</p>
                    </div>
                  </div>
                </div>

                {/* Solution */}
                <div className="mb-6 pb-6 border-b border-line/30">
                  <div className="flex items-start gap-3 mb-2">
                    <Check className="w-5 h-5 text-success mt-0.5 shrink-0" />
                    <div>
                      <p className="font-semibold text-txt mb-1">{item.solution}</p>
                      <p className="text-sm text-success">{item.solutionCost}</p>
                    </div>
                  </div>
                </div>

                {/* Result */}
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${
                    item.impact === 'high' ? 'bg-accent/20' : 'bg-success/20'
                  }`}>
                    <TrendingUp className={`w-4 h-4 ${
                      item.impact === 'high' ? 'text-accent' : 'text-success'
                    }`} />
                  </div>
                  <p className="text-sm font-medium text-txt">{item.result}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <Stagger className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {comparisons.map((item, idx) => (
              <Item key={idx}>
                <div className="bg-gradient-glass backdrop-blur-sm border border-line/50 rounded-2xl p-6 hover:border-accent/50 transition-all duration-300 h-full">
                  {/* Problem */}
                  <div className="mb-6 pb-6 border-b border-line/30">
                    <div className="flex items-start gap-3 mb-2">
                      <X className="w-5 h-5 text-error mt-0.5 shrink-0" />
                      <div>
                        <p className="font-semibold text-txt-2 mb-1">{item.problem}</p>
                        <p className="text-sm text-error">{item.problemCost}</p>
                      </div>
                    </div>
                  </div>

                  {/* Solution */}
                  <div className="mb-6 pb-6 border-b border-line/30">
                    <div className="flex items-start gap-3 mb-2">
                      <Check className="w-5 h-5 text-success mt-0.5 shrink-0" />
                      <div>
                        <p className="font-semibold text-txt mb-1">{item.solution}</p>
                        <p className="text-sm text-success">{item.solutionCost}</p>
                      </div>
                    </div>
                  </div>

                  {/* Result */}
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${
                      item.impact === 'high' ? 'bg-accent/20' : 'bg-success/20'
                    }`}>
                      <TrendingUp className={`w-4 h-4 ${
                        item.impact === 'high' ? 'text-accent' : 'text-success'
                      }`} />
                    </div>
                    <p className="text-sm font-medium text-txt">{item.result}</p>
                  </div>
                </div>
              </Item>
            ))}
          </Stagger>
        )}
      </div>
    </section>
  );
}
