import { motion } from 'framer-motion';
import { TrendingUp, Brain, Dumbbell, Users, Shield, Zap } from 'lucide-react';
import { Stagger, Item } from '@/components/animations/Stagger';

interface SocialProofProps {
  userCount: number;
  workoutCount: number;
  exerciseCount: number;
}

export default function SocialProof({ userCount, workoutCount, exerciseCount }: SocialProofProps) {
  const stats = [
    {
      icon: Users,
      value: userCount,
      label: 'Atletas Transformando',
      color: 'text-accent'
    },
    {
      icon: Dumbbell,
      value: exerciseCount,
      label: 'Exercícios na Biblioteca',
      color: 'text-success'
    },
    {
      icon: TrendingUp,
      value: workoutCount,
      label: 'Treinos Realizados',
      color: 'text-warning'
    }
  ];

  const badges = [
    {
      icon: Brain,
      title: 'Tecnologia OpenAI',
      description: 'Powered by GPT-4 e Gemini Pro'
    },
    {
      icon: Shield,
      title: 'Dados Criptografados',
      description: 'Segurança nível bancário'
    },
    {
      icon: Zap,
      title: '99.9% Uptime',
      description: 'Infraestrutura Supabase'
    }
  ];

  return (
    <section className="py-20 md:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-bg via-surface to-bg" />
      <div className="absolute top-0 right-0 w-96 h-96 bg-success/10 rounded-full blur-[120px]" />

      <div className="container-custom relative z-10 px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Números{' '}
            <span className="bg-gradient-lightning bg-clip-text text-transparent">Reais</span>
          </h2>
          <p className="text-xl text-txt-2 max-w-2xl mx-auto">
            Dados ao vivo do nosso sistema. Sem truques, sem inflação.
          </p>
        </motion.div>

        {/* Stats */}
        <Stagger className="grid md:grid-cols-3 gap-8 mb-20">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <Item key={idx}>
                <div
                  className="bg-surface/95 md:bg-transparent md:bg-gradient-glass md:backdrop-blur-md border border-line/50 rounded-2xl p-8 text-center hover:border-accent/50 transition-all duration-300 hover:-translate-y-2"
                >
                  <div className={`inline-flex p-4 rounded-xl bg-surface/50 border border-line/30 mb-4 ${stat.color}`}>
                    <Icon className="w-8 h-8" />
                  </div>
                  <div className={`text-5xl md:text-6xl font-bold mb-2 ${stat.color}`}>
                    {stat.value}
                  </div>
                  <p className="text-txt-2">{stat.label}</p>
                </div>
              </Item>
            );
          })}
        </Stagger>

        {/* Trust badges */}
        <Stagger className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {badges.map((badge, idx) => {
            const Icon = badge.icon;
            return (
              <Item key={idx}>
                <div className="bg-surface/95 md:bg-transparent md:bg-gradient-glass md:backdrop-blur-md border border-line/50 rounded-2xl p-6 hover:border-accent/50 transition-all duration-300">
                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-xl bg-surface/50 border border-line/30 shrink-0">
                      <Icon className="w-6 h-6 text-accent" />
                    </div>
                    <div>
                      <h3 className="font-bold mb-1">{badge.title}</h3>
                      <p className="text-sm text-txt-2">{badge.description}</p>
                    </div>
                  </div>
                </div>
              </Item>
            );
          })}
        </Stagger>

        {/* Testimonials placeholder */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mt-20 text-center"
        >
          <div className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-surface/95 md:bg-gradient-glass md:backdrop-blur-md border border-accent/30">
            <div className="flex -space-x-2">
              <div className="w-8 h-8 rounded-full bg-gradient-lightning border-2 border-surface" />
              <div className="w-8 h-8 rounded-full bg-gradient-primary border-2 border-surface" />
              <div className="w-8 h-8 rounded-full bg-gradient-secondary border-2 border-surface" />
            </div>
            <span className="text-sm font-medium text-txt-2">
              E mais {userCount - 3} atletas confiando no VOLT
            </span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
