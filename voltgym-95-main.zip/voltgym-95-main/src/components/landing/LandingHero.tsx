import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Zap, Sparkles, TrendingUp, Play, Shield, Clock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useMobileExperience } from '@/hooks/useMobileExperience';
import { mobileVariants } from '@/utils/mobileAnimations';

interface LandingHeroProps {
  userCount: number;
  exerciseCount: number;
}

export default function LandingHero({ userCount, exerciseCount }: LandingHeroProps) {
  const navigate = useNavigate();
  const { isMobile } = useMobileExperience();

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden safe-top">
      {/* Enhanced background with animated gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-bg via-surface to-bg" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-accent/25 via-transparent to-transparent" />
      
      {/* Animated mesh gradient */}
      <motion.div 
        className="absolute inset-0 opacity-30"
        animate={{ 
          background: [
            'radial-gradient(circle at 20% 50%, hsl(213 94% 68% / 0.3) 0%, transparent 50%)',
            'radial-gradient(circle at 80% 50%, hsl(213 94% 68% / 0.3) 0%, transparent 50%)',
            'radial-gradient(circle at 20% 50%, hsl(213 94% 68% / 0.3) 0%, transparent 50%)'
          ]
        }}
        transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
      />
      
      {/* Stronger overlay for mobile readability */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-bg/40 to-bg/80" />
      
      {/* Ambient glows - optimized for mobile */}
      <motion.div 
        className={`absolute top-1/4 left-1/4 w-64 md:w-96 h-64 md:h-96 bg-electric-blue/25 rounded-full ${isMobile ? 'blur-[60px]' : 'blur-[120px]'}`}
        animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.5, 0.3] }}
        transition={{ duration: 6, repeat: Infinity }}
      />
      <motion.div 
        className={`absolute bottom-1/4 right-1/4 w-64 md:w-96 h-64 md:h-96 bg-accent/20 rounded-full ${isMobile ? 'blur-[60px]' : 'blur-[120px]'}`}
        animate={{ scale: [1.2, 1, 1.2], opacity: [0.5, 0.3, 0.5] }}
        transition={{ duration: 8, repeat: Infinity }}
      />

      {/* Content */}
      <div className="container-custom relative z-10 py-12 md:pt-20 md:pb-32 px-4 safe-padding">
        <motion.div
          variants={mobileVariants.fadeIn}
          initial="initial"
          animate="animate"
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto text-center"
        >
          {/* Badge with urgency */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-accent/20 to-accent-2/20 backdrop-blur-md border border-accent/30 mb-8"
          >
            <motion.div 
              className="w-2 h-2 rounded-full bg-success"
              animate={{ scale: [1, 1.3, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
            />
            <span className="text-sm font-medium text-txt">
              <span className="text-success font-bold">47 vagas restantes</span> • Trial Gratuito
            </span>
          </motion.div>

          {/* Emotional headline */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="text-4xl sm:text-5xl md:text-7xl font-bold mb-6 leading-[1.1] tracking-tight"
          >
            {isMobile ? (
              <>
                Chega de Treinos
                <br />
                <span className="bg-gradient-lightning bg-clip-text text-transparent">
                  Sem Resultados
                </span>
              </>
            ) : (
              <>
                Chega de Treinos{' '}
                <span className="bg-gradient-lightning bg-clip-text text-transparent">
                  Sem Resultados
                </span>
              </>
            )}
          </motion.h1>

          {/* Pain point + solution */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="text-lg md:text-2xl text-txt-2 mb-4 max-w-2xl mx-auto leading-relaxed"
          >
            {isMobile 
              ? "IA que entende seu corpo e cria treinos que funcionam"
              : "Você treina, se esforça, mas o espelho não muda. E se uma IA pudesse criar o treino perfeito para o SEU corpo?"
            }
          </motion.p>

          {/* Social proof inline */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            className="text-accent font-semibold mb-8"
          >
            +12.847 pessoas já transformaram seus corpos em 28 dias
          </motion.p>

          {/* CTAs - Prominent primary CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="flex flex-col sm:flex-row gap-3 md:gap-4 justify-center mb-8"
          >
            <Button
              size="lg"
              className="touch-button w-full sm:w-auto bg-gradient-to-r from-accent to-accent-2 text-accent-ink font-bold px-8 md:px-10 h-16 md:h-auto md:py-7 text-lg md:text-xl rounded-2xl shadow-glow hover:shadow-glow-lg transition-all duration-300 active:scale-95 md:hover:scale-105 group"
              onClick={() => navigate('/comecar')}
            >
              <Zap className="w-6 h-6 mr-2 group-hover:animate-pulse" />
              Começar 3 Dias Grátis
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="touch-button w-full sm:w-auto border-2 border-line hover:border-accent hover:bg-surface/50 text-txt font-semibold px-6 md:px-8 h-14 md:h-auto md:py-6 text-base md:text-lg rounded-2xl transition-all duration-300 active:scale-95 group"
              onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
            >
              <Play className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
              Ver Como Funciona
            </Button>
          </motion.div>

          {/* Trust badges - more prominent */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8 }}
            className="flex flex-wrap items-center justify-center gap-4 md:gap-6 text-sm"
          >
            <div className="flex items-center gap-2 px-3 py-2 bg-surface/50 rounded-full border border-line/50">
              <Shield className="w-4 h-4 text-success" />
              <span className="text-txt-2">Sem Cartão</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-2 bg-surface/50 rounded-full border border-line/50">
              <Clock className="w-4 h-4 text-accent" />
              <span className="text-txt-2">Cancele Quando Quiser</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-2 bg-surface/50 rounded-full border border-line/50">
              <TrendingUp className="w-4 h-4 text-warning" />
              <span className="text-txt-2">Resultados em 28 Dias</span>
            </div>
          </motion.div>

          {/* Stats row */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8, duration: 0.8 }}
            className="mt-16 grid grid-cols-3 gap-4 max-w-lg mx-auto"
          >
            <div className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-accent">{userCount}+</div>
              <div className="text-xs text-txt-3">Atletas Ativos</div>
            </div>
            <div className="text-center border-x border-line/30">
              <div className="text-2xl md:text-3xl font-bold text-success">95%</div>
              <div className="text-xs text-txt-3">Satisfação</div>
            </div>
            <div className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-warning">{exerciseCount}+</div>
              <div className="text-xs text-txt-3">Exercícios</div>
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1, duration: 0.8, repeat: Infinity, repeatType: 'reverse' }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <div className="w-6 h-10 border-2 border-txt-3/30 rounded-full flex items-start justify-center p-2">
          <motion.div
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-1.5 h-1.5 bg-accent rounded-full"
          />
        </div>
      </motion.div>
    </section>
  );
}
