import { motion } from 'framer-motion';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
} from "@/components/ui/carousel";
import Autoplay from "embla-carousel-autoplay";
import { LucideIcon } from 'lucide-react';

interface Feature {
  icon: LucideIcon;
  title: string;
  description: string;
  gradient: string;
  iconColor: string;
  image?: string;
  premium?: boolean;
}

interface SwipeableFeatureCardsProps {
  features: Feature[];
}

/**
 * Carousel swipe-able de features para mobile
 * Usa Embla Carousel para scroll nativo performático
 */
export function SwipeableFeatureCards({ features }: SwipeableFeatureCardsProps) {
  return (
    <Carousel
      opts={{
        align: "center",
        loop: true,
        skipSnaps: false,
        dragFree: false,
      }}
      plugins={[
        Autoplay({
          delay: 4000,
          stopOnInteraction: true,
          stopOnMouseEnter: true
        })
      ]}
      className="w-full"
    >
      <CarouselContent className="-ml-2 md:-ml-4">
        {features.map((feature, idx) => {
          const Icon = feature.icon;
          
          return (
            <CarouselItem 
              key={idx} 
              className="pl-2 basis-[75%] sm:basis-[60%]"
            >
              <motion.div
                whileTap={{ scale: 0.98 }}
                className="h-full"
              >
                <div className="relative group h-full touch-manipulation">
                  {/* Card background - ultra compact */}
                  <div className="relative h-full bg-surface/95 border border-line/30 rounded-lg p-3 overflow-hidden transition-all duration-200 flex flex-col">
                    
                    {/* Content */}
                    <div className="relative z-10 flex flex-col h-full">
                      {/* Icon */}
                      <div className={`inline-flex p-2 rounded-lg bg-surface/80 border border-line/20 mb-2 self-start ${feature.iconColor}`}>
                        <Icon className="w-4 h-4" />
                      </div>

                      {/* Title */}
                      <h3 className="text-sm font-bold mb-1.5 flex items-center gap-1.5">
                        {feature.title}
                        {feature.premium && (
                          <span className="text-[10px] px-1.5 py-0.5 bg-accent/20 text-accent rounded-full font-medium">
                            Pro
                          </span>
                        )}
                      </h3>

                      {/* Description */}
                      <p className="text-[11px] text-txt-2 leading-relaxed line-clamp-3">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </CarouselItem>
          );
        })}
      </CarouselContent>

      {/* Dots indicator - ultra compact */}
      <div className="flex justify-center gap-1 mt-2">
        {features.map((_, idx) => (
          <div
            key={idx}
            className="w-1 h-1 rounded-full bg-line/40"
          />
        ))}
      </div>
    </Carousel>
  );
}
