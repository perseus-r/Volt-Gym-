import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Zap, Check, Shield, Headphones } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface LandingCTAProps {
  userCount: number;
}

export default function LandingCTA({ userCount }: LandingCTAProps) {
  const navigate = useNavigate();

  const guarantees = [
    { icon: Check, text: 'Sem cartão de crédito' },
    { icon: Check, text: 'Cancele quando quiser' },
    { icon: Shield, text: '30 dias de garantia' },
    { icon: Headphones, text: 'Suporte 24/7' }
  ];

  return (
    <section className="section-compact relative overflow-hidden">
      {/* Background - simplified on mobile */}
      <div className="absolute inset-0 bg-gradient-to-br from-accent/10 via-purple-500/5 to-bg" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] md:w-[600px] h-[400px] md:h-[600px] bg-accent/10 rounded-full blur-[100px] md:blur-[150px]" />

      <div className="landing-container relative z-10">
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6 }}
          className="max-w-3xl mx-auto text-center"
        >
          {/* Main content - Ultra Compact */}
          <div className="cta-compact bg-surface/95 md:bg-gradient-glass md:backdrop-blur-md border border-accent/20 shadow-lg">
            {/* Headline */}
            <motion.h2
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1, duration: 0.4 }}
              className="landing-h2 mb-2 sm:mb-3 md:mb-4"
            >
              Pronto para Transformar{' '}
              <span className="bg-gradient-lightning bg-clip-text text-transparent">
                Seu Corpo?
              </span>
            </motion.h2>

            {/* Subheadline */}
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.15, duration: 0.4 }}
              className="landing-subtitle mb-3 sm:mb-4 md:mb-6"
            >
              Junte-se a {userCount} atletas treinando com IA
            </motion.p>

            {/* CTA Button - Ultra Compact */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2, duration: 0.4 }}
              className="mb-3 sm:mb-4 md:mb-6"
            >
              <Button
                size="default"
                className="cta-button-compact bg-accent hover:bg-accent-2 text-accent-ink shadow-glow transition-all duration-200"
                onClick={() => navigate('/comecar')}
              >
                <Zap className="w-4 h-4 mr-1.5" />
                Começar 3 Dias Grátis
              </Button>
            </motion.div>

            {/* Guarantees - Ultra compact grid */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.25, duration: 0.4 }}
              className="grid grid-cols-2 md:flex md:flex-wrap items-center justify-center gap-2 sm:gap-3 md:gap-4"
            >
              {guarantees.map((item, idx) => {
                const Icon = item.icon;
                return (
                  <div key={idx} className="flex items-center gap-1">
                    <div className="p-0.5 sm:p-1 rounded-full bg-success/15">
                      <Icon className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-success" />
                    </div>
                    <span className="text-[10px] sm:text-xs text-txt-2">{item.text}</span>
                  </div>
                );
              })}
            </motion.div>

            {/* Trust indicator */}
            <motion.p
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3, duration: 0.4 }}
              className="text-[10px] sm:text-xs text-txt-3 mt-3 sm:mt-4 md:mt-6"
            >
              🔒 Criptografia de nível bancário
            </motion.p>
          </div>

          {/* Bottom stats - Compact */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.5, duration: 0.5 }}
            className="mt-4 md:mt-6 flex flex-wrap justify-center gap-4 md:gap-6 text-xs text-txt-3"
          >
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" />
              <span>Ativação instantânea</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" />
              <span>Sem fidelidade</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" />
              <span>Suporte em português</span>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
