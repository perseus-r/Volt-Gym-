import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function LandingFAQ() {
  const faqs = [
    {
      question: 'Como funciona o trial de 3 dias?',
      answer: 'Você tem acesso completo ao plano Pro ou Premium por 3 dias. Sem cartão de crédito. Após os 3 dias, escolha se quer continuar. Simples assim.'
    },
    {
      question: 'Posso cancelar a qualquer momento?',
      answer: 'Sim! Sem fidelidade, sem multas, sem complicação. Cancele direto pelo app em 2 cliques. Seus dados continuam salvos se quiser voltar depois.'
    },
    {
      question: 'A IA realmente funciona?',
      answer: 'Usamos OpenAI GPT-4 e Google Gemini Pro. As mesmas tecnologias por trás do ChatGPT. Treinos personalizados baseados em seu histórico, cargas atuais e objetivos. Testado por 24 atletas reais.'
    },
    {
      question: 'Preciso de equipamentos?',
      answer: 'Não! A IA adapta treinos para casa (peso corporal) ou academia (equipamentos completos). Você escolhe no questionário inicial.'
    },
    {
      question: 'Funciona para iniciantes?',
      answer: 'Absolutamente! A IA ajusta complexidade baseado no seu nível (iniciante/intermediário/avançado). Instruções detalhadas e vídeos para cada exercício.'
    },
    {
      question: 'Qual a diferença entre Pro e Premium?',
      answer: 'Pro: treinos ilimitados + IA Coach. Premium: Pro + dashboard nutricional completo + IA Nutricionista + contador de calorias por foto + selo verificado.'
    },
    {
      question: 'Como funciona o contador de calorias IA?',
      answer: 'Fotografe sua refeição. Nossa IA com visão computacional identifica os alimentos e calcula calorias, proteínas, carboidratos e gorduras automaticamente. Funciona com qualquer comida.'
    },
    {
      question: 'Meus dados são seguros?',
      answer: 'Sim! Usamos criptografia de ponta a ponta. Banco de dados Supabase com segurança nível bancário. Seus treinos, fotos e dados nunca são compartilhados. LGPD compliant.'
    }
  ];

  return (
    <section className="section-compact relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-surface via-bg to-surface" />

      <div className="landing-container relative z-10">
        {/* Header - Compact */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-4 sm:mb-6 md:mb-10"
        >
          <h2 className="landing-h2 mb-1 sm:mb-2">
            Perguntas{' '}
            <span className="bg-gradient-lightning bg-clip-text text-transparent">Frequentes</span>
          </h2>
          <p className="landing-subtitle max-w-xl mx-auto">
            Tudo que você precisa saber
          </p>
        </motion.div>

        {/* FAQ Accordion - Ultra Compact */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="max-w-lg mx-auto"
        >
          <Accordion type="single" collapsible className="space-y-1.5 sm:space-y-2 md:space-y-3">
            {faqs.map((faq, idx) => (
              <AccordionItem
                key={idx}
                value={`item-${idx}`}
                className="bg-surface/95 border border-line/30 rounded-lg sm:rounded-xl px-3 sm:px-4 md:px-5 hover:border-accent/30 transition-colors duration-200"
              >
                <AccordionTrigger className="faq-question-compact text-left hover:text-accent transition-colors">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="faq-answer-compact">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>

        {/* Bottom CTA - Compact */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center mt-6 md:mt-8"
        >
          <p className="text-xs text-txt-3">
            Ainda tem dúvidas?{' '}
            <Link to="/contact" className="text-accent hover:text-accent-2 font-medium transition-colors">
              Fale conosco
            </Link>
          </p>
        </motion.div>
      </div>
    </section>
  );
}
