import { motion } from 'framer-motion';
import { Check, Zap, Crown, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { Stagger, Item } from '@/components/animations/Stagger';
import { useMobileExperience } from '@/hooks/useMobileExperience';

export default function LandingPricing() {
  const navigate = useNavigate();
  const { isMobile } = useMobileExperience();

  const plans = [
    {
      name: 'Atleta Free',
      price: 'Grátis',
      period: 'para sempre',
      description: 'Experimente o básico',
      features: [
        '3 treinos por mês',
        '5 consultas IA por mês',
        'Dashboard básico',
        'Biblioteca de exercícios',
        'Comunidade'
      ],
      cta: 'Começar Grátis',
      ctaVariant: 'outline' as const,
      link: '/cadastro',
      popular: false,
      icon: Zap
    },
    {
      name: 'Atleta Pro',
      price: 'R$ 99',
      period: '/mês',
      description: 'Para atletas sérios',
      features: [
        '✅ Treinos ilimitados',
        '✅ IA Coach ilimitada',
        '✅ Métricas avançadas',
        '✅ Templates profissionais',
        '✅ Programa 28 dias IA',
        '✅ Histórico completo',
        '✅ Exportar dados'
      ],
      cta: '3 Dias Grátis Pro',
      ctaVariant: 'default' as const,
      link: '/pro',
      popular: true,
      icon: Star,
      badge: 'Atletas'
    },
    {
      name: 'Personal Trainer',
      price: 'R$ 197',
      period: '/mês',
      description: 'Gerencie até 30 atletas',
      features: [
        '✅ Dashboard de gestão',
        '✅ Templates de treino',
        '✅ IA Coach personalizada',
        '✅ Análise de progresso IA',
        '✅ Relatórios automáticos',
        '✅ Branding personalizado',
        '✅ Integração WhatsApp',
        '✅ Suporte prioritário'
      ],
      cta: 'Ver Planos PT',
      ctaVariant: 'default' as const,
      link: '/pt/pricing',
      popular: false,
      icon: Crown,
      gradient: true,
      badge: 'Para PTs'
    }
  ];

  return (
    <section className="section-compact relative overflow-hidden">
      {/* Background - simplified */}
      <div className="absolute inset-0 bg-gradient-to-b from-bg via-surface to-bg" />
      <div className="absolute top-0 left-1/4 w-64 md:w-96 h-64 md:h-96 bg-accent/5 md:bg-accent/10 rounded-full blur-[80px] md:blur-[120px]" />

      <div className="landing-container relative z-10">
        {/* Header - Compact */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-6 md:mb-10"
        >
          <h2 className="landing-h2 mb-2">
            Preços{' '}
            <span className="bg-gradient-lightning bg-clip-text text-transparent">Transparentes</span>
          </h2>
          <p className="landing-subtitle max-w-xl mx-auto">
            Escolha o plano ideal. Cancele quando quiser.
          </p>
        </motion.div>

        {/* Mobile: Vertical stack with popular first | Desktop: Grid */}
        {isMobile ? (
          <div className="flex flex-col gap-3 max-w-xs mx-auto">
            {/* Popular plan first on mobile */}
            {[...plans].sort((a, b) => (b.popular ? 1 : 0) - (a.popular ? 1 : 0)).map((plan, idx) => {
              const Icon = plan.icon;
              return (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.05 }}
                  className={`pricing-card-compact relative ${plan.popular ? 'popular' : ''} ${plan.gradient ? 'bg-gradient-to-br from-purple-500/5 to-accent/5' : ''}`}
                >
                  {/* Popular badge */}
                  {plan.popular && (
                    <div className="absolute -top-2 left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-full bg-accent text-accent-ink text-[10px] font-bold shadow-glow">
                      {plan.badge}
                    </div>
                  )}

                  {/* Icon & Name */}
                  <div className="flex items-center gap-2.5 mb-2">
                    <div className={`p-1.5 rounded-lg ${plan.popular ? 'bg-accent/20 border border-accent/30' : 'bg-surface/50 border border-line/20'}`}>
                      <Icon className={`w-4 h-4 ${plan.popular ? 'text-accent' : 'text-txt-2'}`} />
                    </div>
                    <div>
                      <h3 className="text-base font-bold">{plan.name}</h3>
                      <p className="text-[10px] text-txt-3">{plan.description}</p>
                    </div>
                  </div>

                  {/* Price */}
                  <div className="mb-2.5">
                    <div className="flex items-baseline gap-1">
                      <span className="text-xl font-bold bg-gradient-lightning bg-clip-text text-transparent">
                        {plan.price}
                      </span>
                      <span className="text-txt-3 text-xs">{plan.period}</span>
                    </div>
                  </div>

                  {/* Features - ultra compact */}
                  <ul className="space-y-1 mb-3">
                    {plan.features.slice(0, 4).map((feature, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <Check className="w-3 h-3 text-success mt-0.5 shrink-0" />
                        <span className="text-[11px] text-txt-2">{feature}</span>
                      </li>
                    ))}
                    {plan.features.length > 4 && (
                      <li className="text-[10px] text-txt-3 pl-4">+{plan.features.length - 4} mais...</li>
                    )}
                  </ul>

                  {/* CTA */}
                  <Button
                    className={`w-full h-9 text-xs ${plan.ctaVariant === 'default' ? 'bg-accent hover:bg-accent-2 text-accent-ink' : 'border-line hover:bg-surface/50'}`}
                    variant={plan.ctaVariant}
                    onClick={() => navigate(plan.link)}
                  >
                    {plan.cta}
                  </Button>

                  {/* Guarantee */}
                  {idx > 0 && (
                    <p className="text-[10px] text-txt-3 text-center mt-1.5">
                      3 dias grátis • Cancele quando quiser
                    </p>
                  )}
                </motion.div>
              );
            })}
          </div>
        ) : (
          <Stagger className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {plans.map((plan, idx) => {
              const Icon = plan.icon;
              return (
                <Item key={idx}>
                  <div
                    className={`relative bg-surface/95 md:bg-transparent md:bg-gradient-glass md:backdrop-blur-sm border rounded-2xl p-8 h-full transition-all duration-300 hover:-translate-y-2 hover:scale-[1.02] ${
                      plan.popular
                        ? 'border-accent shadow-glow'
                        : 'border-line/50 hover:border-accent/50'
                    } ${plan.gradient ? 'bg-gradient-to-br from-purple-500/5 to-accent/5' : ''}`}
                  >
                    {/* Popular badge */}
                    {plan.popular && (
                      <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1.5 rounded-full bg-accent text-accent-ink text-sm font-bold shadow-glow">
                        {plan.badge}
                      </div>
                    )}

                    {/* Icon */}
                    <div className="flex items-center justify-between mb-6">
                      <div className={`p-3 rounded-xl ${
                        plan.popular
                          ? 'bg-accent/20 border border-accent/30'
                          : 'bg-surface/50 border border-line/30'
                      }`}>
                        <Icon className={`w-6 h-6 ${plan.popular ? 'text-accent' : 'text-txt-2'}`} />
                      </div>
                    </div>

                    {/* Plan name */}
                    <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                    <p className="text-sm text-txt-3 mb-6">{plan.description}</p>

                    {/* Price */}
                    <div className="mb-8">
                      <div className="flex items-baseline gap-1">
                        <span className="text-4xl md:text-5xl font-bold bg-gradient-lightning bg-clip-text text-transparent">
                          {plan.price}
                        </span>
                        <span className="text-txt-3">{plan.period}</span>
                      </div>
                    </div>

                    {/* Features */}
                    <ul className="space-y-3 mb-8">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-3">
                          <Check className="w-5 h-5 text-success mt-0.5 shrink-0" />
                          <span className="text-sm text-txt-2">{feature}</span>
                        </li>
                      ))}
                    </ul>

                    {/* CTA */}
                    <Button
                      className={`w-full ${
                        plan.ctaVariant === 'default'
                          ? 'bg-accent hover:bg-accent-2 text-accent-ink shadow-glow'
                          : 'border-line hover:bg-surface/50'
                      }`}
                      variant={plan.ctaVariant}
                      onClick={() => navigate(plan.link)}
                      size="lg"
                    >
                      {plan.cta}
                    </Button>

                    {/* Guarantee */}
                    {idx > 0 && (
                      <p className="text-xs text-txt-3 text-center mt-4">
                        3 dias grátis • Cancele quando quiser
                      </p>
                    )}
                  </div>
                </Item>
              );
            })}
          </Stagger>
        )}

        {/* Bottom note - compact */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center mt-6 md:mt-10"
        >
          <p className="text-xs text-txt-3">
            💳 Stripe • 🔒 Seguro • 🚀 Ative em segundos
          </p>
        </motion.div>
      </div>
    </section>
  );
}
