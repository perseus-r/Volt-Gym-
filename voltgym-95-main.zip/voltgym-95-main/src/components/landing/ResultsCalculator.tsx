import React, { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Scale, Percent, Dumbbell, Calendar, Sparkles, ChevronRight } from 'lucide-react';
import { useLandingProgress } from '@/hooks/useLandingProgress';
import { useDynamicTheme } from '@/hooks/useDynamicTheme';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

interface Projection {
  days: number;
  label: string;
  value: string;
  unit: string;
  icon: React.ReactNode;
}

const ResultsCalculator: React.FC = () => {
  const navigate = useNavigate();
  const { progress, isComplete } = useLandingProgress();
  const { getGradientClass, getAccentColor } = useDynamicTheme(progress.objetivo);
  const [selectedPeriod, setSelectedPeriod] = useState<30 | 60 | 90>(30);

  const projections = useMemo(() => {
    if (!isComplete) return null;

    const frequencia = progress.frequencia || 3;
    const nivel = progress.nivel;
    
    // Base multipliers based on level (beginners progress faster initially)
    const levelMultiplier = nivel === 'iniciante' ? 1.3 : nivel === 'intermediario' ? 1.0 : 0.8;
    const frequencyMultiplier = frequencia / 4;

    const results: Record<string, Record<30 | 60 | 90, Projection[]>> = {
      massa: {
        30: [
          { days: 30, label: 'Ganho de Massa', value: (1.5 * levelMultiplier * frequencyMultiplier).toFixed(1), unit: 'kg', icon: <Scale className="w-5 h-5" /> },
          { days: 30, label: 'Aumento de Força', value: (15 * levelMultiplier * frequencyMultiplier).toFixed(0), unit: '%', icon: <Dumbbell className="w-5 h-5" /> },
          { days: 30, label: 'Treinos Realizados', value: (frequencia * 4).toString(), unit: 'sessões', icon: <Calendar className="w-5 h-5" /> },
        ],
        60: [
          { days: 60, label: 'Ganho de Massa', value: (3.0 * levelMultiplier * frequencyMultiplier).toFixed(1), unit: 'kg', icon: <Scale className="w-5 h-5" /> },
          { days: 60, label: 'Aumento de Força', value: (28 * levelMultiplier * frequencyMultiplier).toFixed(0), unit: '%', icon: <Dumbbell className="w-5 h-5" /> },
          { days: 60, label: 'Treinos Realizados', value: (frequencia * 8).toString(), unit: 'sessões', icon: <Calendar className="w-5 h-5" /> },
        ],
        90: [
          { days: 90, label: 'Ganho de Massa', value: (4.5 * levelMultiplier * frequencyMultiplier).toFixed(1), unit: 'kg', icon: <Scale className="w-5 h-5" /> },
          { days: 90, label: 'Aumento de Força', value: (40 * levelMultiplier * frequencyMultiplier).toFixed(0), unit: '%', icon: <Dumbbell className="w-5 h-5" /> },
          { days: 90, label: 'Treinos Realizados', value: (frequencia * 12).toString(), unit: 'sessões', icon: <Calendar className="w-5 h-5" /> },
        ],
      },
      definicao: {
        30: [
          { days: 30, label: 'Perda de Gordura', value: (2.0 * levelMultiplier * frequencyMultiplier).toFixed(1), unit: 'kg', icon: <Scale className="w-5 h-5" /> },
          { days: 30, label: 'Redução BF%', value: (1.5 * levelMultiplier * frequencyMultiplier).toFixed(1), unit: '%', icon: <Percent className="w-5 h-5" /> },
          { days: 30, label: 'Treinos Realizados', value: (frequencia * 4).toString(), unit: 'sessões', icon: <Calendar className="w-5 h-5" /> },
        ],
        60: [
          { days: 60, label: 'Perda de Gordura', value: (4.0 * levelMultiplier * frequencyMultiplier).toFixed(1), unit: 'kg', icon: <Scale className="w-5 h-5" /> },
          { days: 60, label: 'Redução BF%', value: (3.0 * levelMultiplier * frequencyMultiplier).toFixed(1), unit: '%', icon: <Percent className="w-5 h-5" /> },
          { days: 60, label: 'Treinos Realizados', value: (frequencia * 8).toString(), unit: 'sessões', icon: <Calendar className="w-5 h-5" /> },
        ],
        90: [
          { days: 90, label: 'Perda de Gordura', value: (5.5 * levelMultiplier * frequencyMultiplier).toFixed(1), unit: 'kg', icon: <Scale className="w-5 h-5" /> },
          { days: 90, label: 'Redução BF%', value: (4.5 * levelMultiplier * frequencyMultiplier).toFixed(1), unit: '%', icon: <Percent className="w-5 h-5" /> },
          { days: 90, label: 'Treinos Realizados', value: (frequencia * 12).toString(), unit: 'sessões', icon: <Calendar className="w-5 h-5" /> },
        ],
      },
      forca: {
        30: [
          { days: 30, label: 'Aumento de Força', value: (20 * levelMultiplier * frequencyMultiplier).toFixed(0), unit: '%', icon: <Dumbbell className="w-5 h-5" /> },
          { days: 30, label: 'PRs Quebrados', value: Math.round(3 * frequencyMultiplier).toString(), unit: 'recordes', icon: <TrendingUp className="w-5 h-5" /> },
          { days: 30, label: 'Treinos Realizados', value: (frequencia * 4).toString(), unit: 'sessões', icon: <Calendar className="w-5 h-5" /> },
        ],
        60: [
          { days: 60, label: 'Aumento de Força', value: (35 * levelMultiplier * frequencyMultiplier).toFixed(0), unit: '%', icon: <Dumbbell className="w-5 h-5" /> },
          { days: 60, label: 'PRs Quebrados', value: Math.round(6 * frequencyMultiplier).toString(), unit: 'recordes', icon: <TrendingUp className="w-5 h-5" /> },
          { days: 60, label: 'Treinos Realizados', value: (frequencia * 8).toString(), unit: 'sessões', icon: <Calendar className="w-5 h-5" /> },
        ],
        90: [
          { days: 90, label: 'Aumento de Força', value: (50 * levelMultiplier * frequencyMultiplier).toFixed(0), unit: '%', icon: <Dumbbell className="w-5 h-5" /> },
          { days: 90, label: 'PRs Quebrados', value: Math.round(10 * frequencyMultiplier).toString(), unit: 'recordes', icon: <TrendingUp className="w-5 h-5" /> },
          { days: 90, label: 'Treinos Realizados', value: (frequencia * 12).toString(), unit: 'sessões', icon: <Calendar className="w-5 h-5" /> },
        ],
      },
      saude: {
        30: [
          { days: 30, label: 'Melhora Energia', value: (25 * levelMultiplier * frequencyMultiplier).toFixed(0), unit: '%', icon: <Sparkles className="w-5 h-5" /> },
          { days: 30, label: 'Qualidade Sono', value: (20 * levelMultiplier * frequencyMultiplier).toFixed(0), unit: '%', icon: <TrendingUp className="w-5 h-5" /> },
          { days: 30, label: 'Treinos Realizados', value: (frequencia * 4).toString(), unit: 'sessões', icon: <Calendar className="w-5 h-5" /> },
        ],
        60: [
          { days: 60, label: 'Melhora Energia', value: (45 * levelMultiplier * frequencyMultiplier).toFixed(0), unit: '%', icon: <Sparkles className="w-5 h-5" /> },
          { days: 60, label: 'Qualidade Sono', value: (35 * levelMultiplier * frequencyMultiplier).toFixed(0), unit: '%', icon: <TrendingUp className="w-5 h-5" /> },
          { days: 60, label: 'Treinos Realizados', value: (frequencia * 8).toString(), unit: 'sessões', icon: <Calendar className="w-5 h-5" /> },
        ],
        90: [
          { days: 90, label: 'Melhora Energia', value: (60 * levelMultiplier * frequencyMultiplier).toFixed(0), unit: '%', icon: <Sparkles className="w-5 h-5" /> },
          { days: 90, label: 'Qualidade Sono', value: (50 * levelMultiplier * frequencyMultiplier).toFixed(0), unit: '%', icon: <TrendingUp className="w-5 h-5" /> },
          { days: 90, label: 'Treinos Realizados', value: (frequencia * 12).toString(), unit: 'sessões', icon: <Calendar className="w-5 h-5" /> },
        ],
      },
    };

    return progress.objetivo ? results[progress.objetivo][selectedPeriod] : null;
  }, [progress.objetivo, progress.nivel, progress.frequencia, selectedPeriod, isComplete]);

  if (!isComplete) {
    return (
      <section className="py-16 md:py-20 px-4">
        <div className="container mx-auto max-w-4xl text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-card/50 backdrop-blur-sm rounded-3xl p-8 border border-border/50"
          >
            <Sparkles className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-xl font-semibold mb-2">Complete seu perfil</h3>
            <p className="text-muted-foreground">
              Responda as perguntas acima para ver sua projeção de resultados personalizada.
            </p>
          </motion.div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 md:py-20 px-4 relative overflow-hidden">
      {/* Background gradient */}
      <div className={`absolute inset-0 bg-gradient-to-br ${getGradientClass()} opacity-5`} />
      
      <div className="container mx-auto max-w-5xl relative">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            <Sparkles className="w-4 h-4" />
            Projeção Personalizada
          </span>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Seus Resultados Estimados
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Baseado no seu objetivo, nível e frequência de treino, aqui está o que você pode alcançar.
          </p>
        </motion.div>

        {/* Period selector */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex justify-center gap-3 mb-10"
        >
          {([30, 60, 90] as const).map((days) => (
            <button
              key={days}
              onClick={() => setSelectedPeriod(days)}
              className={`px-6 py-2.5 rounded-full font-medium transition-all ${
                selectedPeriod === days
                  ? `bg-gradient-to-r ${getGradientClass()} text-white shadow-lg`
                  : 'bg-muted hover:bg-muted/80 text-muted-foreground'
              }`}
            >
              {days} dias
            </button>
          ))}
        </motion.div>

        {/* Results cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {projections?.map((projection, index) => (
            <motion.div
              key={projection.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative group"
            >
              <div className="bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border/50 hover:border-primary/30 transition-all h-full">
                <div 
                  className={`w-12 h-12 rounded-xl bg-gradient-to-br ${getGradientClass()} flex items-center justify-center text-white mb-4`}
                >
                  {projection.icon}
                </div>
                
                <p className="text-sm text-muted-foreground mb-2">{projection.label}</p>
                
                <div className="flex items-baseline gap-1">
                  <motion.span
                    key={`${projection.value}-${selectedPeriod}`}
                    initial={{ opacity: 0, scale: 0.5 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-4xl font-bold"
                    style={{ color: getAccentColor() }}
                  >
                    {projection.value}
                  </motion.span>
                  <span className="text-muted-foreground">{projection.unit}</span>
                </div>

                {/* Progress bar */}
                <div className="mt-4 h-2 bg-muted rounded-full overflow-hidden">
                  <motion.div
                    className={`h-full bg-gradient-to-r ${getGradientClass()}`}
                    initial={{ width: 0 }}
                    whileInView={{ width: `${(selectedPeriod / 90) * 100}%` }}
                    viewport={{ once: true }}
                    transition={{ duration: 1, delay: index * 0.1 }}
                  />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Comparison section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-card/80 backdrop-blur-sm rounded-3xl p-8 border border-border/50"
        >
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-xl font-semibold mb-4">Com VOLT vs. Sem VOLT</h3>
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className={`w-3 h-3 rounded-full bg-gradient-to-r ${getGradientClass()}`} />
                  <span className="text-sm">Progressão inteligente e adaptativa</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className={`w-3 h-3 rounded-full bg-gradient-to-r ${getGradientClass()}`} />
                  <span className="text-sm">Coach IA para correções em tempo real</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className={`w-3 h-3 rounded-full bg-gradient-to-r ${getGradientClass()}`} />
                  <span className="text-sm">Tracking completo de métricas</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className={`w-3 h-3 rounded-full bg-gradient-to-r ${getGradientClass()}`} />
                  <span className="text-sm">Planos personalizados para seu objetivo</span>
                </div>
              </div>
            </div>
            
            <div className="text-center">
              <p className="text-muted-foreground mb-4">
                Usuários do VOLT alcançam resultados em média
              </p>
              <motion.div
                initial={{ scale: 0.8 }}
                whileInView={{ scale: 1 }}
                viewport={{ once: true }}
                className="inline-flex items-center gap-2"
              >
                <span 
                  className="text-5xl font-bold"
                  style={{ color: getAccentColor() }}
                >
                  2.3x
                </span>
                <span className="text-muted-foreground">mais rápido</span>
              </motion.div>
              
              <Button
                onClick={() => navigate('/auth')}
                className={`mt-6 bg-gradient-to-r ${getGradientClass()} text-white hover:opacity-90`}
              >
                Começar Agora
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default ResultsCalculator;
