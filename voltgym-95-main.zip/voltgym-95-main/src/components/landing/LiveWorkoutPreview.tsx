import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Play, 
  SkipForward, 
  Check,
  Timer,
  Dumbbell,
  ChevronRight,
  X,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { useLandingProgress } from '@/hooks/useLandingProgress';
import { useMobileExperience } from '@/hooks/useMobileExperience';
import { supabase } from '@/integrations/supabase/client';

interface DemoExercise {
  id: string | number;
  name: string;
  sets: number;
  reps: string;
  rest: number;
  muscle: string;
  videoId: string;
  thumbnail: string;
}

// Fallback mock data in case database is empty
const fallbackExercises: DemoExercise[] = [
  {
    id: 'fallback-1',
    name: 'Supino Reto',
    sets: 4,
    reps: '10-12',
    rest: 90,
    muscle: 'Peito',
    videoId: 'rT7DgCr-3pg',
    thumbnail: 'https://img.youtube.com/vi/rT7DgCr-3pg/mqdefault.jpg'
  },
  {
    id: 'fallback-2',
    name: 'Crucifixo Inclinado',
    sets: 3,
    reps: '12-15',
    rest: 60,
    muscle: 'Peito',
    videoId: 'eozdVDA78K0',
    thumbnail: 'https://img.youtube.com/vi/eozdVDA78K0/mqdefault.jpg'
  },
  {
    id: 'fallback-3',
    name: 'Tríceps Corda',
    sets: 4,
    reps: '12-15',
    rest: 60,
    muscle: 'Tríceps',
    videoId: 'vB5OHsJ3EME',
    thumbnail: 'https://img.youtube.com/vi/vB5OHsJ3EME/mqdefault.jpg'
  },
  {
    id: 'fallback-4',
    name: 'Tríceps Francês',
    sets: 3,
    reps: '10-12',
    rest: 60,
    muscle: 'Tríceps',
    videoId: 'YbX7Wd8jQ-Q',
    thumbnail: 'https://img.youtube.com/vi/YbX7Wd8jQ-Q/mqdefault.jpg'
  }
];

interface ExerciseModalProps {
  exercise: DemoExercise;
  onClose: () => void;
}

const ExerciseModal = ({ exercise, onClose }: ExerciseModalProps) => (
  <motion.div
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
    className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
    onClick={onClose}
  >
    <motion.div
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      exit={{ scale: 0.9, opacity: 0 }}
      className="bg-background rounded-2xl overflow-hidden max-w-lg w-full"
      onClick={(e) => e.stopPropagation()}
    >
      <div className="relative aspect-video bg-black">
        <iframe
          src={`https://www.youtube.com/embed/${exercise.videoId}?autoplay=1&rel=0&modestbranding=1`}
          className="absolute inset-0 w-full h-full"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
        <button
          onClick={onClose}
          className="absolute top-4 right-4 w-10 h-10 rounded-full bg-black/50 flex items-center justify-center text-white hover:bg-black/70 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>
      <div className="p-4">
        <h3 className="font-bold text-lg mb-1">{exercise.name}</h3>
        <p className="text-sm text-muted-foreground">
          {exercise.sets} séries × {exercise.reps} reps • {exercise.rest}s descanso
        </p>
      </div>
    </motion.div>
  </motion.div>
);

export const LiveWorkoutPreview = () => {
  const navigate = useNavigate();
  const { isMobile } = useMobileExperience();
  const { markWorkoutPreviewSeen } = useLandingProgress();
  const [currentExercise, setCurrentExercise] = useState(0);
  const [currentSet, setCurrentSet] = useState(1);
  const [isResting, setIsResting] = useState(false);
  const [restTime, setRestTime] = useState(0);
  const [showVideo, setShowVideo] = useState<DemoExercise | null>(null);
  const [completedSets, setCompletedSets] = useState<Record<string | number, number[]>>({});
  const [exercises, setExercises] = useState<DemoExercise[]>(fallbackExercises);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch exercises from database
  useEffect(() => {
    const fetchExercises = async () => {
      try {
        // Fetch exercises with youtube_video_id from different muscle groups
        const { data, error } = await supabase
          .from('exercises')
          .select('id, name, youtube_video_id, primary_muscles, category_id')
          .not('youtube_video_id', 'is', null)
          .limit(20);

        if (error) throw error;

        if (data && data.length >= 4) {
          // Group exercises by primary muscle and select varied ones
          const muscleGroups: Record<string, typeof data> = {};
          
          data.forEach(ex => {
            const muscle = ex.primary_muscles?.[0] || 'Geral';
            if (!muscleGroups[muscle]) muscleGroups[muscle] = [];
            muscleGroups[muscle].push(ex);
          });

          // Select exercises from different muscle groups for variety
          const selectedExercises: DemoExercise[] = [];
          const muscleKeys = Object.keys(muscleGroups);
          
          // Try to get 4 exercises from different groups
          let index = 0;
          while (selectedExercises.length < 4 && index < 10) {
            for (const muscle of muscleKeys) {
              if (selectedExercises.length >= 4) break;
              const exercisesInGroup = muscleGroups[muscle];
              const exerciseIndex = Math.floor(index / muscleKeys.length);
              
              if (exercisesInGroup[exerciseIndex]) {
                const ex = exercisesInGroup[exerciseIndex];
                // Avoid duplicates
                if (!selectedExercises.find(s => s.id === ex.id)) {
                  selectedExercises.push({
                    id: ex.id,
                    name: ex.name,
                    sets: Math.floor(Math.random() * 2) + 3, // 3-4 sets
                    reps: ['8-10', '10-12', '12-15'][Math.floor(Math.random() * 3)],
                    rest: [60, 75, 90][Math.floor(Math.random() * 3)],
                    muscle: ex.primary_muscles?.[0] || 'Geral',
                    videoId: ex.youtube_video_id!,
                    thumbnail: `https://img.youtube.com/vi/${ex.youtube_video_id}/mqdefault.jpg`
                  });
                }
              }
            }
            index++;
          }

          if (selectedExercises.length >= 4) {
            setExercises(selectedExercises);
          }
        }
      } catch (error) {
        console.error('Error fetching exercises:', error);
        // Keep fallback exercises on error
      } finally {
        setIsLoading(false);
      }
    };

    fetchExercises();
  }, []);

  useEffect(() => {
    markWorkoutPreviewSeen();
  }, [markWorkoutPreviewSeen]);

  // Rest Timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isResting && restTime > 0) {
      interval = setInterval(() => {
        setRestTime(prev => prev - 1);
      }, 1000);
    } else if (restTime === 0 && isResting) {
      setIsResting(false);
    }
    return () => clearInterval(interval);
  }, [isResting, restTime]);

  const exercise = exercises[currentExercise];

  const completeSet = () => {
    if (!exercise) return;
    
    setCompletedSets(prev => ({
      ...prev,
      [exercise.id]: [...(prev[exercise.id] || []), currentSet]
    }));

    if (currentSet < exercise.sets) {
      setCurrentSet(prev => prev + 1);
      setRestTime(exercise.rest);
      setIsResting(true);
    } else if (currentExercise < exercises.length - 1) {
      setCurrentExercise(prev => prev + 1);
      setCurrentSet(1);
    }
  };

  const skipRest = () => {
    setIsResting(false);
    setRestTime(0);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const totalProgress = exercises.reduce((acc, ex) => {
    return acc + (completedSets[ex.id]?.length || 0);
  }, 0);
  const totalSets = exercises.reduce((acc, ex) => acc + ex.sets, 0);

  // Get workout title based on muscle groups
  const workoutTitle = (() => {
    const muscles = [...new Set(exercises.map(e => e.muscle))];
    if (muscles.length <= 2) return muscles.join(' + ');
    return `${muscles[0]} + ${muscles[1]} + Mais`;
  })();

  if (isLoading) {
    return (
      <section className="py-16 md:py-20 bg-gradient-to-b from-background to-muted/30">
        <div className="container mx-auto px-4 flex items-center justify-center min-h-[400px]">
          <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 md:py-20 bg-gradient-to-b from-background to-muted/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-orange-500/10 border border-orange-500/20 mb-4">
            <Dumbbell className="w-4 h-4 text-orange-500" />
            <span className="text-sm font-medium text-orange-500">Demo Interativa</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-black mb-4">
            Experimente um
            <span className="text-orange-500"> Treino Real</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Clique nos exercícios para ver os vídeos, complete séries e teste o timer de descanso.
          </p>
        </motion.div>

        {/* Workout Interface */}
        <div className={`max-w-4xl mx-auto ${isMobile ? '' : 'grid grid-cols-2 gap-8'}`}>
          {/* Exercise List */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-3 mb-8 lg:mb-0"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold">Treino: {workoutTitle}</h3>
              <span className="text-sm text-muted-foreground">
                {totalProgress}/{totalSets} séries
              </span>
            </div>
            
            {/* Progress Bar */}
            <div className="h-2 bg-muted rounded-full overflow-hidden mb-4">
              <motion.div
                className="h-full bg-gradient-to-r from-orange-500 to-red-500"
                initial={{ width: 0 }}
                animate={{ width: `${(totalProgress / totalSets) * 100}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>

            {exercises.map((ex, index) => {
              const isActive = index === currentExercise;
              const exerciseCompletedSets = completedSets[ex.id]?.length || 0;
              const isComplete = exerciseCompletedSets >= ex.sets;

              return (
                <div
                  key={ex.id}
                  onClick={() => setShowVideo(ex)}
                  className={`p-4 rounded-xl border-2 cursor-pointer transition-all hover:scale-[1.02] active:scale-[0.98] ${
                    isActive 
                      ? 'border-orange-500 bg-orange-500/10' 
                      : isComplete
                        ? 'border-green-500/50 bg-green-500/5'
                        : 'border-border hover:border-orange-500/50 bg-card'
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <div className="relative w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <img 
                        src={ex.thumbnail} 
                        alt={ex.name}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = '/placeholder.svg';
                        }}
                      />
                      <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                        <Play className="w-6 h-6 text-white" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold">{ex.name}</h4>
                        {isComplete && <Check className="w-4 h-4 text-green-500" />}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {ex.sets} séries × {ex.reps} reps
                      </p>
                      <div className="flex gap-1 mt-2">
                        {Array.from({ length: ex.sets }).map((_, i) => (
                          <div
                            key={i}
                            className={`w-6 h-1.5 rounded-full ${
                              (completedSets[ex.id]?.includes(i + 1)) 
                                ? 'bg-green-500' 
                                : 'bg-muted'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    <ChevronRight className="w-5 h-5 text-muted-foreground" />
                  </div>
                </div>
              );
            })}
          </motion.div>

          {/* Active Exercise / Rest Screen */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-card rounded-2xl border border-border overflow-hidden"
          >
            <AnimatePresence mode="wait">
              {isResting ? (
                <motion.div
                  key="rest"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="p-8 text-center"
                >
                  <Timer className="w-12 h-12 text-accent mx-auto mb-4" />
                  <h3 className="text-xl font-bold mb-2">Tempo de Descanso</h3>
                  <motion.div
                    className="text-6xl font-black text-accent mb-6"
                    key={restTime}
                    initial={{ scale: 1.2 }}
                    animate={{ scale: 1 }}
                  >
                    {formatTime(restTime)}
                  </motion.div>
                  
                  {/* Progress Ring */}
                  <div className="relative w-32 h-32 mx-auto mb-6">
                    <svg className="w-full h-full transform -rotate-90">
                      <circle
                        cx="64"
                        cy="64"
                        r="56"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="none"
                        className="text-muted"
                      />
                      <motion.circle
                        cx="64"
                        cy="64"
                        r="56"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="none"
                        strokeLinecap="round"
                        className="text-accent"
                        initial={{ pathLength: 1 }}
                        animate={{ pathLength: restTime / exercise.rest }}
                        transition={{ duration: 0.5 }}
                        style={{ strokeDasharray: '352', strokeDashoffset: '0' }}
                      />
                    </svg>
                  </div>

                  <Button onClick={skipRest} variant="outline" className="gap-2">
                    <SkipForward className="w-4 h-4" />
                    Pular Descanso
                  </Button>
                </motion.div>
              ) : (
                <motion.div
                  key="exercise"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  {/* Video Thumbnail */}
                  <div 
                    onClick={() => setShowVideo(exercise)}
                    className="relative aspect-video bg-black cursor-pointer group"
                  >
                    <img 
                      src={exercise.thumbnail}
                      alt={exercise.name}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = '/placeholder.svg';
                      }}
                    />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center group-hover:bg-black/50 transition-colors">
                      <div className="w-16 h-16 rounded-full bg-white/90 flex items-center justify-center hover:scale-110 transition-transform">
                        <Play className="w-8 h-8 text-orange-500 ml-1" />
                      </div>
                    </div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <span className="px-2 py-1 bg-black/60 rounded text-white text-xs">
                        Clique para ver demonstração
                      </span>
                    </div>
                  </div>

                  {/* Exercise Info */}
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-bold">{exercise.name}</h3>
                        <p className="text-sm text-muted-foreground">{exercise.muscle}</p>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-accent">
                          Série {currentSet}/{exercise.sets}
                        </div>
                        <p className="text-sm text-muted-foreground">{exercise.reps} reps</p>
                      </div>
                    </div>

                    {/* Set Indicators */}
                    <div className="flex gap-2 mb-6">
                      {Array.from({ length: exercise.sets }).map((_, i) => (
                        <motion.div
                          key={i}
                          className={`flex-1 h-2 rounded-full ${
                            completedSets[exercise.id]?.includes(i + 1)
                              ? 'bg-green-500'
                              : i + 1 === currentSet
                                ? 'bg-accent'
                                : 'bg-muted'
                          }`}
                          animate={i + 1 === currentSet ? { scale: [1, 1.1, 1] } : {}}
                          transition={{ duration: 0.5, repeat: Infinity }}
                        />
                      ))}
                    </div>

                    <Button 
                      onClick={completeSet}
                      className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:opacity-90 text-lg py-6"
                    >
                      <Check className="w-5 h-5 mr-2" />
                      Completar Série
                    </Button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <p className="text-muted-foreground mb-4">
            Gostou da experiência? Crie sua conta para acessar treinos completos!
          </p>
          <Button 
            onClick={() => navigate('/auth')}
            size="lg"
            className="bg-gradient-to-r from-orange-500 to-red-500 hover:opacity-90"
          >
            Começar Meu Treino Grátis
            <ChevronRight className="w-5 h-5 ml-2" />
          </Button>
        </motion.div>
      </div>

      {/* Video Modal */}
      <AnimatePresence>
        {showVideo && (
          <ExerciseModal exercise={showVideo} onClose={() => setShowVideo(null)} />
        )}
      </AnimatePresence>
    </section>
  );
};

export default LiveWorkoutPreview;
