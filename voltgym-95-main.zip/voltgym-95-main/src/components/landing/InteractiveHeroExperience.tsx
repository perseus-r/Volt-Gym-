import { useState, useEffect, memo, lazy, Suspense } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { 
  Target, 
  Dumbbell, 
  Flame, 
  Heart,
  Sparkles,
  ArrowRight,
  Check,
  Zap
} from 'lucide-react';
import { useLandingProgress, LandingProgress } from '@/hooks/useLandingProgress';
import { useIsMobile } from '@/hooks/use-mobile';
import { useDynamicTheme } from '@/hooks/useDynamicTheme';
import { celebrations } from '@/utils/celebrations';

// Lazy load Phone3DMock - pesado
const Phone3DMock = lazy(() => import('./Phone3DMock'));

const objetivos = [
  { id: 'massa', label: 'Ganhar Massa', icon: Dumbbell, color: 'from-blue-500 to-cyan-500' },
  { id: 'definicao', label: 'Definir Corpo', icon: Flame, color: 'from-orange-500 to-red-500' },
  { id: 'forca', label: 'Ficar Forte', icon: Target, color: 'from-purple-500 to-pink-500' },
  { id: 'saude', label: 'Saúde Geral', icon: Heart, color: 'from-green-500 to-emerald-500' },
];

const niveis = [
  { id: 'iniciante', label: 'Iniciante', desc: 'Menos de 6 meses' },
  { id: 'intermediario', label: 'Intermediário', desc: '6 meses a 2 anos' },
  { id: 'avancado', label: 'Avançado', desc: 'Mais de 2 anos' },
];

const frequencias = [2, 3, 4, 5, 6];

interface PhoneMockContentProps {
  progress: LandingProgress;
}

// Content simplificado para o phone mock
const PhoneMockContent = memo(({ progress }: PhoneMockContentProps) => {
  const objetivo = objetivos.find(o => o.id === progress.objetivo);
  const nivel = niveis.find(n => n.id === progress.nivel);
  
  return (
    <div className="h-full w-full bg-gradient-to-b from-background to-muted pt-8">
      {!progress.objetivo ? (
        <div className="h-full flex flex-col items-center justify-center p-6 text-center">
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-accent to-primary flex items-center justify-center mb-4">
            <Zap className="w-8 h-8 text-primary-foreground" />
          </div>
          <p className="text-sm text-muted-foreground">
            Selecione seu objetivo
          </p>
        </div>
      ) : !progress.nivel ? (
        <div className="h-full flex flex-col p-4">
          <div className={`h-24 rounded-xl bg-gradient-to-r ${objetivo?.color} flex items-center justify-center mb-4`}>
            {objetivo && <objetivo.icon className="w-12 h-12 text-white" />}
          </div>
          <h3 className="font-bold text-lg mb-1">{objetivo?.label}</h3>
          <p className="text-xs text-muted-foreground">
            Selecione seu nível
          </p>
        </div>
      ) : !progress.frequencia ? (
        <div className="h-full flex flex-col p-4">
          <div className={`h-20 rounded-xl bg-gradient-to-r ${objetivo?.color} flex items-center justify-center mb-3`}>
            {objetivo && <objetivo.icon className="w-10 h-10 text-white" />}
          </div>
          <div className="flex items-center gap-2 mb-3">
            <Check className="w-4 h-4 text-green-500" />
            <span className="text-sm">{nivel?.label}</span>
          </div>
          <p className="text-xs text-muted-foreground">
            Quantos dias por semana?
          </p>
        </div>
      ) : (
        <div className="h-full flex flex-col p-4">
          <div className="text-xs text-muted-foreground mb-2">Seu Treino</div>
          <div className={`h-16 rounded-xl bg-gradient-to-r ${objetivo?.color} flex items-center px-4 gap-3 mb-3`}>
            {objetivo && <objetivo.icon className="w-8 h-8 text-white" />}
            <div className="text-white">
              <div className="font-bold text-sm">{objetivo?.label}</div>
              <div className="text-xs opacity-80">{progress.frequencia}x/semana</div>
            </div>
          </div>
          
          <div className="space-y-2 flex-1">
            {['Supino Reto', 'Crucifixo', 'Tríceps'].map((ex, i) => (
              <div
                key={ex}
                className="flex items-center gap-3 p-2 bg-muted/50 rounded-lg"
              >
                <div className="w-8 h-8 rounded bg-accent/20 flex items-center justify-center">
                  <Dumbbell className="w-4 h-4 text-accent" />
                </div>
                <div className="flex-1">
                  <div className="text-xs font-medium">{ex}</div>
                  <div className="text-[10px] text-muted-foreground">4x12</div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-3 py-2 px-4 bg-accent text-accent-foreground rounded-full text-center text-sm font-medium">
            Iniciar Treino
          </div>
        </div>
      )}
    </div>
  );
});

const InteractiveHeroExperience = () => {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const { progress, setObjetivo, setNivel, setFrequencia, isComplete } = useLandingProgress();
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    if (progress.objetivo && !progress.nivel) setCurrentStep(1);
    else if (progress.nivel && !progress.frequencia) setCurrentStep(2);
    else if (progress.frequencia) setCurrentStep(3);
  }, [progress]);

  useEffect(() => {
    if (isComplete) {
      celebrations.completeQuiz();
    }
  }, [isComplete]);

  return (
    <section className="relative min-h-screen flex items-start justify-center bg-gradient-to-b from-background via-background to-muted/30">
      {/* Background estático - SEM animações infinitas */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-primary/5 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 container mx-auto px-4 pt-24 md:pt-32 pb-20">
        <div className={`flex ${isMobile ? 'flex-col' : 'flex-row'} items-center gap-12`}>
          {/* Left: Interactive Quiz */}
          <div className="flex-1 max-w-xl">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/20 mb-6">
              <Sparkles className="w-4 h-4 text-accent" />
              <span className="text-sm font-medium text-accent">Experimente Agora - Sem Cadastro</span>
            </div>

            {/* Headline */}
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-black mb-4 leading-tight">
              Seu Treino
              <span className="block bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">
                Personalizado por IA
              </span>
            </h1>

            <p className="text-lg text-muted-foreground mb-8">
              Responda 3 perguntas e veja instantaneamente como seria seu treino ideal.
            </p>

            {/* Progress Steps - sem animação infinita */}
            <div className="flex items-center gap-2 mb-6">
              {[0, 1, 2].map((step) => (
                <div key={step} className="flex items-center gap-2">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-colors ${
                      currentStep > step 
                        ? 'bg-green-500 text-white' 
                        : currentStep === step 
                          ? 'bg-accent text-accent-foreground' 
                          : 'bg-muted text-muted-foreground'
                    }`}
                  >
                    {currentStep > step ? <Check className="w-4 h-4" /> : step + 1}
                  </div>
                  {step < 2 && (
                    <div className={`w-8 h-1 rounded transition-colors ${currentStep > step ? 'bg-green-500' : 'bg-muted'}`} />
                  )}
                </div>
              ))}
            </div>

            {/* Interactive Steps - animações simplificadas */}
            <AnimatePresence mode="wait">
              {currentStep === 0 && (
                <motion.div
                  key="step-0"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  transition={{ duration: 0.2 }}
                  className="space-y-4"
                >
                  <h2 className="text-xl font-bold">Qual seu principal objetivo?</h2>
                  <div className="grid grid-cols-2 gap-3">
                    {objetivos.map((obj) => (
                      <button
                        key={obj.id}
                        onClick={() => setObjetivo(obj.id as LandingProgress['objetivo'])}
                        className={`p-4 rounded-xl border-2 transition-all active:scale-95 ${
                          progress.objetivo === obj.id 
                            ? 'border-accent bg-accent/10' 
                            : 'border-border hover:border-accent/50 bg-card'
                        }`}
                      >
                        <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${obj.color} flex items-center justify-center mb-2 mx-auto`}>
                          <obj.icon className="w-5 h-5 text-white" />
                        </div>
                        <span className="font-medium text-sm">{obj.label}</span>
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}

              {currentStep === 1 && (
                <motion.div
                  key="step-1"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  transition={{ duration: 0.2 }}
                  className="space-y-4"
                >
                  <h3 className="text-xl font-bold">Qual seu nível de experiência?</h3>
                  <div className="space-y-3">
                    {niveis.map((nivel) => (
                      <button
                        key={nivel.id}
                        onClick={() => setNivel(nivel.id as LandingProgress['nivel'])}
                        className={`w-full p-4 rounded-xl border-2 text-left transition-all active:scale-[0.98] ${
                          progress.nivel === nivel.id 
                            ? 'border-accent bg-accent/10' 
                            : 'border-border hover:border-accent/50 bg-card'
                        }`}
                      >
                        <span className="font-medium">{nivel.label}</span>
                        <span className="text-sm text-muted-foreground ml-2">({nivel.desc})</span>
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}

              {currentStep === 2 && (
                <motion.div
                  key="step-2"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 10 }}
                  transition={{ duration: 0.2 }}
                  className="space-y-4"
                >
                  <h3 className="text-xl font-bold">Quantos dias por semana você treina?</h3>
                  <div className="flex gap-3 flex-wrap">
                    {frequencias.map((freq) => (
                      <button
                        key={freq}
                        onClick={() => setFrequencia(freq)}
                        className={`w-14 h-14 rounded-full border-2 font-bold text-lg transition-all active:scale-90 ${
                          progress.frequencia === freq 
                            ? 'border-accent bg-accent text-accent-foreground' 
                            : 'border-border hover:border-accent/50 bg-card'
                        }`}
                      >
                        {freq}x
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}

              {currentStep === 3 && (
                <motion.div
                  key="step-3"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.2 }}
                  className="space-y-4"
                >
                  <div className="p-4 rounded-xl bg-green-500/10 border border-green-500/20">
                    <div className="flex items-center gap-2 text-green-500 mb-2">
                      <Check className="w-5 h-5" />
                      <span className="font-bold">Perfil Configurado!</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Role a página para explorar mais funcionalidades!
                    </p>
                  </div>
                  
                  <Button 
                    onClick={() => navigate('/auth')}
                    size="lg"
                    className="w-full bg-gradient-to-r from-accent to-primary hover:opacity-90 text-lg py-6"
                  >
                    Criar Minha Conta Grátis
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                  
                  <p className="text-xs text-center text-muted-foreground">
                    Suas escolhas serão salvas automaticamente
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Right: 3D Phone Mock - Lazy loaded */}
          {!isMobile && (
            <div className="flex-shrink-0">
              <Suspense fallback={
                <div className="w-[280px] h-[560px] bg-muted/20 rounded-[3rem] animate-pulse" />
              }>
                <Phone3DMock className="w-[280px]" intensity={8}>
                  <PhoneMockContent progress={progress} />
                </Phone3DMock>
              </Suspense>
            </div>
          )}
        </div>

        {/* Scroll Indicator - sem animação infinita */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
          <span className="text-sm text-muted-foreground">Role para explorar</span>
          <svg 
            className="w-6 h-6 text-muted-foreground animate-bounce"
            fill="none" 
            viewBox="0 0 24 24" 
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </div>
      </div>
    </section>
  );
};

export default InteractiveHeroExperience;
