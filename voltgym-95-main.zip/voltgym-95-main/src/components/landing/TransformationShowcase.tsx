import { motion } from 'framer-motion';
import { TrendingDown, TrendingUp, Target, Award, ArrowRight, Flame } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const transformations = [
  {
    name: 'Lucas T.',
    period: '90 dias',
    category: 'Perda de Peso',
    metrics: [
      { label: 'Peso', before: '98kg', after: '82kg', change: '-16kg', icon: TrendingDown, color: 'success' },
      { label: 'Gordura', before: '32%', after: '18%', change: '-14%', icon: Target, color: 'success' },
      { label: 'Força', before: '60kg', after: '95kg', change: '+58%', icon: TrendingUp, color: 'accent' }
    ],
    avatar: 'LT',
    gradient: 'from-success/20 to-success/5'
  },
  {
    name: 'Fernanda M.',
    period: '60 dias',
    category: 'Definição',
    metrics: [
      { label: 'BF%', before: '26%', after: '18%', change: '-8%', icon: TrendingDown, color: 'success' },
      { label: 'Cintura', before: '82cm', after: '71cm', change: '-11cm', icon: Target, color: 'success' },
      { label: 'Músculo', before: '-', after: '+3kg', change: '+3kg', icon: TrendingUp, color: 'accent' }
    ],
    avatar: 'FM',
    gradient: 'from-accent/20 to-accent/5'
  },
  {
    name: 'Ricardo S.',
    period: '120 dias',
    category: 'Hipertrofia',
    metrics: [
      { label: 'Massa', before: '68kg', after: '78kg', change: '+10kg', icon: TrendingUp, color: 'accent' },
      { label: 'Supino', before: '60kg', after: '100kg', change: '+67%', icon: Award, color: 'warning' },
      { label: 'Braço', before: '32cm', after: '38cm', change: '+6cm', icon: TrendingUp, color: 'accent' }
    ],
    avatar: 'RS',
    gradient: 'from-warning/20 to-warning/5'
  },
  {
    name: 'Patrícia L.',
    period: '45 dias',
    category: 'Condicionamento',
    metrics: [
      { label: 'Cardio', before: '5min', after: '30min', change: '6x mais', icon: Flame, color: 'error' },
      { label: 'Energia', before: 'Baixa', after: 'Alta', change: '+200%', icon: TrendingUp, color: 'success' },
      { label: 'Sono', before: '5h', after: '7h', change: '+40%', icon: Target, color: 'accent' }
    ],
    avatar: 'PL',
    gradient: 'from-error/20 to-error/5'
  }
];

export default function TransformationShowcase() {
  const navigate = useNavigate();

  return (
    <section className="py-20 md:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-surface/50 via-bg to-surface/50" />

      <div className="container-custom relative z-10 px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-2 rounded-full bg-accent/10 text-accent text-sm font-medium mb-6">
            Resultados Comprovados
          </span>
          <h2 className="text-3xl md:text-5xl font-bold mb-4">
            Transformações{' '}
            <span className="bg-gradient-lightning bg-clip-text text-transparent">
              Que Inspiram
            </span>
          </h2>
          <p className="text-lg text-txt-2 max-w-2xl mx-auto">
            Números reais de pessoas reais. Sem photoshop, sem mentiras - apenas dedicação e a orientação certa.
          </p>
        </motion.div>

        {/* Transformations Grid */}
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          {transformations.map((item, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              className={`bg-gradient-to-br ${item.gradient} backdrop-blur-sm border border-line/50 rounded-3xl p-6 md:p-8 hover:border-accent/50 transition-all duration-300 group`}
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-accent to-accent-2 flex items-center justify-center text-lg font-bold text-accent-ink">
                    {item.avatar}
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">{item.name}</h3>
                    <p className="text-txt-3 text-sm">{item.category}</p>
                  </div>
                </div>
                <div className="px-3 py-1.5 bg-surface/80 rounded-full">
                  <span className="text-sm font-medium text-accent">{item.period}</span>
                </div>
              </div>

              {/* Metrics */}
              <div className="space-y-4">
                {item.metrics.map((metric, mIdx) => (
                  <div key={mIdx} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl bg-${metric.color}/20 flex items-center justify-center`}>
                        <metric.icon className={`w-5 h-5 text-${metric.color}`} />
                      </div>
                      <div>
                        <p className="text-sm text-txt-3">{metric.label}</p>
                        <div className="flex items-center gap-2">
                          <span className="text-txt-3 line-through text-xs">{metric.before}</span>
                          <ArrowRight className="w-3 h-3 text-txt-3" />
                          <span className="font-bold">{metric.after}</span>
                        </div>
                      </div>
                    </div>
                    <div className={`px-3 py-1 rounded-lg bg-${metric.color}/20`}>
                      <span className={`text-sm font-bold text-${metric.color}`}>{metric.change}</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Verified badge */}
              <div className="mt-6 pt-4 border-t border-line/30 flex items-center justify-between">
                <span className="text-xs text-txt-3 flex items-center gap-1">
                  <Award className="w-3 h-3 text-success" />
                  Resultado verificado pela equipe VOLT
                </span>
                <div className="w-2 h-2 rounded-full bg-success animate-pulse" />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <p className="text-txt-2 mb-6">
            A próxima transformação pode ser a{' '}
            <span className="text-accent font-semibold">sua</span>
          </p>
          <Button
            size="lg"
            className="bg-gradient-to-r from-accent to-accent-2 text-accent-ink font-bold px-8 py-6 text-lg rounded-2xl shadow-glow hover:shadow-glow-lg transition-all duration-300"
            onClick={() => navigate('/comecar')}
          >
            Começar Minha Transformação
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
