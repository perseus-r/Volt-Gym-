import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef, useState, useEffect } from 'react';
import { Smartphone, Play, Sparkles, TrendingUp, Dumbbell, Brain } from 'lucide-react';

const screens = [
  {
    title: 'Dashboard Inteligente',
    description: 'Veja seu progresso em tempo real',
    icon: TrendingUp,
    gradient: 'from-accent to-accent-2',
    mockContent: (
      <div className="p-4 space-y-3">
        <div className="flex justify-between items-center">
          <span className="text-xs text-txt-3">Hoje</span>
          <span className="text-xs text-success">+12% esta semana</span>
        </div>
        <div className="h-24 bg-gradient-to-r from-accent/30 to-accent/10 rounded-lg flex items-end p-2 gap-1">
          {[40, 60, 45, 80, 70, 90, 85].map((h, i) => (
            <div key={i} className="flex-1 bg-accent rounded-t" style={{ height: `${h}%` }} />
          ))}
        </div>
        <div className="grid grid-cols-3 gap-2">
          {['Treinos', 'Calorias', 'Streak'].map((label, i) => (
            <div key={i} className="bg-surface/50 rounded-lg p-2 text-center">
              <div className="text-lg font-bold text-accent">{[12, 2840, 7][i]}</div>
              <div className="text-[10px] text-txt-3">{label}</div>
            </div>
          ))}
        </div>
      </div>
    )
  },
  {
    title: 'IA Coach em Ação',
    description: 'Converse e tire dúvidas 24/7',
    icon: Brain,
    gradient: 'from-purple-500 to-pink-500',
    mockContent: (
      <div className="p-4 space-y-3">
        <div className="flex gap-2">
          <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center">
            <Brain className="w-4 h-4 text-accent" />
          </div>
          <div className="flex-1 bg-surface/50 rounded-2xl rounded-tl-none p-3">
            <p className="text-xs">Analisei seu treino de ontem. Você está progredindo bem! 💪</p>
          </div>
        </div>
        <div className="flex gap-2 flex-row-reverse">
          <div className="w-8 h-8 rounded-full bg-success/20 flex items-center justify-center">
            <span className="text-xs">EU</span>
          </div>
          <div className="flex-1 bg-accent/20 rounded-2xl rounded-tr-none p-3">
            <p className="text-xs">O que devo focar hoje?</p>
          </div>
        </div>
        <div className="flex gap-2">
          <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center">
            <Brain className="w-4 h-4 text-accent" />
          </div>
          <div className="flex-1 bg-surface/50 rounded-2xl rounded-tl-none p-3">
            <p className="text-xs">Recomendo treino de pernas com foco em quadríceps. Separei 6 exercícios ideais para você!</p>
          </div>
        </div>
      </div>
    )
  },
  {
    title: 'Treino Guiado',
    description: 'Exercícios com vídeo e timer',
    icon: Dumbbell,
    gradient: 'from-orange-500 to-red-500',
    mockContent: (
      <div className="p-4 space-y-3">
        <div className="bg-gradient-to-br from-accent/20 to-accent/5 rounded-xl p-3">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 bg-surface rounded-lg flex items-center justify-center">
              <Play className="w-6 h-6 text-accent" />
            </div>
            <div>
              <p className="font-semibold text-sm">Supino Reto</p>
              <p className="text-xs text-txt-3">3x12 • 60kg</p>
            </div>
          </div>
          <div className="flex gap-2">
            <div className="flex-1 h-1 bg-accent rounded-full" />
            <div className="flex-1 h-1 bg-accent rounded-full" />
            <div className="flex-1 h-1 bg-line rounded-full" />
          </div>
        </div>
        <div className="text-center py-4">
          <div className="text-4xl font-bold text-accent">01:23</div>
          <p className="text-xs text-txt-3 mt-1">Descanso restante</p>
        </div>
        <div className="bg-success/20 rounded-lg p-2 text-center">
          <p className="text-xs text-success font-medium">🔥 Novo recorde pessoal!</p>
        </div>
      </div>
    )
  },
  {
    title: 'Progresso Visual',
    description: 'Gráficos e métricas detalhadas',
    icon: Sparkles,
    gradient: 'from-green-500 to-emerald-500',
    mockContent: (
      <div className="p-4 space-y-3">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium">Evolução 28 dias</span>
          <span className="text-xs text-success">Meta: 95%</span>
        </div>
        <div className="space-y-2">
          {[
            { label: 'Força', value: 85, color: 'accent' },
            { label: 'Consistência', value: 92, color: 'success' },
            { label: 'Recuperação', value: 78, color: 'warning' }
          ].map((item, i) => (
            <div key={i}>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-txt-3">{item.label}</span>
                <span className={`text-${item.color}`}>{item.value}%</span>
              </div>
              <div className="h-2 bg-surface rounded-full overflow-hidden">
                <div 
                  className={`h-full bg-${item.color} rounded-full`}
                  style={{ width: `${item.value}%` }}
                />
              </div>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-2 mt-3">
          <div className="bg-surface/50 rounded-lg p-2 text-center">
            <div className="text-lg font-bold text-success">-4.2kg</div>
            <div className="text-[10px] text-txt-3">Gordura</div>
          </div>
          <div className="bg-surface/50 rounded-lg p-2 text-center">
            <div className="text-lg font-bold text-accent">+2.8kg</div>
            <div className="text-[10px] text-txt-3">Músculo</div>
          </div>
        </div>
      </div>
    )
  }
];

export default function AppPreviewSection() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [activeScreen, setActiveScreen] = useState(0);
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], [100, -100]);

  // Auto-rotate screens
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveScreen((prev) => (prev + 1) % screens.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section ref={containerRef} className="py-20 md:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-bg via-surface/30 to-bg" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-accent/10 via-transparent to-transparent" />

      <div className="container-custom relative z-10 px-4">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left: Phone mockup */}
          <motion.div
            style={{ y }}
            className="relative flex justify-center order-2 lg:order-1"
          >
            {/* Glow effect */}
            <div className="absolute inset-0 bg-accent/20 blur-[80px] rounded-full scale-75" />
            
            {/* Phone frame */}
            <div className="relative">
              <div className="w-[280px] md:w-[320px] h-[560px] md:h-[640px] bg-gradient-to-b from-card to-surface rounded-[3rem] border-4 border-line/50 shadow-2xl overflow-hidden">
                {/* Notch */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-bg rounded-b-2xl z-10" />
                
                {/* Screen content */}
                <div className="absolute inset-2 bg-bg rounded-[2.5rem] overflow-hidden">
                  {/* Status bar */}
                  <div className="h-12 bg-surface/50 flex items-center justify-between px-6 pt-2">
                    <span className="text-xs text-txt-3">9:41</span>
                    <div className="flex gap-1">
                      <div className="w-4 h-2 bg-txt-3 rounded-sm" />
                      <div className="w-4 h-2 bg-txt-3 rounded-sm" />
                    </div>
                  </div>
                  
                  {/* App header */}
                  <div className="px-4 py-3 border-b border-line/30">
                    <div className="flex items-center gap-2">
                      <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${screens[activeScreen].gradient} flex items-center justify-center`}>
                        {(() => {
                          const Icon = screens[activeScreen].icon;
                          return <Icon className="w-4 h-4 text-white" />;
                        })()}
                      </div>
                      <div>
                        <p className="text-sm font-semibold">{screens[activeScreen].title}</p>
                        <p className="text-[10px] text-txt-3">{screens[activeScreen].description}</p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Dynamic content */}
                  <motion.div
                    key={activeScreen}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                  >
                    {screens[activeScreen].mockContent}
                  </motion.div>
                </div>
              </div>

              {/* Floating elements */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity }}
                className="absolute -right-8 top-1/4 bg-gradient-glass backdrop-blur-md border border-line/50 rounded-xl p-3 shadow-lg"
              >
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-success/20 flex items-center justify-center">
                    <TrendingUp className="w-4 h-4 text-success" />
                  </div>
                  <div>
                    <p className="text-xs font-medium">+23%</p>
                    <p className="text-[10px] text-txt-3">força</p>
                  </div>
                </div>
              </motion.div>

              <motion.div
                animate={{ y: [0, 10, 0] }}
                transition={{ duration: 4, repeat: Infinity }}
                className="absolute -left-8 bottom-1/3 bg-gradient-glass backdrop-blur-md border border-line/50 rounded-xl p-3 shadow-lg"
              >
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center">
                    <Sparkles className="w-4 h-4 text-accent" />
                  </div>
                  <div>
                    <p className="text-xs font-medium">12 dias</p>
                    <p className="text-[10px] text-txt-3">streak</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>

          {/* Right: Content */}
          <div className="order-1 lg:order-2">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 text-accent text-sm font-medium mb-6">
                <Smartphone className="w-4 h-4" />
                Veja o app em ação
              </span>
              
              <h2 className="text-3xl md:text-5xl font-bold mb-6">
                Seu Personal Trainer{' '}
                <span className="bg-gradient-lightning bg-clip-text text-transparent">
                  No Bolso
                </span>
              </h2>
              
              <p className="text-lg text-txt-2 mb-8">
                Interface intuitiva, treinos guiados em vídeo, IA que responde suas dúvidas 24/7 e progresso visual que te motiva a continuar.
              </p>

              {/* Screen selector */}
              <div className="grid grid-cols-2 gap-3">
                {screens.map((screen, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveScreen(idx)}
                    className={`p-4 rounded-xl border text-left transition-all duration-300 ${
                      activeScreen === idx 
                        ? 'bg-accent/10 border-accent/50' 
                        : 'bg-surface/50 border-line/50 hover:border-accent/30'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${screen.gradient} flex items-center justify-center`}>
                        <screen.icon className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <p className="font-medium text-sm">{screen.title}</p>
                        <p className="text-xs text-txt-3">{screen.description}</p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>

              {/* Progress dots */}
              <div className="flex gap-2 mt-6 justify-center lg:justify-start">
                {screens.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveScreen(idx)}
                    className={`h-1.5 rounded-full transition-all duration-300 ${
                      activeScreen === idx 
                        ? 'w-8 bg-accent' 
                        : 'w-1.5 bg-line hover:bg-txt-3'
                    }`}
                  />
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
