import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  LayoutDashboard, 
  Dumbbell, 
  Brain, 
  TrendingUp,
  Play,
  MessageSquare,
  Target,
  Zap,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { useMobileExperience } from '@/hooks/useMobileExperience';

const screens = [
  {
    id: 'dashboard',
    title: 'Dashboard Inteligente',
    description: 'Visão completa do seu progresso, treinos do dia e metas personalizadas.',
    icon: LayoutDashboard,
    color: 'from-blue-500 to-cyan-500',
    bgColor: 'rgba(59, 130, 246, 0.25)',
    content: (
      <div className="p-4 h-full flex flex-col">
        <div className="text-xs text-muted-foreground mb-2">Bom dia, João!</div>
        <div className="h-16 rounded-xl bg-gradient-to-r from-blue-500 to-cyan-500 mb-3 flex items-center px-4">
          <div className="text-white">
            <div className="font-bold">Treino de Hoje</div>
            <div className="text-xs opacity-80">Peito + Tríceps • 45 min</div>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 mb-3">
          <div className="p-3 bg-muted/50 rounded-lg">
            <div className="text-lg font-bold text-accent">12</div>
            <div className="text-[10px] text-muted-foreground">Treinos este mês</div>
          </div>
          <div className="p-3 bg-muted/50 rounded-lg">
            <div className="text-lg font-bold text-green-500">+15%</div>
            <div className="text-[10px] text-muted-foreground">Evolução</div>
          </div>
        </div>
        <div className="flex-1 bg-muted/30 rounded-lg p-2">
          <div className="text-[10px] text-muted-foreground mb-1">Volume Semanal</div>
          <div className="flex items-end gap-1 h-12">
            {[40, 65, 45, 80, 55, 90, 70].map((h, i) => (
              <motion.div
                key={i}
                initial={{ height: 0 }}
                animate={{ height: `${h}%` }}
                transition={{ delay: i * 0.1, duration: 0.5 }}
                className="flex-1 bg-gradient-to-t from-accent to-accent/50 rounded-t"
              />
            ))}
          </div>
        </div>
      </div>
    )
  },
  {
    id: 'workout',
    title: 'Treinos Guiados',
    description: 'Vídeos demonstrativos, timer de descanso e registro automático de progresso.',
    icon: Dumbbell,
    color: 'from-orange-500 to-red-500',
    bgColor: 'rgba(249, 115, 22, 0.25)',
    content: (
      <div className="p-4 h-full flex flex-col">
        <div className="h-28 rounded-xl bg-gradient-to-br from-orange-500/20 to-red-500/20 mb-3 flex items-center justify-center relative overflow-hidden">
          <div className="absolute inset-0 bg-[url('/placeholder.svg')] bg-cover bg-center opacity-30" />
          <div className="w-12 h-12 rounded-full bg-white/90 flex items-center justify-center z-10">
            <Play className="w-6 h-6 text-orange-500 ml-1" />
          </div>
        </div>
        <div className="font-bold mb-1">Supino Reto</div>
        <div className="text-xs text-muted-foreground mb-3">4 séries × 12 repetições</div>
        <div className="space-y-2">
          {[1, 2, 3, 4].map((set) => (
            <div key={set} className="flex items-center gap-2">
              <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${set <= 2 ? 'bg-green-500 text-white' : 'bg-muted'}`}>
                {set}
              </div>
              <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: set <= 2 ? '100%' : '0%' }}
                  className="h-full bg-green-500"
                />
              </div>
              <span className="text-xs text-muted-foreground">80kg</span>
            </div>
          ))}
        </div>
      </div>
    )
  },
  {
    id: 'ai-coach',
    title: 'Coach de IA',
    description: 'Tire dúvidas, receba sugestões e adapte treinos em tempo real com inteligência artificial.',
    icon: Brain,
    color: 'from-purple-500 to-pink-500',
    bgColor: 'rgba(168, 85, 247, 0.25)',
    content: (
      <div className="p-4 h-full flex flex-col">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
            <Brain className="w-4 h-4 text-white" />
          </div>
          <div>
            <div className="font-bold text-sm">VOLT Coach</div>
            <div className="text-[10px] text-green-500">Online</div>
          </div>
        </div>
        <div className="flex-1 space-y-2 overflow-hidden">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="max-w-[80%] p-2 bg-muted rounded-lg rounded-tl-none text-xs"
          >
            Como posso te ajudar hoje?
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="max-w-[80%] ml-auto p-2 bg-accent text-accent-foreground rounded-lg rounded-tr-none text-xs"
          >
            Qual exercício substitui supino?
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.6 }}
            className="max-w-[80%] p-2 bg-muted rounded-lg rounded-tl-none text-xs"
          >
            Você pode usar o Supino com Halteres ou o Crucifixo na máquina. Ambos trabalham o peitoral de forma similar! 💪
          </motion.div>
        </div>
        <div className="mt-2 flex items-center gap-2">
          <div className="flex-1 h-9 bg-muted rounded-full px-3 flex items-center">
            <MessageSquare className="w-4 h-4 text-muted-foreground" />
            <span className="text-xs text-muted-foreground ml-2">Digite sua dúvida...</span>
          </div>
        </div>
      </div>
    )
  },
  {
    id: 'progress',
    title: 'Análise de Progresso',
    description: 'Gráficos detalhados, recordes pessoais e insights sobre sua evolução.',
    icon: TrendingUp,
    color: 'from-green-500 to-emerald-500',
    bgColor: 'rgba(34, 197, 94, 0.25)',
    content: (
      <div className="p-4 h-full flex flex-col">
        <div className="text-xs text-muted-foreground mb-2">Últimos 30 dias</div>
        <div className="grid grid-cols-3 gap-2 mb-3">
          <div className="p-2 bg-green-500/10 rounded-lg text-center">
            <div className="text-sm font-bold text-green-500">+2.5kg</div>
            <div className="text-[10px] text-muted-foreground">Massa</div>
          </div>
          <div className="p-2 bg-orange-500/10 rounded-lg text-center">
            <div className="text-sm font-bold text-orange-500">-3.2%</div>
            <div className="text-[10px] text-muted-foreground">Gordura</div>
          </div>
          <div className="p-2 bg-purple-500/10 rounded-lg text-center">
            <div className="text-sm font-bold text-purple-500">+18%</div>
            <div className="text-[10px] text-muted-foreground">Força</div>
          </div>
        </div>
        <div className="flex-1 bg-muted/30 rounded-lg p-2">
          <div className="text-[10px] text-muted-foreground mb-1">Evolução de Carga - Supino</div>
          <div className="h-20 flex items-end">
            <svg viewBox="0 0 100 40" className="w-full h-full">
              <motion.path
                d="M 0 35 Q 20 30, 40 25 T 60 20 T 80 12 T 100 5"
                fill="none"
                stroke="url(#gradient)"
                strokeWidth="2"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 2 }}
              />
              <defs>
                <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#22c55e" />
                  <stop offset="100%" stopColor="#10b981" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        </div>
        <div className="mt-2 p-2 bg-accent/10 rounded-lg flex items-center gap-2">
          <Target className="w-4 h-4 text-accent" />
          <span className="text-xs">Novo PR: Supino 100kg! 🎉</span>
        </div>
      </div>
    )
  }
];


// Mobile Component - No useScroll dependency
const MobileScrollytellingContent = () => {
  const [activeScreen, setActiveScreen] = useState(0);

  return (
    <section className="py-16 bg-gradient-to-b from-muted/30 to-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/20 mb-4">
            <Zap className="w-4 h-4 text-accent" />
            <span className="text-sm font-medium text-accent">Explore o App</span>
          </div>
          <h2 className="text-2xl font-black mb-2">
            Tudo que você precisa em
            <span className="block text-accent">um só lugar</span>
          </h2>
        </motion.div>

        {/* Tabs Navigation */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2 scrollbar-hide">
          {screens.map((screen, index) => (
            <button
              key={screen.id}
              onClick={() => setActiveScreen(index)}
              className={`flex items-center gap-2 px-4 py-2 rounded-full whitespace-nowrap transition-all ${
                activeScreen === index 
                  ? 'bg-accent text-accent-foreground' 
                  : 'bg-muted/50 text-muted-foreground'
              }`}
            >
              <screen.icon className="w-4 h-4" />
              <span className="text-sm font-medium">{screen.title.split(' ')[0]}</span>
            </button>
          ))}
        </div>

        {/* Active Screen Content */}
        <motion.div
          key={activeScreen}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="bg-background rounded-3xl border border-border shadow-xl overflow-hidden"
        >
          {/* Screen Header */}
          <div className="p-4 border-b border-border flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${screens[activeScreen].color} flex items-center justify-center`}>
              {(() => {
                const Icon = screens[activeScreen].icon;
                return <Icon className="w-5 h-5 text-white" />;
              })()}
            </div>
            <div>
              <h3 className="font-bold text-sm">{screens[activeScreen].title}</h3>
              <p className="text-xs text-muted-foreground">{screens[activeScreen].description}</p>
            </div>
          </div>
          
          {/* Screen Content */}
          <div className="h-[320px]">
            {screens[activeScreen].content}
          </div>
        </motion.div>

        {/* Dots Indicator */}
        <div className="flex justify-center gap-2 mt-4">
          {screens.map((_, index) => (
            <button
              key={index}
              onClick={() => setActiveScreen(index)}
              className={`w-2 h-2 rounded-full transition-all ${
                activeScreen === index ? 'w-6 bg-accent' : 'bg-muted-foreground/30'
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

// Desktop Component - Click-based navigation only
const DesktopScrollytellingContent = () => {
  const [activeScreen, setActiveScreen] = useState(0);
  
  const nextScreen = () => setActiveScreen(prev => Math.min(prev + 1, screens.length - 1));
  const prevScreen = () => setActiveScreen(prev => Math.max(prev - 1, 0));

  return (
    <section className="py-20 bg-gradient-to-b from-muted/30 via-background to-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/20 mb-4">
            <Zap className="w-4 h-4 text-accent" />
            <span className="text-sm font-medium text-accent">Explore o App</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-black mb-4">
            Tudo que você precisa em
            <span className="block text-accent">um só lugar</span>
          </h2>
          <p className="text-muted-foreground max-w-md mx-auto">
            Clique nas funcionalidades ou use as setas para navegar
          </p>
        </motion.div>

        {/* Main Content Grid */}
        <div className="flex flex-row items-center gap-12 lg:gap-16 max-w-6xl mx-auto">
          {/* Left: Clickable Cards */}
          <div className="flex-1 max-w-lg space-y-3">
            {screens.map((screen, index) => (
              <button
                key={screen.id}
                onClick={() => setActiveScreen(index)}
                className={`flex items-start gap-4 p-4 rounded-xl transition-all cursor-pointer w-full text-left hover:scale-[1.02] active:scale-[0.98] ${
                  activeScreen === index 
                    ? 'bg-accent/10 border-2 border-accent/50 opacity-100 translate-x-2' 
                    : 'bg-transparent border-2 border-transparent hover:bg-muted/30 opacity-60 scale-[0.98]'
                }`}
              >
                <div 
                  className={`w-12 h-12 rounded-xl bg-gradient-to-br ${screen.color} flex items-center justify-center flex-shrink-0 transition-transform ${
                    activeScreen === index ? 'scale-110' : ''
                  }`}
                >
                  <screen.icon className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold mb-1">{screen.title}</h3>
                  <p className="text-sm text-muted-foreground">{screen.description}</p>
                </div>
                {activeScreen === index && (
                  <div className="ml-auto self-center w-2 h-8 bg-accent rounded-full" />
                )}
              </button>
            ))}
          </div>

          {/* Right: Phone Mock with Navigation */}
          <div className="flex-shrink-0 hidden md:flex items-center gap-4">
            {/* Previous Button */}
            <button
              onClick={prevScreen}
              disabled={activeScreen === 0}
              className={`w-12 h-12 rounded-full flex items-center justify-center transition-all hover:scale-110 active:scale-90 ${
                activeScreen === 0 
                  ? 'bg-muted/30 text-muted-foreground/30 cursor-not-allowed hover:scale-100' 
                  : 'bg-muted hover:bg-accent/20 text-foreground hover:text-accent'
              }`}
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            {/* Phone Mock */}
            <div className="relative">
              {/* Static glow effect - no animation */}
              <div
                className={`absolute -inset-8 bg-gradient-to-br ${screens[activeScreen].color} opacity-15 blur-3xl rounded-full`}
              />
              
              <div className="relative w-[280px] h-[560px] bg-background rounded-[2.5rem] border-4 border-foreground/20 shadow-2xl overflow-hidden">
                {/* Static border glow */}
                <div 
                  className={`absolute inset-0 rounded-[2.5rem] border-2 bg-gradient-to-br ${screens[activeScreen].color} opacity-25`}
                />
                
                {/* Notch */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-28 h-6 bg-foreground/20 rounded-b-xl z-20" />
                
                {/* Screen Content with AnimatePresence */}
                <div className="absolute inset-2 bg-gradient-to-b from-background to-muted/30 rounded-[2rem] overflow-hidden">
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={screens[activeScreen].id}
                      className="absolute inset-0 h-full w-full"
                      initial={{ opacity: 0, x: 50, scale: 0.98 }}
                      animate={{ opacity: 1, x: 0, scale: 1 }}
                      exit={{ opacity: 0, x: -50, scale: 0.98 }}
                      transition={{ 
                        duration: 0.35, 
                        ease: [0.4, 0, 0.2, 1]
                      }}
                    >
                      <div className="h-full w-full overflow-hidden">
                        {screens[activeScreen].content}
                      </div>
                    </motion.div>
                  </AnimatePresence>
                </div>

                {/* Home Indicator */}
                <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-28 h-1 bg-foreground/20 rounded-full" />
              </div>

              {/* Dots below phone */}
              <div className="flex justify-center gap-2 mt-6">
                {screens.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setActiveScreen(index)}
                    className={`h-2 rounded-full transition-all hover:scale-125 active:scale-90 ${
                      activeScreen === index 
                        ? 'w-6 bg-accent' 
                        : 'w-2 bg-muted-foreground/30 hover:bg-muted-foreground/50'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Next Button */}
            <button
              onClick={nextScreen}
              disabled={activeScreen === screens.length - 1}
              className={`w-12 h-12 rounded-full flex items-center justify-center transition-all hover:scale-110 active:scale-90 ${
                activeScreen === screens.length - 1 
                  ? 'bg-muted/30 text-muted-foreground/30 cursor-not-allowed hover:scale-100' 
                  : 'bg-muted hover:bg-accent/20 text-foreground hover:text-accent'
              }`}
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

// Main Component - Conditionally renders after mount
export const ScrollytellingApp = () => {
  const { isMobile } = useMobileExperience();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  // Placeholder while mounting to avoid hydration mismatch
  if (!mounted) {
    return <div className="min-h-[400px] bg-gradient-to-b from-muted/30 to-background" />;
  }

  return isMobile ? <MobileScrollytellingContent /> : <DesktopScrollytellingContent />;
};

export default ScrollytellingApp;
