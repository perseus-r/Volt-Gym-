import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Brain, 
  Send, 
  Sparkles,
  Lock,
  ArrowRight,
  MessageSquare
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { useLandingProgress } from '@/hooks/useLandingProgress';

const MAX_FREE_QUESTIONS = 2;

const suggestedQuestions = [
  "Como ganhar massa muscular?",
  "Qual a melhor dieta para definir?",
  "Quantas vezes devo treinar por semana?",
  "Como aumentar minha força no supino?"
];

// Pre-defined responses for demo
const demoResponses: Record<string, string> = {
  "como ganhar massa muscular": `Para ganhar massa muscular de forma eficiente, foque em:

**1. Treino com Sobrecarga Progressiva**
Aumente gradualmente peso/reps a cada semana

**2. Alimentação Rica em Proteína**
Consuma 1.6-2.2g de proteína por kg de peso corporal

**3. Descanso Adequado**
Durma 7-9 horas e descanse 48h entre treinos do mesmo grupo

**4. Consistência**
Mantenha a rotina por pelo menos 12 semanas

Quer que eu crie um treino personalizado para você? 💪`,

  "qual a melhor dieta para definir": `Para definição muscular, a chave é o **déficit calórico controlado**:

**1. Calcule seu TDEE** e subtraia 300-500 calorias

**2. Mantenha Proteína Alta**
2.0-2.4g/kg para preservar massa muscular

**3. Carboidratos Estratégicos**
Mais nos dias de treino, menos nos de descanso

**4. Gorduras Saudáveis**
Pelo menos 0.8g/kg para hormônios

**5. Hidratação**
3-4 litros de água por dia

Quer que eu calcule suas macros ideais? 🎯`,

  "quantas vezes devo treinar por semana": `A frequência ideal depende do seu nível e objetivos:

**Iniciante (0-6 meses)**
• 3x por semana - Full Body
• Foco em aprender os movimentos

**Intermediário (6m-2 anos)**
• 4-5x por semana - Upper/Lower ou Push/Pull/Legs
• Maior volume e intensidade

**Avançado (+2 anos)**
• 5-6x por semana - Divisão específica
• Periodização e técnicas avançadas

O mais importante é a **consistência**! Melhor 3x que você consegue manter do que 6x que abandona em 2 semanas.

Qual é seu nível atual? Posso sugerir a melhor divisão! 📊`,

  "como aumentar minha força no supino": `Para aumentar sua força no supino, siga este protocolo:

**1. Técnica Perfeita**
• Escápulas retraídas e deprimidas
• Arco lombar natural
• Pegada 1.5x largura dos ombros

**2. Programação Inteligente**
• 3-5 séries de 3-6 reps (força)
• RPE 7-9 nas séries principais
• Progressão semanal de 2.5-5kg

**3. Exercícios Auxiliares**
• Supino inclinado com halteres
• Tríceps (francês, mergulho)
• Desenvolvimento de ombros

**4. Descanso**
• 3-5 min entre séries pesadas
• 48-72h entre sessões de peito

Qual é sua carga atual no supino? Posso calcular uma progressão ideal! 🏋️`,

  default: `Ótima pergunta! Para te dar a melhor resposta possível, preciso conhecer mais sobre você:

• Qual seu objetivo principal?
• Há quanto tempo treina?
• Tem alguma limitação ou lesão?

Com essas informações, posso criar um plano personalizado!

**Crie sua conta grátis** para ter acesso ilimitado ao Coach de IA e receber orientações personalizadas baseadas no seu perfil completo. 🚀`
};

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

export const AICoachDemo = () => {
  const navigate = useNavigate();
  const { progress, incrementAIQuestions } = useLandingProgress();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Olá! Sou o **VOLT Coach**, sua IA de treino pessoal. Você tem **2 perguntas gratuitas** para experimentar. O que gostaria de saber?'
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const questionsRemaining = MAX_FREE_QUESTIONS - progress.aiQuestionsUsed;
  const isLocked = questionsRemaining <= 0;

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const getResponse = (question: string): string => {
    const normalizedQuestion = question.toLowerCase().trim();
    
    for (const [key, response] of Object.entries(demoResponses)) {
      if (key !== 'default' && normalizedQuestion.includes(key)) {
        return response;
      }
    }
    
    return demoResponses.default;
  };

  const sendMessage = async (text: string) => {
    if (isLocked || !text.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);
    incrementAIQuestions();

    // Simulate AI thinking
    await new Promise(resolve => setTimeout(resolve, 1500));

    const response = getResponse(text);
    const assistantMessage: Message = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: response
    };

    setMessages(prev => [...prev, assistantMessage]);
    setIsTyping(false);

    // Check if locked after this question
    if (progress.aiQuestionsUsed + 1 >= MAX_FREE_QUESTIONS) {
      setTimeout(() => {
        setMessages(prev => [...prev, {
          id: (Date.now() + 2).toString(),
          role: 'assistant',
          content: '🔒 Você usou suas **2 perguntas gratuitas**! Crie sua conta para continuar conversando comigo e ter acesso a treinos personalizados, análise de progresso e muito mais.'
        }]);
      }, 1000);
    }
  };

  return (
    <section className="py-16 md:py-20 bg-gradient-to-b from-muted/30 to-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-500/10 border border-purple-500/20 mb-4">
            <Brain className="w-4 h-4 text-purple-500" />
            <span className="text-sm font-medium text-purple-500">IA Coach - Demo</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-black mb-4">
            Converse com seu
            <span className="text-purple-500"> Personal de IA</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Tire suas dúvidas sobre treino, dieta e progressão. Experimente agora com {questionsRemaining} pergunta{questionsRemaining !== 1 ? 's' : ''} gratuita{questionsRemaining !== 1 ? 's' : ''}!
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-2xl mx-auto"
        >
          {/* Chat Container */}
          <div className="bg-card rounded-2xl border border-border overflow-hidden shadow-xl">
            {/* Header */}
            <div className="p-4 border-b border-border bg-gradient-to-r from-purple-500/10 to-pink-500/10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                  <Brain className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-bold">VOLT Coach</h3>
                  <div className="flex items-center gap-1 text-xs text-green-500">
                    <span className="w-2 h-2 rounded-full bg-green-500" />
                    Online
                  </div>
                </div>
                <div className="ml-auto text-right">
                  <div className="text-sm font-medium">{questionsRemaining} pergunta{questionsRemaining !== 1 ? 's' : ''}</div>
                  <div className="text-xs text-muted-foreground">restante{questionsRemaining !== 1 ? 's' : ''}</div>
                </div>
              </div>
            </div>

            {/* Messages */}
            <div className="h-[400px] overflow-y-auto p-4 space-y-4">
              <AnimatePresence initial={false}>
                {messages.map((message) => (
                  <motion.div
                    key={message.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] p-3 rounded-2xl ${
                        message.role === 'user'
                          ? 'bg-accent text-accent-foreground rounded-tr-none'
                          : 'bg-muted rounded-tl-none'
                      }`}
                    >
                      <div 
                        className="text-sm whitespace-pre-wrap"
                        dangerouslySetInnerHTML={{ 
                          __html: message.content
                            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                            .replace(/\n/g, '<br />')
                        }}
                      />
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>

              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-muted rounded-2xl rounded-tl-none p-3">
                    <div className="flex gap-1">
                      <span className="w-2 h-2 rounded-full bg-purple-500 animate-bounce" style={{ animationDelay: '0ms', animationDuration: '600ms', animationIterationCount: 3 }} />
                      <span className="w-2 h-2 rounded-full bg-purple-500 animate-bounce" style={{ animationDelay: '150ms', animationDuration: '600ms', animationIterationCount: 3 }} />
                      <span className="w-2 h-2 rounded-full bg-purple-500 animate-bounce" style={{ animationDelay: '300ms', animationDuration: '600ms', animationIterationCount: 3 }} />
                    </div>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Suggested Questions */}
            {!isLocked && messages.length <= 2 && (
              <div className="px-4 pb-2">
                <p className="text-xs text-muted-foreground mb-2">Sugestões:</p>
                <div className="flex flex-wrap gap-2">
                  {suggestedQuestions.map((question) => (
                    <button
                      key={question}
                      onClick={() => sendMessage(question)}
                      className="px-3 py-1.5 text-xs bg-muted hover:bg-muted/80 rounded-full transition-colors active:scale-95"
                    >
                      {question}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Input */}
            <div className="p-4 border-t border-border">
              {isLocked ? (
                <div className="text-center">
                  <div className="flex items-center justify-center gap-2 text-muted-foreground mb-3">
                    <Lock className="w-4 h-4" />
                    <span className="text-sm">Limite de perguntas atingido</span>
                  </div>
                  <Button 
                    onClick={() => navigate('/auth')}
                    className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:opacity-90"
                  >
                    <Sparkles className="w-4 h-4 mr-2" />
                    Criar Conta para Acesso Ilimitado
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              ) : (
                <form 
                  onSubmit={(e) => { e.preventDefault(); sendMessage(input); }}
                  className="flex gap-2"
                >
                  <div className="flex-1 relative">
                    <MessageSquare className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <input
                      type="text"
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      placeholder="Digite sua pergunta..."
                      className="w-full pl-10 pr-4 py-3 bg-muted rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-accent"
                      disabled={isTyping}
                    />
                  </div>
                  <Button 
                    type="submit" 
                    size="icon" 
                    className="w-12 h-12 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 hover:opacity-90"
                    disabled={!input.trim() || isTyping}
                  >
                    <Send className="w-5 h-5" />
                  </Button>
                </form>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default AICoachDemo;
