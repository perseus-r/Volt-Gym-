import { motion } from 'framer-motion';
import { Brain, Dumbbell, Apple, TrendingUp, Users, ShoppingBag, Sparkles } from 'lucide-react';
import { Stagger, Item } from '@/components/animations/Stagger';
import { useMobileExperience } from '@/hooks/useMobileExperience';
import { SwipeableFeatureCards } from './SwipeableFeatureCards';

export default function FeaturesShowcase() {
  const { isMobile } = useMobileExperience();
  
  const features = [
    {
      icon: Brain,
      title: 'IA Coach - Seu Personal 24/7',
      description: 'Peça um treino e a IA cria na hora. Ajuste automático de cargas baseado em RPE. Programas de 28 dias gerados por IA.',
      gradient: 'from-purple-500/20 to-accent/20',
      iconColor: 'text-purple-400',
      image: '🤖'
    },
    {
      icon: Dumbbell,
      title: 'Sistema de Treinos Inteligente',
      description: 'Builder customizado, templates prontos (Push/Pull/Legs), histórico completo de séries e cargas, calendário integrado.',
      gradient: 'from-accent/20 to-success/20',
      iconColor: 'text-accent',
      image: '🏋️'
    },
    {
      icon: Apple,
      title: 'Nutrição com IA (Premium)',
      description: 'Fotografe sua refeição → IA conta calorias e macros automaticamente. Dashboard nutricional completo com IA Nutricionista.',
      gradient: 'from-success/20 to-warning/20',
      iconColor: 'text-success',
      image: '🥗',
      premium: true
    },
    {
      icon: TrendingUp,
      title: 'Progresso & Gamificação',
      description: 'Sistema de níveis e XP, conquistas desbloqueáveis, streak de dias, ranking competitivo, análise de balanceamento muscular.',
      gradient: 'from-warning/20 to-error/20',
      iconColor: 'text-warning',
      image: '📊'
    },
    {
      icon: Users,
      title: 'Comunidade Fitness',
      description: 'Feed social inteligente com IA, compartilhe seus PRs e conquistas, inspire-se com outros atletas em tempo real.',
      gradient: 'from-accent/20 to-purple-500/20',
      iconColor: 'text-accent-2',
      image: '👥'
    },
    {
      icon: ShoppingBag,
      title: 'Loja Fitness Integrada',
      description: 'Suplementos e equipamentos, checkout via WhatsApp ou Stripe, rastreamento de pedidos, tudo em um só lugar.',
      gradient: 'from-error/20 to-accent/20',
      iconColor: 'text-error',
      image: '🛒'
    }
  ];

  return (
    <section id="features" className="section-compact relative overflow-hidden">
      {/* Background - simplified on mobile */}
      <div className="absolute inset-0 bg-gradient-to-b from-bg via-surface to-bg" />
      <div className="absolute top-0 left-1/4 w-64 md:w-96 h-64 md:h-96 bg-accent/5 md:bg-accent/10 rounded-full blur-[80px] md:blur-[120px]" />

      <div className="landing-container relative z-10">
        {/* Header - Compact */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-6 md:mb-10"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-surface/95 border border-line/30 mb-4">
            <Sparkles className="w-3.5 h-3.5 text-accent" />
            <span className="text-xs font-medium text-txt-2">Tudo que você precisa</span>
          </div>
          <h2 className="landing-h2 mb-2">
            Funcionalidades{' '}
            <span className="bg-gradient-lightning bg-clip-text text-transparent">Reais</span>
          </h2>
          <p className="landing-subtitle max-w-xl mx-auto">
            Não é promessa. É o que está funcionando agora.
          </p>
        </motion.div>

        {/* Mobile: Swipeable carousel | Desktop: Grid */}
        {isMobile ? (
          <SwipeableFeatureCards features={features} />
        ) : (
          <Stagger className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5">
            {features.map((feature, idx) => {
              const Icon = feature.icon;
              return (
                <Item key={idx}>
                  <div className="feature-card-compact h-full group overflow-hidden hover:-translate-y-1">
                    {/* Gradient background */}
                    <div className={`absolute inset-0 bg-gradient-to-br ${feature.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-300`} />
                    
                    {/* Content */}
                    <div className="relative z-10">
                      {/* Icon */}
                      <div className="flex items-center justify-between mb-3">
                        <div className="p-2 rounded-lg bg-surface/50 border border-line/20">
                          <Icon className={`w-5 h-5 ${feature.iconColor}`} />
                        </div>
                        <span className="text-2xl">{feature.image}</span>
                      </div>

                      {/* Title */}
                      <h3 className="text-base md:text-lg font-bold mb-2 flex items-center gap-2">
                        {feature.title}
                        {feature.premium && (
                          <span className="px-1.5 py-0.5 text-xs bg-accent/20 text-accent rounded-full">
                            Premium
                          </span>
                        )}
                      </h3>

                      {/* Description */}
                      <p className="text-xs md:text-sm text-txt-2 leading-relaxed">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                </Item>
              );
            })}
          </Stagger>
        )}
      </div>
    </section>
  );
}
