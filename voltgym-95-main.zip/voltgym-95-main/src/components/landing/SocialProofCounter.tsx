import { useEffect, useRef, memo } from 'react';
import { Star, TrendingUp, Users, Dumbbell } from 'lucide-react';
import { useReducedMotion } from '@/hooks/useReducedMotion';

interface CounterProps {
  value: number;
  duration?: number;
}

// Optimized counter using CSS animations instead of Framer Motion
function Counter({ value, duration = 2000 }: CounterProps) {
  const nodeRef = useRef<HTMLSpanElement>(null);
  const { shouldReduceMotion } = useReducedMotion();

  useEffect(() => {
    const node = nodeRef.current;
    if (!node) return;
    
    // Skip animation if reduced motion
    if (shouldReduceMotion) {
      node.textContent = value.toLocaleString('pt-BR');
      return;
    }

    const startTime = performance.now();
    const startValue = 0;
    
    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // Ease out cubic
      const easeOut = 1 - Math.pow(1 - progress, 3);
      const currentValue = Math.round(startValue + (value - startValue) * easeOut);
      
      node.textContent = currentValue.toLocaleString('pt-BR');
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };
    
    requestAnimationFrame(animate);
  }, [value, duration, shouldReduceMotion]);

  return <span ref={nodeRef}>0</span>;
}

interface SocialProofCounterProps {
  userCount: number;
  workoutCount: number;
  exerciseCount: number;
}

const SocialProofCounter = memo(function SocialProofCounter({ 
  userCount, 
  workoutCount, 
  exerciseCount 
}: SocialProofCounterProps) {
  const { shouldReduceMotion } = useReducedMotion();
  
  const stats = [
    {
      icon: Users,
      value: userCount * 1000,
      label: 'Atletas Ativos',
      color: 'text-accent',
      bgColor: 'bg-accent/10'
    },
    {
      icon: Dumbbell,
      value: workoutCount * 10000,
      label: 'Treinos Realizados',
      color: 'text-success',
      bgColor: 'bg-success/10'
    },
    {
      icon: TrendingUp,
      value: exerciseCount * 100,
      label: 'Exercícios na Base',
      color: 'text-primary',
      bgColor: 'bg-primary/10'
    },
    {
      icon: Star,
      value: 4.9,
      label: 'Avaliação Média',
      color: 'text-yellow-500',
      bgColor: 'bg-yellow-500/10',
      suffix: '/5'
    }
  ];

  return (
    <section className="py-8 md:py-12 relative overflow-hidden">
      {/* Static background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-muted/10 to-background" />
      
      <div className="landing-container relative z-10">
        <div className={`text-center mb-6 md:mb-8 ${shouldReduceMotion ? '' : 'animate-fade-in'}`}>
          <h2 className="landing-h3 mb-2">
            Junte-se a Milhares de{' '}
            <span className="bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">
              Atletas
            </span>
          </h2>
          <p className="text-xs md:text-sm text-muted-foreground max-w-lg mx-auto">
            Resultados reais de quem já transformou o corpo
          </p>
        </div>

        {/* Stats grid - Compact */}
        <div className="social-proof-grid max-w-4xl mx-auto">
          {stats.map((stat, idx) => {
            const Icon = stat.icon;
            
            return (
              <div
                key={idx}
                className={`${shouldReduceMotion ? '' : 'animate-fade-in'}`}
                style={{ animationDelay: shouldReduceMotion ? '0ms' : `${idx * 80}ms` }}
              >
                <div className="social-proof-card hover:border-accent/30 transition-colors duration-200">
                  <div className="relative z-10">
                    {/* Icon */}
                    <div className={`inline-flex p-2 rounded-lg ${stat.bgColor} mb-2`}>
                      <Icon className={`w-4 h-4 ${stat.color}`} />
                    </div>

                    {/* Counter */}
                    <div className="mb-1">
                      <span className="social-proof-value text-foreground">
                        {stat.value < 10 ? (
                          stat.value.toFixed(1)
                        ) : (
                          <Counter value={stat.value} />
                        )}
                        {stat.suffix || '+'}
                      </span>
                    </div>

                    {/* Label */}
                    <p className="social-proof-label">
                      {stat.label}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Reviews - Compact */}
        <div 
          className={`mt-6 md:mt-8 text-center ${shouldReduceMotion ? '' : 'animate-fade-in'}`}
          style={{ animationDelay: shouldReduceMotion ? '0ms' : '400ms' }}
        >
          <div className="flex items-center justify-center gap-1 mb-2">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-4 h-4 fill-yellow-500 text-yellow-500" />
            ))}
          </div>
          <p className="text-xs text-muted-foreground">
            "Melhor app de treino que já usei!" — João S.
          </p>
        </div>
      </div>
    </section>
  );
});

export default SocialProofCounter;
