import { useState, useEffect, useRef, ReactNode, memo } from 'react';

interface LazySectionProps {
  children: ReactNode;
  threshold?: number;
  rootMargin?: string;
  className?: string;
  fallback?: ReactNode;
}

/**
 * Lazy loading de seções - só renderiza quando entra no viewport
 * OTIMIZADO: rootMargin reduzido, sem animação framer-motion
 */
export const LazySection = memo(function LazySection({ 
  children, 
  threshold = 0.05, 
  rootMargin = '50px', // Reduzido de 200px para 50px
  className = '',
  fallback
}: LazySectionProps) {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold, rootMargin }
    );

    observer.observe(element);

    return () => observer.disconnect();
  }, [threshold, rootMargin]);

  return (
    <div ref={ref} className={className}>
      {isVisible ? (
        <div className="animate-fade-in">
          {children}
        </div>
      ) : (
        fallback || <SkeletonSection />
      )}
    </div>
  );
});

// Skeleton placeholder simples
const SkeletonSection = memo(function SkeletonSection() {
  return (
    <div className="py-12 md:py-16">
      <div className="container-custom px-4">
        <div className="space-y-6">
          <div className="text-center space-y-3">
            <div className="h-10 bg-muted/30 rounded-lg max-w-sm mx-auto" />
            <div className="h-5 bg-muted/20 rounded-lg max-w-md mx-auto" />
          </div>
          <div className="grid md:grid-cols-3 gap-4 mt-8">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-48 bg-muted/20 rounded-xl" />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
});
