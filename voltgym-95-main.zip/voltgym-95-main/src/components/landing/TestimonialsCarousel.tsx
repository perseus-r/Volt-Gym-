import { motion, AnimatePresence } from 'framer-motion';
import { useState, useEffect } from 'react';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useMobileExperience } from '@/hooks/useMobileExperience';

const testimonials = [
  {
    name: 'Carlos M.',
    age: 34,
    goal: 'Perda de Peso',
    avatar: 'CM',
    quote: 'Eu era cético com apps de treino. Já tinha tentado 3 antes sem resultado. O VOLT foi diferente - a IA realmente entende meu corpo e adapta os treinos. Em 6 semanas perdi 8kg que não conseguia há 2 anos.',
    result: '-8kg em 6 semanas',
    rating: 5,
    before: '92kg',
    after: '84kg',
    verified: true
  },
  {
    name: 'Ana Paula S.',
    age: 28,
    goal: 'Ganho de Massa',
    avatar: 'AP',
    quote: 'Como mulher que queria ganhar massa muscular, sempre me senti perdida na academia. O VOLT me deu um plano claro e os vídeos me ensinaram a executar tudo certo. Ganhei 4kg de músculo sem personal!',
    result: '+4kg massa muscular',
    rating: 5,
    before: '54kg',
    after: '58kg',
    verified: true
  },
  {
    name: 'Roberto F.',
    age: 45,
    goal: 'Saúde e Disposição',
    avatar: 'RF',
    quote: 'Aos 45 anos achei que era tarde demais. O coach IA adaptou tudo para minhas limitações no joelho. Hoje faço o que não fazia aos 30. Minha esposa não acredita na minha energia.',
    result: '+40% disposição',
    rating: 5,
    before: 'Sedentário',
    after: '4x/semana',
    verified: true
  },
  {
    name: 'Juliana R.',
    age: 31,
    goal: 'Definição',
    avatar: 'JR',
    quote: 'Gastava R$ 600/mês com personal e nutricionista. O VOLT me deu resultados melhores por R$ 99. A análise de fotos de refeição é game-changer - contagem de macros automática!',
    result: '-12% gordura corporal',
    rating: 5,
    before: '28% BF',
    after: '16% BF',
    verified: true
  },
  {
    name: 'Marcos V.',
    age: 26,
    goal: 'Hipertrofia',
    avatar: 'MV',
    quote: 'Treino há 5 anos e estava estagnado. O programa de 28 dias do VOLT identificou fraquezas que eu nem sabia que tinha. Quebrei 4 recordes pessoais no primeiro mês!',
    result: '+15kg no supino',
    rating: 5,
    before: '80kg',
    after: '95kg',
    verified: true
  }
];

export default function TestimonialsCarousel() {
  const [current, setCurrent] = useState(0);
  const { isMobile } = useMobileExperience();

  // Auto-rotate
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const next = () => setCurrent((prev) => (prev + 1) % testimonials.length);
  const prev = () => setCurrent((prev) => (prev - 1 + testimonials.length) % testimonials.length);

  const testimonial = testimonials[current];

  return (
    <section className="py-20 md:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-bg via-surface/50 to-bg" />
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-accent/10 rounded-full blur-[120px]" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-success/10 rounded-full blur-[120px]" />

      <div className="container-custom relative z-10 px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-2 rounded-full bg-success/10 text-success text-sm font-medium mb-6">
            Histórias Reais de Transformação
          </span>
          <h2 className="text-3xl md:text-5xl font-bold mb-4">
            Eles Duvidaram, Depois{' '}
            <span className="bg-gradient-lightning bg-clip-text text-transparent">
              Transformaram
            </span>
          </h2>
          <p className="text-lg text-txt-2 max-w-2xl mx-auto">
            Mais de 12.000 pessoas já mudaram suas vidas. Estas são algumas das suas histórias.
          </p>
        </motion.div>

        {/* Main testimonial card */}
        <div className="max-w-4xl mx-auto">
          <div className="relative">
            <AnimatePresence mode="wait">
              <motion.div
                key={current}
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ duration: 0.5 }}
                className="bg-gradient-glass backdrop-blur-md border border-line/50 rounded-3xl p-8 md:p-12"
              >
                {/* Quote icon */}
                <Quote className="w-12 h-12 text-accent/30 mb-6" />

                {/* Quote text */}
                <blockquote className="text-xl md:text-2xl text-txt leading-relaxed mb-8">
                  "{testimonial.quote}"
                </blockquote>

                {/* User info and results */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                  {/* User */}
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-accent to-accent-2 flex items-center justify-center text-xl font-bold text-accent-ink">
                      {testimonial.avatar}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-lg">{testimonial.name}</h4>
                        {testimonial.verified && (
                          <span className="px-2 py-0.5 bg-success/20 text-success text-xs rounded-full">
                            ✓ Verificado
                          </span>
                        )}
                      </div>
                      <p className="text-txt-3">{testimonial.age} anos • {testimonial.goal}</p>
                      <div className="flex gap-0.5 mt-1">
                        {Array.from({ length: testimonial.rating }).map((_, i) => (
                          <Star key={i} className="w-4 h-4 fill-warning text-warning" />
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Results */}
                  <div className="flex gap-4">
                    <div className="text-center px-4 py-2 bg-error/10 rounded-xl">
                      <p className="text-xs text-txt-3 mb-1">Antes</p>
                      <p className="font-bold text-error">{testimonial.before}</p>
                    </div>
                    <div className="flex items-center">
                      <div className="w-8 h-0.5 bg-gradient-to-r from-error to-success" />
                    </div>
                    <div className="text-center px-4 py-2 bg-success/10 rounded-xl">
                      <p className="text-xs text-txt-3 mb-1">Depois</p>
                      <p className="font-bold text-success">{testimonial.after}</p>
                    </div>
                  </div>
                </div>

                {/* Result badge */}
                <div className="absolute -top-4 right-8 px-4 py-2 bg-gradient-to-r from-accent to-accent-2 rounded-full shadow-lg">
                  <span className="font-bold text-accent-ink">{testimonial.result}</span>
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Navigation arrows */}
            <div className="absolute top-1/2 -translate-y-1/2 -left-4 md:-left-16">
              <Button
                variant="ghost"
                size="icon"
                onClick={prev}
                className="w-12 h-12 rounded-full bg-surface/80 backdrop-blur-sm border border-line/50 hover:border-accent"
              >
                <ChevronLeft className="w-6 h-6" />
              </Button>
            </div>
            <div className="absolute top-1/2 -translate-y-1/2 -right-4 md:-right-16">
              <Button
                variant="ghost"
                size="icon"
                onClick={next}
                className="w-12 h-12 rounded-full bg-surface/80 backdrop-blur-sm border border-line/50 hover:border-accent"
              >
                <ChevronRight className="w-6 h-6" />
              </Button>
            </div>
          </div>

          {/* Dots */}
          <div className="flex justify-center gap-2 mt-8">
            {testimonials.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrent(idx)}
                className={`h-2 rounded-full transition-all duration-300 ${
                  current === idx 
                    ? 'w-8 bg-accent' 
                    : 'w-2 bg-line hover:bg-txt-3'
                }`}
              />
            ))}
          </div>

          {/* Trust indicators */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-wrap justify-center gap-8 mt-12 text-sm text-txt-3"
          >
            <div className="flex items-center gap-2">
              <Star className="w-4 h-4 fill-warning text-warning" />
              <span>4.9/5 média de avaliação</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-success" />
              <span>12.847 usuários ativos</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-accent" />
              <span>98% recomendam</span>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
