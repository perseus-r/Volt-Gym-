import React, { useEffect, useState, memo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, Dumbbell, TrendingUp, MessageCircle, Trophy, X } from 'lucide-react';
import { useLandingProgress } from '@/hooks/useLandingProgress';

interface Notification {
  id: string;
  icon: React.ReactNode;
  title: string;
  message: string;
  time: string;
  color: string;
}

const baseNotifications: Notification[] = [
  {
    id: 'workout-reminder',
    icon: <Dumbbell className="w-5 h-5" />,
    title: 'Hora do Treino! 💪',
    message: 'Seu treino de hoje está pronto.',
    time: 'agora',
    color: 'from-emerald-500 to-teal-500',
  },
  {
    id: 'ai-suggestion',
    icon: <MessageCircle className="w-5 h-5" />,
    title: 'Coach IA',
    message: 'Que tal aumentar a carga hoje?',
    time: '2 min',
    color: 'from-blue-500 to-violet-500',
  },
];

const NotificationPreview: React.FC = memo(() => {
  const { progress } = useLandingProgress();
  const [visibleNotification, setVisibleNotification] = useState<Notification | null>(null);
  const [notificationIndex, setNotificationIndex] = useState(0);

  useEffect(() => {
    if (!progress.hasInteracted) return;

    // OTIMIZADO: Delay inicial aumentado de 3s para 8s
    const showTimer = setTimeout(() => {
      setVisibleNotification(baseNotifications[0]);
      
      // Auto-dismiss após 5 segundos
      setTimeout(() => {
        setVisibleNotification(null);
      }, 5000);
    }, 8000);

    // Mostrar próxima notificação a cada 15 segundos (era 8s)
    const interval = setInterval(() => {
      setNotificationIndex(prev => {
        const next = (prev + 1) % baseNotifications.length;
        setVisibleNotification(baseNotifications[next]);
        
        setTimeout(() => {
          setVisibleNotification(null);
        }, 5000);
        
        return next;
      });
    }, 15000);

    return () => {
      clearTimeout(showTimer);
      clearInterval(interval);
    };
  }, [progress.hasInteracted]);

  const dismissNotification = () => {
    setVisibleNotification(null);
  };

  if (!visibleNotification) return null;

  return (
    <div className="fixed top-24 right-4 z-40 max-w-sm">
      <AnimatePresence mode="wait">
        <motion.div
          key={visibleNotification.id}
          initial={{ opacity: 0, x: 50, scale: 0.9 }}
          animate={{ opacity: 1, x: 0, scale: 1 }}
          exit={{ opacity: 0, x: 50, scale: 0.9 }}
          transition={{ duration: 0.2 }}
          className="relative overflow-hidden"
        >
          <div className="bg-background/95 backdrop-blur-lg rounded-xl shadow-lg border border-border/50 p-4 pr-10">
            <div className={`absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b ${visibleNotification.color}`} />
            
            <div className="flex items-start gap-3">
              <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${visibleNotification.color} flex items-center justify-center text-white shrink-0`}>
                {visibleNotification.icon}
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-semibold text-sm truncate">{visibleNotification.title}</p>
                  <span className="text-xs text-muted-foreground">{visibleNotification.time}</span>
                </div>
                <p className="text-sm text-muted-foreground line-clamp-1 mt-0.5">
                  {visibleNotification.message}
                </p>
              </div>
            </div>

            <button
              onClick={dismissNotification}
              className="absolute top-2 right-2 p-1.5 rounded-full hover:bg-muted transition-colors"
            >
              <X className="w-4 h-4 text-muted-foreground" />
            </button>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
});

export default NotificationPreview;
