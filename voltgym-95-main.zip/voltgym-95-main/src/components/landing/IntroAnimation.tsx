import React, { useEffect, useState, memo } from 'react';
import { Zap } from 'lucide-react';
import { useReducedMotion } from '@/hooks/useReducedMotion';

interface IntroAnimationProps {
  onComplete: () => void;
}

export const IntroAnimation = memo(function IntroAnimation({ onComplete }: IntroAnimationProps) {
  const [phase, setPhase] = useState<'intro' | 'exit'>('intro');
  const { shouldReduceMotion } = useReducedMotion();

  useEffect(() => {
    // Skip animation entirely if reduced motion
    if (shouldReduceMotion) {
      onComplete();
      return;
    }

    // Fast intro: 600ms visible, 200ms fade out
    const exitTimer = setTimeout(() => {
      setPhase('exit');
    }, 600);

    const completeTimer = setTimeout(() => {
      onComplete();
    }, 800);

    return () => {
      clearTimeout(exitTimer);
      clearTimeout(completeTimer);
    };
  }, [onComplete, shouldReduceMotion]);

  const handleSkip = () => {
    onComplete();
  };

  // Don't render if reduced motion
  if (shouldReduceMotion) return null;

  return (
    <div
      className={`fixed inset-0 z-[100] bg-background overflow-hidden transition-opacity duration-200 ${
        phase === 'exit' ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Static gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-accent/5" />

      {/* Central Content */}
      <div className="relative flex flex-col items-center justify-center h-full">
        {/* Logo Container */}
        <div className="relative animate-scale-in">
          {/* Static glow */}
          <div className="absolute inset-0 rounded-3xl bg-primary/30 blur-xl" />
          
          {/* Logo */}
          <div className="relative w-20 h-20 md:w-24 md:h-24 rounded-3xl bg-gradient-to-br from-accent via-primary to-primary flex items-center justify-center shadow-xl">
            <Zap className="w-10 h-10 md:w-12 md:h-12 text-primary-foreground fill-current" />
          </div>
        </div>

        {/* VOLT Text */}
        <h1 className="text-5xl md:text-6xl font-black tracking-[0.2em] mt-6 text-foreground animate-fade-in">
          VOLT
        </h1>

        {/* Tagline */}
        <p className="text-muted-foreground text-sm md:text-base mt-2 animate-fade-in" style={{ animationDelay: '100ms' }}>
          Sua evolução começa aqui
        </p>

        {/* Progress Bar */}
        <div className="mt-6 w-40 h-1 bg-muted/30 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-accent to-primary rounded-full"
            style={{
              animation: 'progress-fill 0.5s ease-out forwards'
            }}
          />
        </div>
      </div>

      {/* Skip Button */}
      <button
        onClick={handleSkip}
        className="absolute bottom-6 right-6 text-muted-foreground/60 hover:text-foreground text-sm transition-colors touch-manipulation"
      >
        Pular →
      </button>

      <style>{`
        @keyframes progress-fill {
          from { width: 0%; }
          to { width: 100%; }
        }
      `}</style>
    </div>
  );
});
