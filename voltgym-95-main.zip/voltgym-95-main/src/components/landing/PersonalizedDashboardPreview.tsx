import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { 
  TrendingUp, 
  Target, 
  Calendar,
  Flame,
  Award,
  ChevronRight,
  Dumbbell,
  Apple,
  Moon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { useLandingProgress } from '@/hooks/useLandingProgress';
import { useMobileExperience } from '@/hooks/useMobileExperience';

const objectiveData = {
  massa: {
    title: 'Ganho de Massa',
    color: 'from-blue-500 to-cyan-500',
    projection30: { peso: '+2.5kg', gordura: '+1%', forca: '+15%' },
    projection90: { peso: '+6kg', gordura: '+2%', forca: '+35%' },
    todayWorkout: 'Peito + Tríceps',
    calories: '+500 kcal',
    tip: 'Aumente proteína para 2g/kg'
  },
  definicao: {
    title: 'Definição',
    color: 'from-orange-500 to-red-500',
    projection30: { peso: '-3kg', gordura: '-2.5%', forca: '+5%' },
    projection90: { peso: '-8kg', gordura: '-6%', forca: '+10%' },
    todayWorkout: 'Full Body + HIIT',
    calories: '-500 kcal',
    tip: 'Mantenha proteína alta durante déficit'
  },
  forca: {
    title: 'Força',
    color: 'from-purple-500 to-pink-500',
    projection30: { peso: '+1kg', gordura: '0%', forca: '+20%' },
    projection90: { peso: '+3kg', gordura: '+1%', forca: '+45%' },
    todayWorkout: 'Powerlifting - Força',
    calories: '+300 kcal',
    tip: 'Foco em progressão de carga'
  },
  saude: {
    title: 'Saúde Geral',
    color: 'from-green-500 to-emerald-500',
    projection30: { peso: '-1kg', gordura: '-1%', forca: '+10%' },
    projection90: { peso: '-3kg', gordura: '-3%', forca: '+25%' },
    todayWorkout: 'Cardio + Funcional',
    calories: 'Manutenção',
    tip: 'Equilibre treino e recuperação'
  }
};

const frequencyData: Record<number, string> = {
  2: '2x por semana - Foco em Full Body',
  3: '3x por semana - Upper/Lower Split',
  4: '4x por semana - Push/Pull/Legs',
  5: '5x por semana - Divisão Clássica',
  6: '6x por semana - Alto Volume'
};

export const PersonalizedDashboardPreview = () => {
  const navigate = useNavigate();
  const { isMobile } = useMobileExperience();
  const { progress, markDashboardSeen, isComplete } = useLandingProgress();
  const [showProjection, setShowProjection] = useState<'30' | '90'>('30');

  useEffect(() => {
    if (isComplete) {
      markDashboardSeen();
    }
  }, [isComplete, markDashboardSeen]);

  if (!isComplete) {
    return (
      <section className="py-16 md:py-20 bg-gradient-to-b from-background to-muted/30">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/20 mb-4">
              <Target className="w-4 h-4 text-accent" />
              <span className="text-sm font-medium text-accent">Dashboard Personalizado</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-black mb-4">
              Complete o quiz para ver
              <span className="block text-accent">seu dashboard personalizado</span>
            </h2>
            <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
              Role para cima e responda as 3 perguntas para ver projeções e métricas baseadas no seu perfil.
            </p>
            <Button 
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              variant="outline"
            >
              Voltar ao Quiz
            </Button>
          </motion.div>
        </div>
      </section>
    );
  }

  const data = objectiveData[progress.objetivo!];
  const projection = showProjection === '30' ? data.projection30 : data.projection90;
  const freqText = frequencyData[progress.frequencia!] || '3x por semana';

  return (
    <section className="py-16 md:py-20 bg-gradient-to-b from-background to-muted/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-500/10 border border-green-500/20 mb-4">
            <Award className="w-4 h-4 text-green-500" />
            <span className="text-sm font-medium text-green-500">Seu Dashboard Personalizado</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-black mb-4">
            Assim será seu
            <span className={`bg-gradient-to-r ${data.color} bg-clip-text text-transparent`}> progresso</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Baseado nas suas escolhas: <strong>{data.title}</strong> | <strong>{progress.nivel}</strong> | <strong>{progress.frequencia}x/semana</strong>
          </p>
        </motion.div>

        {/* Dashboard Mock */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto"
        >
          <div className="bg-card rounded-2xl border border-border overflow-hidden shadow-xl">
            {/* Header */}
            <div className={`p-6 bg-gradient-to-r ${data.color}`}>
              <div className="flex items-center justify-between text-white">
                <div>
                  <p className="text-sm opacity-80">Bem-vindo de volta!</p>
                  <h3 className="text-2xl font-bold">Seu Plano: {data.title}</h3>
                </div>
                <div className="text-right">
                  <p className="text-sm opacity-80">Frequência</p>
                  <p className="font-bold">{progress.frequencia}x por semana</p>
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="p-6">
              {/* Today's Workout */}
              <div className="mb-6">
                <h4 className="font-bold mb-3 flex items-center gap-2">
                  <Dumbbell className="w-5 h-5 text-accent" />
                  Treino de Hoje
                </h4>
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  className={`p-4 rounded-xl bg-gradient-to-r ${data.color} text-white cursor-pointer`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-bold text-lg">{data.todayWorkout}</p>
                      <p className="text-sm opacity-80">~45 minutos • 6 exercícios</p>
                    </div>
                    <ChevronRight className="w-6 h-6" />
                  </div>
                </motion.div>
              </div>

              {/* Projections */}
              <div className="mb-6">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-bold flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-accent" />
                    Projeção de Resultados
                  </h4>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setShowProjection('30')}
                      className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                        showProjection === '30' ? 'bg-accent text-accent-foreground' : 'bg-muted'
                      }`}
                    >
                      30 dias
                    </button>
                    <button
                      onClick={() => setShowProjection('90')}
                      className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                        showProjection === '90' ? 'bg-accent text-accent-foreground' : 'bg-muted'
                      }`}
                    >
                      90 dias
                    </button>
                  </div>
                </div>

                <div className={`grid ${isMobile ? 'grid-cols-1' : 'grid-cols-3'} gap-4`}>
                  <motion.div
                    key={`peso-${showProjection}`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 bg-blue-500/10 rounded-xl text-center"
                  >
                    <p className="text-2xl font-bold text-blue-500">{projection.peso}</p>
                    <p className="text-sm text-muted-foreground">Peso Corporal</p>
                  </motion.div>
                  <motion.div
                    key={`gordura-${showProjection}`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 }}
                    className="p-4 bg-orange-500/10 rounded-xl text-center"
                  >
                    <p className="text-2xl font-bold text-orange-500">{projection.gordura}</p>
                    <p className="text-sm text-muted-foreground">Gordura Corporal</p>
                  </motion.div>
                  <motion.div
                    key={`forca-${showProjection}`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="p-4 bg-green-500/10 rounded-xl text-center"
                  >
                    <p className="text-2xl font-bold text-green-500">{projection.forca}</p>
                    <p className="text-sm text-muted-foreground">Ganho de Força</p>
                  </motion.div>
                </div>
              </div>

              {/* Quick Stats */}
              <div className={`grid ${isMobile ? 'grid-cols-2' : 'grid-cols-4'} gap-4 mb-6`}>
                <div className="p-4 bg-muted/50 rounded-xl">
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar className="w-4 h-4 text-accent" />
                    <span className="text-xs text-muted-foreground">Frequência</span>
                  </div>
                  <p className="font-bold">{progress.frequencia}x/semana</p>
                </div>
                <div className="p-4 bg-muted/50 rounded-xl">
                  <div className="flex items-center gap-2 mb-2">
                    <Apple className="w-4 h-4 text-green-500" />
                    <span className="text-xs text-muted-foreground">Calorias</span>
                  </div>
                  <p className="font-bold">{data.calories}</p>
                </div>
                <div className="p-4 bg-muted/50 rounded-xl">
                  <div className="flex items-center gap-2 mb-2">
                    <Flame className="w-4 h-4 text-orange-500" />
                    <span className="text-xs text-muted-foreground">Streak</span>
                  </div>
                  <p className="font-bold">0 dias</p>
                </div>
                <div className="p-4 bg-muted/50 rounded-xl">
                  <div className="flex items-center gap-2 mb-2">
                    <Moon className="w-4 h-4 text-purple-500" />
                    <span className="text-xs text-muted-foreground">Descanso</span>
                  </div>
                  <p className="font-bold">48h ideal</p>
                </div>
              </div>

              {/* AI Tip */}
              <div className="p-4 rounded-xl bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/20">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0">
                    <Award className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="font-bold mb-1">Dica da IA para você</p>
                    <p className="text-sm text-muted-foreground">{data.tip}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* CTA */}
            <div className="p-6 bg-muted/30 border-t border-border">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <p className="font-bold">Pronto para começar?</p>
                  <p className="text-sm text-muted-foreground">Suas escolhas serão salvas automaticamente</p>
                </div>
                <Button 
                  onClick={() => navigate('/auth')}
                  size="lg"
                  className={`bg-gradient-to-r ${data.color} hover:opacity-90`}
                >
                  Criar Minha Conta Grátis
                  <ChevronRight className="w-5 h-5 ml-2" />
                </Button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default PersonalizedDashboardPreview;
