import { motion } from 'framer-motion';
import { UserPlus, Sparkles, Zap, ArrowRight } from 'lucide-react';
import { Stagger, Item } from '@/components/animations/Stagger';

export default function HowItWorks() {
  const steps = [
    {
      icon: UserPlus,
      number: '01',
      title: 'Crie sua conta grátis',
      description: '30 segundos. Google sign-in disponível. Sem cartão de crédito.',
      time: '30s',
      color: 'text-accent'
    },
    {
      icon: Sparkles,
      number: '02',
      title: 'IA personaliza tudo',
      description: 'Questionário rápido. IA cria programa de 28 dias baseado em você.',
      time: '2min',
      color: 'text-purple-400'
    },
    {
      icon: Zap,
      number: '03',
      title: 'Comece a treinar',
      description: 'Dashboard pronto. Primeiro treino em 5 minutos. Zero enrolação.',
      time: '5min',
      color: 'text-success'
    }
  ];

  return (
    <section className="py-20 md:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-surface via-bg to-surface" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-accent/5 rounded-full blur-[120px]" />

      <div className="container-custom relative z-10 px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Como{' '}
            <span className="bg-gradient-lightning bg-clip-text text-transparent">Funciona</span>
          </h2>
          <p className="text-xl text-txt-2 max-w-2xl mx-auto">
            Começar é simples. Complexidade é para nós, não para você.
          </p>
        </motion.div>

        {/* Steps */}
        <Stagger className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 md:gap-4">
            {steps.map((step, idx) => {
              const Icon = step.icon;
              return (
                <Item key={idx}>
                  <div className="relative">
                    {/* Connector line (desktop only) */}
                    {idx < steps.length - 1 && (
                      <div className="hidden md:block absolute top-12 left-[calc(50%+80px)] w-[calc(100%-80px)] h-0.5 bg-gradient-to-r from-accent/50 to-transparent" />
                    )}

                    <div
                      className="bg-surface/95 md:bg-transparent md:bg-gradient-glass md:backdrop-blur-md border border-line/50 rounded-2xl p-8 hover:border-accent/50 transition-all duration-300 relative z-10 hover:-translate-y-2"
                    >
                      {/* Number badge */}
                      <div className="absolute -top-4 -right-4 w-12 h-12 rounded-full bg-accent flex items-center justify-center font-bold text-accent-ink shadow-glow">
                        {step.number}
                      </div>

                      {/* Icon */}
                      <div className="mb-6">
                        <div className={`inline-flex p-4 rounded-xl bg-surface/50 border border-line/30 ${step.color}`}>
                          <Icon className="w-8 h-8" />
                        </div>
                      </div>

                      {/* Content */}
                      <h3 className="text-2xl font-bold mb-3">{step.title}</h3>
                      <p className="text-txt-2 mb-4 leading-relaxed">
                        {step.description}
                      </p>

                      {/* Time badge */}
                      <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-accent/10 border border-accent/30">
                        <div className="w-2 h-2 rounded-full bg-accent" />
                        <span className="text-sm font-medium text-accent">{step.time}</span>
                      </div>
                    </div>
                  </div>
                </Item>
              );
            })}
          </div>
        </Stagger>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-center mt-12"
        >
          <p className="text-lg text-txt-2 flex items-center justify-center gap-2">
            Total: <span className="font-bold text-accent">7min 30s</span>
            <ArrowRight className="w-5 h-5 text-accent" />
            <span className="font-bold text-txt">Do zero ao primeiro treino</span>
          </p>
        </motion.div>
      </div>
    </section>
  );
}
