import React, { useEffect, useState, memo } from 'react';
import { Trophy, Star, Zap, Target, Eye } from 'lucide-react';
import { useLandingProgress } from '@/hooks/useLandingProgress';
import { celebrations } from '@/utils/celebrations';
import { useReducedMotion } from '@/hooks/useReducedMotion';

interface Badge {
  id: string;
  name: string;
  icon: React.ReactNode;
  description: string;
  condition: (progress: ReturnType<typeof useLandingProgress>['progress']) => boolean;
}

const badges: Badge[] = [
  {
    id: 'explorer',
    name: 'Explorador',
    icon: <Eye className="w-4 h-4" />,
    description: 'Começou a explorar',
    condition: (p) => p.hasInteracted,
  },
  {
    id: 'focused',
    name: 'Focado',
    icon: <Target className="w-4 h-4" />,
    description: 'Definiu objetivo',
    condition: (p) => p.objetivo !== null,
  },
  {
    id: 'planner',
    name: 'Planejador',
    icon: <Star className="w-4 h-4" />,
    description: 'Perfil completo',
    condition: (p) => p.objetivo !== null && p.nivel !== null && p.frequencia !== null,
  },
];

const XP_REWARDS = {
  setObjetivo: 20,
  setNivel: 15,
  setFrequencia: 15,
  askAI: 25,
  viewWorkout: 30,
  viewDashboard: 20,
};

const GamificationBar: React.FC = memo(() => {
  const { progress, getProgressPercentage } = useLandingProgress();
  const { shouldReduceMotion } = useReducedMotion();
  const [currentXP, setCurrentXP] = useState(0);
  const [unlockedBadges, setUnlockedBadges] = useState<string[]>([]);
  const [showXPGain, setShowXPGain] = useState(false);
  const [xpGainAmount, setXpGainAmount] = useState(0);
  const [newBadge, setNewBadge] = useState<Badge | null>(null);
  const [isVisible, setIsVisible] = useState(false);

  // Animate in after interaction
  useEffect(() => {
    if (progress.hasInteracted && !isVisible) {
      setIsVisible(true);
    }
  }, [progress.hasInteracted, isVisible]);

  // Calculate XP
  useEffect(() => {
    let xp = 0;
    if (progress.objetivo) xp += XP_REWARDS.setObjetivo;
    if (progress.nivel) xp += XP_REWARDS.setNivel;
    if (progress.frequencia) xp += XP_REWARDS.setFrequencia;
    xp += progress.aiQuestionsUsed * XP_REWARDS.askAI;
    if (progress.workoutPreviewSeen) xp += XP_REWARDS.viewWorkout;
    if (progress.dashboardSeen) xp += XP_REWARDS.viewDashboard;

    if (xp > currentXP) {
      const diff = xp - currentXP;
      setXpGainAmount(diff);
      setShowXPGain(true);
      if (!shouldReduceMotion) {
        celebrations.gainXP(diff);
      }
      setTimeout(() => setShowXPGain(false), 1500);
    }
    setCurrentXP(xp);
  }, [progress, currentXP, shouldReduceMotion]);

  // Check badges
  useEffect(() => {
    badges.forEach(badge => {
      if (badge.condition(progress) && !unlockedBadges.includes(badge.id)) {
        setUnlockedBadges(prev => [...prev, badge.id]);
        setNewBadge(badge);
        if (!shouldReduceMotion) {
          celebrations.unlockBadge();
        }
        setTimeout(() => setNewBadge(null), 2500);
      }
    });
  }, [progress, unlockedBadges, shouldReduceMotion]);

  // Don't show if no interaction
  if (!progress.hasInteracted) return null;

  const progressPercent = getProgressPercentage();
  const level = Math.floor(currentXP / 100) + 1;
  const xpInLevel = currentXP % 100;

  return (
    <>
      {/* Fixed gamification bar - NO backdrop-blur, solid background */}
      <div
        className={`fixed top-0 left-0 right-0 z-50 bg-background border-b border-border/50 transition-transform duration-300 ${
          isVisible ? 'translate-y-0' : '-translate-y-full'
        }`}
      >
        <div className="container mx-auto px-4 py-2">
          <div className="flex items-center justify-between gap-4">
            {/* Level & XP */}
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                  <span className="text-sm font-bold text-primary-foreground">{level}</span>
                </div>
                <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-yellow-500 flex items-center justify-center">
                  <Zap className="w-2.5 h-2.5 text-yellow-900" />
                </div>
              </div>
              
              <div className="flex flex-col">
                <span className="text-xs text-muted-foreground">Nível {level}</span>
                <div className="flex items-center gap-2">
                  <div className="w-16 h-1.5 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-primary to-accent transition-all duration-300"
                      style={{ width: `${xpInLevel}%` }}
                    />
                  </div>
                  <span className="text-xs font-medium">{xpInLevel}/100</span>
                </div>
              </div>

              {/* XP Gain - CSS animation */}
              {showXPGain && (
                <span className="text-sm font-bold text-emerald-500 animate-fade-in">
                  +{xpGainAmount}
                </span>
              )}
            </div>

            {/* Badges - desktop only */}
            <div className="hidden sm:flex items-center gap-1.5">
              {badges.map(badge => {
                const isUnlocked = unlockedBadges.includes(badge.id);
                return (
                  <div
                    key={badge.id}
                    className={`w-7 h-7 rounded-full flex items-center justify-center transition-colors ${
                      isUnlocked 
                        ? 'bg-gradient-to-br from-yellow-400 to-orange-500 text-white' 
                        : 'bg-muted text-muted-foreground'
                    }`}
                    title={`${badge.name}: ${badge.description}`}
                  >
                    {badge.icon}
                  </div>
                );
              })}
            </div>

            {/* Progress */}
            <div className="flex items-center gap-1.5">
              <Trophy className="w-4 h-4 text-yellow-500" />
              <span className="text-sm font-medium">{progressPercent}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* New Badge Notification - CSS animation */}
      {newBadge && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-5 py-2.5 rounded-xl shadow-lg animate-fade-in">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
              {newBadge.icon}
            </div>
            <div>
              <p className="text-xs opacity-80">Badge!</p>
              <p className="font-bold text-sm">{newBadge.name}</p>
            </div>
          </div>
        </div>
      )}
    </>
  );
});

export default GamificationBar;
