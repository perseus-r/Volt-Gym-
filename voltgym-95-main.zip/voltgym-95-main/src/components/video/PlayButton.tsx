import { motion } from 'framer-motion';
import { Play, Pause } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PlayButtonProps {
  isPlaying?: boolean;
  size?: 'sm' | 'md' | 'lg';
  onClick?: () => void;
  className?: string;
}

const sizeClasses = {
  sm: 'w-10 h-10',
  md: 'w-14 h-14',
  lg: 'w-16 h-16',
};

const iconSizes = {
  sm: 'w-4 h-4',
  md: 'w-6 h-6',
  lg: 'w-7 h-7',
};

export function PlayButton({ isPlaying = false, size = 'lg', onClick, className }: PlayButtonProps) {
  const Icon = isPlaying ? Pause : Play;
  
  return (
    <motion.button
      type="button"
      onClick={onClick}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
      className={cn(
        sizeClasses[size],
        "rounded-full bg-primary/90 backdrop-blur-sm flex items-center justify-center",
        "shadow-2xl shadow-primary/30 transition-colors duration-200",
        "hover:bg-primary focus:outline-none focus:ring-2 focus:ring-primary/50",
        className
      )}
      aria-label={isPlaying ? "Pausar vídeo" : "Reproduzir vídeo"}
    >
      <Icon className={cn(iconSizes[size], "text-primary-foreground fill-current", !isPlaying && "ml-0.5")} />
    </motion.button>
  );
}
