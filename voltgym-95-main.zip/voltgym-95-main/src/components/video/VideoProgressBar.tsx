import { useState, useCallback, useRef } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface VideoProgressBarProps {
  currentTime: number;
  duration: number;
  buffered: number;
  onSeek: (time: number) => void;
  className?: string;
}

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

export function VideoProgressBar({
  currentTime,
  duration,
  buffered,
  onSeek,
  className,
}: VideoProgressBarProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [hoverPosition, setHoverPosition] = useState<number | null>(null);
  const [hoverTime, setHoverTime] = useState<number | null>(null);
  const barRef = useRef<HTMLDivElement>(null);

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;
  const bufferedProgress = duration > 0 ? (buffered / duration) * 100 : 0;

  const getTimeFromPosition = useCallback((clientX: number): number => {
    if (!barRef.current || !duration) return 0;
    const rect = barRef.current.getBoundingClientRect();
    const position = (clientX - rect.left) / rect.width;
    return Math.max(0, Math.min(duration, position * duration));
  }, [duration]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!barRef.current || !duration) return;
    const rect = barRef.current.getBoundingClientRect();
    const position = ((e.clientX - rect.left) / rect.width) * 100;
    const time = getTimeFromPosition(e.clientX);
    setHoverPosition(Math.max(0, Math.min(100, position)));
    setHoverTime(time);

    if (isDragging) {
      onSeek(time);
    }
  }, [duration, isDragging, getTimeFromPosition, onSeek]);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    setIsDragging(true);
    const time = getTimeFromPosition(e.clientX);
    onSeek(time);
  }, [getTimeFromPosition, onSeek]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  const handleMouseLeave = useCallback(() => {
    setHoverPosition(null);
    setHoverTime(null);
    setIsDragging(false);
  }, []);

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    setIsDragging(true);
    const time = getTimeFromPosition(e.touches[0].clientX);
    onSeek(time);
  }, [getTimeFromPosition, onSeek]);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!isDragging) return;
    const time = getTimeFromPosition(e.touches[0].clientX);
    onSeek(time);
  }, [isDragging, getTimeFromPosition, onSeek]);

  const handleTouchEnd = useCallback(() => {
    setIsDragging(false);
  }, []);

  return (
    <div className={cn("relative group", className)}>
      {/* Hover time tooltip */}
      {hoverPosition !== null && hoverTime !== null && (
        <motion.div
          initial={{ opacity: 0, y: 4 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute -top-8 transform -translate-x-1/2 px-2 py-1 bg-popover text-popover-foreground text-xs rounded shadow-lg pointer-events-none z-10"
          style={{ left: `${hoverPosition}%` }}
        >
          {formatTime(hoverTime)}
        </motion.div>
      )}

      {/* Progress bar container */}
      <div
        ref={barRef}
        className="relative h-1 group-hover:h-2 transition-all duration-150 cursor-pointer rounded-full bg-muted/50 overflow-hidden"
        onMouseMove={handleMouseMove}
        onMouseDown={handleMouseDown}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseLeave}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* Buffered bar */}
        <div
          className="absolute inset-y-0 left-0 bg-white/30 rounded-full"
          style={{ width: `${bufferedProgress}%` }}
        />

        {/* Progress bar */}
        <motion.div
          className="absolute inset-y-0 left-0 bg-primary rounded-full"
          style={{ width: `${progress}%` }}
          layoutId="video-progress"
        />

        {/* Hover indicator */}
        {hoverPosition !== null && (
          <div
            className="absolute inset-y-0 left-0 bg-white/20 rounded-full pointer-events-none"
            style={{ width: `${hoverPosition}%` }}
          />
        )}

        {/* Thumb */}
        <motion.div
          className={cn(
            "absolute top-1/2 -translate-y-1/2 -translate-x-1/2",
            "w-3 h-3 rounded-full bg-primary shadow-md",
            "opacity-0 group-hover:opacity-100 transition-opacity",
            isDragging && "opacity-100 scale-125"
          )}
          style={{ left: `${progress}%` }}
        />
      </div>
    </div>
  );
}
