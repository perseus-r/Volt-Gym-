import { useEffect, useMemo, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Dumbbell } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useVideoPlayer } from '@/hooks/useVideoPlayer';
import { useVideoKeyboard } from '@/hooks/useVideoKeyboard';
import { VideoLoadingOverlay } from './VideoLoadingOverlay';
import { VideoErrorOverlay } from './VideoErrorOverlay';
import { VideoControls } from './VideoControlsNew';
import { getYouTubeId, toEmbedUrl, getThumbnailUrl } from '@/utils/youtube';

type VideoType = 'youtube' | 'vimeo' | 'direct' | 'unknown';

interface UnifiedVideoPlayerProps {
  url: string | null;
  thumbnail?: string;
  title?: string;
  autoPlay?: boolean;
  muted?: boolean;
  loop?: boolean;
  controls?: boolean;
  clickToPlay?: boolean;
  aspectRatio?: '16:9' | '4:3' | '1:1' | '9:16';
  className?: string;
  onEnded?: () => void;
  onError?: (error: string) => void;
}

function detectVideoType(url: string | null): VideoType {
  if (!url) return 'unknown';
  
  if (url.includes('youtube.com') || url.includes('youtu.be')) {
    return 'youtube';
  }
  if (url.includes('vimeo.com')) {
    return 'vimeo';
  }
  if (url.match(/\.(mp4|webm|ogg|mov)(\?|$)/i) || url.includes('/storage/')) {
    return 'direct';
  }
  return 'unknown';
}

function extractVimeoId(url: string): string | null {
  const match = url.match(/vimeo\.com\/(?:video\/)?(\d+)/);
  return match ? match[1] : null;
}

export function UnifiedVideoPlayer({
  url,
  thumbnail,
  title,
  autoPlay = false,
  muted = true,
  loop = false,
  controls = true,
  clickToPlay = true,
  aspectRatio = '16:9',
  className,
  onEnded,
  onError,
}: UnifiedVideoPlayerProps) {
  const [hasStarted, setHasStarted] = useState(!clickToPlay);
  const [iframeLoading, setIframeLoading] = useState(true);
  
  const videoType = useMemo(() => detectVideoType(url), [url]);
  
  const { videoRef, containerRef, state, actions, PLAYBACK_RATES } = useVideoPlayer({
    autoPlay: autoPlay && hasStarted,
    muted,
    loop,
    onEnded,
    onError,
  });

  // Keyboard shortcuts for direct videos
  useVideoKeyboard({
    enabled: videoType === 'direct' && hasStarted,
    onTogglePlay: actions.togglePlay,
    onToggleMute: actions.toggleMute,
    onToggleFullscreen: actions.toggleFullscreen,
    onSeekForward: () => actions.seekBy(10),
    onSeekBackward: () => actions.seekBy(-10),
    onVolumeUp: () => actions.setVolume(state.volume + 0.1),
    onVolumeDown: () => actions.setVolume(state.volume - 0.1),
  });

  // Compute thumbnail for YouTube
  const computedThumbnail = useMemo(() => {
    if (thumbnail) return thumbnail;
    if (videoType === 'youtube') {
      const youtubeId = getYouTubeId(url);
      return youtubeId ? getThumbnailUrl(youtubeId, 'hq') : null;
    }
    return null;
  }, [thumbnail, videoType, url]);

  const aspectRatioClass = {
    '16:9': 'aspect-video',
    '4:3': 'aspect-[4/3]',
    '1:1': 'aspect-square',
    '9:16': 'aspect-[9/16]',
  }[aspectRatio];

  const handleStart = () => {
    setHasStarted(true);
  };

  // Click to play overlay
  if (!hasStarted && clickToPlay) {
    return (
      <div
        ref={containerRef}
        className={cn(
          "relative overflow-hidden rounded-lg bg-muted cursor-pointer group",
          aspectRatioClass,
          className
        )}
        onClick={handleStart}
      >
        {/* Thumbnail */}
        {computedThumbnail && (
          <img
            src={computedThumbnail}
            alt={title || 'Video thumbnail'}
            className="absolute inset-0 w-full h-full object-cover"
          />
        )}

        {/* Fallback if no thumbnail */}
        {!computedThumbnail && (
          <div className="absolute inset-0 flex items-center justify-center bg-muted">
            <Dumbbell className="w-12 h-12 text-muted-foreground/50" />
          </div>
        )}

        {/* Play button overlay */}
        <div className="absolute inset-0 flex items-center justify-center bg-black/30 group-hover:bg-black/40 transition-colors">
          <motion.div
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            className="w-16 h-16 rounded-full bg-primary/90 flex items-center justify-center shadow-2xl"
          >
            <svg className="w-7 h-7 text-primary-foreground ml-1" fill="currentColor" viewBox="0 0 24 24">
              <path d="M8 5v14l11-7z" />
            </svg>
          </motion.div>
        </div>
      </div>
    );
  }

  // YouTube player
  if (videoType === 'youtube') {
    const youtubeId = getYouTubeId(url);
    if (!youtubeId) {
      return (
        <div className={cn("relative rounded-lg bg-muted flex items-center justify-center", aspectRatioClass, className)}>
          <p className="text-muted-foreground text-sm">URL do YouTube inválida</p>
        </div>
      );
    }

    const embedUrl = toEmbedUrl(youtubeId, { 
      autoplay: true, 
      nocookie: true 
    }) + `&mute=${muted ? 1 : 0}&loop=${loop ? 1 : 0}&rel=0&modestbranding=1`;

    return (
      <div
        ref={containerRef}
        className={cn("relative overflow-hidden rounded-lg bg-black", aspectRatioClass, className)}
      >
        <VideoLoadingOverlay isLoading={iframeLoading} message="Conectando ao YouTube..." />
        
        <iframe
          src={embedUrl}
          title={title || 'YouTube video'}
          className="absolute inset-0 w-full h-full"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          onLoad={() => setIframeLoading(false)}
        />
      </div>
    );
  }

  // Vimeo player
  if (videoType === 'vimeo') {
    const vimeoId = extractVimeoId(url!);
    if (!vimeoId) {
      return (
        <div className={cn("relative rounded-lg bg-muted flex items-center justify-center", aspectRatioClass, className)}>
          <p className="text-muted-foreground text-sm">URL do Vimeo inválida</p>
        </div>
      );
    }

    const embedUrl = `https://player.vimeo.com/video/${vimeoId}?autoplay=${autoPlay ? 1 : 0}&muted=${muted ? 1 : 0}&loop=${loop ? 1 : 0}`;

    return (
      <div
        ref={containerRef}
        className={cn("relative overflow-hidden rounded-lg bg-black", aspectRatioClass, className)}
      >
        <VideoLoadingOverlay isLoading={iframeLoading} message="Conectando ao Vimeo..." />
        
        <iframe
          src={embedUrl}
          title={title || 'Vimeo video'}
          className="absolute inset-0 w-full h-full"
          allow="autoplay; fullscreen; picture-in-picture"
          allowFullScreen
          onLoad={() => setIframeLoading(false)}
        />
      </div>
    );
  }

  // Direct video player
  if (videoType === 'direct') {
    return (
      <div
        ref={containerRef}
        className={cn("relative overflow-hidden rounded-lg bg-black", aspectRatioClass, className)}
      >
        <video
          ref={videoRef}
          src={url!}
          poster={computedThumbnail || undefined}
          autoPlay={autoPlay}
          muted={muted}
          loop={loop}
          playsInline
          className="absolute inset-0 w-full h-full object-contain"
        />

        <VideoLoadingOverlay 
          isLoading={state.isLoading && !state.hasError} 
          message="Carregando vídeo..." 
        />

        <VideoErrorOverlay
          hasError={state.hasError}
          errorMessage={state.errorMessage}
          videoUrl={url!}
          thumbnail={computedThumbnail || undefined}
          onRetry={actions.retry}
        />

        {controls && !state.hasError && (
          <VideoControls
            state={state}
            onTogglePlay={actions.togglePlay}
            onToggleMute={actions.toggleMute}
            onSetVolume={actions.setVolume}
            onSeek={actions.seek}
            onToggleFullscreen={actions.toggleFullscreen}
            onTogglePiP={actions.togglePiP}
            onSetPlaybackRate={actions.setPlaybackRate}
            playbackRates={PLAYBACK_RATES}
            loop={loop}
          />
        )}
      </div>
    );
  }

  // Unknown/unsupported
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-lg bg-muted flex flex-col items-center justify-center gap-2",
        aspectRatioClass,
        className
      )}
    >
      <Dumbbell className="w-12 h-12 text-muted-foreground/50" />
      <p className="text-sm text-muted-foreground">Vídeo não disponível</p>
    </div>
  );
}
