import { motion, AnimatePresence } from 'framer-motion';
import { useState, useRef, useEffect } from 'react';
import { cn } from '@/lib/utils';

interface VideoSpeedControlProps {
  currentRate: number;
  rates: readonly number[];
  onRateChange: (rate: number) => void;
  className?: string;
}

export function VideoSpeedControl({
  currentRate,
  rates,
  onRateChange,
  className,
}: VideoSpeedControlProps) {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Close on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [isOpen]);

  const formatRate = (rate: number) => {
    return rate === 1 ? '1x' : `${rate}x`;
  };

  return (
    <div ref={containerRef} className={cn("relative", className)}>
      {/* Toggle button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={cn(
          "px-2 py-1 text-xs font-medium rounded transition-colors",
          "text-white/80 hover:text-white hover:bg-white/10",
          currentRate !== 1 && "text-primary"
        )}
        aria-label={`Velocidade: ${formatRate(currentRate)}`}
      >
        {formatRate(currentRate)}
      </button>

      {/* Dropdown menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 8, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 8, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className={cn(
              "absolute bottom-full left-1/2 -translate-x-1/2 mb-2",
              "bg-popover/95 backdrop-blur-sm border border-border rounded-lg shadow-xl",
              "py-1 min-w-[80px] z-50"
            )}
          >
            {rates.map((rate) => (
              <button
                key={rate}
                onClick={() => {
                  onRateChange(rate);
                  setIsOpen(false);
                }}
                className={cn(
                  "w-full px-3 py-1.5 text-sm text-left transition-colors",
                  "hover:bg-accent hover:text-accent-foreground",
                  rate === currentRate && "text-primary font-medium bg-primary/10"
                )}
              >
                {formatRate(rate)}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
