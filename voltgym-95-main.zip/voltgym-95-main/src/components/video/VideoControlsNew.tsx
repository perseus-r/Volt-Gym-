import { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Minimize,
  PictureInPicture2,
  Repeat
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { VideoProgressBar } from './VideoProgressBar';
import { VideoSpeedControl } from './VideoSpeedControl';
import type { VideoPlayerState } from '@/hooks/useVideoPlayer';

interface VideoControlsProps {
  state: VideoPlayerState;
  onTogglePlay: () => void;
  onToggleMute: () => void;
  onSetVolume: (volume: number) => void;
  onSeek: (time: number) => void;
  onToggleFullscreen: () => void;
  onTogglePiP: () => void;
  onSetPlaybackRate: (rate: number) => void;
  playbackRates: readonly number[];
  loop?: boolean;
  className?: string;
}

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, '0')}`;
}

export function VideoControls({
  state,
  onTogglePlay,
  onToggleMute,
  onSetVolume,
  onSeek,
  onToggleFullscreen,
  onTogglePiP,
  onSetPlaybackRate,
  playbackRates,
  loop,
  className,
}: VideoControlsProps) {
  const [isVisible, setIsVisible] = useState(true);
  const [showVolumeSlider, setShowVolumeSlider] = useState(false);
  const hideTimeoutRef = useRef<NodeJS.Timeout>();
  const containerRef = useRef<HTMLDivElement>(null);

  const { 
    isPlaying, 
    isMuted, 
    isFullscreen, 
    isPiP,
    currentTime, 
    duration, 
    buffered,
    volume,
    playbackRate 
  } = state;

  const showControls = useCallback(() => {
    setIsVisible(true);
    if (hideTimeoutRef.current) {
      clearTimeout(hideTimeoutRef.current);
    }
    if (isPlaying) {
      hideTimeoutRef.current = setTimeout(() => setIsVisible(false), 3000);
    }
  }, [isPlaying]);

  useEffect(() => {
    showControls();
  }, [isPlaying, showControls]);

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value);
    onSetVolume(newVolume);
  };

  // Check if PiP is supported
  const isPiPSupported = document.pictureInPictureEnabled;

  return (
    <div
      ref={containerRef}
      className={cn("absolute inset-0", className)}
      onMouseMove={showControls}
      onMouseLeave={() => isPlaying && setIsVisible(false)}
      onTouchStart={showControls}
    >
      {/* Click to play/pause overlay */}
      <div 
        className="absolute inset-0 cursor-pointer" 
        onClick={onTogglePlay}
      />

      <AnimatePresence>
        {isVisible && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/80 via-black/40 to-transparent"
          >
            {/* Progress bar */}
            <div className="mb-3">
              <VideoProgressBar
                currentTime={currentTime}
                duration={duration}
                buffered={buffered}
                onSeek={onSeek}
              />
            </div>

            {/* Controls row */}
            <div className="flex items-center gap-2 sm:gap-3">
              {/* Play/Pause */}
              <button
                onClick={onTogglePlay}
                className="w-8 h-8 flex items-center justify-center text-white hover:text-primary transition-colors"
                aria-label={isPlaying ? "Pausar" : "Reproduzir"}
              >
                {isPlaying ? (
                  <Pause className="w-5 h-5 fill-current" />
                ) : (
                  <Play className="w-5 h-5 fill-current ml-0.5" />
                )}
              </button>

              {/* Time */}
              <span className="text-xs text-white/80 font-mono min-w-[80px] hidden sm:inline">
                {formatTime(currentTime)} / {formatTime(duration)}
              </span>

              {/* Loop indicator */}
              {loop && (
                <motion.div
                  initial={{ scale: 0.8 }}
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="flex items-center gap-1 text-primary"
                >
                  <Repeat className="w-3.5 h-3.5" />
                </motion.div>
              )}

              {/* Spacer */}
              <div className="flex-1" />

              {/* Volume */}
              <div 
                className="relative flex items-center gap-1"
                onMouseEnter={() => setShowVolumeSlider(true)}
                onMouseLeave={() => setShowVolumeSlider(false)}
              >
                <button
                  onClick={onToggleMute}
                  className="w-8 h-8 flex items-center justify-center text-white hover:text-primary transition-colors"
                  aria-label={isMuted ? "Ativar som" : "Mudo"}
                >
                  {isMuted || volume === 0 ? (
                    <VolumeX className="w-5 h-5" />
                  ) : (
                    <Volume2 className="w-5 h-5" />
                  )}
                </button>
                
                <AnimatePresence>
                  {showVolumeSlider && (
                    <motion.div
                      initial={{ width: 0, opacity: 0 }}
                      animate={{ width: 80, opacity: 1 }}
                      exit={{ width: 0, opacity: 0 }}
                      transition={{ duration: 0.15 }}
                      className="overflow-hidden"
                    >
                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.05"
                        value={isMuted ? 0 : volume}
                        onChange={handleVolumeChange}
                        className="w-20 h-1 accent-primary cursor-pointer"
                        aria-label="Volume"
                      />
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Speed control */}
              <VideoSpeedControl
                currentRate={playbackRate}
                rates={playbackRates}
                onRateChange={onSetPlaybackRate}
              />

              {/* Picture-in-Picture */}
              {isPiPSupported && (
                <button
                  onClick={onTogglePiP}
                  className={cn(
                    "w-8 h-8 flex items-center justify-center transition-colors",
                    isPiP ? "text-primary" : "text-white hover:text-primary"
                  )}
                  aria-label={isPiP ? "Sair do Picture-in-Picture" : "Picture-in-Picture"}
                >
                  <PictureInPicture2 className="w-4 h-4" />
                </button>
              )}

              {/* Fullscreen */}
              <button
                onClick={onToggleFullscreen}
                className="w-8 h-8 flex items-center justify-center text-white hover:text-primary transition-colors"
                aria-label={isFullscreen ? "Sair da tela cheia" : "Tela cheia"}
              >
                {isFullscreen ? (
                  <Minimize className="w-5 h-5" />
                ) : (
                  <Maximize className="w-5 h-5" />
                )}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Center play button when paused */}
      <AnimatePresence>
        {!isPlaying && isVisible && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="absolute inset-0 flex items-center justify-center pointer-events-none"
          >
            <div className="w-16 h-16 rounded-full bg-primary/90 backdrop-blur-sm flex items-center justify-center shadow-2xl">
              <Play className="w-7 h-7 text-primary-foreground fill-current ml-1" />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
