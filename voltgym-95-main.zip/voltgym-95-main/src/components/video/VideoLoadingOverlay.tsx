import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';

interface VideoLoadingOverlayProps {
  isLoading: boolean;
  message?: string;
  className?: string;
}

export function VideoLoadingOverlay({ 
  isLoading, 
  message = 'Carregando vídeo...', 
  className 
}: VideoLoadingOverlayProps) {
  return (
    <AnimatePresence>
      {isLoading && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className={cn(
            "absolute inset-0 bg-muted/60 backdrop-blur-sm flex flex-col items-center justify-center z-10 gap-4",
            className
          )}
        >
          {/* Animated skeleton shimmer */}
          <div className="relative w-full h-full overflow-hidden">
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent"
              animate={{
                x: ['-100%', '100%'],
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                ease: 'linear',
              }}
            />
          </div>

          {/* Center loading indicator */}
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
            <div className="relative">
              {/* Outer ring */}
              <div className="w-14 h-14 rounded-full border-2 border-primary/20" />
              
              {/* Spinning ring */}
              <motion.div 
                className="absolute inset-0 w-14 h-14 rounded-full border-2 border-transparent border-t-primary"
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
              />
              
              {/* Pulsing center dot */}
              <motion.div
                className="absolute inset-0 flex items-center justify-center"
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                <div className="w-2 h-2 rounded-full bg-primary" />
              </motion.div>
            </div>

            {/* Loading message */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="text-sm text-muted-foreground font-medium"
            >
              {message}
            </motion.p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
