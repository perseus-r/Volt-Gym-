import { motion, AnimatePresence } from 'framer-motion';
import { AlertCircle, RefreshCw, ExternalLink, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useState } from 'react';

interface VideoErrorOverlayProps {
  hasError: boolean;
  errorMessage: string | null;
  videoUrl?: string;
  thumbnail?: string;
  onRetry: () => void;
  className?: string;
}

export function VideoErrorOverlay({
  hasError,
  errorMessage,
  videoUrl,
  thumbnail,
  onRetry,
  className,
}: VideoErrorOverlayProps) {
  const [copied, setCopied] = useState(false);

  const handleCopyLink = async () => {
    if (!videoUrl) return;
    try {
      await navigator.clipboard.writeText(videoUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  const handleOpenNewTab = () => {
    if (videoUrl) {
      window.open(videoUrl, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <AnimatePresence>
      {hasError && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className={cn(
            "absolute inset-0 flex flex-col items-center justify-center z-20",
            "bg-background/95 backdrop-blur-sm",
            className
          )}
          style={{
            backgroundImage: thumbnail ? `url(${thumbnail})` : undefined,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        >
          {/* Dark overlay on thumbnail */}
          {thumbnail && (
            <div className="absolute inset-0 bg-background/90 backdrop-blur-sm" />
          )}

          <div className="relative z-10 flex flex-col items-center gap-4 p-6 max-w-sm text-center">
            {/* Error icon */}
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center"
            >
              <AlertCircle className="w-8 h-8 text-destructive" />
            </motion.div>

            {/* Error message */}
            <div className="space-y-1">
              <h3 className="text-lg font-semibold text-foreground">
                Não foi possível carregar o vídeo
              </h3>
              <p className="text-sm text-muted-foreground">
                {errorMessage || 'Ocorreu um erro desconhecido'}
              </p>
            </div>

            {/* Action buttons */}
            <div className="flex flex-wrap items-center justify-center gap-2 mt-2">
              <Button
                variant="default"
                size="sm"
                onClick={onRetry}
                className="gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                Tentar novamente
              </Button>

              {videoUrl && (
                <>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleOpenNewTab}
                    className="gap-2"
                  >
                    <ExternalLink className="w-4 h-4" />
                    Abrir em nova aba
                  </Button>

                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleCopyLink}
                    className="gap-2"
                  >
                    {copied ? (
                      <>
                        <Check className="w-4 h-4 text-green-500" />
                        Copiado!
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        Copiar link
                      </>
                    )}
                  </Button>
                </>
              )}
            </div>

            {/* Help text */}
            <p className="text-xs text-muted-foreground mt-2">
              Verifique sua conexão ou tente novamente mais tarde
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
