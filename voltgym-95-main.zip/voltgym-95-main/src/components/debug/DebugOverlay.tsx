import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { usePWA } from '@/hooks/usePWA';
import { X, RefreshCw, Trash2, Bug, ChevronDown, ChevronUp } from 'lucide-react';

interface ErrorLog {
  timestamp: string;
  message: string;
  stack?: string;
}

export function DebugOverlay() {
  const location = useLocation();
  const { appVersion, isInstalled, isOnline, updateAvailable, updateApp } = usePWA();
  
  const [isExpanded, setIsExpanded] = useState(false);
  const [swStatus, setSwStatus] = useState<{
    controller: boolean;
    waiting: boolean;
    installing: boolean;
    active: boolean;
  }>({ controller: false, waiting: false, installing: false, active: false });
  const [buildInfo, setBuildInfo] = useState<{ version: string; buildDate: string; buildId: string }>({ 
    version: 'loading...', 
    buildDate: '', 
    buildId: '' 
  });
  const [errors, setErrors] = useState<ErrorLog[]>([]);
  const [viewportInfo, setViewportInfo] = useState({ 
    innerHeight: 0, 
    visualViewport: 0,
    standalone: false 
  });
  const [isUpdating, setIsUpdating] = useState(false);

  // Check if debug mode is enabled via query param
  const searchParams = new URLSearchParams(location.search);
  const isDebugMode = searchParams.get('debug') === '1';

  // Capture errors
  useEffect(() => {
    if (!isDebugMode) return;

    const handleError = (event: ErrorEvent) => {
      setErrors(prev => [...prev.slice(-9), {
        timestamp: new Date().toISOString(),
        message: event.message,
        stack: event.error?.stack
      }]);
    };

    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      setErrors(prev => [...prev.slice(-9), {
        timestamp: new Date().toISOString(),
        message: `Promise rejected: ${event.reason?.message || event.reason}`,
        stack: event.reason?.stack
      }]);
    };

    window.addEventListener('error', handleError);
    window.addEventListener('unhandledrejection', handleUnhandledRejection);

    return () => {
      window.removeEventListener('error', handleError);
      window.removeEventListener('unhandledrejection', handleUnhandledRejection);
    };
  }, [isDebugMode]);

  // Fetch build info with cache bust
  useEffect(() => {
    if (!isDebugMode) return;

    fetch(`/version.json?ts=${Date.now()}`)
      .then(r => r.json())
      .then(data => setBuildInfo({
        version: data.version || 'unknown',
        buildDate: data.buildDate || '',
        buildId: data.buildId || data.version || 'unknown'
      }))
      .catch(() => setBuildInfo({ version: 'fetch-error', buildDate: '', buildId: 'error' }));
  }, [isDebugMode]);

  // Check SW status
  useEffect(() => {
    if (!isDebugMode || !('serviceWorker' in navigator)) return;

    const checkSW = async () => {
      try {
        const registration = await navigator.serviceWorker.ready;
        setSwStatus({
          controller: !!navigator.serviceWorker.controller,
          waiting: !!registration.waiting,
          installing: !!registration.installing,
          active: !!registration.active
        });
      } catch {
        setSwStatus({ controller: false, waiting: false, installing: false, active: false });
      }
    };

    checkSW();
    const interval = setInterval(checkSW, 2000);
    return () => clearInterval(interval);
  }, [isDebugMode]);

  // Viewport info
  useEffect(() => {
    if (!isDebugMode) return;

    const updateViewport = () => {
      setViewportInfo({
        innerHeight: window.innerHeight,
        visualViewport: window.visualViewport?.height || 0,
        standalone: window.matchMedia('(display-mode: standalone)').matches || 
                   (window.navigator as any).standalone === true
      });
    };

    updateViewport();
    window.addEventListener('resize', updateViewport);
    window.visualViewport?.addEventListener('resize', updateViewport);

    return () => {
      window.removeEventListener('resize', updateViewport);
      window.visualViewport?.removeEventListener('resize', updateViewport);
    };
  }, [isDebugMode]);

  const handleForceUpdate = async () => {
    if (!('serviceWorker' in navigator)) return;
    
    setIsUpdating(true);
    try {
      const registration = await navigator.serviceWorker.ready;
      
      // Force check for updates
      await registration.update();
      
      // If there's a waiting SW, activate it
      if (registration.waiting) {
        registration.waiting.postMessage({ type: 'SKIP_WAITING' });
      }
      
      // Reload after short delay
      setTimeout(() => window.location.reload(), 500);
    } catch (error) {
      console.error('Force update failed:', error);
      setIsUpdating(false);
    }
  };

  const handleClearCaches = async () => {
    try {
      if ('caches' in window) {
        const cacheNames = await caches.keys();
        await Promise.all(cacheNames.map(name => caches.delete(name)));
        alert(`${cacheNames.length} caches limpos!`);
      }
      
      // Also unregister SW
      if ('serviceWorker' in navigator) {
        const registrations = await navigator.serviceWorker.getRegistrations();
        await Promise.all(registrations.map(r => r.unregister()));
      }
      
      window.location.reload();
    } catch (error) {
      console.error('Clear caches failed:', error);
    }
  };

  if (!isDebugMode) return null;

  return (
    <div 
      className="fixed bottom-20 left-2 right-2 z-[99999] bg-black/95 text-white rounded-lg shadow-2xl border border-yellow-500/50 text-xs font-mono"
      style={{ maxHeight: isExpanded ? '60vh' : '40px' }}
    >
      {/* Header - always visible */}
      <div 
        className="flex items-center justify-between p-2 cursor-pointer bg-yellow-500/20"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center gap-2">
          <Bug className="w-4 h-4 text-yellow-500" />
          <span className="text-yellow-500 font-bold">DEBUG</span>
          <span className="text-gray-400">v{buildInfo.buildId}</span>
          {errors.length > 0 && (
            <span className="bg-red-500 text-white px-1.5 rounded-full text-[10px]">
              {errors.length} errors
            </span>
          )}
        </div>
        {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
      </div>

      {isExpanded && (
        <div className="p-3 space-y-3 overflow-y-auto" style={{ maxHeight: 'calc(60vh - 40px)' }}>
          {/* Build Info */}
          <div className="space-y-1">
            <div className="text-yellow-500 font-bold mb-1">📦 Build</div>
            <div>Version: <span className="text-green-400">{buildInfo.version}</span></div>
            <div>Build ID: <span className="text-green-400">{buildInfo.buildId}</span></div>
            <div>Date: <span className="text-green-400">{buildInfo.buildDate}</span></div>
          </div>

          {/* PWA Status */}
          <div className="space-y-1">
            <div className="text-yellow-500 font-bold mb-1">📱 PWA Status</div>
            <div>Standalone: <span className={viewportInfo.standalone ? 'text-green-400' : 'text-red-400'}>{viewportInfo.standalone ? 'SIM' : 'NÃO'}</span></div>
            <div>Installed: <span className={isInstalled ? 'text-green-400' : 'text-red-400'}>{isInstalled ? 'SIM' : 'NÃO'}</span></div>
            <div>Online: <span className={isOnline ? 'text-green-400' : 'text-red-400'}>{isOnline ? 'SIM' : 'NÃO'}</span></div>
            <div>Update available: <span className={updateAvailable ? 'text-yellow-400' : 'text-gray-400'}>{updateAvailable ? 'SIM!' : 'não'}</span></div>
          </div>

          {/* Service Worker */}
          <div className="space-y-1">
            <div className="text-yellow-500 font-bold mb-1">⚙️ Service Worker</div>
            <div>Controller: <span className={swStatus.controller ? 'text-green-400' : 'text-red-400'}>{swStatus.controller ? 'SIM' : 'NÃO'}</span></div>
            <div>Waiting: <span className={swStatus.waiting ? 'text-yellow-400' : 'text-gray-400'}>{swStatus.waiting ? 'SIM (update pending!)' : 'não'}</span></div>
            <div>Installing: <span className={swStatus.installing ? 'text-blue-400' : 'text-gray-400'}>{swStatus.installing ? 'SIM' : 'não'}</span></div>
            <div>Active: <span className={swStatus.active ? 'text-green-400' : 'text-gray-400'}>{swStatus.active ? 'SIM' : 'não'}</span></div>
          </div>

          {/* Viewport */}
          <div className="space-y-1">
            <div className="text-yellow-500 font-bold mb-1">📐 Viewport</div>
            <div>innerHeight: <span className="text-cyan-400">{viewportInfo.innerHeight}px</span></div>
            <div>visualViewport: <span className="text-cyan-400">{viewportInfo.visualViewport}px</span></div>
            <div>Route: <span className="text-cyan-400">{location.pathname}</span></div>
          </div>

          {/* Errors */}
          {errors.length > 0 && (
            <div className="space-y-1">
              <div className="text-red-500 font-bold mb-1">❌ Errors ({errors.length})</div>
              <div className="max-h-32 overflow-y-auto space-y-2">
                {errors.map((err, i) => (
                  <div key={i} className="bg-red-900/30 p-2 rounded text-[10px]">
                    <div className="text-red-400">{err.message}</div>
                    {err.stack && (
                      <div className="text-gray-500 mt-1 whitespace-pre-wrap">{err.stack.slice(0, 200)}...</div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-2 pt-2 border-t border-gray-700">
            <button
              onClick={handleForceUpdate}
              disabled={isUpdating}
              className="flex-1 flex items-center justify-center gap-1 bg-green-600 hover:bg-green-500 disabled:bg-gray-600 px-3 py-2 rounded text-white"
            >
              <RefreshCw className={`w-3 h-3 ${isUpdating ? 'animate-spin' : ''}`} />
              {isUpdating ? 'Atualizando...' : 'Forçar Update'}
            </button>
            <button
              onClick={handleClearCaches}
              className="flex-1 flex items-center justify-center gap-1 bg-red-600 hover:bg-red-500 px-3 py-2 rounded text-white"
            >
              <Trash2 className="w-3 h-3" />
              Limpar Caches
            </button>
            <button
              onClick={() => window.location.reload()}
              className="flex items-center justify-center gap-1 bg-blue-600 hover:bg-blue-500 px-3 py-2 rounded text-white"
            >
              <RefreshCw className="w-3 h-3" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
