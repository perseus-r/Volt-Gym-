import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { CheckCircle, Dumbbell, ArrowRight, Sparkles } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface WorkoutCreationNotificationProps {
  workoutName: string;
  onDismiss: () => void;
}

export const WorkoutCreationNotification: React.FC<WorkoutCreationNotificationProps> = ({
  workoutName,
  onDismiss
}) => {
  const navigate = useNavigate();

  const handleViewWorkout = () => {
    onDismiss();
    navigate('/treinos');
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 50, scale: 0.9 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 50, scale: 0.9 }}
        transition={{ type: 'spring', duration: 0.5 }}
        className="fixed bottom-6 right-6 z-50 max-w-md"
      >
        <Card className="glass-card p-4 md:p-5 border-accent/40 bg-gradient-to-br from-accent/20 via-surface/90 to-accent-2/20 backdrop-blur-xl shadow-2xl">
          <div className="flex items-start gap-3 md:gap-4">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1, rotate: [0, 360] }}
              transition={{ delay: 0.2, duration: 0.6 }}
              className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-gradient-to-br from-accent/30 to-accent-2/30 flex items-center justify-center flex-shrink-0 border-2 border-accent/50"
            >
              <CheckCircle className="w-5 h-5 md:w-6 md:h-6 text-accent" />
            </motion.div>
            
            <div className="flex-1 min-w-0">
              <motion.h4
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.3 }}
                className="text-sm md:text-base font-bold text-txt mb-1 flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-accent" />
                Treino Criado Automaticamente!
              </motion.h4>
              
              <motion.p
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.4 }}
                className="text-xs md:text-sm text-txt-2 mb-3"
              >
                <strong className="text-accent font-semibold">{workoutName}</strong> foi gerado pela IA e está pronto para você começar.
              </motion.p>
              
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="flex gap-2 flex-wrap"
              >
                <Button
                  size="sm"
                  onClick={handleViewWorkout}
                  className="h-8 md:h-9 px-3 md:px-4 text-xs md:text-sm bg-gradient-to-r from-accent to-accent-2 hover:from-accent/90 hover:to-accent-2/90 text-accent-ink font-semibold shadow-lg"
                >
                  <Dumbbell className="w-3 h-3 md:w-4 md:h-4 mr-1.5" />
                  Começar Treino
                  <ArrowRight className="w-3 h-3 md:w-4 md:h-4 ml-1.5" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={onDismiss}
                  className="h-8 md:h-9 px-3 text-xs md:text-sm text-txt-2 hover:text-txt hover:bg-surface/50"
                >
                  Fechar
                </Button>
              </motion.div>
            </div>
          </div>
          
          {/* Animated background effect */}
          <motion.div
            className="absolute inset-0 rounded-2xl bg-gradient-to-r from-accent/5 via-accent-2/5 to-accent/5 pointer-events-none"
            animate={{
              opacity: [0.3, 0.6, 0.3],
              scale: [1, 1.02, 1],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />
        </Card>
      </motion.div>
    </AnimatePresence>
  );
};