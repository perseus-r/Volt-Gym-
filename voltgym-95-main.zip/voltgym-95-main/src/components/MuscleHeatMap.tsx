/**
 * MuscleHeatMap - Visual representation of muscle group training frequency
 * 
 * Shows which muscle groups are being trained most/least with color coding.
 */

import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { MuscleGroupData } from '@/hooks/usePerformanceInsights';
import { AlertTriangle, CheckCircle2, XCircle } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface MuscleHeatMapProps {
  data: MuscleGroupData[];
  className?: string;
}

export function MuscleHeatMap({ data, className }: MuscleHeatMapProps) {
  const getIntensityColor = (percentage: number, isNeglected: boolean): string => {
    if (isNeglected) return 'from-destructive/20 to-destructive/40';
    if (percentage >= 20) return 'from-accent to-accent/80';
    if (percentage >= 15) return 'from-accent/80 to-accent/60';
    if (percentage >= 10) return 'from-accent/60 to-accent/40';
    if (percentage >= 5) return 'from-warning/60 to-warning/40';
    return 'from-muted/40 to-muted/20';
  };

  const getStatusIcon = (group: MuscleGroupData) => {
    if (group.isNeglected) {
      return <XCircle className="w-3 h-3 text-destructive" />;
    }
    if (group.avgRpe >= 8.5 && group.count >= 3) {
      return <AlertTriangle className="w-3 h-3 text-warning" />;
    }
    return <CheckCircle2 className="w-3 h-3 text-success" />;
  };

  const maxCount = Math.max(...data.map(d => d.count), 1);

  return (
    <TooltipProvider>
      <div className={cn('space-y-3', className)}>
        {data.map((group, index) => (
          <motion.div
            key={group.name}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.05 }}
            className="relative"
          >
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span className="cursor-help">{getStatusIcon(group)}</span>
                  </TooltipTrigger>
                  <TooltipContent>
                    {group.isNeglected && 'Negligenciado (+7 dias sem treino)'}
                    {!group.isNeglected && group.avgRpe >= 8.5 && 'Alto volume de intensidade'}
                    {!group.isNeglected && group.avgRpe < 8.5 && 'Frequência adequada'}
                  </TooltipContent>
                </Tooltip>
                <span className="text-sm font-medium">{group.name}</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span>{group.count} treinos</span>
                <span className="text-accent font-medium">{Math.round(group.percentage)}%</span>
              </div>
            </div>
            
            {/* Progress bar */}
            <div className="h-2 bg-muted/30 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${(group.count / maxCount) * 100}%` }}
                transition={{ delay: index * 0.05 + 0.2, duration: 0.5 }}
                className={cn(
                  'h-full rounded-full bg-gradient-to-r',
                  getIntensityColor(group.percentage, group.isNeglected)
                )}
              />
            </div>
            
            {/* RPE indicator */}
            {group.avgRpe > 0 && (
              <div className="mt-1 text-xs text-muted-foreground">
                RPE médio: <span className={cn(
                  group.avgRpe >= 8.5 ? 'text-warning' : 
                  group.avgRpe >= 7 ? 'text-accent' : 'text-success'
                )}>{group.avgRpe.toFixed(1)}</span>
              </div>
            )}
          </motion.div>
        ))}

        {data.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <p>Nenhum dado de grupo muscular disponível</p>
            <p className="text-sm">Complete alguns treinos para ver a distribuição</p>
          </div>
        )}
      </div>
    </TooltipProvider>
  );
}
