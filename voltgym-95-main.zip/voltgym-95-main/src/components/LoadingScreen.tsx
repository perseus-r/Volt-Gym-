import React from 'react';
import { motion } from 'framer-motion';
import { Zap } from 'lucide-react';

interface LoadingScreenProps {
  message?: string;
  minimal?: boolean;
}

export function LoadingScreen({ message = "Carregando...", minimal = false }: LoadingScreenProps) {
  // Minimal loading - faster, less animation
  if (minimal) {
    return (
      <div className="fixed inset-0 bg-bg/95 flex items-center justify-center z-50">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.15 }}
          className="flex flex-col items-center gap-4"
        >
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-accent to-accent/60 flex items-center justify-center">
            <Zap className="w-6 h-6 text-accent-ink" />
          </div>
          <div className="flex gap-1.5">
            {[...Array(3)].map((_, i) => (
              <motion.div
                key={i}
                className="w-2 h-2 bg-accent rounded-full"
                animate={{ opacity: [0.3, 1, 0.3] }}
                transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.15 }}
              />
            ))}
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-bg flex items-center justify-center z-50">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.2 }}
        className="flex flex-col items-center gap-6"
      >
        {/* Logo animado */}
        <motion.div
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
          className="relative"
        >
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-accent to-accent/60 flex items-center justify-center">
            <Zap className="w-8 h-8 text-accent-ink" />
          </div>
        </motion.div>

        {/* Loading text */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.2 }}
          className="text-center"
        >
          <h2 className="text-xl font-bold text-txt mb-2">VOLT</h2>
          <p className="text-txt-2">{message}</p>
        </motion.div>

        {/* Progress dots */}
        <div className="flex gap-2">
          {[...Array(3)].map((_, i) => (
            <motion.div
              key={i}
              className="w-2 h-2 bg-accent rounded-full"
              animate={{ opacity: [0.3, 1, 0.3] }}
              transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.15 }}
            />
          ))}
        </div>
      </motion.div>
    </div>
  );
}

// Fast inline skeleton for cards
export function SkeletonCard() {
  return (
    <div className="animate-pulse bg-surface rounded-2xl p-4 space-y-3">
      <div className="h-4 bg-line rounded w-3/4"></div>
      <div className="h-3 bg-line rounded w-1/2"></div>
      <div className="flex gap-2">
        <div className="h-8 bg-line rounded w-16"></div>
        <div className="h-8 bg-line rounded w-16"></div>
      </div>
    </div>
  );
}

// Fast stats skeleton
export function SkeletonStats() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {[...Array(4)].map((_, i) => (
        <div key={i} className="animate-pulse bg-surface rounded-2xl p-4 space-y-2">
          <div className="h-3 bg-line rounded w-1/2"></div>
          <div className="h-6 bg-line rounded w-3/4"></div>
        </div>
      ))}
    </div>
  );
}

// Page skeleton for faster perceived loading
export function PageSkeleton() {
  return (
    <motion.div 
      className="p-4 space-y-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.15 }}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="w-28 h-6 bg-muted/20 rounded animate-pulse mb-2" />
          <div className="w-20 h-4 bg-muted/10 rounded animate-pulse" />
        </div>
      </div>

      {/* Button */}
      <div className="w-full h-12 bg-primary/20 rounded-2xl animate-pulse" />

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-3">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="bg-card/30 rounded-xl p-3 animate-pulse">
            <div className="w-6 h-6 bg-muted/20 rounded mx-auto mb-2" />
            <div className="w-10 h-5 bg-muted/20 rounded mx-auto mb-1" />
            <div className="w-14 h-3 bg-muted/10 rounded mx-auto" />
          </div>
        ))}
      </div>

      {/* List items */}
      <div className="space-y-3">
        {[...Array(2)].map((_, i) => (
          <div key={i} className="bg-card/30 rounded-xl p-4 animate-pulse">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-muted/20 rounded-lg" />
              <div className="flex-1">
                <div className="w-3/4 h-4 bg-muted/20 rounded mb-2" />
                <div className="w-1/2 h-3 bg-muted/10 rounded" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}