import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { MessageCircle, CreditCard, ShoppingBag } from "lucide-react";

interface CartItem {
  product: {
    id: string;
    name: string;
    price: number;
    image_url?: string;
  };
  quantity: number;
}

interface CheckoutModalProps {
  cart: CartItem[];
  open: boolean;
  onClose: () => void;
  onComplete: () => void;
}

export function CheckoutModal({ cart, open, onClose, onComplete }: CheckoutModalProps) {
  const [loading, setLoading] = useState(false);
  const [checkoutMethod, setCheckoutMethod] = useState<'whatsapp' | 'stripe'>('whatsapp');
  const [shippingAddress, setShippingAddress] = useState({
    name: '',
    phone: '',
    email: '',
    street: '',
    number: '',
    complement: '',
    neighborhood: '',
    city: '',
    state: '',
    zip: ''
  });
  const [notes, setNotes] = useState('');

  const totalPrice = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);

  const generateWhatsAppMessage = () => {
    const items = cart.map(item => 
      `• ${item.product.name}\n  Qtd: ${item.quantity}\n  Preço: R$ ${(item.product.price * item.quantity).toFixed(2)}`
    ).join('\n\n');

    const address = `${shippingAddress.street}, ${shippingAddress.number}${shippingAddress.complement ? ', ' + shippingAddress.complement : ''}\n${shippingAddress.neighborhood} - ${shippingAddress.city}/${shippingAddress.state}\nCEP: ${shippingAddress.zip}`;

    return `🏋️ *NOVO PEDIDO VOLTGYM* ⚡

📦 *ITENS DO PEDIDO:*
${items}

💰 *TOTAL: R$ ${totalPrice.toFixed(2)}*

📍 *ENDEREÇO DE ENTREGA:*
${shippingAddress.name}
${address}
Tel: ${shippingAddress.phone}

${notes ? `📝 *OBSERVAÇÕES:*\n${notes}\n` : ''}
---
Aguardo confirmação! 💪`;
  };

  const validateAddress = () => {
    if (!shippingAddress.name || !shippingAddress.phone || !shippingAddress.street || 
        !shippingAddress.city || !shippingAddress.state || !shippingAddress.zip) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha todos os campos do endereço",
        variant: "destructive"
      });
      return false;
    }
    return true;
  };

  const handleWhatsAppCheckout = async () => {
    if (!validateAddress()) return;

    setLoading(true);

    try {
      // Salvar pedido no banco
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        toast({
          title: "Erro",
          description: "Você precisa estar logado para fazer um pedido",
          variant: "destructive"
        });
        return;
      }

      const { error } = await supabase.from('orders').insert({
        user_id: user.id,
        status: 'pending',
        items: cart as any,
        total_brl: totalPrice,
        payment_method: 'whatsapp',
        shipping_address: shippingAddress as any,
        notes,
        whatsapp_sent: true
      });

      if (error) throw error;

      // Redirecionar para WhatsApp - buscar número do perfil do usuário ou usar padrão
      const message = generateWhatsAppMessage();
      // Número de WhatsApp configurável - admin deve definir em configurações
      const SHOP_WHATSAPP = import.meta.env.VITE_SHOP_WHATSAPP || "5511999999999";
      const whatsappUrl = `https://wa.me/${SHOP_WHATSAPP}?text=${encodeURIComponent(message)}`;
      
      window.open(whatsappUrl, '_blank');

      toast({
        title: "Pedido enviado!",
        description: "Você será redirecionado para o WhatsApp"
      });

      onComplete();
      onClose();
    } catch (error) {
      console.error('Checkout error:', error);
      toast({
        title: "Erro ao processar pedido",
        description: "Tente novamente mais tarde",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleStripeCheckout = async () => {
    if (!validateAddress()) return;

    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        toast({
          title: "Erro",
          description: "Você precisa estar logado para fazer um pedido",
          variant: "destructive"
        });
        return;
      }

      // Chamar edge function para criar sessão Stripe
      const { data, error } = await supabase.functions.invoke('create-shop-checkout', {
        body: { 
          items: cart,
          shippingAddress,
          userId: user.id
        }
      });

      if (error) throw error;

      if (data?.url) {
        // Salvar pedido antes de redirecionar
        await supabase.from('orders').insert({
          user_id: user.id,
          status: 'pending',
          items: cart as any,
          total_brl: totalPrice,
          payment_method: 'stripe',
          shipping_address: shippingAddress as any,
          notes
        });

        // Redirecionar para Stripe Checkout
        window.location.href = data.url;
      } else {
        throw new Error('URL de checkout não retornada');
      }
    } catch (error) {
      console.error('Stripe checkout error:', error);
      toast({
        title: "Erro ao processar pagamento",
        description: "Tente novamente mais tarde",
        variant: "destructive"
      });
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5" />
            Finalizar Pedido
          </DialogTitle>
          <DialogDescription>
            Preencha seus dados para finalizar o pedido via WhatsApp
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Resumo do Pedido */}
          <div className="bg-muted/50 p-4 rounded-lg space-y-2">
            <h3 className="font-semibold">Resumo do Pedido</h3>
            {cart.map((item, idx) => (
              <div key={idx} className="flex justify-between text-sm">
                <span>{item.quantity}x {item.product.name}</span>
                <span className="font-medium">R$ {(item.product.price * item.quantity).toFixed(2)}</span>
              </div>
            ))}
            <div className="border-t pt-2 flex justify-between font-bold">
              <span>TOTAL</span>
              <span className="text-primary">R$ {totalPrice.toFixed(2)}</span>
            </div>
          </div>

          {/* Dados de Entrega */}
          <div className="space-y-4">
            <h3 className="font-semibold">Dados de Entrega</h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <Label htmlFor="name">Nome Completo *</Label>
                <Input
                  id="name"
                  value={shippingAddress.name}
                  onChange={(e) => setShippingAddress({ ...shippingAddress, name: e.target.value })}
                  placeholder="João Silva"
                />
              </div>

              <div className="col-span-2">
                <Label htmlFor="phone">Telefone/WhatsApp *</Label>
                  <Input
                    id="phone"
                    value={shippingAddress.phone}
                    onChange={(e) => setShippingAddress({ ...shippingAddress, phone: e.target.value })}
                    placeholder="(11) 99999-9999"
                  />
                </div>

                <div className="col-span-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={shippingAddress.email}
                    onChange={(e) => setShippingAddress({ ...shippingAddress, email: e.target.value })}
                    placeholder="seu@email.com"
                  />
                </div>

              <div>
                <Label htmlFor="zip">CEP *</Label>
                <Input
                  id="zip"
                  value={shippingAddress.zip}
                  onChange={(e) => setShippingAddress({ ...shippingAddress, zip: e.target.value })}
                  placeholder="00000-000"
                />
              </div>

              <div>
                <Label htmlFor="street">Rua *</Label>
                <Input
                  id="street"
                  value={shippingAddress.street}
                  onChange={(e) => setShippingAddress({ ...shippingAddress, street: e.target.value })}
                  placeholder="Rua das Flores"
                />
              </div>

              <div className="col-span-2 grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="number">Número *</Label>
                  <Input
                    id="number"
                    value={shippingAddress.number}
                    onChange={(e) => setShippingAddress({ ...shippingAddress, number: e.target.value })}
                    placeholder="123"
                  />
                </div>

                <div className="col-span-2">
                  <Label htmlFor="complement">Complemento</Label>
                  <Input
                    id="complement"
                    value={shippingAddress.complement}
                    onChange={(e) => setShippingAddress({ ...shippingAddress, complement: e.target.value })}
                    placeholder="Apto 45"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="neighborhood">Bairro *</Label>
                <Input
                  id="neighborhood"
                  value={shippingAddress.neighborhood}
                  onChange={(e) => setShippingAddress({ ...shippingAddress, neighborhood: e.target.value })}
                  placeholder="Centro"
                />
              </div>

              <div>
                <Label htmlFor="city">Cidade *</Label>
                <Input
                  id="city"
                  value={shippingAddress.city}
                  onChange={(e) => setShippingAddress({ ...shippingAddress, city: e.target.value })}
                  placeholder="São Paulo"
                />
              </div>

              <div>
                <Label htmlFor="state">Estado *</Label>
                <Input
                  id="state"
                  value={shippingAddress.state}
                  onChange={(e) => setShippingAddress({ ...shippingAddress, state: e.target.value })}
                  placeholder="SP"
                  maxLength={2}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="notes">Observações</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Alguma informação adicional sobre o pedido?"
                rows={3}
              />
            </div>
          </div>

          {/* Seleção do Método de Checkout */}
          <div className="space-y-3">
            <Label>Método de Pagamento</Label>
            <div className="grid grid-cols-2 gap-3">
              <Button
                type="button"
                variant={checkoutMethod === 'whatsapp' ? 'default' : 'outline'}
                onClick={() => setCheckoutMethod('whatsapp')}
                className="h-auto py-4 flex flex-col gap-2"
              >
                <MessageCircle className="w-6 h-6" />
                <div className="text-sm font-medium">WhatsApp</div>
                <div className="text-xs opacity-80">Pague na entrega</div>
              </Button>

              <Button
                type="button"
                variant={checkoutMethod === 'stripe' ? 'default' : 'outline'}
                onClick={() => setCheckoutMethod('stripe')}
                className="h-auto py-4 flex flex-col gap-2"
              >
                <CreditCard className="w-6 h-6" />
                <div className="text-sm font-medium">Cartão</div>
                <div className="text-xs opacity-80">Pagamento online</div>
              </Button>
            </div>
          </div>

          {/* Botões de Checkout */}
          <Button 
            onClick={checkoutMethod === 'whatsapp' ? handleWhatsAppCheckout : handleStripeCheckout}
            disabled={loading}
            className="w-full"
            size="lg"
          >
            {checkoutMethod === 'whatsapp' ? (
              <>
                <MessageCircle className="w-4 h-4 mr-2" />
                {loading ? 'Processando...' : 'Finalizar via WhatsApp'}
              </>
            ) : (
              <>
                <CreditCard className="w-4 h-4 mr-2" />
                {loading ? 'Processando...' : 'Pagar com Cartão'}
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
