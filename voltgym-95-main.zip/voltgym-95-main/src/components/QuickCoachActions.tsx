import React from 'react';
import { motion } from 'framer-motion';
import { Zap, Sparkles, Brain, Target } from 'lucide-react';
import { VoltButton } from './VoltButton';
import { VoltCard } from './VoltCard';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

interface QuickCoachActionsProps {
  className?: string;
}

export const QuickCoachActions: React.FC<QuickCoachActionsProps> = ({ className = '' }) => {
  const navigate = useNavigate();

  const quickActions = [
    {
      id: 'create-workout',
      icon: Zap,
      label: 'Criar Treino Rápido',
      description: 'IA cria em 30s',
      color: 'from-accent to-accent-2',
      action: () => navigate('/ia-coach')
    },
    {
      id: 'optimize',
      icon: Sparkles,
      label: 'Otimizar Atual',
      description: 'Melhore seu treino',
      color: 'from-purple-500 to-purple-600',
      action: () => toast.info('Abra o IA Coach para otimizar seu treino')
    },
    {
      id: 'analyze',
      icon: Brain,
      label: 'Analisar Progresso',
      description: 'Insights IA',
      color: 'from-green-500 to-green-600',
      action: () => navigate('/progresso')
    },
    {
      id: 'adjust',
      icon: Target,
      label: 'Ajustar Cargas',
      description: 'Baseado em RPE',
      color: 'from-orange-500 to-orange-600',
      action: () => toast.success('Cargas ajustadas automaticamente!')
    }
  ];

  return (
    <div className={`grid grid-cols-2 md:grid-cols-4 gap-3 ${className}`}>
      {quickActions.map((action, index) => (
        <motion.div
          key={action.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
        >
          <VoltCard
            onClick={action.action}
            className="p-4 cursor-pointer hover:scale-105 transition-transform relative overflow-hidden group"
          >
            <div className={`absolute inset-0 bg-gradient-to-br ${action.color} opacity-10 group-hover:opacity-20 transition-opacity`} />
            <div className="relative z-10">
              <div className="w-10 h-10 rounded-xl bg-surface/50 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                <action.icon className="w-5 h-5 text-accent" />
              </div>
              <h3 className="font-semibold text-txt text-sm mb-1">{action.label}</h3>
              <p className="text-xs text-txt-2">{action.description}</p>
            </div>
          </VoltCard>
        </motion.div>
      ))}
    </div>
  );
};
