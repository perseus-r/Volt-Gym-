import { useState } from 'react';
import { Search, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';

interface MobileSearchBarProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
}

export function MobileSearchBar({ 
  value, 
  onChange, 
  placeholder = "Buscar...",
  className 
}: MobileSearchBarProps) {
  const [isFocused, setIsFocused] = useState(false);

  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div className={cn(
        "flex-1 flex items-center gap-2",
        "bg-muted/50 rounded-xl",
        "px-3 py-2.5",
        "border border-transparent transition-colors",
        isFocused && "border-primary/30 bg-muted/70"
      )}>
        <Search className="w-4 h-4 text-muted-foreground flex-shrink-0" />
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          placeholder={placeholder}
          className={cn(
            "flex-1 bg-transparent text-sm",
            "placeholder:text-muted-foreground/60",
            "outline-none"
          )}
        />
        <AnimatePresence>
          {value && (
            <motion.button
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              onClick={() => onChange('')}
              className="p-0.5 rounded-full bg-muted-foreground/20 active:scale-90 transition-transform"
            >
              <X className="w-3 h-3 text-muted-foreground" />
            </motion.button>
          )}
        </AnimatePresence>
      </div>

      <AnimatePresence>
        {isFocused && (
          <motion.button
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 10 }}
            onClick={() => {
              onChange('');
              setIsFocused(false);
            }}
            className="text-sm text-primary"
          >
            Cancelar
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}
