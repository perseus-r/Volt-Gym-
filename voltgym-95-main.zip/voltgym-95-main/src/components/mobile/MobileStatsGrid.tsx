import { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface StatItem {
  label: string;
  value: string | number;
  subtitle?: string;
  icon: ReactNode;
  color?: string;
}

interface MobileStatsGridProps {
  stats: StatItem[];
  columns?: 2 | 3 | 4;
  className?: string;
}

export function MobileStatsGrid({ stats, columns = 2, className }: MobileStatsGridProps) {
  return (
    <div 
      className={cn(
        "grid gap-3",
        columns === 2 && "grid-cols-2",
        columns === 3 && "grid-cols-3",
        columns === 4 && "grid-cols-4",
        className
      )}
    >
      {stats.map((stat, index) => (
        <motion.div
          key={stat.label}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.05 }}
          className={cn(
            "bg-card/50 backdrop-blur-sm rounded-xl p-3",
            "border border-border/30"
          )}
        >
          <div className="flex items-start justify-between mb-1">
            <span className={cn(
              "w-8 h-8 rounded-lg flex items-center justify-center",
              stat.color || "bg-primary/10 text-primary"
            )}>
              {stat.icon}
            </span>
          </div>
          <p className="text-2xl font-bold text-foreground">{stat.value}</p>
          <p className="text-xs text-muted-foreground truncate">{stat.label}</p>
          {stat.subtitle && (
            <p className="text-xs text-muted-foreground/70 mt-0.5">{stat.subtitle}</p>
          )}
        </motion.div>
      ))}
    </div>
  );
}

// Horizontal scrollable stats for compact display
interface MobileStatsScrollProps {
  stats: StatItem[];
  className?: string;
}

export function MobileStatsScroll({ stats, className }: MobileStatsScrollProps) {
  return (
    <div className={cn("overflow-x-auto -mx-4 px-4", className)}>
      <div className="flex gap-3 pb-2" style={{ width: 'max-content' }}>
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.05 }}
            className={cn(
              "bg-card/50 backdrop-blur-sm rounded-xl p-3",
              "border border-border/30",
              "min-w-[120px] flex-shrink-0"
            )}
          >
            <div className="flex items-center gap-2 mb-1">
              <span className={cn(
                "w-6 h-6 rounded-md flex items-center justify-center",
                stat.color || "bg-primary/10 text-primary"
              )}>
                {stat.icon}
              </span>
              <p className="text-xs text-muted-foreground truncate">{stat.label}</p>
            </div>
            <p className="text-xl font-bold text-foreground">{stat.value}</p>
            {stat.subtitle && (
              <p className="text-xs text-muted-foreground/70">{stat.subtitle}</p>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  );
}
