import { ReactNode } from 'react';
import { Drawer } from 'vaul';
import { cn } from '@/lib/utils';

interface MobileBottomSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  children: ReactNode;
  title?: string;
  description?: string;
  className?: string;
  snapPoints?: (string | number)[];
}

export function MobileBottomSheet({
  open,
  onOpenChange,
  children,
  title,
  description,
  className,
  snapPoints
}: MobileBottomSheetProps) {
  return (
    <Drawer.Root open={open} onOpenChange={onOpenChange} snapPoints={snapPoints}>
      <Drawer.Portal>
        <Drawer.Overlay className="fixed inset-0 bg-black/60 z-50" />
        <Drawer.Content
          className={cn(
            "fixed bottom-0 left-0 right-0 z-50",
            "bg-background rounded-t-[20px]",
            "max-h-[90vh] flex flex-col",
            className
          )}
        >
          {/* Handle */}
          <div className="mx-auto mt-3 mb-2 h-1.5 w-12 rounded-full bg-muted-foreground/30" />
          
          {/* Header */}
          {(title || description) && (
            <div className="px-4 pb-3 border-b border-border/50">
              {title && (
                <Drawer.Title className="text-lg font-semibold text-foreground">
                  {title}
                </Drawer.Title>
              )}
              {description && (
                <Drawer.Description className="text-sm text-muted-foreground mt-0.5">
                  {description}
                </Drawer.Description>
              )}
            </div>
          )}
          
          {/* Content */}
          <div className="flex-1 overflow-y-auto overscroll-contain px-4 py-4">
            {children}
          </div>
          
          {/* Safe area padding */}
          <div className="h-safe-area-bottom" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }} />
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  );
}

// Action item for bottom sheets
interface MobileBottomSheetActionProps {
  icon: ReactNode;
  label: string;
  description?: string;
  onClick: () => void;
  destructive?: boolean;
  disabled?: boolean;
}

export function MobileBottomSheetAction({
  icon,
  label,
  description,
  onClick,
  destructive = false,
  disabled = false
}: MobileBottomSheetActionProps) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "w-full flex items-center gap-4 p-4 rounded-xl",
        "active:scale-[0.98] transition-all",
        disabled && "opacity-50 cursor-not-allowed",
        destructive 
          ? "text-destructive hover:bg-destructive/10" 
          : "text-foreground hover:bg-muted/50"
      )}
    >
      <div className={cn(
        "w-10 h-10 rounded-full flex items-center justify-center",
        destructive ? "bg-destructive/10" : "bg-primary/10"
      )}>
        {icon}
      </div>
      <div className="flex-1 text-left">
        <p className="font-medium">{label}</p>
        {description && (
          <p className="text-sm text-muted-foreground">{description}</p>
        )}
      </div>
    </button>
  );
}
