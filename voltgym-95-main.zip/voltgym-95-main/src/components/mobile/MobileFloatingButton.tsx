import { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface MobileFloatingButtonProps {
  icon: ReactNode;
  label?: string;
  onClick: () => void;
  className?: string;
  variant?: 'primary' | 'secondary';
  size?: 'default' | 'large';
  position?: 'bottom-right' | 'bottom-center';
}

export function MobileFloatingButton({
  icon,
  label,
  onClick,
  className,
  variant = 'primary',
  size = 'default',
  position = 'bottom-right'
}: MobileFloatingButtonProps) {
  return (
    <motion.button
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      exit={{ scale: 0, opacity: 0 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className={cn(
        "fixed z-40",
        "flex items-center justify-center gap-2",
        "rounded-full shadow-lg",
        "active:scale-95 transition-transform",
        // Position
        position === 'bottom-right' && "bottom-24 right-4",
        position === 'bottom-center' && "bottom-24 left-1/2 -translate-x-1/2",
        // Size
        size === 'default' && !label && "w-14 h-14",
        size === 'large' && !label && "w-16 h-16",
        label && "px-6 py-4",
        // Variant
        variant === 'primary' && "bg-primary text-primary-foreground",
        variant === 'secondary' && "bg-card text-foreground border border-border",
        className
      )}
      style={{
        boxShadow: variant === 'primary' 
          ? '0 4px 20px hsl(var(--primary) / 0.4)' 
          : '0 4px 20px hsl(var(--foreground) / 0.1)'
      }}
    >
      {icon}
      {label && <span className="font-semibold">{label}</span>}
    </motion.button>
  );
}
