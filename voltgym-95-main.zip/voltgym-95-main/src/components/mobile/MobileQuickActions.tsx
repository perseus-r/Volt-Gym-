import { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { ChevronRight } from 'lucide-react';

interface QuickAction {
  icon: ReactNode;
  label: string;
  onClick: () => void;
  color?: string;
}

interface MobileQuickActionsProps {
  actions: QuickAction[];
  className?: string;
}

export function MobileQuickActions({ actions, className }: MobileQuickActionsProps) {
  return (
    <div className={cn("overflow-x-auto -mx-4 px-4", className)}>
      <div className="flex gap-3 pb-2" style={{ width: 'max-content' }}>
        {actions.map((action, index) => (
          <motion.button
            key={action.label}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.05 }}
            onClick={action.onClick}
            className={cn(
              "flex flex-col items-center gap-2 p-4",
              "bg-card/50 backdrop-blur-sm rounded-xl",
              "border border-border/30",
              "min-w-[80px] flex-shrink-0",
              "active:scale-95 transition-transform"
            )}
          >
            <span className={cn(
              "w-12 h-12 rounded-xl flex items-center justify-center",
              action.color || "bg-primary/10 text-primary"
            )}>
              {action.icon}
            </span>
            <span className="text-xs text-foreground font-medium text-center leading-tight">
              {action.label}
            </span>
          </motion.button>
        ))}
      </div>
    </div>
  );
}

// Vertical list style quick actions
interface MobileActionListProps {
  actions: QuickAction[];
  className?: string;
}

export function MobileActionList({ actions, className }: MobileActionListProps) {
  return (
    <div className={cn("space-y-2", className)}>
      {actions.map((action, index) => (
        <motion.button
          key={action.label}
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: index * 0.03 }}
          onClick={action.onClick}
          className={cn(
            "w-full flex items-center gap-3 p-3",
            "bg-card/30 rounded-xl",
            "active:scale-[0.98] transition-transform"
          )}
        >
          <span className={cn(
            "w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0",
            action.color || "bg-primary/10 text-primary"
          )}>
            {action.icon}
          </span>
          <span className="flex-1 text-left text-sm font-medium text-foreground">
            {action.label}
          </span>
          <ChevronRight className="w-4 h-4 text-muted-foreground" />
        </motion.button>
      ))}
    </div>
  );
}
