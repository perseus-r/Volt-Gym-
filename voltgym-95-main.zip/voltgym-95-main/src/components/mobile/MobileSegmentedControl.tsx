import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import React from 'react';

interface Segment {
  value: string;
  label: string;
}

interface MobileSegmentedControlProps {
  segments: Segment[];
  value: string;
  onChange: (value: string) => void;
  className?: string;
  children?: React.ReactNode;
}

const contentVariants = {
  hidden: { 
    opacity: 0, 
    x: 20,
    transition: { duration: 0.15, ease: [0.4, 0, 0.2, 1] as const }
  },
  visible: { 
    opacity: 1, 
    x: 0,
    transition: { duration: 0.2, ease: [0.4, 0, 0.2, 1] as const }
  },
  exit: { 
    opacity: 0, 
    x: -20,
    transition: { duration: 0.15, ease: [0.4, 0, 0.2, 1] as const }
  }
};

export const MobileSegmentedControl = React.memo(function MobileSegmentedControl({ 
  segments, 
  value, 
  onChange,
  className,
  children
}: MobileSegmentedControlProps) {
  return (
    <div className="space-y-3">
      <div className={cn(
        "flex p-0.5 bg-muted/50 rounded-lg",
        className
      )}>
        {segments.map((segment) => {
          const isActive = segment.value === value;
          
          return (
            <button
              key={segment.value}
              onClick={() => onChange(segment.value)}
              className={cn(
                "relative flex-1 py-2 px-2 text-xs font-medium",
                "transition-colors rounded-md active:scale-[0.98]",
                isActive ? "text-foreground" : "text-muted-foreground"
              )}
            >
              {isActive && (
                <motion.div
                  layoutId="segment-indicator"
                  className="absolute inset-0 bg-background rounded-md shadow-sm"
                  transition={{ 
                    type: "spring", 
                    stiffness: 500, 
                    damping: 35,
                    mass: 0.8
                  }}
                />
              )}
              <span className="relative z-10">{segment.label}</span>
            </button>
          );
        })}
      </div>
      
      {/* Animated content wrapper */}
      {children && (
        <AnimatePresence mode="wait">
          <motion.div
            key={value}
            initial="hidden"
            animate="visible"
            exit="exit"
            variants={contentVariants}
            className="will-change-transform flex-1 min-h-0"
          >
            {children}
          </motion.div>
        </AnimatePresence>
      )}
    </div>
  );
});

// Wrapper for individual tab content
interface MobileTabContentProps {
  value: string;
  activeValue: string;
  children: React.ReactNode;
}

export const MobileTabContent = React.memo(function MobileTabContent({
  value,
  activeValue,
  children
}: MobileTabContentProps) {
  if (value !== activeValue) return null;
  return <>{children}</>;
});
