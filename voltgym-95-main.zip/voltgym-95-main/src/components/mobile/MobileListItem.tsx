import { ReactNode } from 'react';
import { ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

interface MobileListItemProps {
  icon?: ReactNode;
  title: string;
  subtitle?: string;
  trailing?: ReactNode;
  showChevron?: boolean;
  onClick?: () => void;
  className?: string;
}

export function MobileListItem({ 
  icon,
  title, 
  subtitle,
  trailing,
  showChevron = true,
  onClick,
  className 
}: MobileListItemProps) {
  return (
    <motion.button
      onClick={onClick}
      whileTap={{ scale: 0.98 }}
      className={cn(
        "w-full flex items-center gap-3 p-3",
        "min-h-[52px]", // 44px+ touch target
        "bg-card/50 rounded-xl",
        "active:bg-muted/50 transition-colors",
        className
      )}
    >
      {icon && (
        <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
          {icon}
        </div>
      )}
      
      <div className="flex-1 text-left min-w-0">
        <p className="font-medium text-foreground truncate">{title}</p>
        {subtitle && (
          <p className="text-sm text-muted-foreground truncate">{subtitle}</p>
        )}
      </div>

      {trailing && <div className="flex-shrink-0">{trailing}</div>}
      
      {showChevron && onClick && (
        <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />
      )}
    </motion.button>
  );
}
