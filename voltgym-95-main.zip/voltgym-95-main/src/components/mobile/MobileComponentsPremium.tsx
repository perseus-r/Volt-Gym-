import React from 'react';
import { motion } from 'framer-motion';
import { Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { haptic } from '@/utils/haptics';

// ==================== MobileButtonPremium ====================
interface MobileButtonPremiumProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  fullWidth?: boolean;
  loading?: boolean;
  hapticFeedback?: boolean;
  children: React.ReactNode;
}

export const MobileButtonPremium: React.FC<MobileButtonPremiumProps> = ({
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  loading = false,
  hapticFeedback = true,
  children,
  onClick,
  className,
  disabled,
  ...props
}) => {
  const [ripples, setRipples] = React.useState<Array<{ x: number; y: number; id: number }>>([]);

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (disabled || loading) return;

    // Haptic feedback
    if (hapticFeedback) {
      haptic.medium();
    }

    // Ripple effect
    const button = e.currentTarget;
    const rect = button.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const id = Date.now();

    setRipples(prev => [...prev, { x, y, id }]);
    setTimeout(() => {
      setRipples(prev => prev.filter(r => r.id !== id));
    }, 600);

    onClick?.(e);
  };

  const variantClasses = {
    primary: 'bg-gradient-to-r from-accent via-accent-bright to-accent text-black font-bold border border-accent/30 shadow-[0_0_40px_rgba(55,160,244,0.4)]',
    secondary: 'bg-black text-accent border-2 border-accent/40 hover:bg-accent/10',
    ghost: 'bg-transparent text-txt-2 border border-line/20 hover:bg-white/5 hover:text-txt',
    danger: 'bg-gradient-to-r from-error to-error/80 text-white border border-error/30 shadow-[0_0_30px_rgba(231,76,60,0.3)]'
  };

  const sizeClasses = {
    sm: 'h-10 px-4 text-sm min-h-[40px]',
    md: 'h-12 px-6 text-base min-h-[48px]',
    lg: 'h-14 px-8 text-lg min-h-[56px]'
  };

  return (
    <motion.button
      className={cn(
        'relative inline-flex items-center justify-center gap-2 rounded-2xl font-semibold',
        'touch-manipulation select-none overflow-hidden transition-all duration-200',
        'disabled:opacity-40 disabled:cursor-not-allowed',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50',
        variantClasses[variant],
        sizeClasses[size],
        fullWidth && 'w-full',
        className
      )}
      onClick={handleClick}
      disabled={disabled || loading}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      transition={{ duration: 0.15 }}
      type={props.type}
    >
      {loading && <Loader2 className="w-4 h-4 animate-spin" />}
      {!loading && children}
      
      {/* Ripple effects */}
      {ripples.map(ripple => (
        <motion.span
          key={ripple.id}
          className="absolute rounded-full bg-white/30 pointer-events-none"
          style={{
            left: ripple.x,
            top: ripple.y,
            width: 0,
            height: 0,
          }}
          initial={{ width: 0, height: 0, opacity: 0.5 }}
          animate={{ width: 300, height: 300, opacity: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
        />
      ))}
    </motion.button>
  );
};

// ==================== MobileCardAllBlack ====================
interface MobileCardAllBlackProps {
  variant?: 'flat' | 'elevated' | 'neon';
  padding?: 'sm' | 'md' | 'lg';
  interactive?: boolean;
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

export const MobileCardAllBlack: React.FC<MobileCardAllBlackProps> = ({
  variant = 'flat',
  padding = 'md',
  interactive = false,
  children,
  className,
  onClick
}) => {
  const variantClasses = {
    flat: 'bg-black border border-line/10',
    elevated: 'bg-black border border-accent/10 shadow-[0_8px_32px_rgba(0,0,0,0.8),0_0_0_1px_rgba(55,160,244,0.1)]',
    neon: 'bg-black border border-accent/30 shadow-[0_0_40px_rgba(55,160,244,0.3),0_8px_24px_rgba(0,0,0,0.9)]'
  };

  const paddingClasses = {
    sm: 'p-3',
    md: 'p-4',
    lg: 'p-6'
  };

  return (
    <motion.div
      className={cn(
        'rounded-2xl transition-all duration-300',
        variantClasses[variant],
        paddingClasses[padding],
        interactive && 'cursor-pointer hover:border-accent/40 hover:shadow-[0_0_60px_rgba(55,160,244,0.4)]',
        className
      )}
      onClick={onClick}
      whileHover={interactive ? { scale: 1.01 } : undefined}
      whileTap={interactive ? { scale: 0.99 } : undefined}
    >
      {children}
    </motion.div>
  );
};

// ==================== MobileLayoutDark ====================
interface MobileLayoutDarkProps {
  children: React.ReactNode;
  variant?: 'default' | 'safe-area' | 'full-screen';
  maxWidth?: 'sm' | 'md' | 'lg' | 'full';
  className?: string;
}

export const MobileLayoutDark: React.FC<MobileLayoutDarkProps> = ({
  children,
  variant = 'default',
  maxWidth = 'lg',
  className
}) => {
  const maxWidthClasses = {
    sm: 'max-w-sm',
    md: 'max-w-md',
    lg: 'max-w-4xl',
    full: 'max-w-full'
  };

  const variantClasses = {
    'default': '',
    'safe-area': 'pt-safe pb-safe px-4',
    'full-screen': 'min-h-screen'
  };

  return (
    <div 
      className={cn(
        'w-full mx-auto bg-black',
        'overflow-x-hidden',
        '-webkit-overflow-scrolling-touch',
        maxWidthClasses[maxWidth],
        variantClasses[variant],
        className
      )}
    >
      {children}
    </div>
  );
};
