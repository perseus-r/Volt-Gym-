import { ReactNode } from 'react';
import { cn } from '@/lib/utils';
import { ThemedBackground } from '@/components/ios/ThemedBackground';
import { useIsMobile } from '@/hooks/use-mobile';

interface MobilePageLayoutProps {
  children: ReactNode;
  className?: string;
  noPadding?: boolean;
  intensity?: 'subtle' | 'medium' | 'strong';
  showGlow?: boolean;
}

export function MobilePageLayout({
  children, 
  className, 
  noPadding = false,
  intensity = 'subtle',
  showGlow = true,
}: MobilePageLayoutProps) {
  const isMobile = useIsMobile();

  if (!isMobile) {
    return (
      <ThemedBackground intensity={intensity} showGlow={showGlow} className={className}>
        {children}
      </ThemedBackground>
    );
  }

  return (
    <ThemedBackground 
      intensity={intensity} 
      showGlow={showGlow}
      className={cn("flex flex-col h-full", className)}
    >
      <div 
        className="flex-1 scroll-container"
        style={{
          paddingTop: 'env(safe-area-inset-top)',
          paddingBottom: 'calc(80px + env(safe-area-inset-bottom, 0px) + var(--ios-toolbar-bottom, 0px))',
        }}
      >
        {children}
      </div>
    </ThemedBackground>
  );
}
