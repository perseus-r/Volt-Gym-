import { ReactNode } from 'react';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

interface MobileCompactCardProps {
  children: ReactNode;
  onClick?: () => void;
  className?: string;
  variant?: 'default' | 'glass';
}

export function MobileCompactCard({ 
  children, 
  onClick,
  className,
  variant = 'default'
}: MobileCompactCardProps) {
  const Component = onClick ? motion.button : motion.div;

  return (
    <Component
      onClick={onClick}
      whileTap={onClick ? { scale: 0.98 } : undefined}
      className={cn(
        "rounded-2xl overflow-hidden text-left w-full",
        variant === 'default' && "bg-card border border-border/50",
        variant === 'glass' && "bg-card/50 backdrop-blur-sm border border-border/30",
        onClick && "active:bg-muted/50 transition-colors",
        className
      )}
    >
      {children}
    </Component>
  );
}
