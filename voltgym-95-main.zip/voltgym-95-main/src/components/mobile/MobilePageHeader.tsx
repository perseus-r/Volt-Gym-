import { ReactNode } from 'react';
import { ChevronLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';
import { usePageTheme } from '@/hooks/usePageTheme';

interface MobilePageHeaderProps {
  title: string;
  subtitle?: string;
  showBack?: boolean;
  actions?: ReactNode;
  className?: string;
  compact?: boolean;
}

export function MobilePageHeader({ 
  title, 
  subtitle, 
  showBack = false, 
  actions,
  className,
  compact = false
}: MobilePageHeaderProps) {
  const navigate = useNavigate();
  const { theme, primaryColor } = usePageTheme();

  return (
    <motion.header 
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "sticky top-0 z-40 backdrop-blur-xl",
        "pt-2 pb-3",
        "-mx-4 px-4", // Extend to edges
        className
      )}
      style={{
        background: 'rgba(0, 0, 0, 0.6)',
      }}
    >
      {/* Themed glow behind header */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `radial-gradient(ellipse at center top, ${theme.glow} 0%, transparent 70%)`,
          opacity: 0.3,
        }}
      />

      {/* Top row with back button and actions */}
      {(showBack || actions) && (
        <div className="relative flex items-center justify-between mb-1">
          {showBack ? (
            <button 
              onClick={() => navigate(-1)}
              className="flex items-center gap-1 -ml-1 p-1 active:scale-95 transition-all"
              style={{ color: primaryColor }}
            >
              <ChevronLeft className="w-5 h-5" />
              <span className="text-sm">Voltar</span>
            </button>
          ) : (
            <div />
          )}
          {actions && <div className="flex items-center gap-2">{actions}</div>}
        </div>
      )}

      {/* Large title - COMPACT */}
      <div className="relative">
        <h1 className={cn(
          "font-bold text-foreground tracking-tight",
          compact ? "text-lg" : "text-xl"
        )}>
          {title}
        </h1>
        {subtitle && (
          <p 
            className="text-xs mt-0.5 font-medium"
            style={{ color: primaryColor }}
          >
            {subtitle}
          </p>
        )}
      </div>
    </motion.header>
  );
}
