import React, { useRef, useState } from 'react';
import { motion, PanInfo, useMotionValue, useTransform } from 'framer-motion';
import { Trash2, Star, Archive, Edit, MoreHorizontal } from 'lucide-react';
import { cn } from '@/lib/utils';
import { haptic } from '@/utils/haptics';

export type SwipeAction = 'delete' | 'favorite' | 'archive' | 'edit' | 'more';

interface SwipeActionConfig {
  type: SwipeAction;
  icon: React.ElementType;
  color: string;
  backgroundColor: string;
  label: string;
  onAction: () => void | Promise<void>;
}

interface SwipeableCardProps {
  children: React.ReactNode;
  leftActions?: SwipeActionConfig[];
  rightActions?: SwipeActionConfig[];
  threshold?: number;
  className?: string;
  disabled?: boolean;
}

export function SwipeableCard({
  children,
  leftActions = [],
  rightActions = [],
  threshold = 80,
  className,
  disabled = false,
}: SwipeableCardProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [activeAction, setActiveAction] = useState<SwipeActionConfig | null>(null);
  const x = useMotionValue(0);
  const containerRef = useRef<HTMLDivElement>(null);

  // Transform swipe distance to action visibility
  const leftActionOpacity = useTransform(x, [0, threshold], [0, 1]);
  const rightActionOpacity = useTransform(x, [-threshold, 0], [1, 0]);

  const handlePanStart = () => {
    if (disabled) return;
    setIsDragging(true);
    haptic.soft();
  };

  const handlePan = (event: any, info: PanInfo) => {
    if (disabled) return;

    const offset = info.offset.x;
    const maxSwipe = threshold * 2;

    // Limit swipe distance
    const constrainedOffset = Math.max(-maxSwipe, Math.min(maxSwipe, offset));
    x.set(constrainedOffset);

    // Determine active action
    if (Math.abs(offset) >= threshold) {
      const actions = offset > 0 ? leftActions : rightActions;
      const actionIndex = Math.floor((Math.abs(offset) - threshold) / 80);
      const action = actions[Math.min(actionIndex, actions.length - 1)];

      if (action && action !== activeAction) {
        setActiveAction(action);
        haptic.light();
      }
    } else {
      if (activeAction) {
        setActiveAction(null);
      }
    }
  };

  const handlePanEnd = async (event: any, info: PanInfo) => {
    if (disabled) {
      x.set(0);
      setIsDragging(false);
      return;
    }

    setIsDragging(false);

    const offset = info.offset.x;

    // Check if threshold was reached and action exists
    if (Math.abs(offset) >= threshold && activeAction) {
      // Execute action
      haptic.medium();

      try {
        await activeAction.onAction();
        haptic.success();
      } catch (error) {
        console.error('Swipe action failed:', error);
        haptic.error();
      }
    }

    // Reset
    setActiveAction(null);
    x.set(0);
  };

  return (
    <div className={cn('relative overflow-hidden', className)} ref={containerRef}>
      {/* Left Actions */}
      {leftActions.length > 0 && (
        <motion.div
          className="absolute inset-y-0 left-0 flex items-center"
          style={{ opacity: leftActionOpacity }}
        >
          {leftActions.map((action, index) => (
            <motion.div
              key={action.type}
              className={cn(
                'h-full flex items-center justify-center px-6',
                'transition-colors duration-200'
              )}
              style={{
                backgroundColor: action.backgroundColor,
              }}
              animate={{
                x: Math.max(0, x.get() - index * 80),
              }}
            >
              <div className="flex flex-col items-center gap-1">
                <action.icon className="w-5 h-5" style={{ color: action.color }} />
                <span className="text-xs font-medium" style={{ color: action.color }}>
                  {action.label}
                </span>
              </div>
            </motion.div>
          ))}
        </motion.div>
      )}

      {/* Right Actions */}
      {rightActions.length > 0 && (
        <motion.div
          className="absolute inset-y-0 right-0 flex items-center flex-row-reverse"
          style={{ opacity: rightActionOpacity }}
        >
          {rightActions.map((action, index) => (
            <motion.div
              key={action.type}
              className={cn(
                'h-full flex items-center justify-center px-6',
                'transition-colors duration-200'
              )}
              style={{
                backgroundColor: action.backgroundColor,
              }}
              animate={{
                x: Math.min(0, x.get() + index * 80),
              }}
            >
              <div className="flex flex-col items-center gap-1">
                <action.icon className="w-5 h-5" style={{ color: action.color }} />
                <span className="text-xs font-medium" style={{ color: action.color }}>
                  {action.label}
                </span>
              </div>
            </motion.div>
          ))}
        </motion.div>
      )}

      {/* Card Content */}
      <motion.div
        drag="x"
        dragConstraints={{ left: 0, right: 0 }}
        dragElastic={0.2}
        onPanStart={handlePanStart}
        onPan={handlePan}
        onPanEnd={handlePanEnd}
        style={{ x }}
        className={cn(
          'relative z-10 bg-surface/80 backdrop-blur-sm',
          isDragging && 'cursor-grabbing'
        )}
      >
        {children}
      </motion.div>

      {/* Visual threshold indicator */}
      {isDragging && Math.abs(x.get()) >= threshold && (
        <motion.div
          className="absolute inset-0 pointer-events-none border-2 rounded-custom"
          style={{
            borderColor: activeAction?.color || 'hsl(var(--accent))',
          }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        />
      )}
    </div>
  );
}

// Preset action configurations
export const swipeActions = {
  delete: (onDelete: () => void | Promise<void>): SwipeActionConfig => ({
    type: 'delete',
    icon: Trash2,
    color: '#fff',
    backgroundColor: 'hsl(var(--error))',
    label: 'Excluir',
    onAction: onDelete,
  }),

  favorite: (onFavorite: () => void | Promise<void>): SwipeActionConfig => ({
    type: 'favorite',
    icon: Star,
    color: '#fff',
    backgroundColor: 'hsl(var(--warning))',
    label: 'Favoritar',
    onAction: onFavorite,
  }),

  archive: (onArchive: () => void | Promise<void>): SwipeActionConfig => ({
    type: 'archive',
    icon: Archive,
    color: '#fff',
    backgroundColor: 'hsl(var(--txt-3))',
    label: 'Arquivar',
    onAction: onArchive,
  }),

  edit: (onEdit: () => void | Promise<void>): SwipeActionConfig => ({
    type: 'edit',
    icon: Edit,
    color: '#fff',
    backgroundColor: 'hsl(var(--accent))',
    label: 'Editar',
    onAction: onEdit,
  }),

  more: (onMore: () => void | Promise<void>): SwipeActionConfig => ({
    type: 'more',
    icon: MoreHorizontal,
    color: '#fff',
    backgroundColor: 'hsl(var(--accent-2))',
    label: 'Mais',
    onAction: onMore,
  }),
};
