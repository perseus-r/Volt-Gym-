import React, { useState, useRef, useCallback } from 'react';
import { motion, useMotionValue, useTransform, PanInfo } from 'framer-motion';
import { RefreshCw, Check } from 'lucide-react';
import { cn } from '@/lib/utils';
import { haptic } from '@/utils/haptics';
import confetti from 'canvas-confetti';

interface PremiumPullToRefreshProps {
  onRefresh: () => Promise<void>;
  children: React.ReactNode;
  threshold?: number;
  className?: string;
  disabled?: boolean;
}

export function PremiumPullToRefresh({
  onRefresh,
  children,
  threshold = 80,
  className,
  disabled = false,
}: PremiumPullToRefreshProps) {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [refreshSuccess, setRefreshSuccess] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const y = useMotionValue(0);
  const [isPulling, setIsPulling] = useState(false);

  // Transform pull distance to indicator size
  const indicatorScale = useTransform(y, [0, threshold], [0, 1]);
  const indicatorOpacity = useTransform(y, [0, threshold / 2, threshold], [0, 0.5, 1]);
  const indicatorRotation = useTransform(y, [0, threshold], [0, 360]);

  const handlePanStart = () => {
    if (disabled || isRefreshing) return;
    
    // Only allow pull to refresh if already at the top
    const scrollTop = containerRef.current?.scrollTop || 0;
    if (scrollTop === 0) {
      setIsPulling(true);
      haptic.soft();
    }
  };

  const handlePan = (event: any, info: PanInfo) => {
    if (disabled || isRefreshing || !isPulling) return;

    const scrollTop = containerRef.current?.scrollTop || 0;
    if (scrollTop > 0) {
      setIsPulling(false);
      y.set(0);
      return;
    }

    // Only pull down (positive Y)
    if (info.offset.y > 0) {
      y.set(Math.min(info.offset.y, threshold * 1.5));

      // Haptic feedback at threshold
      if (info.offset.y >= threshold && info.offset.y < threshold + 5) {
        haptic.medium();
      }
    }
  };

  const handlePanEnd = async (event: any, info: PanInfo) => {
    if (disabled || !isPulling) {
      y.set(0);
      setIsPulling(false);
      return;
    }

    setIsPulling(false);

    // Check if threshold was reached
    if (info.offset.y >= threshold) {
      setIsRefreshing(true);
      haptic.heavy();

      try {
        await onRefresh();
        
        // Success feedback
        setRefreshSuccess(true);
        haptic.success();
        
        // Confetti celebration
        confetti({
          particleCount: 30,
          spread: 60,
          origin: { y: 0.1 },
          colors: ['#37A0F4', '#38BDF8', '#60A5FA'],
        });

        // Hold success state briefly
        await new Promise(resolve => setTimeout(resolve, 800));
      } catch (error) {
        // Error is handled by haptic feedback
        haptic.error();
      } finally {
        setRefreshSuccess(false);
        setIsRefreshing(false);
      }
    }

    // Animate back to 0
    y.set(0);
  };

  return (
    <div className={cn('relative overflow-hidden', className)} ref={containerRef}>
      {/* Pull to Refresh Indicator */}
      <motion.div
        className="absolute top-0 left-0 right-0 z-50 flex items-center justify-center pointer-events-none"
        style={{
          height: y,
        }}
      >
        <motion.div
          className="flex flex-col items-center gap-2"
          style={{
            scale: indicatorScale,
            opacity: indicatorOpacity,
          }}
        >
          {/* Circular Progress Ring */}
          <div className="relative">
            <svg className="w-12 h-12" viewBox="0 0 48 48">
              {/* Background circle */}
              <circle
                cx="24"
                cy="24"
                r="20"
                fill="none"
                stroke="hsl(var(--line))"
                strokeWidth="3"
                opacity="0.3"
              />
              {/* Progress circle */}
              <motion.circle
                cx="24"
                cy="24"
                r="20"
                fill="none"
                stroke="hsl(var(--accent))"
                strokeWidth="3"
                strokeLinecap="round"
                strokeDasharray="125.6"
                strokeDashoffset={125.6 * (1 - Math.min(y.get() / threshold, 1))}
                style={{
                  filter: 'drop-shadow(0 0 8px hsl(var(--accent) / 0.5))',
                }}
                className="origin-center -rotate-90"
              />
            </svg>

            {/* Icon in center */}
            <div className="absolute inset-0 flex items-center justify-center">
              {refreshSuccess ? (
                <motion.div
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ type: 'spring', stiffness: 300, damping: 20 }}
                >
                  <Check className="w-6 h-6 text-success" strokeWidth={3} />
                </motion.div>
              ) : isRefreshing ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                >
                  <RefreshCw className="w-6 h-6 text-accent" />
                </motion.div>
              ) : (
                <motion.div style={{ rotate: indicatorRotation }}>
                  <RefreshCw className="w-6 h-6 text-accent" />
                </motion.div>
              )}
            </div>
          </div>

          {/* Status Text */}
          <motion.p
            className="text-xs font-medium text-txt-2"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            {refreshSuccess
              ? 'Atualizado!'
              : isRefreshing
              ? 'Atualizando...'
              : y.get() >= threshold
              ? 'Solte para atualizar'
              : 'Puxe para atualizar'}
          </motion.p>
        </motion.div>
      </motion.div>

      {/* Content with pan gesture */}
      <motion.div
        onPanStart={handlePanStart}
        onPan={handlePan}
        onPanEnd={handlePanEnd}
        style={{
          y: isRefreshing ? threshold : y,
        }}
        transition={{
          type: 'spring',
          stiffness: 300,
          damping: 30,
        }}
      >
        {children}
      </motion.div>

      {/* Elastic Background Effect */}
      <motion.div
        className="absolute top-0 left-0 right-0 bg-gradient-to-b from-accent/10 to-transparent pointer-events-none"
        style={{
          height: y,
          opacity: indicatorOpacity,
        }}
      />
    </div>
  );
}

// Simplified hook version for easier integration
export function usePullToRefresh(onRefresh: () => Promise<void>) {
  const [isRefreshing, setIsRefreshing] = useState(false);

  const refresh = useCallback(async () => {
    if (isRefreshing) return;
    
    setIsRefreshing(true);
    haptic.heavy();
    
    try {
      await onRefresh();
      haptic.success();
    } catch (error) {
      haptic.error();
      throw error;
    } finally {
      setIsRefreshing(false);
    }
  }, [onRefresh, isRefreshing]);

  return { isRefreshing, refresh };
}
