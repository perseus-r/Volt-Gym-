import React, { ReactNode } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useIsMobile } from '@/hooks/use-mobile';
import { VoltCard } from '@/components/VoltCard';
import { haptic } from '@/utils/haptics';
import { Button } from '@/components/ui/button';

// ==================== MobileContainer ====================
interface MobileContainerProps {
  children: ReactNode;
  variant?: 'default' | 'safe-area' | 'full-bleed';
  padding?: 'none' | 'sm' | 'md' | 'lg';
  className?: string;
}

export function MobileContainer({ 
  children, 
  variant = 'default',
  padding = 'md',
  className 
}: MobileContainerProps) {
  const isMobile = useIsMobile();
  
  const paddingClasses = {
    none: '',
    sm: 'px-3 py-4',
    md: 'px-4 py-6',
    lg: 'px-6 py-8'
  };
  
  const variantClasses = {
    'default': paddingClasses[padding],
    'safe-area': cn(
      paddingClasses[padding],
      'pb-[calc(var(--mobile-space-2xl)+env(safe-area-inset-bottom))]'
    ),
    'full-bleed': 'p-0'
  };

  if (!isMobile) {
    return <div className={className}>{children}</div>;
  }

  return (
    <div className={cn('mobile-container', variantClasses[variant], className)}>
      {children}
    </div>
  );
}

// ==================== MobileCard ====================
interface MobileCardProps {
  children: ReactNode;
  variant?: 'glass' | 'solid' | 'premium';
  interactive?: boolean;
  haptic?: boolean;
  onClick?: () => void;
  className?: string;
}

export function MobileCard({ 
  children, 
  variant = 'glass',
  interactive = false,
  haptic: enableHaptic = false,
  onClick,
  className 
}: MobileCardProps) {
  const isMobile = useIsMobile();

  const handleClick = () => {
    if (enableHaptic) haptic.light();
    onClick?.();
  };

  if (!isMobile) {
    return (
      <VoltCard 
        variant={variant} 
        interactive={interactive}
        onClick={handleClick}
        className={className}
      >
        {children}
      </VoltCard>
    );
  }

  return (
    <VoltCard 
      variant={variant}
      interactive={interactive}
      hover={interactive}
      onClick={handleClick}
      className={cn('mobile-card', className)}
    >
      {children}
    </VoltCard>
  );
}

// ==================== MobileSection ====================
interface MobileSectionProps {
  children: ReactNode;
  title?: string;
  subtitle?: string;
  icon?: ReactNode;
  action?: ReactNode;
  className?: string;
}

export function MobileSection({ 
  children, 
  title, 
  subtitle,
  icon,
  action,
  className 
}: MobileSectionProps) {
  const isMobile = useIsMobile();

  return (
    <section className={cn('mobile-section', className)}>
      {(title || subtitle || action) && (
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-2 flex-1">
            {icon && <div className="flex-shrink-0">{icon}</div>}
            <div className="flex-1 min-w-0">
              {title && (
                <h2 className={isMobile ? 'mobile-h2 text-txt' : 'text-2xl font-bold text-txt'}>
                  {title}
                </h2>
              )}
              {subtitle && (
                <p className={cn(
                  isMobile ? 'mobile-caption text-txt-2 mt-1' : 'text-sm text-txt-2 mt-1'
                )}>
                  {subtitle}
                </p>
              )}
            </div>
          </div>
          {action && <div className="ml-4 flex-shrink-0">{action}</div>}
        </div>
      )}
      {children}
    </section>
  );
}

// ==================== MobileGrid ====================
interface MobileGridProps {
  children: ReactNode;
  cols?: 2 | 3 | 4;
  gap?: 'sm' | 'md' | 'lg';
  stagger?: boolean;
  className?: string;
}

export function MobileGrid({ 
  children, 
  cols = 2,
  gap = 'md',
  stagger = false,
  className 
}: MobileGridProps) {
  const isMobile = useIsMobile();

  const gapClasses = {
    sm: 'gap-2',
    md: 'gap-3',
    lg: 'gap-4'
  };

  const colClasses = {
    2: 'grid-cols-2',
    3: 'grid-cols-3',
    4: 'grid-cols-2 md:grid-cols-4'
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.08,
        delayChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20, scale: 0.95 },
    visible: { 
      opacity: 1, 
      y: 0, 
      scale: 1,
      transition: {
        type: "spring" as const,
        stiffness: 100,
        damping: 15
      }
    }
  };

  if (!stagger || !isMobile) {
    return (
      <div className={cn('grid', colClasses[cols], gapClasses[gap], className)}>
        {children}
      </div>
    );
  }

  return (
    <motion.div
      className={cn('grid', colClasses[cols], gapClasses[gap], className)}
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {React.Children.map(children, (child, index) => (
        <motion.div key={index} variants={itemVariants}>
          {child}
        </motion.div>
      ))}
    </motion.div>
  );
}

// ==================== MobileHeader ====================
interface MobileHeaderProps {
  title: string;
  subtitle?: string;
  backButton?: boolean;
  actions?: ReactNode;
  className?: string;
}

export function MobileHeader({ 
  title, 
  subtitle, 
  backButton = false,
  actions,
  className 
}: MobileHeaderProps) {
  const navigate = useNavigate();
  const isMobile = useIsMobile();

  const handleBack = () => {
    haptic.light();
    navigate(-1);
  };

  if (!isMobile) {
    return (
      <div className={cn('mb-6', className)}>
        <div className="flex items-center justify-between">
          {backButton && (
            <Button variant="ghost" onClick={handleBack} className="mr-2">
              <ChevronLeft className="w-5 h-5" />
            </Button>
          )}
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-txt">{title}</h1>
            {subtitle && <p className="text-txt-2 mt-1">{subtitle}</p>}
          </div>
          {actions}
        </div>
      </div>
    );
  }

  return (
    <motion.div 
      className={cn('mobile-header sticky top-0 z-20 bg-bg/80 backdrop-blur-xl border-b border-white/10 -mx-4 px-4 py-3 mb-6', className)}
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
    >
      <div className="flex items-center justify-between">
        {backButton && (
          <MobileTouchTarget haptic onClick={handleBack}>
            <motion.button
              whileTap={{ scale: 0.9 }}
              className="p-2 rounded-xl glass-button mr-2"
            >
              <ChevronLeft className="w-5 h-5 text-txt" />
            </motion.button>
          </MobileTouchTarget>
        )}
        <div className="flex-1 min-w-0">
          <h1 className="mobile-h2 text-txt truncate">{title}</h1>
          {subtitle && <p className="mobile-caption text-txt-2 truncate">{subtitle}</p>}
        </div>
        {actions && <div className="ml-2">{actions}</div>}
      </div>
    </motion.div>
  );
}

// ==================== MobileTouchTarget ====================
interface MobileTouchTargetProps {
  children: ReactNode;
  minSize?: number;
  haptic?: boolean;
  ripple?: boolean;
  onClick?: () => void;
  className?: string;
}

export function MobileTouchTarget({ 
  children, 
  minSize = 44,
  haptic: enableHaptic = false,
  ripple = false,
  onClick,
  className 
}: MobileTouchTargetProps) {
  const isMobile = useIsMobile();

  const handleClick = () => {
    if (enableHaptic) haptic.light();
    onClick?.();
  };

  if (!isMobile) {
    return <div onClick={handleClick} className={className}>{children}</div>;
  }

  return (
    <motion.div
      whileTap={{ scale: 0.95 }}
      onClick={handleClick}
      className={cn('mobile-touch-target', className)}
      style={{ minWidth: minSize, minHeight: minSize }}
    >
      {children}
    </motion.div>
  );
}

// ==================== MobileBottomSheet ====================
interface MobileBottomSheetProps {
  children: ReactNode;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  snapPoints?: number[];
  modal?: boolean;
  className?: string;
}

export function MobileBottomSheet({ 
  children, 
  open,
  onOpenChange,
  snapPoints = [0.5, 0.9],
  modal = true,
  className 
}: MobileBottomSheetProps) {
  const isMobile = useIsMobile();

  const handleClose = () => {
    haptic.light();
    onOpenChange(false);
  };

  if (!isMobile) {
    return (
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
            onClick={handleClose}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className={cn('glass-ultra rounded-3xl p-6 max-w-lg w-full max-h-[80vh] overflow-y-auto', className)}
            >
              {children}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    );
  }

  return (
    <AnimatePresence>
      {open && (
        <>
          {modal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={handleClose}
              className="fixed inset-0 bg-black/50 z-40"
            />
          )}
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0, bottom: 0.5 }}
            onDragEnd={(e, info) => {
              if (info.offset.y > 100) {
                handleClose();
              }
            }}
            className={cn(
              'fixed bottom-0 left-0 right-0 z-50',
              'glass-ultra rounded-t-3xl',
              'max-h-[90vh] overflow-y-auto',
              'pb-[env(safe-area-inset-bottom)]',
              className
            )}
          >
            {/* Drag Handle */}
            <div className="sticky top-0 z-10 pt-4 pb-2 bg-bg/80 backdrop-blur-xl">
              <div className="w-12 h-1.5 bg-txt-2/30 rounded-full mx-auto" />
            </div>
            
            <div className="px-4 pb-6">
              {children}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

// ==================== MobilePullToRefresh ====================
interface MobilePullToRefreshProps {
  children: ReactNode;
  onRefresh: () => Promise<void>;
  enabled?: boolean;
  threshold?: number;
  className?: string;
}

export function MobilePullToRefresh({ 
  children, 
  onRefresh,
  enabled = true,
  threshold = 80,
  className 
}: MobilePullToRefreshProps) {
  const [isRefreshing, setIsRefreshing] = React.useState(false);
  const [pullDistance, setPullDistance] = React.useState(0);
  const isMobile = useIsMobile();

  const handleTouchStart = (e: React.TouchEvent) => {
    if (!enabled || !isMobile || window.scrollY > 0) return;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!enabled || !isMobile || window.scrollY > 0) return;
    
    const touch = e.touches[0];
    const distance = Math.max(0, touch.clientY - 60);
    setPullDistance(Math.min(distance, threshold * 1.5));
  };

  const handleTouchEnd = async () => {
    if (!enabled || !isMobile) return;
    
    if (pullDistance >= threshold && !isRefreshing) {
      setIsRefreshing(true);
      haptic.medium();
      try {
        await onRefresh();
      } finally {
        setIsRefreshing(false);
        setPullDistance(0);
      }
    } else {
      setPullDistance(0);
    }
  };

  if (!enabled || !isMobile) {
    return <div className={className}>{children}</div>;
  }

  const progress = Math.min(pullDistance / threshold, 1);

  return (
    <div
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      className={cn('relative', className)}
    >
      {/* Pull Indicator */}
      <AnimatePresence>
        {(pullDistance > 0 || isRefreshing) && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-0 left-0 right-0 flex justify-center pt-4 z-10"
          >
            <div className="glass-ultra rounded-full p-3">
              <motion.div
                animate={{ rotate: isRefreshing ? 360 : progress * 360 }}
                transition={{ 
                  duration: isRefreshing ? 1 : 0,
                  repeat: isRefreshing ? Infinity : 0,
                  ease: 'linear'
                }}
                className="w-6 h-6 border-2 border-accent border-t-transparent rounded-full"
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div
        animate={{ y: isRefreshing ? 60 : pullDistance * 0.5 }}
        transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      >
        {children}
      </motion.div>
    </div>
  );
}
