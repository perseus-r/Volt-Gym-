import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface VoltButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'ghost' | 'warning' | 'outline' | 'gradient';
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  onClick?: () => void;
  disabled?: boolean;
  loading?: boolean;
}

export function VoltButton({ 
  children, 
  variant = 'primary',
  size = 'md',
  className,
  onClick,
  disabled = false,
  loading = false
}: VoltButtonProps) {
  const buttonVariants = {
    initial: { scale: 1 },
    hover: { scale: 1.02, y: -1 },
    tap: { scale: 0.98 },
  };

  const variants = {
    primary: "bg-gradient-to-r from-accent via-accent-2 to-accent text-accent-ink font-bold shadow-xl shadow-accent/40 hover:shadow-2xl hover:shadow-accent/60 bg-[length:200%_100%] hover:bg-[position:100%_0]",
    secondary: "glass-ultra text-txt border border-white/10 hover:border-white/20 hover:glass-intense backdrop-blur-xl font-semibold",
    ghost: "text-txt-2 hover:text-txt hover:bg-white/10 backdrop-blur-sm font-semibold",
    warning: "bg-gradient-to-r from-orange-500 to-orange-600 text-white font-bold shadow-xl shadow-orange-500/40 hover:shadow-2xl hover:shadow-orange-500/60",
    outline: "border-2 border-accent text-accent hover:bg-accent/10 hover:border-accent-2 font-bold backdrop-blur-sm",
    gradient: "bg-gradient-to-r from-accent via-purple-500 to-accent-2 text-white font-bold shadow-xl shadow-accent/40 hover:shadow-2xl hover:shadow-purple-500/50",
  };

  const sizes = {
    xs: "px-3 py-1.5 text-xs rounded-lg",
    sm: "px-4 py-2 text-sm rounded-xl",
    md: "px-6 py-3 text-base rounded-xl",
    lg: "px-8 py-4 text-lg rounded-2xl",
    xl: "px-10 py-5 text-xl rounded-2xl",
  };

  return (
    <motion.button
      variants={buttonVariants}
      initial="initial"
      whileHover={!disabled ? "hover" : "initial"}
      whileTap={!disabled ? "tap" : "initial"}
      transition={{ 
        duration: 0.2,
        ease: [0.25, 0.46, 0.45, 0.94]
      }}
      onClick={onClick}
      disabled={disabled || loading}
      className={cn(
        // Base styles
        "relative inline-flex items-center justify-center gap-2 overflow-hidden",
        "font-medium tracking-wide",
        "transition-all duration-300 ease-out",
        "disabled:opacity-50 disabled:cursor-not-allowed",
        "active:scale-95",
        
        // Variant styles
        variants[variant],
        
        // Size styles
        sizes[size],
        
        className
      )}
    >
      {/* Shimmer effect for primary/gradient buttons */}
      {(variant === 'primary' || variant === 'gradient') && !disabled && !loading && (
        <motion.div
          className="absolute inset-0 -translate-x-full"
          animate={{
            translateX: ['100%', '-100%']
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            repeatDelay: 2,
            ease: "linear"
          }}
          style={{
            background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent)'
          }}
        />
      )}

      {/* Ripple effect on tap */}
      <motion.div
        className="absolute inset-0 bg-white/20 rounded-inherit"
        initial={{ scale: 0, opacity: 0.5 }}
        whileTap={{ scale: 2, opacity: 0 }}
        transition={{ duration: 0.4 }}
      />

      {loading ? (
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin" />
          <span className="relative z-10">Carregando...</span>
        </div>
      ) : (
        <span className="relative z-10 flex items-center gap-2">{children}</span>
      )}
    </motion.button>
  );
}