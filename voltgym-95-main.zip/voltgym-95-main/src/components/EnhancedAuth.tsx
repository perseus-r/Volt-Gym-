import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useProfileCheck } from '@/hooks/useProfileCheck';
import { toast } from 'sonner';
import { Eye, EyeOff, UserPlus, LogIn, Zap, Shield, Sparkles } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { AuthSkeleton } from './auth/AuthSkeleton';
import { IPhoneCard } from './ui/iphone-card';
import { IPhoneButton } from './ui/iphone-button';
import { IPhoneInput } from './ui/iphone-input';

const EnhancedAuth = () => {
  const [searchParams] = useSearchParams();
  const accountType = searchParams.get('type');
  
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [phone, setPhone] = useState('');
  const [brandName, setBrandName] = useState('');
  const [specialization, setSpecialization] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [setupRunning, setSetupRunning] = useState(false);
  
  const { signIn, signUp, user, loading: authLoading } = useAuth();
  const { profileComplete, loading: profileLoading } = useProfileCheck();
  const navigate = useNavigate();

  useEffect(() => {
    if (authLoading || profileLoading || setupRunning) return;
    
    if (user) {
      const pendingToken = sessionStorage.getItem('pending_invite_token');
      if (pendingToken) {
        sessionStorage.removeItem('pending_invite_token');
        navigate(`/invite?token=${pendingToken}`);
        return;
      }
      
      if (isLogin || !accountType) {
        navigate('/dashboard');
      }
    }
  }, [user, authLoading, profileLoading, navigate, isLogin, accountType, setupRunning]);

  const setupPTAccount = async (userId: string) => {
    setSetupRunning(true);
    try {
      const { data, error } = await supabase.functions.invoke('setup-pt-account', {
        body: { userId, brandName, specialization }
      });

      if (error) throw error;
      
      toast.success(data.message);
      navigate(data.redirect);
    } catch (err: any) {
      toast.error(err.message || 'Erro ao configurar conta PT');
      navigate('/pt/onboarding');
    } finally {
      setSetupRunning(false);
    }
  };

  const setupAthleteAccount = async (userId: string) => {
    setSetupRunning(true);
    try {
      const { data, error } = await supabase.functions.invoke('setup-athlete-account', {
        body: { userId }
      });

      if (error) throw error;
      
      toast.success(data.message);
      navigate(data.redirect);
    } catch (err: any) {
      toast.error(err.message || 'Erro ao configurar conta');
      navigate('/onboarding');
    } finally {
      setSetupRunning(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      let result;
      
      if (isLogin) {
        result = await signIn(email, password);
      } else {
        if (!displayName.trim()) {
          toast.error('Por favor, insira seu nome completo.');
          setLoading(false);
          return;
        }
        if (!phone.trim()) {
          toast.error('Por favor, insira seu número de telefone.');
          setLoading(false);
          return;
        }
        if (accountType === 'pt' && !brandName.trim()) {
          toast.error('Por favor, insira o nome da sua marca.');
          setLoading(false);
          return;
        }
        if (accountType === 'pt' && !specialization) {
          toast.error('Por favor, selecione sua especialidade.');
          setLoading(false);
          return;
        }
        
        result = await signUp(email, password, displayName, phone);
      }

      if (result.error) {
        let errorMessage = "Erro desconhecido";
        
        if (result.error.message.includes('Invalid login credentials')) {
          errorMessage = "Email ou senha incorretos";
        } else if (result.error.message.includes('User already registered')) {
          errorMessage = "Este email já está cadastrado. Tente fazer login.";
        } else if (result.error.message.includes('Password should be at least 6 characters')) {
          errorMessage = "A senha deve ter pelo menos 6 caracteres";
        } else if (result.error.message.includes('Invalid email')) {
          errorMessage = "Email inválido";
        } else if (result.error.message.includes('captcha verification process failed')) {
          errorMessage = "Falha na verificação de segurança. Tente novamente.";
        } else if (result.error.message.includes('email_not_confirmed')) {
          errorMessage = "Confirme seu email antes de fazer login. Verifique sua caixa de entrada.";
        }

        toast.error(errorMessage);
      } else if (!isLogin) {
        toast.success('⚡ Conta criada com sucesso!');
        
        const { data: { user: currentUser } } = await supabase.auth.getUser();
        if (currentUser) {
          if (accountType === 'pt') {
            await setupPTAccount(currentUser.id);
          } else if (accountType === 'independent') {
            await setupAthleteAccount(currentUser.id);
          } else {
            navigate('/onboarding');
          }
        }
      } else {
        toast.success('⚡ Login realizado! Bem-vindo de volta ao VOLT!');
      }
    } catch (error) {
      toast.error('Algo deu errado. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  if (authLoading || profileLoading) {
    return <AuthSkeleton />;
  }

  return (
    <div className="min-h-screen relative overflow-hidden flex items-center justify-center p-4">
      {/* Simplified gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-background to-primary/5" />
      
      {/* Optimized gradient orbs - reduced blur */}
      <div className="absolute top-20 -left-20 w-80 h-80 rounded-full bg-primary/10 blur-[40px]" />
      <div className="absolute bottom-20 -right-20 w-80 h-80 rounded-full bg-blue-500/8 blur-[40px]" />

      {/* Main card with CSS animation instead of framer-motion */}
      <div className="w-full max-w-md relative z-10 animate-auth-fade-in">
        <IPhoneCard 
          variant="widget" 
          size="lg" 
          glow
          static
          className="p-8 backdrop-blur-md border-border/40"
        >
          {/* Static shine effect */}
          <div className="absolute inset-0 rounded-[24px] bg-gradient-to-tr from-white/0 via-white/[0.03] to-white/0" />

          {/* Logo section - static, no animations */}
          <div className="text-center mb-8 relative animate-auth-slide-down">
            {/* Premium logo container - static */}
            <div className="w-24 h-24 mx-auto mb-6 relative">
              {/* Outer glow ring - static */}
              <div className="absolute inset-0 rounded-[28px] bg-gradient-to-br from-primary via-primary/50 to-blue-500 blur-xl opacity-40" />
              
              {/* Main logo container */}
              <div className="relative w-full h-full rounded-[28px] bg-gradient-to-br from-primary via-primary to-blue-600 flex items-center justify-center shadow-2xl shadow-primary/30 overflow-hidden">
                {/* Inner shine */}
                <div className="absolute inset-0 bg-gradient-to-tr from-white/20 via-transparent to-transparent" />
                
                <Zap className="w-12 h-12 text-primary-foreground relative z-10 drop-shadow-lg" strokeWidth={2.5} />
              </div>
              
              {/* Static sparkle decoration */}
              <div className="absolute -top-2 -right-2">
                <Sparkles className="w-5 h-5 text-yellow-400" />
              </div>
            </div>
            
            {/* Brand name - static gradient */}
            <h1 className="text-4xl font-black tracking-tight mb-2">
              <span className="bg-gradient-to-r from-primary via-blue-500 to-primary bg-clip-text text-transparent">
                VOLT
              </span>
            </h1>
            
            <p className="text-muted-foreground text-sm">
              {isLogin 
                ? 'Bem-vindo de volta, campeão!' 
                : accountType === 'pt' 
                  ? 'Configure sua conta de Personal Trainer'
                  : accountType === 'independent'
                    ? 'Treine de forma independente com IA'
                    : 'Junte-se aos campeões'
              }
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Signup fields with CSS transition */}
            {!isLogin && (
              <div className="space-y-3 animate-auth-slide-down">
                <IPhoneInput
                  placeholder="Nome de atleta"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                />
                <IPhoneInput
                  placeholder="WhatsApp para suporte"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  type="tel"
                />
                
                {accountType === 'pt' && (
                  <>
                    <IPhoneInput
                      placeholder="Nome da sua marca (ex: FitCoach Pro)"
                      value={brandName}
                      onChange={(e) => setBrandName(e.target.value)}
                    />
                    <select
                      value={specialization}
                      onChange={(e) => setSpecialization(e.target.value)}
                      className="w-full px-4 py-4 bg-muted/50 border border-border/50 rounded-2xl text-foreground transition-all focus:outline-none focus:border-primary/50 focus:bg-muted/70 focus:ring-2 focus:ring-primary/20"
                    >
                      <option value="">Selecione sua especialidade</option>
                      <option value="hipertrofia">Hipertrofia</option>
                      <option value="emagrecimento">Emagrecimento</option>
                      <option value="performance">Performance</option>
                      <option value="funcional">Funcional</option>
                      <option value="geral">Condicionamento Geral</option>
                    </select>
                  </>
                )}
              </div>
            )}

            <IPhoneInput
              placeholder="seu@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              type="email"
            />

            <div className="relative">
              <IPhoneInput
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                type={showPassword ? "text" : "password"}
              />
              <button
                type="button"
                className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors p-1"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>

            <IPhoneButton
              variant="primary"
              fullWidth
              loading={loading}
              icon={isLogin ? LogIn : UserPlus}
              className="py-5 text-lg font-bold mt-6"
            >
              {loading 
                ? 'Processando...' 
                : isLogin 
                  ? 'ENTRAR NO VOLT' 
                  : 'COMEÇAR JORNADA'
              }
            </IPhoneButton>
          </form>

          {/* Toggle login/signup - static */}
          <div className="mt-8 animate-auth-fade-in" style={{ animationDelay: '0.2s' }}>
            <IPhoneCard 
              variant="glass" 
              size="sm" 
              hoverable={false}
              static
              className="p-4 text-center"
            >
              <p className="text-muted-foreground text-sm mb-3">
                {isLogin ? 'Novo no universo VOLT?' : 'Já faz parte da família fitness?'}
              </p>
              <IPhoneButton
                variant="glass"
                size="sm"
                onClick={() => {
                  setIsLogin(!isLogin);
                  setEmail('');
                  setPassword('');
                  setDisplayName('');
                  setPhone('');
                  setBrandName('');
                  setSpecialization('');
                }}
              >
                {isLogin 
                  ? accountType === 'pt' 
                    ? '🚀 Criar conta de Personal' 
                    : '🚀 Criar minha conta'
                  : '⚡ Fazer login'
                }
              </IPhoneButton>
            </IPhoneCard>
          </div>

          {/* Free trial badge - CSS transition */}
          {!isLogin && (
            <div className="mt-6 animate-auth-slide-up">
              <IPhoneCard 
                variant="glass" 
                hoverable={false}
                static
                className="p-4 bg-gradient-to-r from-primary/10 to-blue-500/10 border-primary/20"
              >
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="w-4 h-4 text-primary" />
                  <span className="text-primary font-bold text-sm">
                    {accountType === 'pt' ? '7 DIAS GRÁTIS' : '3 DIAS PREMIUM GRÁTIS'}
                  </span>
                </div>
                <p className="text-muted-foreground text-xs">
                  Acesso completo • Sem cartão • Cancela quando quiser
                </p>
              </IPhoneCard>
            </div>
          )}

          {/* Account type selection link */}
          {isLogin && !accountType && (
            <div className="mt-4 text-center animate-auth-fade-in" style={{ animationDelay: '0.3s' }}>
              <button
                onClick={() => navigate('/comecar')}
                className="text-sm text-muted-foreground hover:text-primary transition-colors underline underline-offset-4"
              >
                Novo aqui? Escolha seu tipo de conta
              </button>
            </div>
          )}
        </IPhoneCard>
      </div>
    </div>
  );
};

export default EnhancedAuth;
