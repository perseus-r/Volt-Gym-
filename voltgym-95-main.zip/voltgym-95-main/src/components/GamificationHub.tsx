import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Trophy, Zap, Star, Award, ChevronRight, Sparkles } from 'lucide-react';
import { ProgressEngine } from '@/services/ProgressEngine';
import { AchievementService, Achievement } from '@/services/AchievementService';
import { AchievementCard } from '@/components/achievements/AchievementCard';
import { AchievementUnlockModal } from '@/components/achievements/AchievementUnlockModal';
import { USER_LEVELS, UserLevel } from '@/components/UserLevelSystem';
import { motion, AnimatePresence } from 'framer-motion';

export function GamificationHub() {
  const navigate = useNavigate();
  const [currentXP, setCurrentXP] = useState(0);
  const [currentLevel, setCurrentLevel] = useState<UserLevel>(USER_LEVELS[0]);
  const [nextLevel, setNextLevel] = useState<UserLevel | null>(null);
  const [streak, setStreak] = useState(0);
  const [recentAchievements, setRecentAchievements] = useState<Achievement[]>([]);
  const [nearCompletion, setNearCompletion] = useState<Achievement[]>([]);
  const [totalUnlocked, setTotalUnlocked] = useState(0);
  const [selectedAchievement, setSelectedAchievement] = useState<Achievement | null>(null);

  useEffect(() => {
    loadGamificationData();
  }, []);

  const loadGamificationData = async () => {
    const xp = ProgressEngine.currentXP();
    const streakDays = ProgressEngine.currentStreak();
    const allAchievements = await AchievementService.getAllAchievements();
    
    const level = USER_LEVELS.find(l => xp >= l.minXP && xp <= l.maxXP) || USER_LEVELS[0];
    const next = USER_LEVELS.find(l => l.minXP > xp);

    // Get recent unlocked achievements (sorted by unlock date)
    const unlocked = allAchievements
      .filter(a => a.isUnlocked && a.unlockedAt)
      .sort((a, b) => new Date(b.unlockedAt!).getTime() - new Date(a.unlockedAt!).getTime())
      .slice(0, 3);

    // Get achievements near completion (80%+ progress, not unlocked)
    const almostDone = allAchievements
      .filter(a => !a.isUnlocked && !a.isSecret && (a.progress / a.maxProgress) >= 0.5)
      .sort((a, b) => (b.progress / b.maxProgress) - (a.progress / a.maxProgress))
      .slice(0, 3);

    setCurrentXP(xp);
    setCurrentLevel(level);
    setNextLevel(next || null);
    setStreak(streakDays);
    setRecentAchievements(unlocked);
    setNearCompletion(almostDone);
    setTotalUnlocked(allAchievements.filter(a => a.isUnlocked).length);
  };

  const xpProgress = nextLevel 
    ? ((currentXP - currentLevel.minXP) / (nextLevel.minXP - currentLevel.minXP)) * 100
    : 100;

  const LevelIcon = currentLevel.icon;

  const handleAchievementClick = (achievement: Achievement) => {
    if (achievement.isUnlocked) {
      setSelectedAchievement(achievement);
    }
  };

  return (
    <div className="space-y-3 md:space-y-4">
      {/* Current Level Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <Card className="p-4 md:p-6 bg-gradient-to-br from-accent/10 via-accent/5 to-transparent border-accent/20 overflow-hidden relative">
          {/* Glow effect */}
          <div 
            className="absolute inset-0 opacity-20 blur-3xl pointer-events-none"
            style={{ background: `radial-gradient(circle at 30% 30%, ${currentLevel.color}40, transparent 70%)` }}
          />
          
          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-3 md:mb-4">
              <motion.div 
                className="p-2.5 md:p-3 rounded-full"
                style={{ backgroundColor: currentLevel.color + '30' }}
                whileHover={{ scale: 1.1, rotate: 10 }}
                transition={{ type: 'spring', stiffness: 300 }}
              >
                <LevelIcon 
                  className="w-6 h-6 md:w-8 md:h-8" 
                  style={{ color: currentLevel.color }}
                />
              </motion.div>
              <div className="flex-1 min-w-0">
                <h3 className="text-xl md:text-2xl font-bold truncate">{currentLevel.name}</h3>
                <p className="text-xs md:text-sm text-txt-2">{currentXP.toLocaleString()} XP total</p>
              </div>
              <Badge className="text-sm px-2.5 py-1 shrink-0 bg-accent/20 text-accent border-accent/30">
                Nível {USER_LEVELS.indexOf(currentLevel) + 1}
              </Badge>
            </div>

            {nextLevel && (
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs md:text-sm">
                  <span className="text-txt-2">Próximo: {nextLevel.name}</span>
                  <span className="font-semibold text-accent">{Math.round(xpProgress)}%</span>
                </div>
                <div className="relative">
                  <Progress value={xpProgress} className="h-2.5" />
                  <motion.div
                    className="absolute top-0 left-0 h-full bg-accent/30 rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: `${xpProgress}%` }}
                    transition={{ duration: 1, ease: 'easeOut' }}
                  />
                </div>
                <p className="text-[10px] md:text-xs text-txt-3">
                  {(nextLevel.minXP - currentXP).toLocaleString()} XP restantes
                </p>
              </div>
            )}
          </div>
        </Card>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-2 md:gap-3">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="p-3 md:p-4">
            <div className="flex items-center gap-2 md:gap-3">
              <div className="p-2 rounded-full bg-orange-500/20">
                <Zap className="w-5 h-5 md:w-6 md:h-6 text-orange-500" />
              </div>
              <div>
                <p className="text-xl md:text-2xl font-bold">{streak}</p>
                <p className="text-[10px] md:text-xs text-txt-2">Dias Seguidos</p>
              </div>
            </div>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.15 }}
        >
          <Card className="p-3 md:p-4">
            <div className="flex items-center gap-2 md:gap-3">
              <div className="p-2 rounded-full bg-yellow-500/20">
                <Trophy className="w-5 h-5 md:w-6 md:h-6 text-yellow-500" />
              </div>
              <div>
                <p className="text-xl md:text-2xl font-bold">{totalUnlocked}</p>
                <p className="text-[10px] md:text-xs text-txt-2">Conquistas</p>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>

      {/* Level Benefits */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Card className="p-3 md:p-4">
          <h4 className="font-semibold mb-2 flex items-center gap-2 text-sm md:text-base">
            <Star className="w-3.5 h-3.5 md:w-4 md:h-4 text-accent" />
            Benefícios Desbloqueados
          </h4>
          <div className="space-y-1.5 md:space-y-2">
            {currentLevel.benefits.map((benefit, i) => (
              <div key={i} className="flex items-center gap-2 text-xs md:text-sm">
                <div className="w-1.5 h-1.5 rounded-full bg-accent shrink-0"></div>
                <span className="text-txt-2">{benefit}</span>
              </div>
            ))}
          </div>
        </Card>
      </motion.div>

      {/* Near Completion Achievements */}
      {nearCompletion.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
        >
          <Card className="p-3 md:p-4 border-accent/20">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-semibold flex items-center gap-2 text-sm md:text-base">
                <Sparkles className="w-3.5 h-3.5 md:w-4 md:h-4 text-accent" />
                Próximas Conquistas
              </h4>
            </div>
            <div className="space-y-2">
              {nearCompletion.map((achievement, index) => (
                <motion.div
                  key={achievement.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                >
                  <AchievementCard
                    achievement={achievement}
                    showProgress
                    compact
                    onClick={() => handleAchievementClick(achievement)}
                  />
                </motion.div>
              ))}
            </div>
          </Card>
        </motion.div>
      )}

      {/* Recent Achievements */}
      {recentAchievements.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="p-3 md:p-4">
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-semibold flex items-center gap-2 text-sm md:text-base">
                <Award className="w-3.5 h-3.5 md:w-4 md:h-4 text-yellow-500" />
                Conquistas Recentes
              </h4>
              <Button
                variant="ghost"
                size="sm"
                className="text-xs text-accent h-auto py-1 px-2"
                onClick={() => navigate('/perfil?tab=conquistas')}
              >
                Ver todas
                <ChevronRight className="w-3 h-3 ml-1" />
              </Button>
            </div>
            <div className="space-y-2">
              {recentAchievements.map((achievement, index) => (
                <motion.div
                  key={achievement.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.35 + index * 0.1 }}
                >
                  <AchievementCard
                    achievement={achievement}
                    compact
                    onClick={() => handleAchievementClick(achievement)}
                  />
                </motion.div>
              ))}
            </div>
          </Card>
        </motion.div>
      )}

      {/* Achievement Modal */}
      <AchievementUnlockModal
        achievement={selectedAchievement}
        onClose={() => setSelectedAchievement(null)}
      />
    </div>
  );
}
