import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, Plus, X, Target, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { useUserWorkouts } from '@/hooks/useUserWorkouts';

interface WeekScheduleDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedWorkoutIds: string[];
}

const DAYS_OF_WEEK = [
  { key: 'monday', label: 'Segunda', short: 'SEG' },
  { key: 'tuesday', label: 'Terça', short: 'TER' },
  { key: 'wednesday', label: 'Quarta', short: 'QUA' },
  { key: 'thursday', label: 'Quinta', short: 'QUI' },
  { key: 'friday', label: 'Sexta', short: 'SEX' },
  { key: 'saturday', label: 'Sábado', short: 'SÁB' },
  { key: 'sunday', label: 'Domingo', short: 'DOM' }
];

interface WeeklySchedule {
  [dayKey: string]: string[]; // Array of workout IDs for each day
}

export default function WeekScheduleDialog({ open, onOpenChange, selectedWorkoutIds }: WeekScheduleDialogProps) {
  const [weeklySchedule, setWeeklySchedule] = useState<WeeklySchedule>({});
  const { templates, getQuickTemplates } = useUserWorkouts();

  // Get all available workouts
  const allWorkouts = [
    ...getQuickTemplates(),
    ...templates
  ];

  useEffect(() => {
    if (open) {
      loadWeeklySchedule();
    }
  }, [open]);

  const loadWeeklySchedule = () => {
    const saved = localStorage.getItem('volt_weekly_schedule');
    if (saved) {
      setWeeklySchedule(JSON.parse(saved));
    }
  };

  const saveWeeklySchedule = (schedule: WeeklySchedule) => {
    setWeeklySchedule(schedule);
    localStorage.setItem('volt_weekly_schedule', JSON.stringify(schedule));
  };

  const addWorkoutToDay = (dayKey: string, workoutId: string) => {
    const newSchedule = { ...weeklySchedule };
    if (!newSchedule[dayKey]) {
      newSchedule[dayKey] = [];
    }
    
    if (!newSchedule[dayKey].includes(workoutId)) {
      newSchedule[dayKey].push(workoutId);
      saveWeeklySchedule(newSchedule);
      
      const workout = allWorkouts.find(w => w.id === workoutId);
      const day = DAYS_OF_WEEK.find(d => d.key === dayKey);
      toast.success(`${workout?.name} adicionado à ${day?.label}`);
    }
  };

  const removeWorkoutFromDay = (dayKey: string, workoutId: string) => {
    const newSchedule = { ...weeklySchedule };
    if (newSchedule[dayKey]) {
      newSchedule[dayKey] = newSchedule[dayKey].filter(id => id !== workoutId);
      if (newSchedule[dayKey].length === 0) {
        delete newSchedule[dayKey];
      }
      saveWeeklySchedule(newSchedule);
      
      const workout = allWorkouts.find(w => w.id === workoutId);
      const day = DAYS_OF_WEEK.find(d => d.key === dayKey);
      toast.info(`${workout?.name} removido da ${day?.label}`);
    }
  };

  const addSelectedWorkoutsToDay = (dayKey: string) => {
    selectedWorkoutIds.forEach(workoutId => {
      addWorkoutToDay(dayKey, workoutId);
    });
  };

  const autoDistributeWorkouts = () => {
    const newSchedule: WeeklySchedule = {};
    let dayIndex = 0;
    
    selectedWorkoutIds.forEach(workoutId => {
      const dayKey = DAYS_OF_WEEK[dayIndex % 7].key;
      if (!newSchedule[dayKey]) {
        newSchedule[dayKey] = [];
      }
      newSchedule[dayKey].push(workoutId);
      dayIndex++;
    });
    
    saveWeeklySchedule(newSchedule);
    toast.success('Treinos distribuídos automaticamente!');
  };

  const getWorkoutById = (id: string) => {
    return allWorkouts.find(w => w.id === id);
  };

  const getTotalDuration = (workoutIds: string[]) => {
    return workoutIds.reduce((total, id) => {
      const workout = getWorkoutById(id);
      return total + (workout ? workout.exercises.length * 4 : 0);
    }, 0);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Agendar Treinos na Semana
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Quick Actions */}
          {selectedWorkoutIds.length > 0 && (
            <div className="flex gap-2 flex-wrap">
              <Button 
                onClick={autoDistributeWorkouts}
                className="bg-accent text-accent-ink"
              >
                🎲 Distribuir Automaticamente ({selectedWorkoutIds.length})
              </Button>
              
              {DAYS_OF_WEEK.map(day => (
                <Button
                  key={day.key}
                  variant="outline"
                  size="sm"
                  onClick={() => addSelectedWorkoutsToDay(day.key)}
                >
                  + {day.short}
                </Button>
              ))}
            </div>
          )}

          {/* Weekly Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-7 gap-4">
            {DAYS_OF_WEEK.map(day => {
              const dayWorkouts = weeklySchedule[day.key] || [];
              const isToday = new Date().getDay() === (DAYS_OF_WEEK.indexOf(day) + 1) % 7;
              const totalDuration = getTotalDuration(dayWorkouts);

              return (
                <Card 
                  key={day.key}
                  className={`p-4 ${isToday ? 'ring-2 ring-accent bg-accent/5' : ''}`}
                >
                  {/* Day Header */}
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h4 className="font-semibold text-txt text-sm">
                        {day.short}
                      </h4>
                      {isToday && (
                        <Badge variant="outline" className="text-xs mt-1 bg-accent/20 text-accent">
                          Hoje
                        </Badge>
                      )}
                    </div>
                    {dayWorkouts.length > 0 && (
                      <div className="text-xs text-txt-3 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        ~{totalDuration}min
                      </div>
                    )}
                  </div>

                  {/* Workouts List */}
                  <div className="space-y-2 min-h-[120px]">
                    {dayWorkouts.map(workoutId => {
                      const workout = getWorkoutById(workoutId);
                      if (!workout) return null;

                      return (
                        <div
                          key={workoutId}
                          className="bg-surface/50 p-2 rounded-lg text-xs group relative"
                        >
                          <button
                            onClick={() => removeWorkoutFromDay(day.key, workoutId)}
                            className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="w-3 h-3 text-txt-3 hover:text-red-400" />
                          </button>
                          
                          <div className="pr-4">
                            <h5 className="font-medium text-txt line-clamp-1">
                              {workout.name}
                            </h5>
                            <p className="text-txt-2">{workout.focus}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="flex items-center gap-1">
                                <Target className="w-2 h-2" />
                                {workout.exercises.length}
                              </span>
                              <span className="flex items-center gap-1">
                                <Clock className="w-2 h-2" />
                                ~{workout.exercises.length * 4}min
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    })}

                    {/* Add Workout Button */}
                    {selectedWorkoutIds.length > 0 && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full h-8 text-xs"
                        onClick={() => addSelectedWorkoutsToDay(day.key)}
                      >
                        <Plus className="w-3 h-3 mr-1" />
                        Adicionar
                      </Button>
                    )}
                  </div>
                </Card>
              );
            })}
          </div>

          {/* Selected Workouts Preview */}
          {selectedWorkoutIds.length > 0 && (
            <Card className="p-4">
              <h3 className="font-semibold text-txt mb-3">
                Treinos Selecionados ({selectedWorkoutIds.length})
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                {selectedWorkoutIds.map(workoutId => {
                  const workout = getWorkoutById(workoutId);
                  if (!workout) return null;

                  return (
                    <div key={workoutId} className="bg-surface/50 p-3 rounded-lg">
                      <h4 className="font-medium text-txt text-sm line-clamp-1">
                        {workout.name}
                      </h4>
                      <p className="text-xs text-txt-2">{workout.focus}</p>
                      <div className="flex items-center gap-2 mt-1 text-xs text-txt-3">
                        <span>{workout.exercises.length} exercícios</span>
                        <span>~{workout.exercises.length * 4}min</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>
          )}

          {/* Actions */}
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Fechar
            </Button>
            <Button 
              onClick={() => {
                onOpenChange(false);
                toast.success('Agenda semanal atualizada!');
              }}
              className="bg-accent text-accent-ink"
            >
              Salvar Agenda
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}