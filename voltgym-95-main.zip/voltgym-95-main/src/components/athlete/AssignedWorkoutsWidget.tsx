import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Play, Star } from 'lucide-react';
import { AssignedWorkout } from '@/hooks/useAssignedWorkouts';
import { format, parseISO, isToday, isTomorrow, isPast } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';

interface AssignedWorkoutsWidgetProps {
  workouts: AssignedWorkout[];
  onStartWorkout: (workout: AssignedWorkout) => void;
  onProvideFeedback: (workout: AssignedWorkout) => void;
}

export function AssignedWorkoutsWidget({
  workouts,
  onStartWorkout,
  onProvideFeedback,
}: AssignedWorkoutsWidgetProps) {
  const pendingWorkouts = workouts
    .filter(w => w.status === 'pending')
    .sort((a, b) => {
      if (!a.scheduled_date || !b.scheduled_date) return 0;
      return new Date(a.scheduled_date).getTime() - new Date(b.scheduled_date).getTime();
    });

  const completedWorkouts = workouts
    .filter(w => w.status === 'completed' && !w.athlete_rating)
    .slice(0, 3);

  const getDateLabel = (dateStr: string) => {
    const date = parseISO(dateStr);
    if (isToday(date)) return 'Hoje';
    if (isTomorrow(date)) return 'Amanhã';
    if (isPast(date)) return 'Atrasado';
    return format(date, "d 'de' MMM", { locale: ptBR });
  };

  if (pendingWorkouts.length === 0 && completedWorkouts.length === 0) {
    return null;
  }

  return (
    <div className="space-y-4">
      {pendingWorkouts.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Calendar className="h-5 w-5" />
              Treinos Atribuídos pelo seu Personal
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {pendingWorkouts.map((workout) => (
              <div
                key={workout.id}
                className="p-4 rounded-lg border bg-card space-y-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">Treino Personalizado</span>
                      {workout.scheduled_date && (
                        <Badge
                          variant="outline"
                          className={cn(
                            isPast(parseISO(workout.scheduled_date)) && !isToday(parseISO(workout.scheduled_date))
                              ? 'border-red-500/30 text-red-600'
                              : ''
                          )}
                        >
                          {getDateLabel(workout.scheduled_date)}
                        </Badge>
                      )}
                    </div>
                    {workout.pt_notes && (
                      <p className="text-sm text-muted-foreground mt-2">
                        📝 {workout.pt_notes}
                      </p>
                    )}
                  </div>
                </div>
                <Button
                  onClick={() => onStartWorkout(workout)}
                  className="w-full"
                  size="sm"
                >
                  <Play className="h-4 w-4 mr-2" />
                  Iniciar Treino
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {completedWorkouts.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Star className="h-5 w-5" />
              Avalie seus treinos
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {completedWorkouts.map((workout) => (
              <div
                key={workout.id}
                className="p-4 rounded-lg border bg-card space-y-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <div className="font-medium">Treino Completo</div>
                    {workout.completed_at && (
                      <p className="text-sm text-muted-foreground">
                        {format(parseISO(workout.completed_at), "d 'de' MMM 'às' HH:mm", { locale: ptBR })}
                      </p>
                    )}
                  </div>
                  <Badge className="bg-green-500/20 text-green-600 border-green-500/30">
                    Completo
                  </Badge>
                </div>
                <Button
                  onClick={() => onProvideFeedback(workout)}
                  variant="outline"
                  className="w-full"
                  size="sm"
                >
                  <Star className="h-4 w-4 mr-2" />
                  Avaliar Treino
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
