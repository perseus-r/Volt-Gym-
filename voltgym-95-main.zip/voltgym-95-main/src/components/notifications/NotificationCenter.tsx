import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  X, 
  Bell, 
  Dumbbell, 
  Trophy, 
  Sparkles, 
  Users, 
  Settings,
  Check,
  Trash2
} from 'lucide-react';
import { hapticLight, hapticMedium } from '@/utils/haptics';
import { Button } from '@/components/ui/button';

export type NotificationType = 'workout' | 'achievement' | 'ai' | 'social' | 'reminder';

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  time: string;
  read: boolean;
  actionUrl?: string;
}

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: Notification[];
  onMarkAsRead: (id: string) => void;
  onMarkAllRead: () => void;
  onDelete: (id: string) => void;
  onClearAll: () => void;
  onNotificationClick?: (notification: Notification) => void;
}

export function NotificationCenter({
  isOpen,
  onClose,
  notifications,
  onMarkAsRead,
  onMarkAllRead,
  onDelete,
  onClearAll,
  onNotificationClick,
}: NotificationCenterProps) {
  const [swipedId, setSwipedId] = useState<string | null>(null);

  const getNotificationIcon = (type: NotificationType) => {
    switch (type) {
      case 'workout':
        return <Dumbbell className="w-4 h-4" />;
      case 'achievement':
        return <Trophy className="w-4 h-4" />;
      case 'ai':
        return <Sparkles className="w-4 h-4" />;
      case 'social':
        return <Users className="w-4 h-4" />;
      case 'reminder':
        return <Bell className="w-4 h-4" />;
      default:
        return <Bell className="w-4 h-4" />;
    }
  };

  const getNotificationColor = (type: NotificationType) => {
    switch (type) {
      case 'workout':
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
      case 'achievement':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'ai':
        return 'bg-violet-500/20 text-violet-400 border-violet-500/30';
      case 'social':
        return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'reminder':
        return 'bg-orange-500/20 text-orange-400 border-orange-500/30';
      default:
        return 'bg-primary/20 text-primary border-primary/30';
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  const handleNotificationClick = (notification: Notification) => {
    hapticLight();
    if (!notification.read) {
      onMarkAsRead(notification.id);
    }
    onNotificationClick?.(notification);
  };

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    hapticMedium();
    onDelete(id);
    setSwipedId(null);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm"
          />

          {/* Panel */}
          <motion.div
            initial={{ y: '-100%', opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: '-100%', opacity: 0 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="fixed inset-x-0 top-0 z-50 max-h-[85vh] overflow-hidden rounded-b-3xl bg-background border-b border-border shadow-xl"
          >
            {/* Handle */}
            <div className="flex justify-center pt-3 pb-1">
              <div className="w-12 h-1 rounded-full bg-muted-foreground/30" />
            </div>

            {/* Header */}
            <div className="flex items-center justify-between px-5 py-3 border-b border-border/50">
              <div className="flex items-center gap-3">
                <h2 className="text-lg font-bold">Notificações</h2>
                {unreadCount > 0 && (
                  <span className="px-2 py-0.5 text-xs font-bold rounded-full bg-primary text-primary-foreground">
                    {unreadCount}
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2">
                {unreadCount > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      hapticLight();
                      onMarkAllRead();
                    }}
                    className="text-xs"
                  >
                    <Check className="w-3.5 h-3.5 mr-1" />
                    Marcar lidas
                  </Button>
                )}
                <button
                  onClick={onClose}
                  className="w-8 h-8 rounded-full bg-secondary/50 flex items-center justify-center"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Notifications list */}
            <div className="overflow-y-auto max-h-[60vh] pb-safe">
              {notifications.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="w-16 h-16 rounded-full bg-secondary/30 flex items-center justify-center mb-4">
                    <Bell className="w-8 h-8 text-muted-foreground" />
                  </div>
                  <p className="text-muted-foreground">Nenhuma notificação</p>
                  <p className="text-xs text-muted-foreground/60 mt-1">
                    Você está em dia!
                  </p>
                </div>
              ) : (
                <div className="divide-y divide-border/30">
                  {notifications.map((notification, idx) => (
                    <motion.div
                      key={notification.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      className="relative"
                    >
                      {/* Swipe to delete actions */}
                      <AnimatePresence>
                        {swipedId === notification.id && (
                          <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            className="absolute inset-y-0 right-0 flex items-center px-4"
                          >
                            <button
                              onClick={(e) => handleDelete(e, notification.id)}
                              className="w-10 h-10 rounded-full bg-destructive flex items-center justify-center"
                            >
                              <Trash2 className="w-5 h-5 text-destructive-foreground" />
                            </button>
                          </motion.div>
                        )}
                      </AnimatePresence>

                      {/* Notification item */}
                      <motion.div
                        onClick={() => handleNotificationClick(notification)}
                        onPanEnd={(e, info) => {
                          if (info.offset.x < -50) {
                            setSwipedId(notification.id);
                          } else {
                            setSwipedId(null);
                          }
                        }}
                        drag="x"
                        dragConstraints={{ left: -80, right: 0 }}
                        dragElastic={0.1}
                        className={`relative flex items-start gap-3 p-4 cursor-pointer transition-colors ${
                          notification.read ? 'bg-background' : 'bg-primary/5'
                        }`}
                      >
                        {/* Icon */}
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 border ${getNotificationColor(notification.type)}`}>
                          {getNotificationIcon(notification.type)}
                        </div>

                        {/* Content */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className={`text-sm font-medium ${notification.read ? 'text-foreground' : 'text-foreground'}`}>
                              {notification.title}
                            </p>
                            {!notification.read && (
                              <div className="w-2 h-2 rounded-full bg-primary" />
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                            {notification.message}
                          </p>
                          <p className="text-[10px] text-muted-foreground/60 mt-1">
                            {notification.time}
                          </p>
                        </div>
                      </motion.div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            {notifications.length > 0 && (
              <div className="flex items-center justify-between px-5 py-3 border-t border-border/50">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    hapticLight();
                    onClearAll();
                  }}
                  className="text-xs text-destructive hover:text-destructive"
                >
                  <Trash2 className="w-3.5 h-3.5 mr-1" />
                  Limpar tudo
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-xs"
                >
                  <Settings className="w-3.5 h-3.5 mr-1" />
                  Configurar
                </Button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
