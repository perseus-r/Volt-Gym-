import { motion, AnimatePresence } from 'framer-motion';
import { Bell } from 'lucide-react';
import { hapticLight } from '@/utils/haptics';

interface NotificationBadgeProps {
  count: number;
  onClick: () => void;
  className?: string;
}

export function NotificationBadge({
  count,
  onClick,
  className = '',
}: NotificationBadgeProps) {
  const displayCount = count > 99 ? '99+' : count;
  const hasNotifications = count > 0;

  const handleClick = () => {
    hapticLight();
    onClick();
  };

  return (
    <motion.button
      whileTap={{ scale: 0.9 }}
      onClick={handleClick}
      className={`relative w-10 h-10 rounded-full bg-secondary/50 flex items-center justify-center transition-colors hover:bg-secondary/70 ${className}`}
    >
      {/* Bell icon with animation when has notifications */}
      <motion.div
        animate={hasNotifications ? {
          rotate: [0, -10, 10, -10, 10, 0],
        } : {}}
        transition={{
          duration: 0.5,
          repeat: hasNotifications ? Infinity : 0,
          repeatDelay: 3,
        }}
      >
        <Bell className={`w-5 h-5 ${hasNotifications ? 'text-foreground' : 'text-muted-foreground'}`} />
      </motion.div>

      {/* Badge */}
      <AnimatePresence>
        {hasNotifications && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 500, damping: 25 }}
            className="absolute -top-0.5 -right-0.5"
          >
            <motion.div
              animate={{
                scale: [1, 1.15, 1],
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
              className="relative"
            >
              {/* Glow effect */}
              <div className="absolute inset-0 bg-destructive rounded-full blur-sm opacity-50" />
              
              {/* Badge content */}
              <div className="relative min-w-[18px] h-[18px] px-1 rounded-full bg-destructive flex items-center justify-center">
                <motion.span
                  key={count}
                  initial={{ scale: 1.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="text-[10px] font-bold text-destructive-foreground leading-none"
                >
                  {displayCount}
                </motion.span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Pulse ring when has new notifications */}
      <AnimatePresence>
        {hasNotifications && (
          <motion.div
            initial={{ opacity: 0, scale: 1 }}
            animate={{ 
              opacity: [0.5, 0],
              scale: [1, 1.8],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              repeatDelay: 1,
            }}
            className="absolute inset-0 rounded-full border-2 border-destructive"
          />
        )}
      </AnimatePresence>
    </motion.button>
  );
}
