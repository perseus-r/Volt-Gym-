import React, { useState, useEffect } from 'react';
import { Calendar, Image as ImageIcon, Repeat } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { VoltCard } from '@/components/VoltCard';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { motion, AnimatePresence } from 'framer-motion';
import { format, subDays, startOfDay, endOfDay } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface NutritionLog {
  id: string;
  user_id: string;
  date: string;
  meal_type: string;
  food_name: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  photo_url?: string;
  created_at: string;
}

const mealTypeLabels = {
  breakfast: '☀️ Café',
  lunch: '🍽️ Almoço',
  dinner: '🌙 Jantar',
  snack: '🍎 Lanche'
};

export function NutritionHistory() {
  const [logs, setLogs] = useState<NutritionLog[]>([]);
  const [period, setPeriod] = useState<'today' | 'yesterday' | 'week' | 'month'>('today');
  const [loading, setLoading] = useState(false);
  const [expandedLog, setExpandedLog] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    loadLogs();
  }, [period]);

  const loadLogs = async () => {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    let startDate = new Date();
    
    switch (period) {
      case 'yesterday':
        startDate = subDays(new Date(), 1);
        break;
      case 'week':
        startDate = subDays(new Date(), 7);
        break;
      case 'month':
        startDate = subDays(new Date(), 30);
        break;
    }

    const { data, error } = await supabase
      .from('nutrition_logs')
      .select('*')
      .eq('user_id', user.id)
      .gte('date', format(startOfDay(startDate), 'yyyy-MM-dd'))
      .lte('date', format(endOfDay(new Date()), 'yyyy-MM-dd'))
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error loading logs:', error);
    } else {
      setLogs(data || []);
    }
    setLoading(false);
  };

  const handleRepeatMeal = (log: NutritionLog) => {
    toast({
      title: 'Refeição repetida',
      description: `${log.food_name} foi adicionada novamente`,
    });
  };

  const totalStats = logs.reduce(
    (acc, log) => ({
      calories: acc.calories + log.calories,
      protein: acc.protein + log.protein,
      carbs: acc.carbs + log.carbs,
      fat: acc.fat + log.fat
    }),
    { calories: 0, protein: 0, carbs: 0, fat: 0 }
  );

  const periods = [
    { id: 'today', label: 'Hoje' },
    { id: 'yesterday', label: 'Ontem' },
    { id: 'week', label: 'Semana' },
    { id: 'month', label: 'Mês' }
  ] as const;

  return (
    <div className="space-y-4">
      <div className="flex gap-2 overflow-x-auto pb-2">
        {periods.map(({ id, label }) => (
          <Badge
            key={id}
            variant={period === id ? 'default' : 'outline'}
            className="cursor-pointer whitespace-nowrap"
            onClick={() => setPeriod(id)}
          >
            <Calendar className="w-3 h-3 mr-1" />
            {label}
          </Badge>
        ))}
      </div>

      <VoltCard className="p-4">
        <h3 className="text-sm font-semibold mb-3">Resumo do Período</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-surface/50 rounded p-2">
            <p className="text-txt-3 text-xs">Calorias</p>
            <p className="font-semibold">{Math.round(totalStats.calories)} kcal</p>
          </div>
          <div className="bg-surface/50 rounded p-2">
            <p className="text-txt-3 text-xs">Proteína</p>
            <p className="font-semibold">{Math.round(totalStats.protein)}g</p>
          </div>
          <div className="bg-surface/50 rounded p-2">
            <p className="text-txt-3 text-xs">Carboidrato</p>
            <p className="font-semibold">{Math.round(totalStats.carbs)}g</p>
          </div>
          <div className="bg-surface/50 rounded p-2">
            <p className="text-txt-3 text-xs">Gordura</p>
            <p className="font-semibold">{Math.round(totalStats.fat)}g</p>
          </div>
        </div>
      </VoltCard>

      <div className="space-y-2">
        <AnimatePresence mode="popLayout">
          {logs.length === 0 ? (
            <div className="text-center py-8 text-txt-3">
              <p>Nenhum registro encontrado neste período</p>
            </div>
          ) : (
            logs.map((log) => (
              <motion.div
                key={log.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                layout
              >
                  <VoltCard
                    className="p-3 cursor-pointer hover:border-accent transition-colors"
                    onClick={() => setExpandedLog(expandedLog === log.id ? null : log.id)}
                  >
                  <div className="flex items-start gap-3">
                    {log.photo_url && (
                      <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0 bg-surface">
                        <img
                          src={log.photo_url}
                          alt={log.food_name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-lg">
                          {mealTypeLabels[log.meal_type as keyof typeof mealTypeLabels] || '🍴'}
                        </span>
                        <p className="font-medium text-sm truncate">{log.food_name}</p>
                      </div>
                      
                      <div className="flex gap-3 text-xs text-txt-3 mb-2">
                        <span>{log.calories} kcal</span>
                        <span>P: {log.protein}g</span>
                        <span>C: {log.carbs}g</span>
                        <span>G: {log.fat}g</span>
                      </div>

                      <p className="text-xs text-txt-3">
                        {format(new Date(log.created_at), "dd/MM 'às' HH:mm", { locale: ptBR })}
                      </p>
                    </div>

                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRepeatMeal(log);
                      }}
                    >
                      <Repeat className="w-4 h-4" />
                    </Button>
                  </div>

                  {expandedLog === log.id && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-3 pt-3 border-t border-border"
                    >
                      {log.photo_url && (
                        <div className="mb-3">
                          <img
                            src={log.photo_url}
                            alt={log.food_name}
                            className="w-full rounded-lg max-h-64 object-cover"
                          />
                        </div>
                      )}
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div className="bg-surface/50 rounded p-2">
                          <p className="text-txt-3 text-xs">Calorias</p>
                          <p className="font-semibold">{log.calories} kcal</p>
                        </div>
                        <div className="bg-surface/50 rounded p-2">
                          <p className="text-txt-3 text-xs">Proteína</p>
                          <p className="font-semibold">{log.protein}g</p>
                        </div>
                        <div className="bg-surface/50 rounded p-2">
                          <p className="text-txt-3 text-xs">Carboidrato</p>
                          <p className="font-semibold">{log.carbs}g</p>
                        </div>
                        <div className="bg-surface/50 rounded p-2">
                          <p className="text-txt-3 text-xs">Gordura</p>
                          <p className="font-semibold">{log.fat}g</p>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </VoltCard>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
