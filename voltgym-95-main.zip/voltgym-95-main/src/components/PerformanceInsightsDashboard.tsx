/**
 * PerformanceInsightsDashboard - Comprehensive workout performance analytics
 */

import React from 'react';
import { motion } from 'framer-motion';
import { usePerformanceInsights } from '@/hooks/usePerformanceInsights';
import { ConsistencyCalendar } from '@/components/ConsistencyCalendar';
import { MuscleHeatMap } from '@/components/MuscleHeatMap';
import { StrengthProgressionChart } from '@/components/StrengthProgressionChart';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  TrendingUp, TrendingDown, Activity, Target, Flame, Trophy, 
  Calendar, BarChart3, Zap, AlertTriangle 
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface PerformanceInsightsDashboardProps {
  className?: string;
}

export function PerformanceInsightsDashboard({ className }: PerformanceInsightsDashboardProps) {
  const [timeRange, setTimeRange] = React.useState<'7d' | '30d' | '90d'>('30d');
  const insights = usePerformanceInsights(timeRange);

  if (insights.isLoading) {
    return (
      <div className={cn('space-y-4', className)}>
        <Skeleton className="h-32 w-full" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-24" />)}
        </div>
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  const metricCards = [
    { 
      label: 'Volume Total', 
      value: `${Math.round(insights.totalVolume / 1000)}t`, 
      change: insights.volumeChange,
      icon: Activity,
      color: 'text-accent'
    },
    { 
      label: 'Treinos', 
      value: insights.workoutsThisMonth, 
      subtext: 'este mês',
      icon: Calendar,
      color: 'text-success'
    },
    { 
      label: 'Consistência', 
      value: `${Math.round(insights.consistencyScore)}%`, 
      icon: Target,
      color: insights.consistencyScore >= 70 ? 'text-success' : 'text-warning'
    },
    { 
      label: 'Streak', 
      value: `${insights.currentStreak}d`, 
      subtext: `máx: ${insights.longestStreak}d`,
      icon: Flame,
      color: 'text-warning'
    },
  ];

  return (
    <div className={cn('space-y-4', className)}>
      {/* Time Range Selector - Compact */}
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-bold">Performance Insights</h2>
        <Select value={timeRange} onValueChange={(v) => setTimeRange(v as any)}>
          <SelectTrigger className="w-28 h-8 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7d">7 dias</SelectItem>
            <SelectItem value="30d">30 dias</SelectItem>
            <SelectItem value="90d">90 dias</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Metric Cards - Compact */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 md:gap-3">
        {metricCards.map((metric, i) => (
          <motion.div
            key={metric.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
          >
            <Card className="bg-card/50 backdrop-blur border-border/50">
              <CardContent className="p-3 md:p-4">
                <div className="flex items-start justify-between">
                  <div className="min-w-0 flex-1">
                    <p className="text-[10px] md:text-xs text-muted-foreground truncate">{metric.label}</p>
                    <p className={cn('text-xl md:text-2xl font-bold', metric.color)}>{metric.value}</p>
                    {metric.subtext && (
                      <p className="text-[10px] md:text-xs text-muted-foreground">{metric.subtext}</p>
                    )}
                    {metric.change !== undefined && (
                      <div className="flex items-center gap-0.5 mt-0.5">
                        {metric.change > 0 ? (
                          <TrendingUp className="w-2.5 h-2.5 md:w-3 md:h-3 text-success" />
                        ) : (
                          <TrendingDown className="w-2.5 h-2.5 md:w-3 md:h-3 text-destructive" />
                        )}
                        <span className={cn('text-[10px] md:text-xs', metric.change > 0 ? 'text-success' : 'text-destructive')}>
                          {metric.change > 0 ? '+' : ''}{Math.round(metric.change)}%
                        </span>
                      </div>
                    )}
                  </div>
                  <metric.icon className={cn('w-4 h-4 md:w-5 md:h-5 shrink-0', metric.color)} />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Alerts */}
      {(insights.neglectedMuscles.length > 0 || insights.overtrainedMuscles.length > 0) && (
        <Card className="bg-warning/10 border-warning/30">
          <CardContent className="p-4 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-warning shrink-0 mt-0.5" />
            <div className="text-sm">
              {insights.neglectedMuscles.length > 0 && (
                <p><strong>Músculos negligenciados:</strong> {insights.neglectedMuscles.join(', ')}</p>
              )}
              {insights.overtrainedMuscles.length > 0 && (
                <p><strong>Alto volume:</strong> {insights.overtrainedMuscles.join(', ')}</p>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Content Tabs - Scrollable on mobile */}
      <Tabs defaultValue="volume" className="space-y-3 md:space-y-4">
        <div className="overflow-x-auto -mx-3 px-3 scrollbar-hide md:mx-0 md:px-0">
          <TabsList className="inline-flex w-auto min-w-full md:grid md:w-full md:grid-cols-4 gap-1">
            <TabsTrigger value="volume" className="flex-shrink-0 text-xs md:text-sm px-3">
              <BarChart3 className="w-3.5 h-3.5 md:w-4 md:h-4 mr-1" /> Volume
            </TabsTrigger>
            <TabsTrigger value="strength" className="flex-shrink-0 text-xs md:text-sm px-3">
              <Trophy className="w-3.5 h-3.5 md:w-4 md:h-4 mr-1" /> Força
            </TabsTrigger>
            <TabsTrigger value="muscles" className="flex-shrink-0 text-xs md:text-sm px-3">
              <Zap className="w-3.5 h-3.5 md:w-4 md:h-4 mr-1" /> Músculos
            </TabsTrigger>
            <TabsTrigger value="consistency" className="flex-shrink-0 text-xs md:text-sm px-3">
              <Calendar className="w-3.5 h-3.5 md:w-4 md:h-4 mr-1" /> Frequência
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="volume">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base md:text-lg">Volume Semanal</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {insights.weeklyVolume.length > 0 ? (
                <div className="h-48 md:h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={insights.weeklyVolume}>
                      <XAxis dataKey="label" tick={{ fontSize: 10 }} />
                      <YAxis tick={{ fontSize: 10 }} />
                      <Tooltip formatter={(v: number) => [`${Math.round(v)}kg`, 'Volume']} />
                      <Bar dataKey="volume" fill="hsl(var(--accent))" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <p className="text-center py-6 text-muted-foreground text-sm">Sem dados de volume</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="strength">
          <Card>
            <CardHeader><CardTitle>Progressão de Força</CardTitle></CardHeader>
            <CardContent>
              <StrengthProgressionChart data={insights.strengthProgress} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="muscles">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Distribuição Muscular</CardTitle>
                <span className="text-sm text-muted-foreground">
                  Equilíbrio: <span className={cn(
                    insights.balanceScore >= 70 ? 'text-success' : 'text-warning'
                  )}>{insights.balanceScore}%</span>
                </span>
              </div>
            </CardHeader>
            <CardContent>
              <MuscleHeatMap data={insights.muscleGroups} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="consistency">
          <Card>
            <CardHeader><CardTitle>Calendário de Atividade</CardTitle></CardHeader>
            <CardContent>
              <ConsistencyCalendar data={insights.consistencyCalendar} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
