'use client';

import Reveal from '@/components/animations/Reveal';
import { motion } from 'framer-motion';
import { ArrowRight, Zap, Shield, Heart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function SalesCTA() {
  const navigate = useNavigate();

  return (
    <section className="py-32 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-accent/20 via-bg to-primary/20" />
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-transparent via-accent/10 to-transparent"
        animate={{
          x: ['-100%', '100%'],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      
      {/* Grid Pattern */}
      <div className="absolute inset-0 bg-grid-pattern opacity-[0.03]" />
      
      {/* Floating Elements */}
      <motion.div
        className="absolute top-1/4 left-10 w-32 h-32 bg-accent/20 rounded-full blur-2xl"
        animate={{
          scale: [1, 1.5, 1],
          opacity: [0.2, 0.4, 0.2],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
        }}
      />
      <motion.div
        className="absolute bottom-1/4 right-10 w-40 h-40 bg-primary/20 rounded-full blur-2xl"
        animate={{
          scale: [1.5, 1, 1.5],
          opacity: [0.3, 0.1, 0.3],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
        }}
      />

      <div className="container mx-auto px-6 relative">
        <Reveal>
          <div className="max-w-4xl mx-auto text-center">
            {/* Main CTA Content */}
            <motion.div
              className="glass-card p-12 md:p-16 relative overflow-hidden"
              whileHover={{ scale: 1.02 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              {/* Card Background Effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-accent/10 via-transparent to-primary/10" />
              
              {/* Badge */}
              <motion.div
                className="inline-flex items-center gap-2 px-4 py-2 bg-accent/20 backdrop-blur-sm rounded-full text-accent text-sm font-medium mb-8"
                initial={{ scale: 0.8, opacity: 0 }}
                whileInView={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.2 }}
              >
                <Zap className="w-4 h-4" />
                Oferta Limitada - Primeiros 1000 Usuários
              </motion.div>

              {/* Main Headline */}
              <motion.h2
                className="text-4xl md:text-6xl font-bold text-white mb-6"
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
              >
                Sua Transformação
                <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent to-primary">
                  Começa Agora
                </span>
              </motion.h2>

              {/* Description */}
              <motion.p
                className="text-xl text-txt-2 mb-12 max-w-2xl mx-auto leading-relaxed"
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.4 }}
              >
                Não deixe para amanhã o que pode transformar sua vida hoje. 
                Junte-se a milhares de pessoas que já descobriram o poder do treino inteligente.
              </motion.p>

              {/* Trust Elements */}
              <motion.div
                className="flex flex-wrap justify-center gap-8 mb-12"
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                <div className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-green-500" />
                  <span className="text-txt-2">Garantia 30 dias</span>
                </div>
                <div className="flex items-center gap-2">
                  <Heart className="w-5 h-5 text-red-500" />
                  <span className="text-txt-2">Suporte dedicado</span>
                </div>
                <div className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-accent" />
                  <span className="text-txt-2">Resultados rápidos</span>
                </div>
              </motion.div>

              {/* CTA Buttons */}
              <motion.div
                className="flex flex-col sm:flex-row gap-4 justify-center"
                initial={{ y: 20, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.6 }}
              >
                <motion.button
                  onClick={() => navigate('/auth')}
                  className="group relative px-8 py-4 bg-gradient-to-r from-accent to-primary text-bg font-bold rounded-2xl text-lg overflow-hidden"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {/* Button Background Effect */}
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-primary to-accent opacity-0 group-hover:opacity-100"
                    transition={{ duration: 0.3 }}
                  />
                  
                  <span className="relative flex items-center gap-2">
                    Começar Grátis Agora
                    <motion.div
                      animate={{ x: [0, 5, 0] }}
                      transition={{ duration: 1, repeat: Infinity }}
                    >
                      <ArrowRight className="w-5 h-5" />
                    </motion.div>
                  </span>
                  
                  {/* Shine Effect */}
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12"
                    animate={{ x: ['-100%', '200%'] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                  />
                </motion.button>

                <motion.button
                  onClick={() => {
                    const element = document.getElementById('pricing');
                    if (element) {
                      element.scrollIntoView({ behavior: 'smooth' });
                    }
                  }}
                  className="px-8 py-4 border-2 border-accent/50 text-accent hover:bg-accent/10 font-semibold rounded-2xl text-lg transition-all duration-300"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Ver Planos Premium
                </motion.button>
              </motion.div>

              {/* Small Print */}
              <motion.p
                className="text-xs text-txt-3 mt-6"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ delay: 0.8 }}
              >
                ✓ Sem compromisso • ✓ Cancele quando quiser • ✓ Dados seguros
              </motion.p>
            </motion.div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}