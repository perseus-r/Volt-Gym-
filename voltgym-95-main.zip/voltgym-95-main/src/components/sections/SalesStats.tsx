'use client';

import Reveal from '@/components/animations/Reveal';
import { Stagger, Item } from '@/components/animations/Stagger';
import { motion } from 'framer-motion';
import { TrendingUp, Users, Target, Zap } from 'lucide-react';

const stats = [
  {
    icon: Users,
    value: "50K+",
    label: "Usuários Ativos",
    description: "Pessoas transformando suas vidas",
    color: "from-accent to-accent/70"
  },
  {
    icon: Target,
    value: "90%",
    label: "Taxa de Sucesso",
    description: "Atingem suas metas de fitness",
    color: "from-primary to-primary/70"
  },
  {
    icon: TrendingUp,
    value: "2.5x",
    label: "Melhora Média",
    description: "Em força e resistência",
    color: "from-accent to-primary"
  },
  {
    icon: Zap,
    value: "15min",
    label: "Setup Médio",
    description: "Para treinar em qualquer lugar",
    color: "from-primary to-accent"
  }
];

export default function SalesStats() {
  return (
    <section className="py-24 bg-gradient-to-b from-bg to-surface/30 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-grid-pattern opacity-[0.02]" />
      <motion.div
        className="absolute top-20 left-1/4 w-64 h-64 bg-accent/10 rounded-full blur-3xl"
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.5, 0.3],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      
      <div className="container mx-auto px-6 relative">
        <Stagger>
          {/* Header */}
          <Item>
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
                Resultados que
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent to-primary ml-3">
                  Falam por Si
                </span>
              </h2>
              <p className="text-txt-2 text-lg max-w-2xl mx-auto">
                Milhares de pessoas já transformaram suas vidas com nossa plataforma.
                Seus dados são a prova do nosso compromisso.
              </p>
            </div>
          </Item>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <Item key={index}>
                <motion.div
                  className="glass-card p-8 text-center group relative overflow-hidden"
                  whileHover={{ 
                    scale: 1.05,
                    rotateY: 5,
                  }}
                  transition={{ 
                    type: "spring", 
                    stiffness: 300, 
                    damping: 20 
                  }}
                >
                  {/* Gradient Background */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-10 transition-opacity duration-500`} />
                  
                  {/* Icon */}
                  <motion.div
                    className={`w-16 h-16 mx-auto mb-6 rounded-2xl bg-gradient-to-br ${stat.color} p-4 relative`}
                    whileHover={{ rotate: 360 }}
                    transition={{ duration: 0.6 }}
                  >
                    <stat.icon className="w-full h-full text-white" />
                    
                    {/* Glow Effect */}
                    <motion.div
                      className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${stat.color} blur-xl opacity-0 group-hover:opacity-50`}
                      transition={{ duration: 0.3 }}
                    />
                  </motion.div>

                  {/* Value */}
                  <motion.div
                    className="text-4xl md:text-5xl font-bold text-white mb-2"
                    initial={{ scale: 0.8 }}
                    whileInView={{ scale: 1 }}
                    transition={{ 
                      type: "spring",
                      stiffness: 200,
                      delay: index * 0.1
                    }}
                  >
                    {stat.value}
                  </motion.div>

                  {/* Label */}
                  <h3 className="text-lg font-semibold text-white mb-2">
                    {stat.label}
                  </h3>

                  {/* Description */}
                  <p className="text-txt-2 text-sm leading-relaxed">
                    {stat.description}
                  </p>

                  {/* Floating Particles */}
                  <motion.div
                    className="absolute top-4 right-4 w-2 h-2 bg-accent rounded-full"
                    animate={{
                      y: [-10, 10, -10],
                      opacity: [0.3, 1, 0.3],
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                      delay: index * 0.2,
                    }}
                  />
                </motion.div>
              </Item>
            ))}
          </div>

          {/* Trust Indicators */}
          <Item>
            <motion.div
              className="mt-20 text-center"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
            >
              <div className="flex flex-wrap justify-center items-center gap-8 opacity-60">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
                  <span className="text-sm text-txt-2">99.9% Uptime</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse" />
                  <span className="text-sm text-txt-2">Dados Criptografados</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-purple-500 rounded-full animate-pulse" />
                  <span className="text-sm text-txt-2">Suporte 24/7</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-yellow-500 rounded-full animate-pulse" />
                  <span className="text-sm text-txt-2">Garantia 30 dias</span>
                </div>
              </div>
            </motion.div>
          </Item>
        </Stagger>
      </div>
    </section>
  );
}