import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LucideIcon, Plus, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { HapticFeedback } from './HapticFeedback';

interface FABAction {
  icon: LucideIcon;
  label: string;
  onClick: () => void;
  variant?: 'default' | 'success' | 'warning' | 'error';
}

interface FloatingActionButtonProps {
  icon?: LucideIcon;
  actions?: FABAction[];
  position?: 'bottom-right' | 'bottom-left' | 'bottom-center';
  variant?: 'default' | 'premium' | 'gradient';
  size?: 'md' | 'lg';
  className?: string;
}

export function FloatingActionButton({
  icon: Icon = Plus,
  actions = [],
  position = 'bottom-right',
  variant = 'premium',
  size = 'lg',
  className
}: FloatingActionButtonProps) {
  const [isOpen, setIsOpen] = useState(false);

  const positionStyles = {
    'bottom-right': 'bottom-20 right-6',
    'bottom-left': 'bottom-20 left-6',
    'bottom-center': 'bottom-20 left-1/2 -translate-x-1/2',
  };

  const variantStyles = {
    default: 'bg-accent text-accent-ink shadow-xl shadow-accent/40',
    premium: 'bg-gradient-to-br from-accent via-accent-2 to-accent text-accent-ink shadow-2xl shadow-accent/60',
    gradient: 'bg-gradient-to-r from-accent via-purple-500 to-accent-2 text-white shadow-2xl shadow-purple-500/50',
  };

  const sizeStyles = {
    md: 'w-14 h-14',
    lg: 'w-16 h-16',
  };

  const handleMainClick = () => {
    if (actions.length > 0) {
      setIsOpen(!isOpen);
    }
  };

  return (
    <>
      {/* Backdrop */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsOpen(false)}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40"
          />
        )}
      </AnimatePresence>

      {/* Action Menu */}
      <AnimatePresence>
        {isOpen && actions.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className={cn(
              'fixed z-50 flex flex-col gap-3',
              position === 'bottom-right' && 'bottom-36 right-6',
              position === 'bottom-left' && 'bottom-36 left-6',
              position === 'bottom-center' && 'bottom-36 left-1/2 -translate-x-1/2'
            )}
          >
            {actions.map((action, index) => {
              const ActionIcon = action.icon;
              const actionVariant = action.variant || 'default';

              const actionColors = {
                default: 'bg-surface text-txt',
                success: 'bg-success/20 text-success border-success/30',
                warning: 'bg-warning/20 text-warning border-warning/30',
                error: 'bg-error/20 text-error border-error/30',
              };

              return (
                <motion.div
                  key={index}
                  initial={{ scale: 0, y: 20 }}
                  animate={{ scale: 1, y: 0 }}
                  exit={{ scale: 0, y: 20 }}
                  transition={{
                    delay: index * 0.05,
                    type: 'spring',
                    stiffness: 300,
                    damping: 20
                  }}
                  className="flex items-center gap-3"
                >
                  {/* Label */}
                  <motion.span
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ delay: index * 0.05 + 0.1 }}
                    className="px-3 py-2 rounded-xl glass-ultra text-sm font-semibold text-txt whitespace-nowrap"
                  >
                    {action.label}
                  </motion.span>

                  {/* Button */}
                  <HapticFeedback intensity="medium">
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => {
                        action.onClick();
                        setIsOpen(false);
                      }}
                      className={cn(
                        'w-12 h-12 rounded-full',
                        'flex items-center justify-center',
                        'border backdrop-blur-xl',
                        'shadow-lg transition-all duration-200',
                        actionColors[actionVariant]
                      )}
                    >
                      <ActionIcon className="w-5 h-5" strokeWidth={2.5} />
                    </motion.button>
                  </HapticFeedback>
                </motion.div>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main FAB */}
      <HapticFeedback intensity="heavy">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleMainClick}
          className={cn(
            'fixed z-50',
            'rounded-full',
            'flex items-center justify-center',
            'transition-all duration-300',
            positionStyles[position],
            variantStyles[variant],
            sizeStyles[size],
            className
          )}
        >
          {/* Rotating icon */}
          <motion.div
            animate={{ rotate: isOpen ? 45 : 0 }}
            transition={{ type: 'spring', stiffness: 200, damping: 15 }}
          >
            {isOpen && actions.length > 0 ? (
              <X className="w-6 h-6" strokeWidth={2.5} />
            ) : (
              <Icon className="w-6 h-6" strokeWidth={2.5} />
            )}
          </motion.div>

          {/* Ripple effect */}
          <motion.div
            className="absolute inset-0 rounded-full"
            initial={{ scale: 1, opacity: 0.5 }}
            animate={{
              scale: [1, 1.5, 1],
              opacity: [0.5, 0, 0.5],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: 'easeInOut'
            }}
            style={{
              background: variant === 'premium' 
                ? 'radial-gradient(circle, hsl(var(--accent)) 0%, transparent 70%)'
                : 'radial-gradient(circle, currentColor 0%, transparent 70%)'
            }}
          />
        </motion.button>
      </HapticFeedback>
    </>
  );
}
