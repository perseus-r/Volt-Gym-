import { motion } from 'framer-motion';
import { ShoppingBag, ChevronRight, Package, Star } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { AnimatedWidget } from './AnimatedWidget';
import { AnimatedIconContainer, AnimatedIcon } from './AnimatedIcon';
import { AnimatedCounter } from './AnimatedCounter';

export const LojaWidget = () => {
  const navigate = useNavigate();

  const { data: stats } = useQuery({
    queryKey: ['lojaStats'],
    queryFn: async () => {
      const { count: totalProducts } = await supabase
        .from('products')
        .select('*', { count: 'exact', head: true })
        .eq('is_active', true);

      const { count: featuredProducts } = await supabase
        .from('products')
        .select('*', { count: 'exact', head: true })
        .eq('is_active', true)
        .eq('featured', true);

      return {
        total: totalProducts || 0,
        featured: featuredProducts || 0
      };
    }
  });

  return (
    <AnimatedWidget onClick={() => navigate('/loja')} glowColor="indigo">
      <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/8 to-transparent" />

      <div className="relative">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <AnimatedIconContainer 
              Icon={ShoppingBag} 
              color="text-indigo-400"
              bgGradient="from-indigo-500/20 to-indigo-500/10"
              borderColor="border-indigo-500/20"
            />
            <motion.span 
              className="font-semibold text-sm"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
            >
              Loja VOLT
            </motion.span>
          </div>
          <motion.div
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </motion.div>
        </div>

        <motion.div 
          className="space-y-2"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
        >
          <div className="flex items-center gap-2">
            <AnimatedIcon Icon={Package} size="sm" color="text-muted-foreground" delay={0.2} />
            <AnimatedCounter 
              value={stats?.total || 0} 
              className="text-lg font-bold" 
              delay={0.25}
            />
            <span className="text-xs text-muted-foreground">produtos</span>
          </div>
          
          {(stats?.featured || 0) > 0 && (
            <motion.div 
              className="flex items-center gap-1.5 text-xs text-muted-foreground"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
            >
              <AnimatedIcon Icon={Star} size="sm" color="text-amber-400" delay={0.35} />
              <span><AnimatedCounter value={stats?.featured || 0} delay={0.4} /> em destaque</span>
            </motion.div>
          )}
        </motion.div>

        <motion.div 
          className="mt-3 pt-2 border-t border-border/30"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.35 }}
        >
          <span className="text-xs text-indigo-400 font-medium">Ver produtos →</span>
        </motion.div>
      </div>
    </AnimatedWidget>
  );
};
