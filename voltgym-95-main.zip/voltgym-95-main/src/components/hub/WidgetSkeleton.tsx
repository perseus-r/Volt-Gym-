import React from 'react';
import { motion } from 'framer-motion';

interface WidgetSkeletonProps {
  variant?: 'default' | 'compact' | 'large';
}

export function WidgetSkeleton({ variant = 'default' }: WidgetSkeletonProps) {
  const heights = {
    default: 'h-32',
    compact: 'h-24',
    large: 'h-44'
  };

  return (
    <div className={`relative overflow-hidden rounded-2xl bg-card/30 border border-border/30 p-4 ${heights[variant]}`}>
      {/* Shimmer overlay */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent"
        animate={{ x: ['-100%', '200%'] }}
        transition={{ 
          duration: 1.5, 
          repeat: Infinity, 
          ease: 'linear',
          repeatDelay: 0.5
        }}
      />

      {/* Skeleton content */}
      <div className="space-y-3">
        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-muted/30 animate-pulse" />
          <div className="h-4 w-20 rounded-md bg-muted/30 animate-pulse" />
        </div>

        {/* Content */}
        {variant !== 'compact' && (
          <>
            <div className="h-3 w-3/4 rounded-md bg-muted/20 animate-pulse" />
            <div className="h-3 w-1/2 rounded-md bg-muted/20 animate-pulse" />
          </>
        )}

        {variant === 'large' && (
          <>
            <div className="h-2 w-full rounded-full bg-muted/20 animate-pulse mt-4" />
            <div className="flex gap-2 mt-2">
              <div className="h-6 w-16 rounded-md bg-muted/20 animate-pulse" />
              <div className="h-6 w-16 rounded-md bg-muted/20 animate-pulse" />
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// Grid skeleton for dashboard
export function DashboardSkeleton() {
  return (
    <div className="space-y-3 px-4">
      <WidgetSkeleton variant="large" />
      <div className="grid grid-cols-2 gap-3">
        <WidgetSkeleton />
        <WidgetSkeleton />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <WidgetSkeleton variant="compact" />
        <WidgetSkeleton variant="compact" />
      </div>
    </div>
  );
}
