import React from 'react';
import { motion } from 'framer-motion';
import { Dumbbell, ChevronRight, Calendar, User, Clock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useAssignedWorkouts } from '@/hooks/useAssignedWorkouts';
import { hapticLight } from '@/utils/haptics';
import { AnimatedWidget } from './AnimatedWidget';
import { AnimatedIconContainer, AnimatedIcon } from './AnimatedIcon';
import { format, parseISO, isToday, isTomorrow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export function CoachAssignedWidget() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { workouts } = useAssignedWorkouts(user?.id);

  const pendingWorkouts = workouts.filter(w => w.status === 'pending' || w.status === 'assigned');
  const nextWorkout = pendingWorkouts[0];

  const getDateLabel = (dateStr: string | null) => {
    if (!dateStr) return null;
    const date = parseISO(dateStr);
    if (isToday(date)) return 'Hoje';
    if (isTomorrow(date)) return 'Amanhã';
    return format(date, "dd/MM", { locale: ptBR });
  };

  const handleClick = () => {
    hapticLight();
    navigate('/athlete/workouts');
  };

  return (
    <AnimatedWidget onClick={handleClick} glowColor="orange">
      {/* Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-orange-500/10 to-transparent" />

      <div className="relative">
        {/* Header */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <AnimatedIconContainer 
              Icon={Dumbbell} 
              color="text-orange-400"
              bgGradient="from-orange-500/20 to-amber-500/20"
              borderColor="border-orange-500/20"
            />
            <motion.span 
              className="font-semibold text-sm text-foreground"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
            >
              Treinos do PT
            </motion.span>
          </div>
          
          {/* Badge */}
          {pendingWorkouts.length > 0 && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', stiffness: 500, damping: 20, delay: 0.2 }}
              className="flex items-center justify-center h-5 min-w-5 px-1.5 rounded-full bg-orange-500 text-white text-xs font-bold"
            >
              {pendingWorkouts.length}
            </motion.div>
          )}
          
          <motion.div
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </motion.div>
        </div>

        {/* Content */}
        <motion.div 
          className="space-y-1"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
        >
          {nextWorkout ? (
            <>
              <div className="flex items-center gap-2">
                <AnimatedIcon Icon={Calendar} size="sm" color="text-orange-400" delay={0.2} />
                <span className="text-xs text-muted-foreground">
                  Próximo: <span className="text-foreground font-medium">
                    {getDateLabel(nextWorkout.scheduled_date)}
                  </span>
                </span>
              </div>
              <div className="flex items-center gap-2">
                <AnimatedIcon Icon={Clock} size="sm" color="text-muted-foreground" delay={0.25} />
                <span className="text-xs text-muted-foreground truncate">
                  Treino personalizado
                </span>
              </div>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <AnimatedIcon Icon={User} size="sm" color="text-muted-foreground" delay={0.2} />
              <span className="text-xs text-muted-foreground">
                Nenhum treino pendente
              </span>
            </div>
          )}
        </motion.div>

        {/* CTA */}
        <motion.div 
          className="mt-3 flex items-center gap-1.5 text-orange-400"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <span className="text-xs font-medium">Ver treinos</span>
          <AnimatedIcon Icon={Dumbbell} size="sm" color="text-orange-400" delay={0.35} />
        </motion.div>
      </div>
    </AnimatedWidget>
  );
}
