import React from 'react';
import { motion, TargetAndTransition } from 'framer-motion';
import { LucideIcon } from 'lucide-react';

interface AnimatedIconProps {
  Icon: LucideIcon;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  color?: string;
  animate?: 'bounce' | 'pulse' | 'spin' | 'none';
  delay?: number;
}

const sizeMap = {
  sm: 'w-3.5 h-3.5',
  md: 'w-4 h-4',
  lg: 'w-5 h-5'
};

export function AnimatedIcon({ 
  Icon, 
  className = '', 
  size = 'md',
  color,
  animate = 'bounce',
  delay = 0
}: AnimatedIconProps) {
  const iconClass = `${sizeMap[size]} ${color || ''} ${className}`;

  // Animation configs
  const getAnimationProps = () => {
    switch (animate) {
      case 'bounce':
        return {
          initial: { scale: 0.5, opacity: 0, y: 5 },
          animate: { scale: 1, opacity: 1, y: 0 } as TargetAndTransition,
          transition: { type: 'spring' as const, stiffness: 400, damping: 15, delay },
          whileHover: { scale: 1.2, rotate: [0, -10, 10, 0] }
        };
      case 'pulse':
        return {
          initial: { scale: 0.8, opacity: 0 },
          animate: { scale: [1, 1.1, 1], opacity: 1 } as TargetAndTransition,
          transition: { 
            scale: { duration: 2, repeat: Infinity, ease: 'easeInOut' as const },
            opacity: { duration: 0.3, delay }
          }
        };
      case 'spin':
        return {
          initial: { rotate: 0, opacity: 0 },
          animate: { rotate: 360, opacity: 1 } as TargetAndTransition,
          transition: { 
            rotate: { duration: 2, repeat: Infinity, ease: 'linear' as const },
            opacity: { duration: 0.3, delay }
          }
        };
      default:
        return {
          initial: { opacity: 0 },
          animate: { opacity: 1 } as TargetAndTransition,
          transition: { duration: 0.3, delay }
        };
    }
  };

  const animationProps = getAnimationProps();

  return (
    <motion.div
      initial={animationProps.initial}
      animate={animationProps.animate}
      transition={animationProps.transition}
      whileHover={animationProps.whileHover}
      className="inline-flex"
    >
      <Icon className={iconClass} />
    </motion.div>
  );
}

// Icon container with background
interface AnimatedIconContainerProps extends AnimatedIconProps {
  bgGradient?: string;
  borderColor?: string;
}

export function AnimatedIconContainer({
  Icon,
  className = '',
  size = 'md',
  color,
  animate = 'bounce',
  delay = 0,
  bgGradient = 'from-violet-500/20 to-purple-500/20',
  borderColor = 'border-violet-500/20'
}: AnimatedIconContainerProps) {
  return (
    <motion.div 
      className={`w-8 h-8 rounded-xl bg-gradient-to-br ${bgGradient} border ${borderColor} flex items-center justify-center`}
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ 
        type: 'spring' as const, 
        stiffness: 400, 
        damping: 20,
        delay 
      }}
      whileHover={{ 
        scale: 1.1,
        transition: { type: 'spring' as const, stiffness: 400 }
      }}
    >
      <AnimatedIcon 
        Icon={Icon} 
        className={className} 
        size={size} 
        color={color}
        animate={animate}
        delay={delay + 0.1}
      />
    </motion.div>
  );
}
