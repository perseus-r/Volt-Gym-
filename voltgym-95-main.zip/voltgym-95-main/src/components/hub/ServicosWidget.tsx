import { motion } from 'framer-motion';
import { Users, ChevronRight, Calendar, Star } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { AnimatedWidget } from './AnimatedWidget';
import { AnimatedIconContainer, AnimatedIcon } from './AnimatedIcon';
import { AnimatedCounter } from './AnimatedCounter';

export const ServicosWidget = () => {
  const navigate = useNavigate();

  const { data: stats } = useQuery({
    queryKey: ['servicosStats'],
    queryFn: async () => {
      const { data: professionals, count } = await supabase
        .from('professionals')
        .select('rating', { count: 'exact' })
        .eq('is_active', true);

      const avgRating = professionals?.length 
        ? professionals.reduce((sum, p) => sum + (p.rating || 0), 0) / professionals.length
        : 0;

      return {
        count: count || 0,
        avgRating: avgRating
      };
    }
  });

  const specialties = ['Personal', 'Nutricionista', 'Fisio'];

  return (
    <AnimatedWidget onClick={() => navigate('/servicos')} glowColor="teal">
      <div className="absolute inset-0 bg-gradient-to-br from-teal-500/8 to-transparent" />

      <div className="relative">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <AnimatedIconContainer 
              Icon={Users} 
              color="text-teal-400"
              bgGradient="from-teal-500/20 to-teal-500/10"
              borderColor="border-teal-500/20"
            />
            <motion.span 
              className="font-semibold text-sm"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
            >
              Serviços
            </motion.span>
          </div>
          <motion.div
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </motion.div>
        </div>

        <motion.div 
          className="space-y-2"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
        >
          <div className="flex items-center gap-2">
            <AnimatedIcon Icon={Calendar} size="sm" color="text-muted-foreground" delay={0.2} />
            <AnimatedCounter 
              value={stats?.count || 0} 
              className="text-lg font-bold" 
              delay={0.25}
            />
            <span className="text-xs text-muted-foreground">profissionais</span>
          </div>
          
          {(stats?.avgRating || 0) > 0 && (
            <motion.div 
              className="flex items-center gap-1.5 text-xs text-muted-foreground"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
            >
              <AnimatedIcon Icon={Star} size="sm" color="text-amber-400" delay={0.35} />
              <span>Avaliação média: <AnimatedCounter value={stats?.avgRating || 0} decimals={1} delay={0.4} /></span>
            </motion.div>
          )}
        </motion.div>

        <motion.div 
          className="mt-3 pt-2 border-t border-border/30"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.35 }}
        >
          <div className="flex flex-wrap gap-1">
            {specialties.map((s, i) => (
              <motion.span 
                key={s} 
                className="text-[10px] px-1.5 py-0.5 bg-teal-500/10 text-teal-400 rounded"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.4 + i * 0.05 }}
              >
                {s}
              </motion.span>
            ))}
          </div>
        </motion.div>
      </div>
    </AnimatedWidget>
  );
};
