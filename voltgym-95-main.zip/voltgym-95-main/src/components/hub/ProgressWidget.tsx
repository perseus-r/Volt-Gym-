import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, ChevronRight, ArrowUp, Target } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { hapticLight } from '@/utils/haptics';
import { AnimatedWidget } from './AnimatedWidget';
import { AnimatedIconContainer, AnimatedIcon } from './AnimatedIcon';
import { AnimatedCounter } from './AnimatedCounter';

export function ProgressWidget() {
  const navigate = useNavigate();
  const { user } = useAuth();

  // Fetch recent PRs
  const { data: recentPRs } = useQuery({
    queryKey: ['recentPRs', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      
      const { data } = await supabase
        .from('personal_records')
        .select('id, weight, achieved_at, exercises(name)')
        .eq('user_id', user.id)
        .gte('achieved_at', thirtyDaysAgo.toISOString())
        .order('achieved_at', { ascending: false })
        .limit(3);
      
      return data || [];
    },
    enabled: !!user?.id
  });

  // Fetch workout count this month
  const { data: monthlyWorkouts } = useQuery({
    queryKey: ['monthlyWorkouts', user?.id],
    queryFn: async () => {
      if (!user?.id) return 0;
      const startOfMonth = new Date();
      startOfMonth.setDate(1);
      startOfMonth.setHours(0, 0, 0, 0);
      
      const { count } = await supabase
        .from('workout_sessions')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .not('completed_at', 'is', null)
        .gte('completed_at', startOfMonth.toISOString());
      return count || 0;
    },
    enabled: !!user?.id
  });

  const handleClick = () => {
    hapticLight();
    navigate('/progresso');
  };

  const latestPR = recentPRs?.[0];
  const exerciseName = (latestPR?.exercises as any)?.name;

  return (
    <AnimatedWidget onClick={handleClick} glowColor="emerald">
      {/* Subtle gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/8 to-transparent" />

      <div className="relative">
        {/* Header */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <AnimatedIconContainer 
              Icon={TrendingUp} 
              color="text-emerald-400"
              bgGradient="from-emerald-500/20 to-teal-500/20"
              borderColor="border-emerald-500/20"
            />
            <motion.span 
              className="font-semibold text-sm text-foreground"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
            >
              Progresso
            </motion.span>
          </div>
          <motion.div
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </motion.div>
        </div>

        {/* Main stat */}
        <motion.div 
          className="mb-2"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
        >
          <div className="flex items-baseline gap-2">
            <AnimatedCounter 
              value={monthlyWorkouts || 0} 
              className="text-2xl font-bold text-foreground" 
              delay={0.2}
            />
            <span className="text-xs text-muted-foreground">treinos este mês</span>
          </div>
        </motion.div>

        {/* Recent PR */}
        {latestPR && exerciseName && (
          <motion.div 
            className="flex items-center gap-2 p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.25, type: 'spring', stiffness: 300 }}
          >
            <AnimatedIcon Icon={ArrowUp} size="sm" color="text-emerald-400" delay={0.3} />
            <span className="text-xs text-emerald-400">
              Novo PR: {exerciseName} • {latestPR.weight}kg
            </span>
          </motion.div>
        )}

        {!latestPR && (
          <motion.div 
            className="flex items-center gap-2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.25 }}
          >
            <AnimatedIcon Icon={Target} size="sm" color="text-muted-foreground" delay={0.3} />
            <span className="text-xs text-muted-foreground">
              Continue treinando para quebrar PRs!
            </span>
          </motion.div>
        )}
      </div>
    </AnimatedWidget>
  );
}
