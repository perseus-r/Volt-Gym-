import React from 'react';
import { motion } from 'framer-motion';
import { Activity } from 'lucide-react';

export interface DayActivity {
  day: string;
  completed: boolean;
  intensity: number; // 0-100
}

interface WeeklyActivityWidgetProps {
  days: DayActivity[];
  className?: string;
}

export function WeeklyActivityWidget({ days, className = '' }: WeeklyActivityWidgetProps) {
  const completedDays = days.filter(d => d.completed).length;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: "spring", stiffness: 400, damping: 30, delay: 0.15 }}
      className={`relative overflow-hidden rounded-xl bg-card/50 border border-border/50 p-3 ${className}`}
      style={{
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
      }}
    >
      {/* Subtle gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 to-transparent" />
      
      <div className="relative flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5">
          <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-500 flex items-center justify-center">
            <Activity className="w-3 h-3 text-white" />
          </div>
          <span className="font-semibold text-foreground text-xs">Atividade</span>
        </div>
        <div className="flex items-center gap-1 px-1.5 py-0.5 bg-emerald-500/10 rounded-full">
          <span className="text-[10px] text-emerald-500 font-semibold">{completedDays}/7</span>
        </div>
      </div>

      {/* Activity bars - COMPACT */}
      <div className="relative flex items-end justify-between gap-1.5 h-10">
        {days.map((day, index) => (
          <div key={index} className="flex-1 flex flex-col items-center gap-1">
            <div 
              className="w-full rounded-full overflow-hidden bg-muted/30"
              style={{ height: '28px' }}
            >
              <motion.div
                className="w-full rounded-full"
                initial={{ height: 0 }}
                animate={{ height: `${day.completed ? Math.max(day.intensity, 30) : 12}%` }}
                transition={{ 
                  duration: 0.5, 
                  delay: 0.3 + index * 0.06, 
                  ease: [0.4, 0, 0.2, 1]
                }}
                style={{
                  background: day.completed 
                    ? 'linear-gradient(180deg, #34d399 0%, #10b981 100%)' 
                    : 'hsl(var(--muted))',
                }}
              />
            </div>
            <span 
              className={`text-[9px] font-medium ${day.completed ? 'text-emerald-500' : 'text-muted-foreground'}`}
            >
              {day.day}
            </span>
          </div>
        ))}
      </div>
    </motion.div>
  );
}
