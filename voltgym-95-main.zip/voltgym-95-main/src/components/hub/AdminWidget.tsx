import { motion } from 'framer-motion';
import { Shield, ChevronRight, Users, Package, ShoppingCart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { AnimatedWidget } from './AnimatedWidget';
import { AnimatedIconContainer, AnimatedIcon } from './AnimatedIcon';
import { AnimatedCounter } from './AnimatedCounter';

export const AdminWidget = () => {
  const navigate = useNavigate();

  const { data: stats } = useQuery({
    queryKey: ['adminStats'],
    queryFn: async () => {
      const { count: usersCount } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true });

      const { count: productsCount } = await supabase
        .from('products')
        .select('*', { count: 'exact', head: true });

      const { count: pendingOrders } = await supabase
        .from('orders')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'pending');

      return {
        users: usersCount || 0,
        products: productsCount || 0,
        pendingOrders: pendingOrders || 0
      };
    }
  });

  return (
    <AnimatedWidget onClick={() => navigate('/admin')} glowColor="red">
      <div className="absolute inset-0 bg-gradient-to-br from-red-500/8 to-transparent" />

      <div className="relative">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <AnimatedIconContainer 
              Icon={Shield} 
              color="text-red-400"
              bgGradient="from-red-500/20 to-red-500/10"
              borderColor="border-red-500/20"
            />
            <motion.span 
              className="font-semibold text-sm"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
            >
              Admin
            </motion.span>
          </div>
          <motion.div
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </motion.div>
        </div>

        <motion.div 
          className="grid grid-cols-3 gap-2"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
        >
          <motion.div 
            className="text-center"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
          >
            <div className="flex items-center justify-center gap-1">
              <AnimatedIcon Icon={Users} size="sm" color="text-muted-foreground" delay={0.25} />
              <AnimatedCounter value={stats?.users || 0} className="text-sm font-bold" delay={0.3} />
            </div>
            <span className="text-[10px] text-muted-foreground">usuários</span>
          </motion.div>
          
          <motion.div 
            className="text-center"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.25 }}
          >
            <div className="flex items-center justify-center gap-1">
              <AnimatedIcon Icon={Package} size="sm" color="text-muted-foreground" delay={0.3} />
              <AnimatedCounter value={stats?.products || 0} className="text-sm font-bold" delay={0.35} />
            </div>
            <span className="text-[10px] text-muted-foreground">produtos</span>
          </motion.div>
          
          <motion.div 
            className="text-center"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
          >
            <div className="flex items-center justify-center gap-1">
              <AnimatedIcon Icon={ShoppingCart} size="sm" color="text-muted-foreground" delay={0.35} />
              <AnimatedCounter value={stats?.pendingOrders || 0} className="text-sm font-bold" delay={0.4} />
            </div>
            <span className="text-[10px] text-muted-foreground">pendentes</span>
          </motion.div>
        </motion.div>

        <motion.div 
          className="mt-3 pt-2 border-t border-border/30"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <span className="text-xs text-red-400 font-medium">Gerenciar →</span>
        </motion.div>
      </div>
    </AnimatedWidget>
  );
};
