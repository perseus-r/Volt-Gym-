import { motion } from 'framer-motion';
import { Sparkles, MessageCircle, Zap, Target, ChevronRight, Lightbulb, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { hapticLight } from '@/utils/haptics';

interface DailyInsight {
  type: 'tip' | 'suggestion' | 'alert' | 'achievement';
  title: string;
  message: string;
  action?: {
    label: string;
    path: string;
  };
}

interface DailyInsightsWidgetProps {
  userName?: string;
  insights: DailyInsight[];
  muscleRecovery?: {
    muscle: string;
    daysSinceTraining: number;
    status: 'recovered' | 'recovering' | 'sore';
  }[];
  suggestedWorkout?: string;
  isLoading?: boolean;
  className?: string;
}

export function DailyInsightsWidget({
  userName,
  insights = [],
  muscleRecovery = [],
  suggestedWorkout,
  isLoading = false,
  className = '',
}: DailyInsightsWidgetProps) {
  const navigate = useNavigate();

  const handleChatClick = () => {
    hapticLight();
    navigate('/ia-coach');
  };

  const getInsightIcon = (type: DailyInsight['type']) => {
    switch (type) {
      case 'tip':
        return <Lightbulb className="w-4 h-4" />;
      case 'suggestion':
        return <Target className="w-4 h-4" />;
      case 'alert':
        return <AlertCircle className="w-4 h-4" />;
      case 'achievement':
        return <Zap className="w-4 h-4" />;
      default:
        return <Sparkles className="w-4 h-4" />;
    }
  };

  const getInsightColor = (type: DailyInsight['type']) => {
    switch (type) {
      case 'tip':
        return 'text-blue-400 bg-blue-500/10 border-blue-500/20';
      case 'suggestion':
        return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
      case 'alert':
        return 'text-orange-400 bg-orange-500/10 border-orange-500/20';
      case 'achievement':
        return 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20';
      default:
        return 'text-primary bg-primary/10 border-primary/20';
    }
  };

  const getRecoveryStatus = (status: string) => {
    switch (status) {
      case 'recovered':
        return { color: 'bg-emerald-500', label: 'Recuperado' };
      case 'recovering':
        return { color: 'bg-yellow-500', label: 'Recuperando' };
      case 'sore':
        return { color: 'bg-red-500', label: 'Descansando' };
      default:
        return { color: 'bg-secondary', label: '' };
    }
  };

  // Skeleton loader
  if (isLoading) {
    return (
      <div className={`relative overflow-hidden rounded-2xl p-5 ${className}`}>
        <div className="absolute inset-0 bg-gradient-to-br from-violet-500/20 via-purple-500/15 to-indigo-500/20" />
        <div className="relative space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 animate-pulse" />
            <div className="flex-1 space-y-2">
              <div className="h-4 w-32 bg-white/10 rounded animate-pulse" />
              <div className="h-3 w-48 bg-white/10 rounded animate-pulse" />
            </div>
          </div>
          <div className="h-16 bg-white/10 rounded-xl animate-pulse" />
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`relative overflow-hidden rounded-2xl ${className}`}
    >
      {/* AI-themed gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-violet-500/20 via-purple-500/15 to-indigo-500/20" />
      
      {/* Animated particles */}
      <motion.div 
        className="absolute top-4 right-8 w-2 h-2 rounded-full bg-violet-400/50"
        animate={{ 
          y: [0, -10, 0],
          opacity: [0.5, 1, 0.5],
          scale: [1, 1.2, 1]
        }}
        transition={{ duration: 3, repeat: Infinity }}
      />
      <motion.div 
        className="absolute bottom-8 right-16 w-1.5 h-1.5 rounded-full bg-purple-400/40"
        animate={{ 
          y: [0, -8, 0],
          opacity: [0.4, 0.8, 0.4]
        }}
        transition={{ duration: 2.5, repeat: Infinity, delay: 0.5 }}
      />
      <motion.div 
        className="absolute top-12 left-8 w-1 h-1 rounded-full bg-indigo-400/40"
        animate={{ 
          y: [0, -6, 0],
          opacity: [0.3, 0.7, 0.3]
        }}
        transition={{ duration: 2, repeat: Infinity, delay: 1 }}
      />

      {/* Glow */}
      <div className="absolute -top-20 -right-20 w-40 h-40 bg-violet-500/30 rounded-full blur-3xl" />
      
      {/* Glass overlay */}
      <div className="absolute inset-0 backdrop-blur-sm" />
      
      {/* Top shine */}
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/30 to-transparent" />

      <div className="relative p-5">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <motion.div 
              className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500/30 to-purple-500/30 border border-violet-500/30 flex items-center justify-center"
              animate={{ 
                boxShadow: ['0 0 20px rgba(139, 92, 246, 0.3)', '0 0 30px rgba(139, 92, 246, 0.5)', '0 0 20px rgba(139, 92, 246, 0.3)']
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <motion.div
                animate={{ rotate: [0, 360] }}
                transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
              >
                <Sparkles className="w-5 h-5 text-violet-400" />
              </motion.div>
            </motion.div>
            <div>
              <h3 className="font-bold text-sm">Coach IA</h3>
              <p className="text-xs text-muted-foreground">Seus insights de hoje</p>
            </div>
          </div>

          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={handleChatClick}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-violet-500/20 border border-violet-500/30 text-violet-400 text-xs font-medium"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>Conversar</span>
          </motion.button>
        </div>

        {/* Suggested workout */}
        {suggestedWorkout && (
          <motion.div
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="mb-3 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4 text-emerald-400" />
                <span className="text-xs text-emerald-400 font-medium">Treino sugerido</span>
              </div>
              <ChevronRight className="w-4 h-4 text-emerald-400/60" />
            </div>
            <p className="mt-1 text-sm font-bold">{suggestedWorkout}</p>
          </motion.div>
        )}

        {/* Muscle recovery status */}
        {muscleRecovery.length > 0 && (
          <div className="mb-3">
            <span className="text-xs text-muted-foreground mb-2 block">Recuperação muscular</span>
            <div className="flex gap-2 flex-wrap">
              {muscleRecovery.slice(0, 4).map((muscle, idx) => {
                const status = getRecoveryStatus(muscle.status);
                return (
                  <motion.div
                    key={muscle.muscle}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: idx * 0.05 }}
                    className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-secondary/30"
                  >
                    <div className={`w-1.5 h-1.5 rounded-full ${status.color}`} />
                    <span className="text-xs">{muscle.muscle}</span>
                  </motion.div>
                );
              })}
            </div>
          </div>
        )}

        {/* Insights */}
        {insights.length > 0 && (
          <div className="space-y-2">
            {insights.slice(0, 2).map((insight, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 + idx * 0.1 }}
                onClick={() => insight.action && navigate(insight.action.path)}
                className={`p-3 rounded-xl border cursor-pointer transition-all hover:scale-[1.02] ${getInsightColor(insight.type)}`}
              >
                <div className="flex items-start gap-2">
                  <div className="mt-0.5">{getInsightIcon(insight.type)}</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold">{insight.title}</p>
                    <p className="text-xs opacity-80 mt-0.5">{insight.message}</p>
                  </div>
                  {insight.action && (
                    <ChevronRight className="w-4 h-4 opacity-60 flex-shrink-0" />
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Empty state */}
        {insights.length === 0 && !suggestedWorkout && (
          <div className="text-center py-4">
            <p className="text-sm text-muted-foreground">
              Treine mais para receber insights personalizados!
            </p>
          </div>
        )}
      </div>
    </motion.div>
  );
}
