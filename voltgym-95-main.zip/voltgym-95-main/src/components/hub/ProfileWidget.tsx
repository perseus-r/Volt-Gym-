import React from 'react';
import { motion } from 'framer-motion';
import { User, Flame, Trophy, ChevronRight, Star } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { hapticLight } from '@/utils/haptics';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { AnimatedWidget } from './AnimatedWidget';
import { AnimatedIcon } from './AnimatedIcon';
import { AnimatedCounter } from './AnimatedCounter';
import { AnimatedProgressBar } from './AnimatedProgressBar';

export function ProfileWidget() {
  const navigate = useNavigate();
  const { user } = useAuth();

  const { data: profile } = useQuery({
    queryKey: ['profileWidget', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      const { data } = await supabase
        .from('profiles')
        .select('display_name, avatar_url, current_xp, streak_days, total_workouts')
        .eq('user_id', user.id)
        .single();
      return data;
    },
    enabled: !!user?.id
  });

  const handleClick = () => {
    hapticLight();
    navigate('/perfil');
  };

  const level = Math.floor((profile?.current_xp || 0) / 1000) + 1;
  const xpProgress = ((profile?.current_xp || 0) % 1000) / 10;
  const initials = profile?.display_name?.split(' ').map(n => n[0]).join('').slice(0, 2) || 'U';

  return (
    <AnimatedWidget onClick={handleClick} glowColor="blue">
      {/* Subtle gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/8 to-transparent" />

      <div className="relative">
        {/* Header with Avatar */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: 'spring', stiffness: 400, damping: 20 }}
            >
              <Avatar className="w-10 h-10 border-2 border-blue-500/30">
                <AvatarImage src={profile?.avatar_url || undefined} />
                <AvatarFallback className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 text-blue-400 text-sm font-bold">
                  {initials}
                </AvatarFallback>
              </Avatar>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
            >
              <p className="font-semibold text-sm text-foreground line-clamp-1">
                {profile?.display_name || 'Atleta'}
              </p>
              <div className="flex items-center gap-1">
                <AnimatedIcon Icon={Star} size="sm" color="text-yellow-500" delay={0.15} />
                <span className="text-xs text-muted-foreground">
                  Nível <AnimatedCounter value={level} delay={0.2} />
                </span>
              </div>
            </motion.div>
          </div>
          <motion.div
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </motion.div>
        </div>

        {/* XP Progress bar */}
        <motion.div 
          className="mb-3"
          initial={{ opacity: 0, y: 5 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
        >
          <div className="flex justify-between text-xs mb-1">
            <span className="text-muted-foreground">XP para próximo nível</span>
            <span className="text-blue-400 font-medium">
              <AnimatedCounter value={Math.round(xpProgress)} suffix="%" delay={0.3} />
            </span>
          </div>
          <AnimatedProgressBar progress={xpProgress} color="gradient" delay={0.4} />
        </motion.div>

        {/* Stats */}
        <motion.div 
          className="flex items-center gap-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.25 }}
        >
          <div className="flex items-center gap-1.5">
            <AnimatedIcon Icon={Flame} size="sm" color="text-orange-500" delay={0.3} />
            <span className="text-xs text-muted-foreground">
              <AnimatedCounter value={profile?.streak_days || 0} delay={0.35} /> dias
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <AnimatedIcon Icon={Trophy} size="sm" color="text-yellow-500" delay={0.35} />
            <span className="text-xs text-muted-foreground">
              <AnimatedCounter value={profile?.total_workouts || 0} delay={0.4} /> treinos
            </span>
          </div>
        </motion.div>
      </div>
    </AnimatedWidget>
  );
}
