import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { LucideIcon } from 'lucide-react';
import { hapticLight } from '@/utils/haptics';

interface QuickAccessItem {
  id: string;
  title: string;
  icon: LucideIcon;
  path: string;
  gradient: string;
  iconColor: string;
  badge?: string | number;
}

interface QuickAccessGridProps {
  items: QuickAccessItem[];
  columns?: number;
  className?: string;
}

export function QuickAccessGrid({ items, columns = 4, className = '' }: QuickAccessGridProps) {
  const navigate = useNavigate();

  const handleItemClick = (path: string) => {
    hapticLight();
    navigate(path);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.06
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 12, scale: 0.9 },
    visible: { 
      opacity: 1, 
      y: 0,
      scale: 1,
      transition: {
        type: "spring" as const,
        stiffness: 400,
        damping: 25
      }
    }
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className={`grid grid-cols-3 gap-4 ${className}`}
    >
      {items.map((item) => {
        const Icon = item.icon;
        
        return (
          <motion.button
            key={item.id}
            variants={itemVariants}
            onClick={() => handleItemClick(item.path)}
            whileHover={{ scale: 1.08, y: -4 }}
            whileTap={{ scale: 0.92 }}
            className="group flex flex-col items-center gap-2.5 p-3 cursor-pointer"
            style={{ touchAction: 'manipulation' }}
          >
            {/* Icon Container - Larger with glow */}
            <div 
              className={`relative w-16 h-16 rounded-2xl bg-gradient-to-br ${item.gradient} flex items-center justify-center shadow-lg transition-all duration-300 group-hover:shadow-xl`}
              style={{
                boxShadow: `0 8px 24px rgba(0,0,0,0.2), 0 4px 12px ${item.iconColor.includes('primary') ? 'rgba(var(--primary), 0.3)' : 'rgba(0,0,0,0.15)'}`,
              }}
            >
              {/* Inner glow effect */}
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-t from-transparent via-white/5 to-white/15" />
              
              <Icon 
                className={`w-7 h-7 ${item.iconColor} relative z-10 drop-shadow-sm`}
                strokeWidth={2}
              />
              
              {/* Badge */}
              {item.badge && (
                <motion.div 
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 500, delay: 0.2 }}
                  className="absolute -top-1.5 -right-1.5 min-w-[20px] h-[20px] px-1.5 bg-destructive rounded-full flex items-center justify-center shadow-lg"
                >
                  <span className="text-[10px] font-bold text-destructive-foreground">{item.badge}</span>
                </motion.div>
              )}
              
              {/* Hover glow ring */}
              <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 ring-2 ring-white/20" />
            </div>
            
            {/* Title - More readable */}
            <span className="text-xs font-semibold text-muted-foreground text-center leading-tight line-clamp-1 group-hover:text-foreground transition-colors duration-200">
              {item.title}
            </span>
          </motion.button>
        );
      })}
    </motion.div>
  );
}
