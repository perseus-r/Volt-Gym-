import React from 'react';
import { motion } from 'framer-motion';
import { Apple, ChevronRight, Flame, Droplets } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { hapticLight } from '@/utils/haptics';
import { AnimatedWidget } from './AnimatedWidget';
import { AnimatedIconContainer, AnimatedIcon } from './AnimatedIcon';
import { AnimatedCounter } from './AnimatedCounter';
import { AnimatedProgressBar } from './AnimatedProgressBar';

export function NutritionWidget() {
  const navigate = useNavigate();
  const { user } = useAuth();

  // Fetch today's nutrition
  const { data: todayNutrition } = useQuery({
    queryKey: ['todayNutrition', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      const today = new Date().toISOString().split('T')[0];
      
      const { data } = await supabase
        .from('nutrition_logs')
        .select('calories, protein, carbs, fat')
        .eq('user_id', user.id)
        .eq('date', today);
      
      if (!data || data.length === 0) return null;
      
      return data.reduce((acc, log) => ({
        calories: acc.calories + log.calories,
        protein: acc.protein + log.protein,
        carbs: acc.carbs + log.carbs,
        fat: acc.fat + log.fat
      }), { calories: 0, protein: 0, carbs: 0, fat: 0 });
    },
    enabled: !!user?.id
  });

  // Fetch user's calorie goal
  const { data: profile } = useQuery({
    queryKey: ['nutritionGoal', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      const { data } = await supabase
        .from('profiles')
        .select('objetivo_calorico')
        .eq('user_id', user.id)
        .maybeSingle();
      return data;
    },
    enabled: !!user?.id
  });

  const handleClick = () => {
    hapticLight();
    navigate('/nutricao');
  };

  const calorieGoal = profile?.objetivo_calorico || 2000;
  const currentCalories = todayNutrition?.calories || 0;
  const progress = Math.min((currentCalories / calorieGoal) * 100, 100);
  const remaining = Math.max(calorieGoal - currentCalories, 0);

  return (
    <AnimatedWidget onClick={handleClick} glowColor="green">
      {/* Subtle gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-green-500/8 to-transparent" />

      <div className="relative">
        {/* Header */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <AnimatedIconContainer 
              Icon={Apple} 
              color="text-green-400"
              bgGradient="from-green-500/20 to-lime-500/20"
              borderColor="border-green-500/20"
            />
            <motion.span 
              className="font-semibold text-sm text-foreground"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
            >
              Nutrição
            </motion.span>
          </div>
          <motion.div
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </motion.div>
        </div>

        {/* Calories progress */}
        <motion.div 
          className="mb-3"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
        >
          <div className="flex justify-between items-baseline mb-1">
            <div className="flex items-center gap-1.5">
              <AnimatedIcon Icon={Flame} size="sm" color="text-orange-500" delay={0.2} />
              <AnimatedCounter 
                value={currentCalories} 
                className="text-lg font-bold text-foreground" 
                delay={0.25}
              />
              <span className="text-xs text-muted-foreground">/ {calorieGoal} kcal</span>
            </div>
          </div>
          <AnimatedProgressBar 
            progress={progress} 
            color={progress >= 100 ? 'success' : 'warning'} 
            delay={0.35} 
          />
        </motion.div>

        {/* Status */}
        <motion.div 
          className="flex items-center gap-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <AnimatedIcon Icon={Droplets} size="sm" color="text-muted-foreground" delay={0.35} />
          <span className="text-xs text-muted-foreground">
            {remaining > 0 
              ? <>Faltam <AnimatedCounter value={remaining} delay={0.4} /> kcal</>
              : 'Meta atingida! ✓'}
          </span>
        </motion.div>

        {/* Macros summary */}
        {todayNutrition && (
          <motion.div 
            className="mt-2 flex items-center gap-3 text-xs text-muted-foreground"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            <span>P: <AnimatedCounter value={todayNutrition.protein} delay={0.45} />g</span>
            <span>C: <AnimatedCounter value={todayNutrition.carbs} delay={0.5} />g</span>
            <span>G: <AnimatedCounter value={todayNutrition.fat} delay={0.55} />g</span>
          </motion.div>
        )}
      </div>
    </AnimatedWidget>
  );
}
