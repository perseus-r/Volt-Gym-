import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { LucideIcon } from 'lucide-react';
import { hapticLight } from '@/utils/haptics';

interface IOSWidgetLargeProps {
  title: string;
  subtitle?: string;
  icon: LucideIcon;
  path: string;
  gradient: string;
  iconColor: string;
  badge?: string | number;
  stats?: { label: string; value: string | number };
  className?: string;
}

export function IOSWidgetLarge({
  title,
  subtitle,
  icon: Icon,
  path,
  gradient,
  iconColor,
  badge,
  stats,
  className = ''
}: IOSWidgetLargeProps) {
  const navigate = useNavigate();

  const handleClick = () => {
    hapticLight();
    navigate(path);
  };

  return (
    <motion.button
      onClick={handleClick}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: "spring", stiffness: 400, damping: 30 }}
      className={`relative w-full aspect-square rounded-2xl p-4 flex flex-col items-start justify-between overflow-hidden group bg-card/50 border border-border/50 cursor-pointer ${className}`}
      style={{
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
        touchAction: 'manipulation',
      }}
    >
      {/* Subtle Gradient Background */}
      <div 
        className={`absolute inset-0 bg-gradient-to-br ${gradient} opacity-[0.08] group-hover:opacity-[0.12] transition-opacity duration-300`}
      />
      
      {/* Icon Container */}
      <div 
        className={`relative z-10 w-12 h-12 rounded-xl bg-gradient-to-br ${gradient} flex items-center justify-center`}
      >
        <Icon 
          className={`w-6 h-6 ${iconColor}`}
          strokeWidth={2}
        />
      </div>

      {/* Badge */}
      {badge && (
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 500, delay: 0.2 }}
          className="absolute top-3 right-3 min-w-[20px] h-[20px] px-1.5 bg-destructive rounded-full flex items-center justify-center z-20"
        >
          <span className="text-[10px] font-bold text-destructive-foreground">{badge}</span>
        </motion.div>
      )}

      {/* Content */}
      <div className="relative z-10 w-full mt-auto">
        <h3 className="text-sm font-semibold text-foreground tracking-tight">
          {title}
        </h3>
        {subtitle && (
          <p className="text-[11px] text-muted-foreground mt-0.5 line-clamp-1">
            {subtitle}
          </p>
        )}
        {stats && (
          <div className="flex items-baseline gap-1 mt-1">
            <span className={`text-lg font-bold bg-gradient-to-r ${gradient} bg-clip-text text-transparent`}>
              {stats.value}
            </span>
            <span className="text-[10px] text-muted-foreground">{stats.label}</span>
          </div>
        )}
      </div>
    </motion.button>
  );
}
