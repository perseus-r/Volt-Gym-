import React from 'react';
import { motion } from 'framer-motion';
import { Brain, MessageCircle, ChevronRight, Sparkles } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { hapticLight } from '@/utils/haptics';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { AnimatedWidget } from './AnimatedWidget';
import { AnimatedIconContainer, AnimatedIcon } from './AnimatedIcon';
import { AnimatedCounter } from './AnimatedCounter';

export function CoachWidget() {
  const navigate = useNavigate();
  const { user } = useAuth();

  const { data: lastConversation } = useQuery({
    queryKey: ['lastAiConversation', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      const { data } = await supabase
        .from('ai_conversations')
        .select('id, title, updated_at')
        .eq('user_id', user.id)
        .order('updated_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      return data;
    },
    enabled: !!user?.id
  });

  const { data: messageCount } = useQuery({
    queryKey: ['aiMessageCount', user?.id],
    queryFn: async () => {
      if (!user?.id) return 0;
      const { count } = await supabase
        .from('ai_messages')
        .select('*', { count: 'exact', head: true })
        .eq('role', 'assistant');
      return count || 0;
    },
    enabled: !!user?.id
  });

  const handleClick = () => {
    hapticLight();
    navigate('/ia-coach');
  };

  const lastActivity = lastConversation?.updated_at
    ? formatDistanceToNow(new Date(lastConversation.updated_at), { addSuffix: true, locale: ptBR })
    : null;

  return (
    <AnimatedWidget onClick={handleClick} glowColor="violet">
      {/* Subtle gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-violet-500/8 to-transparent" />

      <div className="relative">
        {/* Header */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <AnimatedIconContainer 
              Icon={Brain} 
              color="text-violet-400"
              bgGradient="from-violet-500/20 to-purple-500/20"
              borderColor="border-violet-500/20"
            />
            <motion.span 
              className="font-semibold text-sm text-foreground"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
            >
              Coach IA
            </motion.span>
          </div>
          <motion.div
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </motion.div>
        </div>

        {/* Stats */}
        <motion.div 
          className="space-y-1"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
        >
          <div className="flex items-center gap-2">
            <AnimatedIcon Icon={Sparkles} size="sm" color="text-violet-400" delay={0.2} />
            <span className="text-xs text-muted-foreground">
              {messageCount && messageCount > 0 
                ? <><AnimatedCounter value={messageCount} delay={0.3} /> insights gerados</>
                : 'Pronto para ajudar'}
            </span>
          </div>
          
          {lastActivity && (
            <div className="flex items-center gap-2">
              <AnimatedIcon Icon={MessageCircle} size="sm" color="text-muted-foreground" delay={0.25} />
              <span className="text-xs text-muted-foreground">
                Última conversa {lastActivity}
              </span>
            </div>
          )}
        </motion.div>

        {/* CTA */}
        <motion.div 
          className="mt-3 flex items-center gap-1.5 text-violet-400"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <span className="text-xs font-medium">Conversar</span>
          <AnimatedIcon Icon={MessageCircle} size="sm" color="text-violet-400" delay={0.35} />
        </motion.div>
      </div>
    </AnimatedWidget>
  );
}
