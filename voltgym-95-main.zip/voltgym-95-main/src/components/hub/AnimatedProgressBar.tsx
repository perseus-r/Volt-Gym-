import React from 'react';
import { motion } from 'framer-motion';

interface AnimatedProgressBarProps {
  progress: number; // 0-100
  color?: 'default' | 'success' | 'warning' | 'gradient';
  height?: 'sm' | 'md' | 'lg';
  delay?: number;
  showGlow?: boolean;
  className?: string;
}

const colorMap = {
  default: 'bg-primary',
  success: 'bg-gradient-to-r from-green-500 to-emerald-500',
  warning: 'bg-gradient-to-r from-orange-500 to-yellow-500',
  gradient: 'bg-gradient-to-r from-blue-500 to-cyan-500'
};

const heightMap = {
  sm: 'h-1',
  md: 'h-1.5',
  lg: 'h-2'
};

export function AnimatedProgressBar({
  progress,
  color = 'gradient',
  height = 'md',
  delay = 0.3,
  showGlow = true,
  className = ''
}: AnimatedProgressBarProps) {
  const clampedProgress = Math.min(Math.max(progress, 0), 100);

  return (
    <div className={`relative ${heightMap[height]} bg-muted/30 rounded-full overflow-hidden ${className}`}>
      <motion.div
        className={`absolute inset-y-0 left-0 ${colorMap[color]} rounded-full`}
        initial={{ width: 0 }}
        whileInView={{ width: `${clampedProgress}%` }}
        viewport={{ once: true }}
        transition={{ 
          duration: 1,
          delay,
          ease: [0.4, 0, 0.2, 1] // Smooth easing
        }}
      >
        {/* Animated glow at the end */}
        {showGlow && clampedProgress > 5 && (
          <motion.div
            className="absolute right-0 top-1/2 -translate-y-1/2 w-4 h-4 bg-white/40 rounded-full blur-sm"
            initial={{ opacity: 0 }}
            animate={{ 
              opacity: [0.3, 0.6, 0.3],
              scale: [0.8, 1.2, 0.8]
            }}
            transition={{ 
              duration: 2, 
              repeat: Infinity,
              delay: delay + 0.8
            }}
          />
        )}
      </motion.div>

      {/* Shimmer effect */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent"
        initial={{ x: '-100%' }}
        whileInView={{ x: '100%' }}
        viewport={{ once: true }}
        transition={{ 
          duration: 1.2,
          delay: delay + 0.5,
          ease: 'easeInOut'
        }}
      />
    </div>
  );
}

// Circular progress variant
interface CircularProgressProps {
  progress: number;
  size?: number;
  strokeWidth?: number;
  color?: string;
  className?: string;
}

export function CircularProgress({
  progress,
  size = 48,
  strokeWidth = 4,
  color = 'stroke-primary',
  className = ''
}: CircularProgressProps) {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (progress / 100) * circumference;

  return (
    <div className={`relative ${className}`} style={{ width: size, height: size }}>
      <svg className="transform -rotate-90" width={size} height={size}>
        {/* Background circle */}
        <circle
          className="stroke-muted/30"
          strokeWidth={strokeWidth}
          fill="none"
          r={radius}
          cx={size / 2}
          cy={size / 2}
        />
        {/* Progress circle */}
        <motion.circle
          className={color}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          fill="none"
          r={radius}
          cx={size / 2}
          cy={size / 2}
          initial={{ strokeDashoffset: circumference }}
          whileInView={{ strokeDashoffset: offset }}
          viewport={{ once: true }}
          transition={{ duration: 1.2, ease: 'easeOut' }}
          style={{ strokeDasharray: circumference }}
        />
      </svg>
    </div>
  );
}
