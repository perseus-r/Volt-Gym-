import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { User, ChevronRight, MessageCircle, Star } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { hapticLight } from '@/utils/haptics';
import { AnimatedWidget } from './AnimatedWidget';
import { AnimatedIconContainer, AnimatedIcon } from './AnimatedIcon';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

interface CoachData {
  displayName: string;
  avatarUrl: string | null;
  brandName: string | null;
}

export function MyCoachWidget() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [coach, setCoach] = useState<CoachData | null>(null);

  useEffect(() => {
    async function loadCoach() {
      if (!user?.id) return;

      try {
        const { data: link } = await supabase
          .from('trainer_athlete_links')
          .select('coach_user_id')
          .eq('athlete_user_id', user.id)
          .eq('status', 'active')
          .maybeSingle();

        if (!link || !link.coach_user_id) return;

        const { data: ptProfile } = await supabase
          .from('personal_trainer_profiles')
          .select('user_id, brand_name')
          .eq('user_id', link.coach_user_id)
          .maybeSingle();

        if (!ptProfile) return;

        const { data: profile } = await supabase
          .from('profiles')
          .select('display_name, avatar_url')
          .eq('user_id', ptProfile.user_id)
          .single();

        if (profile) {
          setCoach({
            displayName: profile.display_name || 'Personal Trainer',
            avatarUrl: profile.avatar_url,
            brandName: ptProfile.brand_name
          });
        }
      } catch (error) {
        console.error('Error loading coach:', error);
      }
    }

    loadCoach();
  }, [user?.id]);

  const handleClick = () => {
    hapticLight();
    navigate('/athlete/coach');
  };

  return (
    <AnimatedWidget onClick={handleClick} glowColor="blue">
      {/* Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-transparent" />

      <div className="relative">
        {/* Header */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <AnimatedIconContainer 
              Icon={User} 
              color="text-blue-400"
              bgGradient="from-blue-500/20 to-cyan-500/20"
              borderColor="border-blue-500/20"
            />
            <motion.span 
              className="font-semibold text-sm text-foreground"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
            >
              Meu Coach
            </motion.span>
          </div>
          <motion.div
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </motion.div>
        </div>

        {/* Content */}
        <motion.div 
          className="space-y-2"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
        >
          {coach ? (
            <div className="flex items-center gap-3">
              <Avatar className="h-10 w-10 border border-blue-500/30">
                <AvatarImage src={coach.avatarUrl || undefined} />
                <AvatarFallback className="bg-blue-500/20 text-blue-400">
                  {coach.displayName.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">
                  {coach.displayName}
                </p>
                {coach.brandName && (
                  <p className="text-xs text-muted-foreground truncate">
                    {coach.brandName}
                  </p>
                )}
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <AnimatedIcon Icon={Star} size="sm" color="text-muted-foreground" delay={0.2} />
              <span className="text-xs text-muted-foreground">
                Carregando coach...
              </span>
            </div>
          )}
        </motion.div>

        {/* CTA */}
        <motion.div 
          className="mt-3 flex items-center gap-1.5 text-blue-400"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <span className="text-xs font-medium">Ver perfil</span>
          <AnimatedIcon Icon={MessageCircle} size="sm" color="text-blue-400" delay={0.35} />
        </motion.div>
      </div>
    </AnimatedWidget>
  );
}
