import React from 'react';
import { motion } from 'framer-motion';
import { Check, Circle, Sparkles } from 'lucide-react';

interface Goal {
  id: string;
  label: string;
  completed: boolean;
}

interface DailyGoalWidgetProps {
  goals: Goal[];
  className?: string;
}

export function DailyGoalWidget({ goals, className = '' }: DailyGoalWidgetProps) {
  const completedCount = goals.filter(g => g.completed).length;
  const totalCount = goals.length;
  const progress = totalCount > 0 ? (completedCount / totalCount) * 100 : 0;
  const circumference = 2 * Math.PI * 32;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ type: "spring", stiffness: 400, damping: 30 }}
      className={`relative overflow-hidden rounded-xl backdrop-blur-xl border border-amber-500/20 p-3 ${className}`}
      style={{
        background: 'linear-gradient(135deg, rgba(245, 158, 11, 0.15) 0%, rgba(249, 115, 22, 0.08) 50%, rgba(0,0,0,0) 100%)',
        boxShadow: '0 8px 32px rgba(245, 158, 11, 0.12), inset 0 1px 0 rgba(255,255,255,0.1)'
      }}
    >
      {/* Top shine line */}
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-amber-400/50 to-transparent" />
      
      <div className="flex items-center gap-3">
        {/* Circular Progress - COMPACT */}
        <div className="relative w-[56px] h-[56px] flex-shrink-0">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 56 56">
            {/* Background circle */}
            <circle
              cx="28"
              cy="28"
              r="24"
              fill="none"
              stroke="currentColor"
              strokeWidth="4"
              className="text-white/10"
            />
            {/* Progress circle */}
            <motion.circle
              cx="28"
              cy="28"
              r="24"
              fill="none"
              stroke="url(#goalGradientPremium)"
              strokeWidth="4"
              strokeLinecap="round"
              initial={{ strokeDashoffset: 2 * Math.PI * 24 }}
              animate={{ strokeDashoffset: 2 * Math.PI * 24 - (progress / 100) * 2 * Math.PI * 24 }}
              transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
              style={{ strokeDasharray: 2 * Math.PI * 24 }}
            />
            <defs>
              <linearGradient id="goalGradientPremium" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#fbbf24" />
                <stop offset="100%" stopColor="#f97316" />
              </linearGradient>
            </defs>
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-base font-bold text-txt">{completedCount}</span>
            <span className="text-[8px] text-txt-3 -mt-0.5">de {totalCount}</span>
          </div>
        </div>

        {/* Goals list - COMPACT */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1 mb-2">
            <div className="w-4 h-4 rounded-md bg-amber-500/20 flex items-center justify-center">
              <Sparkles className="w-2.5 h-2.5 text-amber-400" />
            </div>
            <span className="text-[10px] font-semibold text-txt">Metas do Dia</span>
          </div>
          
          <div className="space-y-1.5">
            {goals.slice(0, 3).map((goal, index) => (
              <motion.div
                key={goal.id}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.25 + index * 0.08 }}
                className="flex items-center gap-2.5"
              >
                {/* iOS-style Checkbox */}
                <motion.div
                  initial={false}
                  animate={{
                    backgroundColor: goal.completed ? 'rgb(34, 197, 94)' : 'transparent',
                    borderColor: goal.completed ? 'rgb(34, 197, 94)' : 'rgba(255,255,255,0.25)',
                    scale: goal.completed ? [1, 1.15, 1] : 1
                  }}
                  transition={{ duration: 0.2 }}
                  className="w-[18px] h-[18px] rounded-full border-2 flex items-center justify-center flex-shrink-0"
                  style={{
                    boxShadow: goal.completed ? '0 2px 8px rgba(34, 197, 94, 0.4)' : 'none'
                  }}
                >
                  {goal.completed && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", stiffness: 500 }}
                    >
                      <Check className="w-2.5 h-2.5 text-white" strokeWidth={3} />
                    </motion.div>
                  )}
                </motion.div>
                
                <span className={`text-xs truncate ${goal.completed ? 'text-txt-3 line-through' : 'text-txt-2'}`}>
                  {goal.label}
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Completion celebration */}
      {progress === 100 && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 5 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ type: "spring", stiffness: 400 }}
          className="flex items-center justify-center gap-2 mt-3 py-2 bg-gradient-to-r from-green-500/15 to-emerald-500/10 rounded-xl border border-green-500/20"
        >
          <span className="text-xs text-green-400 font-medium">🎉 Metas concluídas!</span>
        </motion.div>
      )}
    </motion.div>
  );
}
