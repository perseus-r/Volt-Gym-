import React from 'react';
import { motion } from 'framer-motion';
import { Flame, Zap, Trophy, Dumbbell } from 'lucide-react';

interface StatsBarProps {
  streak: number;
  xp: number;
  level: number;
  totalWorkouts: number;
  className?: string;
}

export function StatsBar({ streak, xp, level, totalWorkouts, className = '' }: StatsBarProps) {
  const stats = [
    {
      icon: Flame,
      value: streak,
      label: 'dias',
      iconColor: 'text-orange-500',
    },
    {
      icon: Zap,
      value: xp >= 1000 ? `${(xp / 1000).toFixed(1)}k` : xp,
      label: 'XP',
      iconColor: 'text-amber-500',
    },
    {
      icon: Trophy,
      value: level,
      label: 'nível',
      iconColor: 'text-violet-500',
    },
    {
      icon: Dumbbell,
      value: totalWorkouts,
      label: 'treinos',
      iconColor: 'text-emerald-500',
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
      className={`flex gap-2 ${className}`}
    >
      {stats.map((stat, index) => {
        const Icon = stat.icon;
        
        return (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1 + index * 0.05 }}
            className="flex-1 bg-card/50 border border-border/50 rounded-xl p-2.5 flex flex-col items-center gap-1"
            style={{
              backdropFilter: 'blur(8px)',
              WebkitBackdropFilter: 'blur(8px)',
            }}
          >
            <Icon className={`w-4 h-4 ${stat.iconColor}`} strokeWidth={2} />
            <span className="text-sm font-bold text-foreground">{stat.value}</span>
            <span className="text-[9px] text-muted-foreground uppercase tracking-wider">{stat.label}</span>
          </motion.div>
        );
      })}
    </motion.div>
  );
}
