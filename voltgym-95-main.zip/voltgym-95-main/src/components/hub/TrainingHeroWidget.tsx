import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Dumbbell, ChevronRight, Clock, Flame, Calendar } from 'lucide-react';
import { hapticLight } from '@/utils/haptics';

interface TrainingHeroWidgetProps {
  lastWorkout?: {
    name: string;
    duration?: number;
    date?: string;
  };
  nextWorkout?: {
    name: string;
    scheduledDate?: string;
    focus?: string;
  };
  weeklyCount?: number;
  className?: string;
}

export function TrainingHeroWidget({
  lastWorkout,
  nextWorkout,
  weeklyCount = 0,
  className = ''
}: TrainingHeroWidgetProps) {
  const navigate = useNavigate();

  const handleClick = () => {
    hapticLight();
    navigate('/treinos');
  };

  return (
    <motion.button
      onClick={handleClick}
      whileHover={{ scale: 1.01 }}
      whileTap={{ scale: 0.98 }}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: "spring", stiffness: 400, damping: 30 }}
      className={`relative w-full rounded-2xl p-5 overflow-hidden group text-left bg-card/50 border border-border/50 ${className}`}
      style={{
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
      }}
    >
      {/* Subtle Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-orange-500/10 via-amber-500/5 to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-300" />

      {/* Content Container */}
      <div className="relative z-10 flex items-start justify-between gap-4">
        {/* Left: Icon + Title */}
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-orange-500 to-amber-500 flex items-center justify-center">
            <Dumbbell className="w-5 h-5 text-white" strokeWidth={2} />
          </div>
          <div>
            <h3 className="text-base font-semibold text-foreground tracking-tight">Treino</h3>
            <p className="text-xs text-muted-foreground">Seu progresso semanal</p>
          </div>
        </div>

        {/* Right: Arrow */}
        <div className="w-8 h-8 rounded-full bg-muted/50 flex items-center justify-center group-hover:bg-muted transition-colors">
          <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors" />
        </div>
      </div>

      {/* Workout Info */}
      <div className="relative z-10 mt-4 grid grid-cols-2 gap-3">
        {/* Last Workout */}
        <div className="bg-muted/30 rounded-xl p-3 border border-border/30">
          <div className="flex items-center gap-1.5 mb-1">
            <Clock className="w-3 h-3 text-orange-500" />
            <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Último</span>
          </div>
          <p className="text-sm font-medium text-foreground truncate">
            {lastWorkout?.name || 'Nenhum ainda'}
          </p>
          {lastWorkout?.duration && (
            <p className="text-[10px] text-muted-foreground mt-0.5">{lastWorkout.duration} min</p>
          )}
        </div>

        {/* Next Workout */}
        <div className="bg-muted/30 rounded-xl p-3 border border-border/30">
          <div className="flex items-center gap-1.5 mb-1">
            <Calendar className="w-3 h-3 text-amber-500" />
            <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Próximo</span>
          </div>
          <p className="text-sm font-medium text-foreground truncate">
            {nextWorkout?.name || 'Criar treino'}
          </p>
          {nextWorkout?.focus && (
            <p className="text-[10px] text-muted-foreground mt-0.5">{nextWorkout.focus}</p>
          )}
        </div>
      </div>

      {/* Weekly Progress Bar */}
      <div className="relative z-10 mt-4">
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5 text-orange-500" />
            <span className="text-[11px] text-muted-foreground">{weeklyCount} treinos esta semana</span>
          </div>
          <span className="text-[11px] text-muted-foreground">{Math.min(weeklyCount, 5)}/5</span>
        </div>
        <div className="h-1.5 bg-muted/50 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${Math.min((weeklyCount / 5) * 100, 100)}%` }}
            transition={{ delay: 0.3, duration: 0.8, ease: "easeOut" }}
            className="h-full bg-gradient-to-r from-orange-500 to-amber-400 rounded-full"
          />
        </div>
      </div>
    </motion.button>
  );
}
