import React, { ReactNode } from 'react';
import { motion, Variants } from 'framer-motion';
import { hapticLight } from '@/utils/haptics';

interface AnimatedWidgetProps {
  children: ReactNode;
  onClick?: () => void;
  className?: string;
  delay?: number;
  glowColor?: string;
}

const widgetVariants: Variants = {
  initial: { 
    opacity: 0, 
    y: 20,
    scale: 0.95
  },
  animate: { 
    opacity: 1, 
    y: 0,
    scale: 1,
    transition: {
      type: 'spring',
      stiffness: 300,
      damping: 25
    }
  }
};

export function AnimatedWidget({ 
  children, 
  onClick, 
  className = '',
  delay = 0,
  glowColor = 'violet'
}: AnimatedWidgetProps) {
  const handleClick = () => {
    hapticLight();
    onClick?.();
  };

  // Glow color mapping
  const glowColors: Record<string, string> = {
    violet: 'bg-violet-500/15',
    blue: 'bg-blue-500/15',
    emerald: 'bg-emerald-500/15',
    green: 'bg-green-500/15',
    indigo: 'bg-indigo-500/15',
    teal: 'bg-teal-500/15',
    red: 'bg-red-500/15',
    orange: 'bg-orange-500/15',
  };

  return (
    <motion.button
      onClick={handleClick}
      variants={widgetVariants}
      initial="initial"
      whileInView="animate"
      viewport={{ once: true, amount: 0.3 }}
      whileHover={{ 
        y: -4, 
        scale: 1.02,
        transition: { type: 'spring', stiffness: 400, damping: 25 }
      }}
      whileTap={{ 
        scale: 0.97,
        transition: { type: 'spring', stiffness: 500, damping: 30 }
      }}
      transition={{ delay }}
      className={`relative overflow-hidden rounded-2xl bg-card/50 border border-border/50 p-4 text-left w-full group ${className}`}
      style={{
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
      }}
    >
      {/* Premium animated glow */}
      <motion.div 
        className={`absolute -top-12 -right-12 w-32 h-32 ${glowColors[glowColor] || glowColors.violet} rounded-full blur-3xl pointer-events-none`}
        animate={{ 
          scale: [1, 1.3, 1.1, 1],
          opacity: [0.2, 0.4, 0.3, 0.2],
          rotate: [0, 45, 0]
        }}
        transition={{ 
          duration: 5, 
          repeat: Infinity, 
          ease: 'easeInOut'
        }}
      />

      {/* Hover shine effect */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent opacity-0 group-hover:opacity-100 pointer-events-none"
        initial={{ x: '-100%' }}
        whileHover={{ x: '100%' }}
        transition={{ duration: 0.6, ease: 'easeInOut' }}
      />

      {children}
    </motion.button>
  );
}
