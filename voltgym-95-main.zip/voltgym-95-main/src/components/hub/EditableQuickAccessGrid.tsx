import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import {
  DndContext,
  DragEndEvent,
  PointerSensor,
  TouchSensor,
  useSensor,
  useSensors,
  closestCenter,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  useSortable,
  rectSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { GripVertical } from 'lucide-react';
import { cn } from '@/lib/utils';
import { hapticLight } from '@/utils/haptics';
import { QuickAccessItem } from '@/hooks/useCustomizableMenu';

interface EditableQuickAccessGridProps {
  items: QuickAccessItem[];
  onReorder: (newOrder: string[]) => void;
  isEditing: boolean;
}

interface SortableItemProps {
  item: QuickAccessItem;
  isEditing: boolean;
  onNavigate: (path: string) => void;
}

function SortableItem({ item, isEditing, onNavigate }: SortableItemProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: item.id });

  const Icon = item.icon;

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const handleClick = () => {
    if (!isEditing) {
      hapticLight();
      onNavigate(item.path);
    }
  };

  return (
    <motion.div
      ref={setNodeRef}
      style={style}
      animate={{
        scale: isDragging ? 1.08 : 1,
        zIndex: isDragging ? 50 : 1,
      }}
      className={cn(
        'relative touch-none',
        isDragging && 'shadow-2xl'
      )}
    >
      {/* Drag handle indicator when editing */}
      <AnimatePresence>
        {isEditing && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ 
              scale: 1, 
              opacity: 1,
              rotate: [0, -5, 5, -5, 0],
            }}
            exit={{ scale: 0, opacity: 0 }}
            transition={{ 
              rotate: { repeat: Infinity, duration: 0.8, delay: 0.3 }
            }}
            className="absolute -top-2 -right-2 w-6 h-6 bg-destructive rounded-full flex items-center justify-center z-20 shadow-lg"
          >
            <GripVertical className="w-3 h-3 text-destructive-foreground" />
          </motion.div>
        )}
      </AnimatePresence>

      <button
        onClick={handleClick}
        className={cn(
          'group flex flex-col items-center gap-2.5 p-3 w-full cursor-pointer',
          isEditing && 'pointer-events-none'
        )}
        {...(isEditing ? { ...attributes, ...listeners } : {})}
        style={{ touchAction: isEditing ? 'none' : 'manipulation' }}
      >
        {/* Icon Container - Avatar or Icon */}
        {item.isProfile && item.avatarUrl ? (
          <div 
            className={cn(
              'relative w-16 h-16 rounded-2xl overflow-hidden shadow-lg transition-all duration-300',
              !isEditing && 'group-hover:shadow-xl',
              isEditing && 'animate-[wiggle_0.3s_ease-in-out_infinite]'
            )}
            style={{
              boxShadow: `0 8px 24px rgba(0,0,0,0.2)`,
            }}
          >
            <img 
              src={item.avatarUrl} 
              alt={item.title}
              className="w-full h-full object-cover"
            />
            {/* Gradient border overlay */}
            <div className="absolute inset-0 rounded-2xl ring-2 ring-accent/50" />
            {/* Hover glow ring */}
            <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 ring-2 ring-white/30" />
          </div>
        ) : (
          <div 
            className={cn(
              `relative w-16 h-16 rounded-2xl bg-gradient-to-br ${item.gradient} flex items-center justify-center shadow-lg transition-all duration-300`,
              !isEditing && 'group-hover:shadow-xl',
              isEditing && 'animate-[wiggle_0.3s_ease-in-out_infinite]'
            )}
            style={{
              boxShadow: `0 8px 24px rgba(0,0,0,0.2)`,
            }}
          >
            {/* Inner glow effect */}
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-t from-transparent via-white/5 to-white/15" />
            
            <Icon 
              className={`w-7 h-7 ${item.iconColor} relative z-10 drop-shadow-sm`}
              strokeWidth={2}
            />
            
            {/* Hover glow ring */}
            <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 ring-2 ring-white/20" />
          </div>
        )}
        
        {/* Title */}
        <span className={cn(
          'text-xs font-semibold text-muted-foreground text-center leading-tight line-clamp-1 transition-colors duration-200',
          !isEditing && 'group-hover:text-foreground'
        )}>
          {item.title}
        </span>
      </button>
    </motion.div>
  );
}

export function EditableQuickAccessGrid({ 
  items, 
  onReorder, 
  isEditing 
}: EditableQuickAccessGridProps) {
  const navigate = useNavigate();
  
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(TouchSensor, {
      activationConstraint: {
        delay: 150,
        tolerance: 8,
      },
    })
  );

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (over && active.id !== over.id) {
      const oldIndex = items.findIndex(i => i.id === active.id);
      const newIndex = items.findIndex(i => i.id === over.id);
      const newItems = arrayMove(items, oldIndex, newIndex);
      onReorder(newItems.map(i => i.id));
      hapticLight();
    }
  };

  const handleNavigate = (path: string) => {
    navigate(path);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 12, scale: 0.9 },
    visible: { 
      opacity: 1, 
      y: 0,
      scale: 1,
      transition: {
        type: 'spring' as const,
        stiffness: 400,
        damping: 25
      }
    }
  };

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragEnd={handleDragEnd}
    >
      <SortableContext items={items.map(i => i.id)} strategy={rectSortingStrategy}>
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-3 gap-4"
        >
          {items.map((item) => (
            <motion.div key={item.id} variants={itemVariants}>
              <SortableItem
                item={item}
                isEditing={isEditing}
                onNavigate={handleNavigate}
              />
            </motion.div>
          ))}
        </motion.div>
      </SortableContext>
    </DndContext>
  );
}
