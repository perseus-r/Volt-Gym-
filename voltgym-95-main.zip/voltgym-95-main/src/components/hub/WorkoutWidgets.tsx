import React from 'react';
import { motion } from 'framer-motion';
import { Dumbbell, Calendar, Clock, ChevronRight, Plus, Zap } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { hapticLight } from '@/utils/haptics';

interface LastWorkoutWidgetProps {
  workoutName?: string;
  duration?: number;
  date?: string;
  exerciseCount?: number;
  className?: string;
}

export function LastWorkoutWidget({ 
  workoutName = "Nenhum treino", 
  duration = 0, 
  date,
  exerciseCount = 0,
  className = '' 
}: LastWorkoutWidgetProps) {
  const navigate = useNavigate();

  const handleClick = () => {
    hapticLight();
    navigate('/treinos');
  };

  // Check if workout was recent (less than 24h)
  const isRecent = date ? (new Date().getTime() - new Date(date).getTime()) < 86400000 : false;

  return (
    <motion.button
      onClick={handleClick}
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ type: "spring", stiffness: 400, damping: 30, delay: 0.08 }}
      whileHover={{ scale: 1.03, y: -3 }}
      whileTap={{ scale: 0.97 }}
      className={`relative overflow-hidden rounded-[24px] backdrop-blur-xl border border-emerald-500/30 p-5 text-left w-full ${className}`}
      style={{
        background: 'linear-gradient(145deg, rgba(16, 185, 129, 0.25) 0%, rgba(6, 182, 212, 0.15) 50%, rgba(0,0,0,0) 100%)',
        boxShadow: '0 12px 32px rgba(16, 185, 129, 0.20), inset 0 1px 0 rgba(255,255,255,0.12)'
      }}
    >
      {/* Animated glow for recent workouts */}
      {isRecent && (
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-emerald-500/15 to-transparent"
          animate={{ opacity: [0.3, 0.6, 0.3] }}
          transition={{ duration: 2, repeat: Infinity }}
        />
      )}
      
      {/* Top shine */}
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-emerald-400/60 to-transparent" />
      
      {/* Corner glow */}
      <div className="absolute -top-10 -right-10 w-24 h-24 bg-emerald-500/20 rounded-full blur-2xl" />
      
      <div className="relative flex flex-col items-center text-center">
        {/* Icon with enhanced glow */}
        <div 
          className="w-14 h-14 rounded-2xl mb-3 flex items-center justify-center relative"
          style={{ 
            background: 'linear-gradient(145deg, rgba(16, 185, 129, 0.45), rgba(6, 182, 212, 0.25))',
            boxShadow: '0 6px 20px rgba(16, 185, 129, 0.35)'
          }}
        >
          <Dumbbell className="w-7 h-7 text-emerald-300" style={{ filter: 'drop-shadow(0 0 6px rgba(16, 185, 129, 0.6))' }} />
          {isRecent && (
            <motion.div
              className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-emerald-400 flex items-center justify-center"
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
            >
              <span className="text-[8px]">✓</span>
            </motion.div>
          )}
        </div>
        
        <span className="text-[10px] text-emerald-300/80 uppercase tracking-widest font-semibold">Último Treino</span>
        <h4 className="text-base font-bold text-foreground mt-1 line-clamp-1">{workoutName}</h4>
        
        {duration > 0 && (
          <div className="flex items-center gap-2 mt-2 text-[11px] text-muted-foreground">
            <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-white/5">
              <Clock className="w-3 h-3" />
              <span>{duration}min</span>
            </div>
            {exerciseCount > 0 && (
              <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-white/5">
                <span>{exerciseCount} exercícios</span>
              </div>
            )}
          </div>
        )}
      </div>
      
      <ChevronRight className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
    </motion.button>
  );
}

interface NextWorkoutWidgetProps {
  workoutName?: string;
  scheduledDate?: string;
  focus?: string;
  className?: string;
}

export function NextWorkoutWidget({ 
  workoutName, 
  scheduledDate, 
  focus,
  className = '' 
}: NextWorkoutWidgetProps) {
  const navigate = useNavigate();

  const handleClick = () => {
    hapticLight();
    navigate('/treinos');
  };

  const hasWorkout = !!workoutName;

  return (
    <motion.button
      onClick={handleClick}
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ type: "spring", stiffness: 400, damping: 30, delay: 0.12 }}
      whileHover={{ scale: 1.03, y: -3 }}
      whileTap={{ scale: 0.97 }}
      className={`relative overflow-hidden rounded-[24px] backdrop-blur-xl border ${hasWorkout ? 'border-violet-500/30' : 'border-white/15'} p-5 text-left w-full ${className}`}
      style={{
        background: hasWorkout 
          ? 'linear-gradient(145deg, rgba(139, 92, 246, 0.25) 0%, rgba(168, 85, 247, 0.15) 50%, rgba(0,0,0,0) 100%)'
          : 'linear-gradient(145deg, rgba(100, 116, 139, 0.15) 0%, rgba(71, 85, 105, 0.08) 50%, rgba(0,0,0,0) 100%)',
        boxShadow: hasWorkout 
          ? '0 12px 32px rgba(139, 92, 246, 0.20), inset 0 1px 0 rgba(255,255,255,0.12)'
          : '0 12px 32px rgba(0,0,0,0.20), inset 0 1px 0 rgba(255,255,255,0.08)'
      }}
    >
      {/* Animated pulse for scheduled workout */}
      {hasWorkout && (
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-violet-500/10 to-transparent"
          animate={{ opacity: [0.2, 0.5, 0.2] }}
          transition={{ duration: 3, repeat: Infinity }}
        />
      )}
      
      {/* Top shine */}
      <div className={`absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent ${hasWorkout ? 'via-violet-400/60' : 'via-white/25'} to-transparent`} />
      
      {/* Corner glow */}
      {hasWorkout && (
        <div className="absolute -top-10 -left-10 w-24 h-24 bg-violet-500/20 rounded-full blur-2xl" />
      )}
      
      <div className="relative flex flex-col items-center text-center">
        {/* Icon with enhanced styling */}
        <div 
          className="w-14 h-14 rounded-2xl mb-3 flex items-center justify-center relative"
          style={{ 
            background: hasWorkout 
              ? 'linear-gradient(145deg, rgba(139, 92, 246, 0.45), rgba(168, 85, 247, 0.25))'
              : 'linear-gradient(145deg, rgba(100, 116, 139, 0.30), rgba(71, 85, 105, 0.18))',
            boxShadow: hasWorkout 
              ? '0 6px 20px rgba(139, 92, 246, 0.35)' 
              : '0 6px 16px rgba(0,0,0,0.20)'
          }}
        >
          {hasWorkout ? (
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity, repeatDelay: 3, type: 'tween' }}
            >
              <Zap className="w-7 h-7 text-violet-300" style={{ filter: 'drop-shadow(0 0 6px rgba(139, 92, 246, 0.6))' }} />
            </motion.div>
          ) : (
            <Plus className="w-7 h-7 text-muted-foreground" />
          )}
        </div>
        
        <span className={`text-[10px] uppercase tracking-widest font-semibold ${hasWorkout ? 'text-violet-300/80' : 'text-muted-foreground'}`}>
          {hasWorkout ? 'Próximo Treino' : 'Agendar'}
        </span>
        <h4 className="text-base font-bold text-foreground mt-1 line-clamp-1">
          {workoutName || "Criar treino"}
        </h4>
        
        {hasWorkout && (focus || scheduledDate) && (
          <div className="flex items-center gap-2 mt-2 text-[11px] text-muted-foreground">
            {focus && (
              <span className="px-2 py-0.5 rounded-full bg-violet-500/15 text-violet-300">{focus}</span>
            )}
            {scheduledDate && (
              <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-white/5">
                <Calendar className="w-3 h-3" />
                <span>{scheduledDate}</span>
              </div>
            )}
          </div>
        )}
        
        {/* Start button for scheduled workouts */}
        {hasWorkout && (
          <motion.div
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mt-3 w-full py-2 rounded-xl bg-violet-500/20 border border-violet-500/30 text-violet-300 text-xs font-semibold"
          >
            Iniciar Treino →
          </motion.div>
        )}
      </div>
      
      <ChevronRight className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/20" />
    </motion.button>
  );
}
