import React from 'react';
import { motion } from 'framer-motion';
import { Flame, Zap, Star, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { hapticLight } from '@/utils/haptics';

interface HeroStatsWidgetProps {
  userName: string;
  streak: number;
  currentXp: number;
  level: number;
  xpToNextLevel?: number;
  lastWorkoutDaysAgo?: number;
  className?: string;
}

export function HeroStatsWidget({
  userName,
  streak,
  currentXp,
  level,
  xpToNextLevel = 1000,
  lastWorkoutDaysAgo,
  className = ''
}: HeroStatsWidgetProps) {
  const navigate = useNavigate();
  
  // Greeting based on time of day
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Bom dia';
    if (hour < 18) return 'Boa tarde';
    return 'Boa noite';
  };

  // XP progress percentage
  const xpProgress = Math.min((currentXp % xpToNextLevel) / xpToNextLevel * 100, 100);

  const handleClick = () => {
    hapticLight();
    navigate('/perfil');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      onClick={handleClick}
      className={`relative overflow-hidden rounded-3xl cursor-pointer ${className}`}
    >
      {/* Animated gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/30 via-accent/20 to-primary/10" />
      <motion.div 
        className="absolute inset-0 bg-gradient-to-tr from-accent/20 via-transparent to-primary/20"
        animate={{ 
          opacity: [0.3, 0.6, 0.3],
          scale: [1, 1.05, 1]
        }}
        transition={{ 
          duration: 4, 
          repeat: Infinity, 
          ease: "easeInOut" 
        }}
      />
      
      {/* Glow effects */}
      <div className="absolute -top-20 -right-20 w-40 h-40 bg-accent/30 rounded-full blur-3xl" />
      <div className="absolute -bottom-20 -left-20 w-40 h-40 bg-primary/30 rounded-full blur-3xl" />
      
      {/* Glass overlay */}
      <div className="absolute inset-0 backdrop-blur-sm" />
      
      {/* Top shine */}
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/30 to-transparent" />
      
      {/* Content - COMPACT */}
      <div className="relative p-3">
        {/* Header row - COMPACT */}
        <div className="flex items-start justify-between mb-3">
          <div>
            <motion.p 
              className="text-xs text-foreground/70 mb-0.5"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
            >
              {getGreeting()},
            </motion.p>
            <motion.h2 
              className="text-xl font-bold text-foreground"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.15 }}
            >
              {userName || 'Atleta'}! 💪
            </motion.h2>
          </div>
          
          {/* Streak badge - enhanced animated flame */}
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ type: "spring", stiffness: 400, damping: 20, delay: 0.2 }}
            className="relative flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-orange-500/20 to-red-500/20 border border-orange-500/30"
          >
            {/* Ember particles */}
            {streak >= 7 && (
              <>
                <motion.div
                  className="absolute -top-1 left-3 w-1 h-1 rounded-full bg-orange-400"
                  animate={{ 
                    y: [-2, -8], 
                    opacity: [1, 0],
                    scale: [1, 0.5]
                  }}
                  transition={{ duration: 1, repeat: Infinity, repeatDelay: 0.5 }}
                />
                <motion.div
                  className="absolute -top-0.5 right-4 w-0.5 h-0.5 rounded-full bg-yellow-400"
                  animate={{ 
                    y: [-2, -6], 
                    opacity: [1, 0],
                    scale: [1, 0.3]
                  }}
                  transition={{ duration: 0.8, repeat: Infinity, repeatDelay: 0.7, delay: 0.3 }}
                />
              </>
            )}
            
            <motion.div
              animate={{ 
                scale: [1, 1.3, 1],
                rotate: [-8, 8, -8],
                filter: ['brightness(1)', 'brightness(1.3)', 'brightness(1)']
              }}
              transition={{ 
                duration: 0.6, 
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="relative"
            >
              <Flame className="w-5 h-5 text-orange-400 drop-shadow-[0_0_8px_rgba(251,146,60,0.5)]" />
            </motion.div>
            <div className="flex flex-col items-start">
              <span className="text-sm font-bold text-orange-400">{streak} dias</span>
              {streak >= 7 && (
                <span className="text-[9px] text-orange-400/70 -mt-0.5">🔥 Em chamas!</span>
              )}
            </div>
          </motion.div>
        </div>
        
        {/* Level and XP bar */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="mb-3"
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-accent/20 border border-accent/30">
                <Star className="w-3.5 h-3.5 text-accent" />
                <span className="text-xs font-bold text-accent">Nível {level}</span>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-accent" />
              <span className="text-xs text-foreground/70">
                {currentXp % xpToNextLevel}/{xpToNextLevel} XP
              </span>
            </div>
          </div>
          
          {/* XP Progress bar with shimmer */}
          <div className="h-2 bg-white/10 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${xpProgress}%` }}
              transition={{ duration: 1, delay: 0.3, ease: "easeOut" }}
              className="h-full bg-gradient-to-r from-accent to-primary rounded-full relative"
            >
              {/* Shimmer effect */}
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent"
                animate={{ x: ['-100%', '200%'] }}
                transition={{ 
                  duration: 2, 
                  repeat: Infinity, 
                  ease: "easeInOut",
                  repeatDelay: 1
                }}
              />
            </motion.div>
          </div>
        </motion.div>
        
        {/* Call to action */}
        {lastWorkoutDaysAgo !== undefined && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.35 }}
            className="flex items-center justify-between pt-2 border-t border-white/10"
          >
            <p className="text-xs text-foreground/60">
              {lastWorkoutDaysAgo === 0 
                ? '✨ Você treinou hoje!' 
                : lastWorkoutDaysAgo === 1 
                  ? 'Último treino: ontem'
                  : `Último treino: há ${lastWorkoutDaysAgo} dias`}
            </p>
            <ChevronRight className="w-4 h-4 text-foreground/40" />
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}
