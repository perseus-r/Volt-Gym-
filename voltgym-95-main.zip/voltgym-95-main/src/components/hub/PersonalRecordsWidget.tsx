import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, ChevronRight, TrendingUp } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { hapticLight } from '@/utils/haptics';

interface PersonalRecord {
  id: string;
  exerciseName: string;
  value: number;
  unit: string;
  isNew?: boolean;
  date?: string;
}

interface PersonalRecordsWidgetProps {
  records: PersonalRecord[];
  className?: string;
}

export function PersonalRecordsWidget({ records, className = '' }: PersonalRecordsWidgetProps) {
  const navigate = useNavigate();

  const handleClick = () => {
    hapticLight();
    navigate('/progresso');
  };

  const displayRecords = records.slice(0, 3);
  const hasNewRecord = displayRecords.some(r => r.isNew);

  return (
    <motion.button
      onClick={handleClick}
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ type: "spring", stiffness: 400, damping: 30, delay: 0.15 }}
      whileHover={{ scale: 1.02, y: -2 }}
      whileTap={{ scale: 0.97 }}
      className={`relative overflow-hidden rounded-xl backdrop-blur-xl border border-yellow-500/25 p-3 text-left w-full ${className}`}
      style={{
        background: 'linear-gradient(135deg, rgba(234, 179, 8, 0.20) 0%, rgba(251, 191, 36, 0.12) 50%, rgba(0,0,0,0) 100%)',
        boxShadow: '0 8px 24px rgba(234, 179, 8, 0.15), inset 0 1px 0 rgba(255,255,255,0.1)'
      }}
    >
      {/* Top shine */}
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-yellow-400/50 to-transparent" />
      
      {/* Glow effect for new records */}
      {hasNewRecord && (
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-yellow-500/10 to-transparent"
          animate={{ opacity: [0.3, 0.6, 0.3] }}
          transition={{ duration: 2, repeat: Infinity }}
        />
      )}
      
      {/* Header - COMPACT */}
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-1.5">
          <div 
            className="w-7 h-7 rounded-lg flex items-center justify-center"
            style={{ 
              background: 'linear-gradient(135deg, rgba(234, 179, 8, 0.4), rgba(251, 191, 36, 0.25))',
              boxShadow: '0 4px 12px rgba(234, 179, 8, 0.3)'
            }}
          >
            <Trophy className="w-4 h-4 text-yellow-300" style={{ filter: 'drop-shadow(0 0 4px rgba(234, 179, 8, 0.5))' }} />
          </div>
          <div>
            <h4 className="text-xs font-bold text-foreground">Records</h4>
            {hasNewRecord && (
              <motion.span
                initial={{ opacity: 0, x: -5 }}
                animate={{ opacity: 1, x: 0 }}
                className="text-[9px] text-yellow-400 font-medium"
              >
                ✨ Novo!
              </motion.span>
            )}
          </div>
        </div>
        <ChevronRight className="w-3.5 h-3.5 text-white/30" />
      </div>
      
      {/* Records list - COMPACT */}
      {displayRecords.length > 0 ? (
        <div className="space-y-1.5">
          {displayRecords.map((record, index) => (
            <motion.div
              key={record.id}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 + index * 0.08 }}
              className={`flex items-center justify-between py-1 px-1.5 rounded-md ${record.isNew ? 'bg-yellow-500/15' : 'bg-white/5'}`}
            >
              <div className="flex items-center gap-1.5 min-w-0">
                <TrendingUp className={`w-3 h-3 flex-shrink-0 ${record.isNew ? 'text-yellow-400' : 'text-muted-foreground'}`} />
                <span className="text-[10px] text-foreground/80 truncate">{record.exerciseName}</span>
              </div>
              <div className="flex items-center gap-1">
                <span className={`text-[10px] font-bold ${record.isNew ? 'text-yellow-400' : 'text-foreground'}`}>
                  {record.value}{record.unit}
                </span>
                {record.isNew && (
                  <motion.div
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 0.5, repeat: Infinity, repeatDelay: 1 }}
                    className="w-1 h-1 rounded-full bg-yellow-400"
                  />
                )}
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <p className="text-[10px] text-muted-foreground text-center py-1">
          Seus recordes aparecerão aqui
        </p>
      )}
    </motion.button>
  );
}
