import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { CalendarIcon, Dumbbell, TrendingUp, Zap, Trophy, Target } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { unifiedDataService, WorkoutSessionData } from '@/services/UnifiedDataService';
import { format, isSameDay, startOfMonth, endOfMonth, eachDayOfInterval } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { logger } from '@/utils/logger';

interface WorkoutCalendarProps {
  className?: string;
}

interface CalendarWorkout {
  date: Date;
  workouts: WorkoutSessionData[];
  totalVolume: number;
  avgRpe: number;
  exerciseCount: number;
}

export function WorkoutCalendar({ className = "" }: WorkoutCalendarProps) {
  const { user } = useAuth();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [workoutData, setWorkoutData] = useState<CalendarWorkout[]>([]);
  const [selectedWorkout, setSelectedWorkout] = useState<CalendarWorkout | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadWorkoutData();
    }
  }, [user, currentMonth]);

  const loadWorkoutData = async () => {
    try {
      setIsLoading(true);
      
      // ONLY use UnifiedDataService - single source of truth
      const allWorkouts = await unifiedDataService.getWorkoutHistory(200, true);
      
      logger.log(`📅 Calendar: Loaded ${allWorkouts.length} workouts from UnifiedDataService`);

      // Group workouts by date
      const workoutsByDate = new Map<string, WorkoutSessionData[]>();
      
      allWorkouts.forEach(workout => {
        const dateToUse = workout.completed_at || workout.started_at;
        if (!dateToUse) return;
        
        const dateKey = format(new Date(dateToUse), 'yyyy-MM-dd');
        if (!workoutsByDate.has(dateKey)) {
          workoutsByDate.set(dateKey, []);
        }
        workoutsByDate.get(dateKey)!.push(workout);
      });

      // Create calendar data for current month
      const monthStart = startOfMonth(currentMonth);
      const monthEnd = endOfMonth(currentMonth);
      const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

      const calendarData: CalendarWorkout[] = daysInMonth.map(date => {
        const dateKey = format(date, 'yyyy-MM-dd');
        const dayWorkouts = workoutsByDate.get(dateKey) || [];
        
        // Calculate volume from workout.total_volume or exercises
        const totalVolume = dayWorkouts.reduce((sum, workout) => {
          if (workout.total_volume && workout.total_volume > 0) {
            return sum + workout.total_volume;
          }
          // Fallback: calculate from exercises if available
          if (workout.exercises?.length) {
            return sum + calculateVolumeFromExercises(workout.exercises);
          }
          return sum;
        }, 0);
        
        // Calculate avg RPE
        let totalRpe = 0;
        let rpeCount = 0;
        dayWorkouts.forEach(workout => {
          if (workout.exercises?.length) {
            workout.exercises.forEach((ex: any) => {
              if (ex.rpe) {
                totalRpe += ex.rpe;
                rpeCount++;
              }
            });
          }
        });
        const avgRpe = rpeCount > 0 ? totalRpe / rpeCount : 0;
        
        // Count exercises
        const exerciseCount = dayWorkouts.reduce((sum, workout) => 
          sum + (workout.exercises?.length || 0), 0
        );
        
        return {
          date,
          workouts: dayWorkouts,
          totalVolume,
          avgRpe,
          exerciseCount
        };
      });

      setWorkoutData(calendarData);
    } catch (error) {
      console.error('Error loading workout data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Helper to calculate volume from exercises
  const calculateVolumeFromExercises = (exercises: any[]): number => {
    return exercises.reduce((total, ex) => {
      const sets = ex.sets || 1;
      const reps = typeof ex.reps === 'number' ? ex.reps : parseInt(ex.reps) || 10;
      const weight = ex.weight || 0;
      return total + (sets * reps * weight);
    }, 0);
  };

  const getWorkoutForDate = (date: Date): CalendarWorkout | undefined => {
    return workoutData.find(workout => isSameDay(workout.date, date));
  };

  const handleDateSelect = (date: Date | undefined) => {
    if (!date) return;
    
    setSelectedDate(date);
    const workoutForDate = getWorkoutForDate(date);
    
    if (workoutForDate && workoutForDate.workouts.length > 0) {
      setSelectedWorkout(workoutForDate);
      setIsDetailModalOpen(true);
    }
  };

  const getDayClass = (date: Date) => {
    const workout = getWorkoutForDate(date);
    if (!workout || workout.workouts.length === 0) return '';
    
    // Color based on volume/intensity
    if (workout.totalVolume > 5000) return 'bg-accent text-accent-ink';
    if (workout.totalVolume > 2000) return 'bg-yellow-500/20 text-yellow-400';
    if (workout.totalVolume > 0) return 'bg-green-500/20 text-green-400';
    // Has workouts but no calculated volume
    return 'bg-accent/40 text-accent';
  };

  const getWorkoutSummary = () => {
    const thisMonth = workoutData.filter(day => day.workouts.length > 0);
    const totalWorkouts = thisMonth.reduce((sum, day) => sum + day.workouts.length, 0);
    const totalVolume = thisMonth.reduce((sum, day) => sum + day.totalVolume, 0);
    const avgRpe = thisMonth.length > 0 
      ? thisMonth.reduce((sum, day) => sum + day.avgRpe, 0) / thisMonth.filter(d => d.avgRpe > 0).length || 0
      : 0;

    return { totalWorkouts, totalVolume, avgRpe, activeDays: thisMonth.length };
  };

  const summary = getWorkoutSummary();

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Header with Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="glass-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-accent/20">
              <Dumbbell className="w-5 h-5 text-accent" />
            </div>
            <div>
              <div className="text-2xl font-bold text-txt">{summary.totalWorkouts}</div>
              <div className="text-sm text-txt-2">Treinos</div>
            </div>
          </div>
        </Card>

        <Card className="glass-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-green-500/20">
              <Target className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <div className="text-2xl font-bold text-txt">{summary.activeDays}</div>
              <div className="text-sm text-txt-2">Dias Ativos</div>
            </div>
          </div>
        </Card>

        <Card className="glass-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-yellow-500/20">
              <Trophy className="w-5 h-5 text-yellow-400" />
            </div>
            <div>
              <div className="text-2xl font-bold text-txt">{Math.round(summary.totalVolume).toLocaleString()}</div>
              <div className="text-sm text-txt-2">Volume (kg)</div>
            </div>
          </div>
        </Card>

        <Card className="glass-card p-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-red-500/20">
              <Zap className="w-5 h-5 text-red-400" />
            </div>
            <div>
              <div className="text-2xl font-bold text-txt">{summary.avgRpe.toFixed(1)}</div>
              <div className="text-sm text-txt-2">RPE Médio</div>
            </div>
          </div>
        </Card>
      </div>

      {/* Calendar */}
      <Card className="glass-card p-6">
        <div className="flex items-center gap-3 mb-6">
          <CalendarIcon className="w-6 h-6 text-accent" />
          <h2 className="text-xl font-bold text-txt">Calendário de Treinos</h2>
          <Badge className="bg-accent/20 text-accent">
            {format(currentMonth, 'MMMM yyyy', { locale: ptBR })}
          </Badge>
          {isLoading && (
            <span className="text-xs text-txt-3 animate-pulse">Carregando...</span>
          )}
        </div>

        <Calendar
          mode="single"
          selected={selectedDate}
          onSelect={handleDateSelect}
          month={currentMonth}
          onMonthChange={setCurrentMonth}
          className="rounded-md border-0"
          classNames={{
            day: "h-9 w-9 text-center text-sm p-0 relative [&:has([aria-selected])]:bg-accent first:[&:has([aria-selected])]:rounded-l-md last:[&:has([aria-selected])]:rounded-r-md focus-within:relative focus-within:z-20",
            day_selected: "bg-accent text-accent-ink hover:bg-accent hover:text-accent-ink focus:bg-accent focus:text-accent-ink",
            day_today: "bg-surface text-accent-foreground font-semibold",
            day_outside: "text-txt-3",
            day_disabled: "text-txt-3 opacity-50",
            day_range_middle: "aria-selected:bg-accent/50 aria-selected:text-accent-foreground",
            day_hidden: "invisible",
          }}
          modifiers={{
            workout: workoutData
              .filter(day => day.workouts.length > 0)
              .map(day => day.date)
          }}
          modifiersClassNames={{
            workout: "relative after:absolute after:bottom-1 after:left-1/2 after:transform after:-translate-x-1/2 after:w-1 after:h-1 after:bg-accent after:rounded-full"
          }}
          locale={ptBR}
        />

        <div className="mt-6 p-4 bg-surface/30 rounded-lg">
          <h3 className="text-sm font-semibold text-txt mb-2">Legenda:</h3>
          <div className="flex flex-wrap gap-4 text-xs">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded bg-accent"></div>
              <span className="text-txt-2">Volume Alto (&gt;5000kg)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded bg-yellow-500"></div>
              <span className="text-txt-2">Volume Médio (2000-5000kg)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded bg-green-500"></div>
              <span className="text-txt-2">Volume Baixo (&lt;2000kg)</span>
            </div>
          </div>
        </div>
      </Card>

      {/* Workout Detail Modal */}
      <Dialog open={isDetailModalOpen} onOpenChange={setIsDetailModalOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <CalendarIcon className="w-6 h-6 text-accent" />
              Treinos de {selectedWorkout && format(selectedWorkout.date, "d 'de' MMMM, yyyy", { locale: ptBR })}
            </DialogTitle>
          </DialogHeader>

          {selectedWorkout && (
            <div className="space-y-6">
              {/* Day Summary */}
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center p-3 bg-surface rounded-lg">
                  <div className="text-2xl font-bold text-accent">{selectedWorkout.workouts.length}</div>
                  <div className="text-sm text-txt-2">Sessões</div>
                </div>
                <div className="text-center p-3 bg-surface rounded-lg">
                  <div className="text-2xl font-bold text-yellow-400">{Math.round(selectedWorkout.totalVolume).toLocaleString()}</div>
                  <div className="text-sm text-txt-2">Volume (kg)</div>
                </div>
                <div className="text-center p-3 bg-surface rounded-lg">
                  <div className="text-2xl font-bold text-green-400">{selectedWorkout.avgRpe.toFixed(1)}</div>
                  <div className="text-sm text-txt-2">RPE Médio</div>
                </div>
              </div>

              {/* Workout Sessions */}
              <div className="space-y-4">
                {selectedWorkout.workouts.map((workout, index) => (
                  <Card key={workout.id || index} className="p-4 bg-surface/50">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-semibold text-txt">{workout.name || workout.focus}</h3>
                      <div className="flex items-center gap-2">
                        {workout.total_volume && workout.total_volume > 0 && (
                          <Badge variant="outline" className="text-yellow-400">
                            {Math.round(workout.total_volume)}kg
                          </Badge>
                        )}
                        <Badge variant="outline">
                          {format(new Date(workout.completed_at || workout.started_at!), 'HH:mm')}
                        </Badge>
                      </div>
                    </div>

                    {workout.exercises && workout.exercises.length > 0 ? (
                      <div className="space-y-2">
                        {workout.exercises.map((exercise: any, exIndex: number) => (
                          <div key={exIndex} className="flex items-center justify-between p-2 bg-card/50 rounded">
                            <div className="flex items-center gap-2">
                              <Dumbbell className="w-4 h-4 text-accent" />
                              <span className="text-txt font-medium">{exercise.name || 'Exercício'}</span>
                            </div>
                            <div className="flex items-center gap-4 text-sm text-txt-2">
                              {exercise.weight && <span>{exercise.weight}kg</span>}
                              {exercise.sets && <span>{exercise.sets}x</span>}
                              {exercise.reps && <span>{exercise.reps} reps</span>}
                              {exercise.rpe && <span>RPE {exercise.rpe}</span>}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-txt-3">Detalhes dos exercícios não disponíveis</p>
                    )}

                    {workout.duration_minutes && workout.duration_minutes > 0 && (
                      <div className="mt-3 text-sm text-txt-3">
                        Duração: {workout.duration_minutes} minutos
                      </div>
                    )}
                  </Card>
                ))}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
