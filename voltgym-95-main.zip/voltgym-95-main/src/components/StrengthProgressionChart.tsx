/**
 * StrengthProgressionChart - Line chart showing strength progress for main exercises
 * 
 * Displays weight progression over time with trend indicators.
 */

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { StrengthProgressData } from '@/hooks/usePerformanceInsights';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { TrendingUp, TrendingDown, Minus, Trophy } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface StrengthProgressionChartProps {
  data: StrengthProgressData[];
  className?: string;
}

export function StrengthProgressionChart({ data, className }: StrengthProgressionChartProps) {
  const [selectedExercise, setSelectedExercise] = useState(data[0]?.exercise || '');
  
  const currentExercise = data.find(d => d.exercise === selectedExercise);
  
  const chartData = currentExercise?.data.map(d => ({
    date: new Date(d.date).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' }),
    weight: d.weight,
    reps: d.reps,
    volume: d.volume,
  })) || [];

  const getTrendIcon = (change: number) => {
    if (change > 2) return <TrendingUp className="w-4 h-4 text-success" />;
    if (change < -2) return <TrendingDown className="w-4 h-4 text-destructive" />;
    return <Minus className="w-4 h-4 text-muted-foreground" />;
  };

  const getTrendColor = (change: number) => {
    if (change > 2) return 'text-success';
    if (change < -2) return 'text-destructive';
    return 'text-muted-foreground';
  };

  return (
    <div className={cn('space-y-4', className)}>
      {/* Exercise selector - scrollable horizontal */}
      {data.length > 0 && (
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {data.map((exercise) => (
            <motion.button
              key={exercise.exercise}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedExercise(exercise.exercise)}
              className={cn(
                'px-3 py-1.5 rounded-full text-sm font-medium transition-all whitespace-nowrap flex-shrink-0',
                'outline-none focus:outline-none select-none',
                selectedExercise === exercise.exercise
                  ? 'bg-accent text-accent-foreground'
                  : 'bg-muted/50 text-muted-foreground'
              )}
            >
              {exercise.exercise}
            </motion.button>
          ))}
        </div>
      )}

      {currentExercise && (
        <>
          {/* Stats */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-card/50 rounded-lg p-3 text-center">
              <p className="text-xs text-muted-foreground mb-1">Máximo Atual</p>
              <div className="flex items-center justify-center gap-1">
                <Trophy className="w-4 h-4 text-warning" />
                <span className="text-lg font-bold">{currentExercise.currentMax}kg</span>
              </div>
            </div>
            
            <div className="bg-card/50 rounded-lg p-3 text-center">
              <p className="text-xs text-muted-foreground mb-1">Anterior</p>
              <span className="text-lg font-bold">{currentExercise.previousMax}kg</span>
            </div>
            
            <div className="bg-card/50 rounded-lg p-3 text-center">
              <p className="text-xs text-muted-foreground mb-1">Variação</p>
              <div className="flex items-center justify-center gap-1">
                {getTrendIcon(currentExercise.changePercent)}
                <span className={cn('text-lg font-bold', getTrendColor(currentExercise.changePercent))}>
                  {currentExercise.changePercent > 0 ? '+' : ''}
                  {currentExercise.changePercent.toFixed(1)}%
                </span>
              </div>
            </div>
          </div>

          {/* Chart */}
          {chartData.length > 1 ? (
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                  <XAxis 
                    dataKey="date" 
                    axisLine={false} 
                    tickLine={false}
                    tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false}
                    tick={{ fontSize: 10, fill: 'hsl(var(--muted-foreground))' }}
                    domain={['dataMin - 5', 'dataMax + 5']}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (!active || !payload?.length) return null;
                      const data = payload[0].payload;
                      return (
                        <div className="bg-popover border border-border rounded-lg p-2 shadow-lg">
                          <p className="text-sm font-medium">{data.date}</p>
                          <p className="text-accent">{data.weight}kg x {data.reps} reps</p>
                          <p className="text-xs text-muted-foreground">Vol: {data.volume}kg</p>
                        </div>
                      );
                    }}
                  />
                  <ReferenceLine 
                    y={currentExercise.currentMax} 
                    stroke="hsl(var(--warning))" 
                    strokeDasharray="3 3"
                    label={{ value: 'PR', fill: 'hsl(var(--warning))', fontSize: 10 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="weight"
                    stroke="hsl(var(--accent))"
                    strokeWidth={2}
                    dot={{ fill: 'hsl(var(--accent))', strokeWidth: 0, r: 3 }}
                    activeDot={{ r: 5, fill: 'hsl(var(--accent))' }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-48 flex items-center justify-center text-muted-foreground">
              <p className="text-sm">Dados insuficientes para gráfico</p>
            </div>
          )}

          {/* Progress badge */}
          {currentExercise.changePercent > 5 && (
            <Badge variant="outline" className="bg-success/10 text-success border-success/30">
              🚀 Excelente progresso! +{currentExercise.changePercent.toFixed(1)}% de aumento
            </Badge>
          )}
        </>
      )}

      {data.length === 0 && (
        <div className="text-center py-8 text-muted-foreground space-y-2">
          <Trophy className="w-12 h-12 mx-auto opacity-30" />
          <p className="font-medium">Nenhum dado de progressão disponível</p>
          <p className="text-sm">Seus exercícios aparecerão aqui automaticamente conforme você treinar</p>
        </div>
      )}
    </div>
  );
}
