import React from 'react';
import { cn } from '@/lib/utils';
import voltgymBadge from '@/assets/voltgym-badge.png';

interface VoltBadgeProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showGlow?: boolean;
}

const sizeConfig = {
  xs: 'w-6 h-6',
  sm: 'w-8 h-8',
  md: 'w-10 h-10',
  lg: 'w-12 h-12',
  xl: 'w-14 h-14',
};

export function VoltBadge({ size = 'md', className, showGlow = false }: VoltBadgeProps) {
  const sizeClass = sizeConfig[size];
  
  return (
    <div className={cn("relative", className)}>
      {showGlow && (
        <div 
          className={cn(sizeClass, "absolute inset-0 bg-black/20 blur-xl rounded-full")} 
        />
      )}
      <img 
        src={voltgymBadge} 
        alt="VOLTGYM" 
        className={cn(
          sizeClass, 
          'relative z-10 object-contain drop-shadow-lg'
        )} 
      />
    </div>
  );
}

export default VoltBadge;
