import { useEffect, useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Brain, TrendingUp, Zap, Target, RefreshCw } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { mlFeaturesService, MLFeaturesData } from '@/services/MLFeaturesService';
import { toast } from 'sonner';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const COLORS = ['hsl(var(--primary))', 'hsl(var(--secondary))', 'hsl(var(--accent))', 'hsl(var(--muted))'];

export function MLFeaturesDashboard() {
  const { user } = useAuth();
  const [features, setFeatures] = useState<MLFeaturesData | null>(null);
  const [loading, setLoading] = useState(true);
  const [computing, setComputing] = useState(false);

  const loadFeatures = async () => {
    if (!user?.id) return;
    
    try {
      const data = await mlFeaturesService.getLatestFeatures(user.id);
      setFeatures(data);
    } catch (error) {
      console.error('Error loading ML features:', error);
    } finally {
      setLoading(false);
    }
  };

  const computeFeatures = async () => {
    if (!user?.id) return;
    
    setComputing(true);
    try {
      await mlFeaturesService.computeFeatures(user.id, 30);
      toast.success('Features computadas com sucesso!');
      await loadFeatures();
    } catch (error) {
      console.error('Error computing features:', error);
      toast.error('Erro ao computar features');
    } finally {
      setComputing(false);
    }
  };

  useEffect(() => {
    loadFeatures();
  }, [user?.id]);

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i} className="p-6 animate-pulse">
            <div className="h-20 bg-muted rounded" />
          </Card>
        ))}
      </div>
    );
  }

  if (!features) {
    return (
      <Card className="p-8 text-center">
        <Brain className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
        <h3 className="text-lg font-semibold mb-2">Nenhuma análise disponível</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Compute suas features de ML para visualizar insights avançados
        </p>
        <Button onClick={computeFeatures} disabled={computing}>
          <RefreshCw className={`w-4 h-4 mr-2 ${computing ? 'animate-spin' : ''}`} />
          {computing ? 'Computando...' : 'Computar Features'}
        </Button>
      </Card>
    );
  }

  const { features: f } = features;
  
  const muscleData = Object.entries(f.top_muscle_groups || {}).map(([name, value]) => ({
    name,
    value
  }));

  const volumeTrendData = (f.volume_trend || []).map((vol, idx) => ({
    session: `S${idx + 1}`,
    volume: vol
  }));

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Analytics com ML</h2>
        <Button onClick={computeFeatures} disabled={computing} variant="outline" size="sm">
          <RefreshCw className={`w-4 h-4 mr-2 ${computing ? 'animate-spin' : ''}`} />
          Atualizar
        </Button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="p-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-lg">
              <TrendingUp className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Volume Total</p>
              <p className="text-2xl font-bold">{Math.round(f.total_volume || 0)}</p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-secondary/10 rounded-lg">
              <Zap className="w-5 h-5 text-secondary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Duração Média</p>
              <p className="text-2xl font-bold">{Math.round(f.avg_session_duration || 0)}min</p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-accent/10 rounded-lg">
              <Target className="w-5 h-5 text-accent" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Frequência Semanal</p>
              <p className="text-2xl font-bold">{(f.frequency_per_week || 0).toFixed(1)}x</p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-lg">
              <Brain className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Consistência</p>
              <p className="text-2xl font-bold">{Math.round(f.consistency_score || 0)}%</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Volume Trend */}
        {volumeTrendData.length > 0 && (
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Tendência de Volume</h3>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={volumeTrendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="session" stroke="hsl(var(--muted-foreground))" />
                <YAxis stroke="hsl(var(--muted-foreground))" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
                <Line type="monotone" dataKey="volume" stroke="hsl(var(--primary))" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </Card>
        )}

        {/* Muscle Groups Distribution */}
        {muscleData.length > 0 && (
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Distribuição por Grupo Muscular</h3>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={muscleData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={(entry) => entry.name}
                  outerRadius={80}
                  fill="hsl(var(--primary))"
                  dataKey="value"
                >
                  {muscleData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </Card>
        )}
      </div>

      <p className="text-xs text-muted-foreground text-center">
        Última atualização: {new Date(features.computed_at).toLocaleString('pt-BR')}
      </p>
    </div>
  );
}
