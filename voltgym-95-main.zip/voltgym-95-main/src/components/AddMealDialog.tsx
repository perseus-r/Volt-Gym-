import { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, X } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { z } from 'zod';

const mealSchema = z.object({
  food_name: z.string().trim().min(1, 'Nome da refeição é obrigatório').max(100),
  meal_type: z.enum(['breakfast', 'lunch', 'dinner', 'snack']),
  calories: z.number().min(0, 'Calorias devem ser positivas').max(10000),
  protein: z.number().min(0, 'Proteína deve ser positiva').max(1000),
  carbs: z.number().min(0, 'Carboidratos devem ser positivos').max(1000),
  fat: z.number().min(0, 'Gordura deve ser positiva').max(1000),
  time: z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, 'Formato de hora inválido')
});

interface AddMealDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

export function AddMealDialog({ open, onOpenChange, onSuccess }: AddMealDialogProps) {
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    food_name: '',
    meal_type: 'lunch' as 'breakfast' | 'lunch' | 'dinner' | 'snack',
    calories: '',
    protein: '',
    carbs: '',
    fat: '',
    time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
  });

  const mealTypes = [
    { value: 'breakfast', label: '🍳 Café da Manhã' },
    { value: 'lunch', label: '🍽️ Almoço' },
    { value: 'dinner', label: '🍲 Jantar' },
    { value: 'snack', label: '🍎 Lanche' }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast.error('Você precisa estar logado');
      return;
    }

    try {
      setIsLoading(true);

      // Validar dados
      const validatedData = mealSchema.parse({
        food_name: formData.food_name,
        meal_type: formData.meal_type,
        calories: Number(formData.calories),
        protein: Number(formData.protein),
        carbs: Number(formData.carbs),
        fat: Number(formData.fat),
        time: formData.time
      });

      // Salvar no Supabase
      const { error } = await supabase
        .from('nutrition_logs')
        .insert({
          user_id: user.id,
          date: new Date().toISOString().split('T')[0],
          meal_type: validatedData.meal_type,
          food_name: validatedData.food_name,
          calories: validatedData.calories,
          protein: validatedData.protein,
          carbs: validatedData.carbs,
          fat: validatedData.fat,
          time: validatedData.time
        });

      if (error) throw error;

      toast.success('Refeição adicionada com sucesso!');
      
      // Reset form
      setFormData({
        food_name: '',
        meal_type: 'lunch',
        calories: '',
        protein: '',
        carbs: '',
        fat: '',
        time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
      });
      
      onSuccess();
      onOpenChange(false);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const firstError = error.errors[0];
        toast.error(firstError.message);
      } else {
        console.error('Erro ao adicionar refeição:', error);
        toast.error('Erro ao adicionar refeição');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-line/30 max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-txt">
            <Plus className="w-5 h-5 text-accent" />
            Adicionar Refeição
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="food_name" className="text-txt">
              Nome da Refeição
            </Label>
            <Input
              id="food_name"
              value={formData.food_name}
              onChange={(e) => setFormData({ ...formData, food_name: e.target.value })}
              placeholder="Ex: Frango grelhado com arroz"
              className="bg-surface border-line/30 text-txt"
              required
              maxLength={100}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="meal_type" className="text-txt">
                Tipo de Refeição
              </Label>
              <Select
                value={formData.meal_type}
                onValueChange={(value: any) => setFormData({ ...formData, meal_type: value })}
              >
                <SelectTrigger className="bg-surface border-line/30 text-txt">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {mealTypes.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="time" className="text-txt">
                Horário
              </Label>
              <Input
                id="time"
                type="time"
                value={formData.time}
                onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                className="bg-surface border-line/30 text-txt"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="calories" className="text-txt">
                Calorias (kcal)
              </Label>
              <Input
                id="calories"
                type="number"
                min="0"
                max="10000"
                value={formData.calories}
                onChange={(e) => setFormData({ ...formData, calories: e.target.value })}
                placeholder="0"
                className="bg-surface border-line/30 text-txt"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="protein" className="text-txt">
                Proteína (g)
              </Label>
              <Input
                id="protein"
                type="number"
                min="0"
                max="1000"
                value={formData.protein}
                onChange={(e) => setFormData({ ...formData, protein: e.target.value })}
                placeholder="0"
                className="bg-surface border-line/30 text-txt"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="carbs" className="text-txt">
                Carboidratos (g)
              </Label>
              <Input
                id="carbs"
                type="number"
                min="0"
                max="1000"
                value={formData.carbs}
                onChange={(e) => setFormData({ ...formData, carbs: e.target.value })}
                placeholder="0"
                className="bg-surface border-line/30 text-txt"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="fat" className="text-txt">
                Gordura (g)
              </Label>
              <Input
                id="fat"
                type="number"
                min="0"
                max="1000"
                value={formData.fat}
                onChange={(e) => setFormData({ ...formData, fat: e.target.value })}
                placeholder="0"
                className="bg-surface border-line/30 text-txt"
                required
              />
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="flex-1"
              disabled={isLoading}
            >
              <X className="w-4 h-4 mr-2" />
              Cancelar
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-accent text-accent-ink hover:bg-accent/90"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-accent-ink/30 border-t-accent-ink rounded-full animate-spin mr-2" />
                  Salvando...
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4 mr-2" />
                  Adicionar
                </>
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
