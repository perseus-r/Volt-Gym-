import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { TrendingUp, TrendingDown, Activity, Brain, CheckCircle2, AlertTriangle } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

interface FeedbackAnalysis {
  id: string;
  completion_rate: number;
  avg_rpe: number;
  expected_rpe: number;
  volume_achieved: number;
  adjustment_needed: boolean;
  adjustment_type: string;
  confidence_score: number;
  ai_analysis: string;
  recommendations: string[];
  analyzed_at: string;
}

export function FeedbackLoopDashboard() {
  const [feedbacks, setFeedbacks] = useState<FeedbackAnalysis[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalAnalyses: 0,
    avgCompletionRate: 0,
    avgConfidence: 0,
    activeRecommendations: 0,
  });

  useEffect(() => {
    loadFeedbackData();
  }, []);

  async function loadFeedbackData() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('workout_feedback_analysis')
        .select('*')
        .eq('user_id', user.id)
        .order('analyzed_at', { ascending: false })
        .limit(30);

      if (error) throw error;

      const analyses = (data || []) as FeedbackAnalysis[];
      setFeedbacks(analyses);

      // Calculate stats
      const totalAnalyses = analyses.length;
      const avgCompletionRate = analyses.length > 0
        ? analyses.reduce((sum, f) => sum + (f.completion_rate || 0), 0) / analyses.length
        : 0;
      const avgConfidence = analyses.length > 0
        ? analyses.reduce((sum, f) => sum + (f.confidence_score || 0), 0) / analyses.length
        : 0;
      const activeRecommendations = analyses.filter(f => f.adjustment_needed).length;

      setStats({
        totalAnalyses,
        avgCompletionRate,
        avgConfidence,
        activeRecommendations,
      });
    } catch (error) {
      console.error('Error loading feedback:', error);
    } finally {
      setLoading(false);
    }
  }

  const completionTrendData = feedbacks.slice(0, 10).reverse().map((f, idx) => ({
    name: `T${idx + 1}`,
    taxa: f.completion_rate || 0,
    rpe: f.avg_rpe || 0,
  }));

  const volumeData = feedbacks.slice(0, 10).reverse().map((f, idx) => ({
    name: `T${idx + 1}`,
    volume: f.volume_achieved || 0,
  }));

  const latestFeedback = feedbacks[0];

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (feedbacks.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5" />
            Sistema de Feedback Loop
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-center py-8">
            Complete um treino para ver análises de feedback da IA aqui.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Análises Totais
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Brain className="w-4 h-4 text-primary" />
              <p className="text-2xl font-bold">{stats.totalAnalyses}</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Taxa de Completude
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-green-500" />
              <p className="text-2xl font-bold">{stats.avgCompletionRate.toFixed(0)}%</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Confiança IA
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-blue-500" />
              <p className="text-2xl font-bold">{(stats.avgConfidence * 100).toFixed(0)}%</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Ajustes Ativos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-orange-500" />
              <p className="text-2xl font-bold">{stats.activeRecommendations}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Latest Feedback */}
      {latestFeedback && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Última Análise</span>
              <Badge variant={latestFeedback.adjustment_needed ? 'default' : 'secondary'}>
                {latestFeedback.adjustment_type === 'maintain' ? '✅ Manter' : 
                 latestFeedback.adjustment_type === 'increase_load' ? '📈 Aumentar Carga' :
                 latestFeedback.adjustment_type === 'decrease_volume' ? '📉 Reduzir Volume' :
                 '⏸️ Mais Descanso'}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">{latestFeedback.ai_analysis}</p>
            {latestFeedback.recommendations && latestFeedback.recommendations.length > 0 && (
              <div>
                <h4 className="font-semibold text-sm mb-2">Recomendações:</h4>
                <ul className="space-y-1">
                  {latestFeedback.recommendations.map((rec, idx) => (
                    <li key={idx} className="text-sm flex items-start gap-2">
                      <span className="text-primary">•</span>
                      <span>{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Completion Rate & RPE Trend */}
      <Card>
        <CardHeader>
          <CardTitle>Evolução de Completude e RPE</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={completionTrendData}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis dataKey="name" className="text-xs" />
              <YAxis className="text-xs" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px'
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey="taxa" 
                stroke="hsl(var(--primary))" 
                strokeWidth={2}
                name="Taxa (%)"
              />
              <Line 
                type="monotone" 
                dataKey="rpe" 
                stroke="hsl(var(--destructive))" 
                strokeWidth={2}
                name="RPE"
              />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Volume Progression */}
      <Card>
        <CardHeader>
          <CardTitle>Progressão de Volume</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={volumeData}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis dataKey="name" className="text-xs" />
              <YAxis className="text-xs" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px'
                }}
              />
              <Bar 
                dataKey="volume" 
                fill="hsl(var(--primary))"
                name="Volume (kg)"
                radius={[8, 8, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* AI Learning Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5" />
            Status de Aprendizado da IA
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Feedbacks Processados</span>
              <Badge variant="outline">{stats.totalAnalyses} análises</Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Taxa Média de Completude</span>
              <Badge variant={stats.avgCompletionRate >= 85 ? 'default' : 'secondary'}>
                {stats.avgCompletionRate.toFixed(0)}%
              </Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Confiança nas Análises</span>
              <Badge variant="outline">{(stats.avgConfidence * 100).toFixed(0)}%</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
