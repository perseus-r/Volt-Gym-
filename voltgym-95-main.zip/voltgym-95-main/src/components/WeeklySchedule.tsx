import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { Calendar, CalendarDays, Clock, Dumbbell, Edit3, History, Palette, Play, Plus, RefreshCw, Share2, Sparkles, Target, Trash2, X, Zap } from 'lucide-react';
import { unifiedDataService } from '@/services/UnifiedDataService';
import { supabase } from '@/integrations/supabase/client';
import { StravaStyleShareCard } from '@/components/share/StravaStyleShareCard';
import { WorkoutRoutineCalendar } from '@/components/workout/WorkoutRoutineCalendar';
import { startOfWeek, endOfWeek, format, isSameDay, parseISO, addDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { logger } from '@/utils/logger';

interface WorkoutWithSource {
  id: string;
  name: string;
  focus?: string;
  exercises?: any[];
  source: 'quick' | 'template' | 'saved' | 'custom' | 'history';
  [key: string]: any;
}

interface WeeklyScheduleItem {
  id: string;
  workout: any;
  scheduledFor: string;
  completed: boolean;
  completedAt?: string;
}

interface EnhancedWeeklyScheduleProps {
  onStartWorkout?: (workout: any) => void;
}

const DAYS_OF_WEEK = [
  { key: 'monday', label: 'Segunda-feira', short: 'SEG' },
  { key: 'tuesday', label: 'Terça-feira', short: 'TER' },
  { key: 'wednesday', label: 'Quarta-feira', short: 'QUA' },
  { key: 'thursday', label: 'Quinta-feira', short: 'QUI' },
  { key: 'friday', label: 'Sexta-feira', short: 'SEX' },
  { key: 'saturday', label: 'Sábado', short: 'SÁB' },
  { key: 'sunday', label: 'Domingo', short: 'DOM' }
];

const QUICK_TEMPLATES = [
  { id: 'quick-upper', name: 'Upper Body Express', focus: 'Membros Superiores', exercises: [{ name: 'Supino Reto', sets: 3, reps: '8-10' }] },
  { id: 'quick-lower', name: 'Lower Body Power', focus: 'Membros Inferiores', exercises: [{ name: 'Agachamento', sets: 4, reps: '8-10' }] },
  { id: 'quick-full', name: 'Full Body Essential', focus: 'Corpo Inteiro', exercises: [{ name: 'Puxada Alta', sets: 3, reps: '8-10' }] }
];

const getSourceBadge = (source: string) => {
  switch (source) {
    case 'saved':
      return { label: 'Meu Treino', icon: Sparkles, className: 'bg-green-500/20 text-green-400 border-green-500/30' };
    case 'custom':
      return { label: 'Personalizado', icon: Palette, className: 'bg-purple-500/20 text-purple-400 border-purple-500/30' };
    case 'template':
      return { label: 'Template', icon: Edit3, className: 'bg-blue-500/20 text-blue-400 border-blue-500/30' };
    case 'history':
      return { label: 'Histórico', icon: History, className: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' };
    case 'quick':
    default:
      return { label: 'Rápido', icon: Zap, className: 'bg-accent/20 text-accent border-accent/30' };
  }
};

export function EnhancedWeeklySchedule({ onStartWorkout }: EnhancedWeeklyScheduleProps) {
  const { user } = useAuth();
  const [schedule, setSchedule] = useState<Record<string, WeeklyScheduleItem[]>>({});
  const [availableWorkouts, setAvailableWorkouts] = useState<WorkoutWithSource[]>([]);
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [shareWorkout, setShareWorkout] = useState<any>(null);
  const [viewMode, setViewMode] = useState<'week' | 'month'>('week');
  const [completedWorkouts, setCompletedWorkouts] = useState<any[]>([]);
  const [userProfile, setUserProfile] = useState<{
    current_xp: number;
    streak_days: number;
    total_workouts: number;
  } | null>(null);

  // Carregar perfil do usuário para dados reais no share card
  useEffect(() => {
    const loadUserProfile = async () => {
      if (!user?.id) return;
      
      const { data: profile } = await supabase
        .from('profiles')
        .select('current_xp, streak_days, total_workouts')
        .eq('user_id', user.id)
        .single();
      
      if (profile) {
        setUserProfile(profile);
      }
    };
    loadUserProfile();
  }, [user?.id]);

  // Helper: Calcula as datas da semana atual (segunda a domingo)
  const getWeekDates = useCallback(() => {
    const now = new Date();
    const weekStart = startOfWeek(now, { weekStartsOn: 1 }); // Segunda-feira
    
    const dates: Record<string, Date> = {};
    DAYS_OF_WEEK.forEach((day, index) => {
      const date = addDays(weekStart, index);
      dates[day.key] = date;
    });
    return dates;
  }, []);

  // Memoize week dates for display
  const weekDates = useMemo(() => getWeekDates(), [getWeekDates]);

  // Função para sincronizar treinos do Supabase com a rotina
  const reconcileScheduleWithSessions = useCallback(async (currentSchedule: Record<string, WeeklyScheduleItem[]>) => {
    if (!user?.id) return currentSchedule;

    try {
      const weekDates = getWeekDates();
      const weekStart = startOfWeek(new Date(), { weekStartsOn: 1 });
      const weekEnd = endOfWeek(new Date(), { weekStartsOn: 1 });
      
      // AMPLIADO: buscar últimos 30 dias (AI Coach pode logar com datas passadas)
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

      // Buscar sessões completadas nos últimos 30 dias OU criadas esta semana
      const { data: completedSessions } = await supabase
        .from('workout_sessions')
        .select('*')
        .eq('user_id', user.id)
        .not('completed_at', 'is', null)
        .or(`completed_at.gte.${thirtyDaysAgo.toISOString()},created_at.gte.${weekStart.toISOString()}`)
        .order('total_volume', { ascending: false })
        .order('created_at', { ascending: false });

      if (!completedSessions?.length) return currentSchedule;

      logger.log(`🔄 Reconciling ${completedSessions.length} completed sessions with schedule`);

      const updatedSchedule = { ...currentSchedule };
      let syncedCount = 0;

      // Para cada dia da semana
      for (const day of DAYS_OF_WEEK) {
        const dayDate = weekDates[day.key];
        const dayItems = updatedSchedule[day.key] || [];

        // Encontrar sessões completadas neste dia
        const sessionsOnDay = completedSessions.filter(session => {
          const sessionDate = parseISO(session.completed_at);
          return isSameDay(sessionDate, dayDate);
        });

        if (sessionsOnDay.length === 0) continue;

        // Tentar fazer match/upgrade de itens (inclusive já completados sem sessionId ou com volume 0)
        for (let i = 0; i < dayItems.length; i++) {
          const item = dayItems[i];
          
          // Permitir upgrade se: não completado, OU completado sem sessionId, OU completado com volume 0
          const needsUpgrade = !item.completed || 
            !item.workout?.sessionId || 
            Number(item.workout?.total_volume || 0) === 0;
          
          if (!needsUpgrade) continue;

          // Normalizar nomes para comparação
          const normalize = (str: string) => str?.toLowerCase().trim().normalize('NFD').replace(/[\u0300-\u036f]/g, '') || '';
          const itemName = normalize(item.workout?.name);

          // Encontrar sessões que match por nome, priorizando maior total_volume e mais recente
          const matchingSessions = sessionsOnDay.filter(s => {
            const sessionName = normalize(s.name);
            return sessionName.includes(itemName) || itemName.includes(sessionName);
          });

          // Ordenar por total_volume DESC (numérico!), depois por created_at DESC
          matchingSessions.sort((a, b) => {
            const volumeDiff = Number(b.total_volume || 0) - Number(a.total_volume || 0);
            if (volumeDiff !== 0) return volumeDiff;
            return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
          });

          let matchingSession = matchingSessions[0];

          // Se não encontrou por nome, usar a sessão com maior volume/mais recente do dia (apenas se houver 1 sessão)
          if (!matchingSession && sessionsOnDay.length === 1) {
            matchingSession = sessionsOnDay[0];
          }

          // Só fazer upgrade se a sessão encontrada tem volume maior que o atual
          const currentVolume = Number(item.workout?.total_volume || 0);
          const newVolume = Number(matchingSession?.total_volume || 0);
          
          if (matchingSession && (newVolume > currentVolume || !item.workout?.sessionId)) {
            dayItems[i] = {
              ...item,
              completed: true,
              completedAt: matchingSession.completed_at,
              workout: {
                ...item.workout,
                total_volume: matchingSession.total_volume,
                duration_minutes: matchingSession.duration_minutes,
                xp_earned: matchingSession.xp_earned,
                sessionId: matchingSession.id,
              }
            };
            syncedCount++;
            logger.log(`✅ Synced/Upgraded: "${item.workout?.name}" → session ${matchingSession.id} (volume: ${newVolume}kg)`);
          }
        }

        updatedSchedule[day.key] = dayItems;
      }

      // Também criar itens para sessões que não têm match na rotina (treinos via AI Coach)
      for (const session of completedSessions) {
        const sessionDate = parseISO(session.completed_at);
        const dayKey = DAYS_OF_WEEK[sessionDate.getDay() === 0 ? 6 : sessionDate.getDay() - 1]?.key;
        
        if (!dayKey) continue;
        
        const dayItems = updatedSchedule[dayKey] || [];
        const normalize = (str: string) => str?.toLowerCase().trim().normalize('NFD').replace(/[\u0300-\u036f]/g, '') || '';
        const sessionName = normalize(session.name);
        
        // Verificar se já existe um item para esta sessão (ou se há uma versão melhor)
        const existingIndex = dayItems.findIndex(item => {
          const itemName = normalize(item.workout?.name);
          return item.workout?.sessionId === session.id || 
                 (item.completed && (sessionName.includes(itemName) || itemName.includes(sessionName)));
        });

        // Se não existe, adicionar; se existe mas esta sessão tem maior volume, substituir
        const shouldReplace = existingIndex >= 0 && 
          (session.total_volume || 0) > (dayItems[existingIndex].workout?.total_volume || 0);

        if (existingIndex < 0 || shouldReplace) {
          const newItem = {
            id: `synced_${session.id}`,
            workout: {
              id: session.id,
              name: session.name || 'Treino',
              focus: session.focus || 'Geral',
              total_volume: session.total_volume,
              duration_minutes: session.duration_minutes,
              xp_earned: session.xp_earned,
              sessionId: session.id,
            },
            scheduledFor: dayKey,
            completed: true,
            completedAt: session.completed_at,
          };

          if (shouldReplace) {
            // Substituir item existente com versão de maior volume
            logger.log(`🔄 Replacing "${dayItems[existingIndex].workout?.name}" with higher volume session (${session.total_volume}kg)`);
            dayItems[existingIndex] = newItem;
          } else {
            // Adicionar como novo item completado
            dayItems.push(newItem);
            logger.log(`➕ Added completed session "${session.name}" to ${dayKey}`);
          }
          syncedCount++;
        }

        updatedSchedule[dayKey] = dayItems;
      }

      if (syncedCount > 0) {
        logger.log(`🎉 Synced ${syncedCount} workout(s) with schedule`);
      }

      return updatedSchedule;
    } catch (error) {
      logger.error('Error reconciling schedule:', error);
      return currentSchedule;
    }
  }, [user?.id, getWeekDates]);

  // Sincronizar manualmente
  const handleManualSync = useCallback(async () => {
    if (!user?.id) return;
    
    setSyncing(true);
    try {
      const reconciledSchedule = await reconcileScheduleWithSessions(schedule);
      saveSchedule(reconciledSchedule);
      toast.success('Rotina sincronizada com treinos concluídos!');
    } catch (error) {
      toast.error('Erro ao sincronizar');
    } finally {
      setSyncing(false);
    }
  }, [user?.id, schedule, reconcileScheduleWithSessions]);

  useEffect(() => {
    loadScheduleAndWorkouts();
  }, [user?.id]);

  const loadScheduleAndWorkouts = async () => {
    try {
      setLoading(true);
      
      // Usar chave padronizada volt_*
      const scheduleKey = user?.id ? `volt_schedule_${user.id}` : 'volt_schedule_anonymous';
      
      // Migrar de chave antiga se necessário
      const legacySchedule = localStorage.getItem('enhanced_weekly_schedule');
      if (legacySchedule && !localStorage.getItem(scheduleKey)) {
        localStorage.setItem(scheduleKey, legacySchedule);
        logger.log('📦 Migrated enhanced_weekly_schedule → ' + scheduleKey);
      }
      
      // Carregar agenda salva
      let initialSchedule: Record<string, WeeklyScheduleItem[]> = {};
      const savedV2 = localStorage.getItem(scheduleKey);
      if (savedV2) {
        const parsed = JSON.parse(savedV2);
        Object.entries(parsed || {}).forEach(([day, value]) => {
          initialSchedule[day] = Array.isArray(value) ? (value as WeeklyScheduleItem[]) : value ? [value as WeeklyScheduleItem] : [];
        });
      }

      const allWorkouts: WorkoutWithSource[] = [];
      const seenNames = new Set<string>();

      const addWorkout = (w: any, source: WorkoutWithSource['source']) => {
        if (!w?.name) return;
        const key = w.name.toLowerCase().trim();
        if (seenNames.has(key)) return;
        seenNames.add(key);
        allWorkouts.push({ 
          ...w, 
          id: w.id || `${source}_${Date.now()}_${Math.random().toString(36).slice(2)}`,
          source 
        });
      };

      // 1. Templates do usuário (volt_templates_*)
      if (user?.id) {
        try {
          const userTemplates = JSON.parse(localStorage.getItem(`volt_templates_${user.id}`) || '[]');
          userTemplates.forEach((t: any) => addWorkout(t, 'template'));
        } catch {}
      }

      // 2. Histórico via unifiedDataService (já consolida todas as fontes)
      try {
        const history = await unifiedDataService.getWorkoutHistory(30);
        history.forEach((w: any) => addWorkout(w, 'history'));
      } catch {}

      // 3. Treinos do Supabase (inclui treinos do Coach IA)
      if (user?.id) {
        try {
          const { data: dbSessions } = await supabase
            .from('workout_sessions')
            .select('*')
            .eq('user_id', user.id)
            .not('completed_at', 'is', null)
            .order('completed_at', { ascending: false })
            .limit(20);
          
          dbSessions?.forEach((session: any) => addWorkout({
            id: session.id,
            name: session.name || 'Treino',
            focus: session.focus || 'Geral',
            duration_minutes: session.duration_minutes,
            total_volume: session.total_volume,
            completed_at: session.completed_at,
            xp_earned: session.xp_earned,
            notes: session.notes,
            source: 'history'
          }, 'history'));
        } catch (e) {
          logger.error('Erro ao carregar treinos do banco:', e);
        }
      }

      // 4. Quick templates como fallback
      QUICK_TEMPLATES.forEach(q => addWorkout(q, 'quick'));

      setAvailableWorkouts(allWorkouts);

      // 5. Fetch completed workouts for calendar
      if (user?.id) {
        try {
          const { data: sessions } = await supabase
            .from('workout_sessions')
            .select('*')
            .eq('user_id', user.id)
            .not('completed_at', 'is', null)
            .order('completed_at', { ascending: false })
            .limit(100);
          
          if (sessions) {
            setCompletedWorkouts(sessions.map(s => ({
              id: s.id,
              name: s.name || 'Treino',
              focus: s.focus,
              completed_at: s.completed_at,
              created_at: s.created_at,
              total_volume: s.total_volume,
              duration_minutes: s.duration_minutes,
            })));
          }
        } catch (e) {
          logger.error('Erro ao carregar treinos para calendário:', e);
        }
      }

      // 6. AUTO-SYNC: Reconciliar treinos concluídos do Supabase com a rotina
      if (user?.id) {
        const reconciledSchedule = await reconcileScheduleWithSessions(initialSchedule);
        setSchedule(reconciledSchedule);
        localStorage.setItem(scheduleKey, JSON.stringify(reconciledSchedule));
      } else {
        setSchedule(initialSchedule);
      }
    } catch (e) {
      logger.error('Erro ao carregar agenda', e);
      toast.error('Erro ao carregar agenda');
    } finally {
      setLoading(false);
    }
  };

  const saveSchedule = (next: Record<string, WeeklyScheduleItem[]>) => {
    setSchedule(next);
    const scheduleKey = user?.id ? `volt_schedule_${user.id}` : 'volt_schedule_anonymous';
    localStorage.setItem(scheduleKey, JSON.stringify(next));
  };

  const addWorkoutToDay = (dayKey: string, workout: any) => {
    const item: WeeklyScheduleItem = {
      id: `sched_${Date.now()}_${Math.random().toString(36).slice(2)}`,
      workout,
      scheduledFor: dayKey,
      completed: false,
    };
    const next = { ...schedule, [dayKey]: [ ...(schedule[dayKey] || []), item ] };
    saveSchedule(next);
    toast.success(`Adicionado em ${DAYS_OF_WEEK.find(d => d.key === dayKey)?.label}`);
    setShowAddDialog(false);
    setSelectedDay(null);
  };

  const removeOneFromDay = (dayKey: string, itemId: string) => {
    const list = schedule[dayKey] || [];
    const nextList = list.filter(i => i.id !== itemId);
    const next = { ...schedule };
    if (nextList.length) next[dayKey] = nextList; else delete next[dayKey];
    saveSchedule(next);
  };

  const clearDay = (dayKey: string) => {
    const dayLabel = DAYS_OF_WEEK.find(d => d.key === dayKey)?.label || dayKey;
    if (confirm(`Remover todos os treinos de ${dayLabel}?`)) {
      const next = { ...schedule };
      delete next[dayKey];
      saveSchedule(next);
      toast.success(`Todos os treinos de ${dayLabel} foram removidos`);
    }
  };

  const markCompleted = (dayKey: string, itemId: string) => {
    const list = schedule[dayKey] || [];
    const idx = list.findIndex(i => i.id === itemId);
    if (idx === -1) return;
    const updated = { ...list[idx], completed: true, completedAt: new Date().toISOString() };
    const nextList = [...list.slice(0, idx), updated, ...list.slice(idx + 1)];
    saveSchedule({ ...schedule, [dayKey]: nextList });
  };

  const startWorkout = (dayKey: string, itemId: string) => {
    const list = schedule[dayKey] || [];
    const item = list.find(i => i.id === itemId);
    if (!item) return;
    onStartWorkout?.(item.workout);
    markCompleted(dayKey, itemId);
  };

  // Helper para extrair nome limpo do exercício
  const extractExerciseName = (notes: string | null) => {
    if (!notes) return 'Exercício';
    // Pegar apenas até o primeiro " - " (remove instruções como "4x10 - Mantenha...")
    const parts = notes.split(' - ');
    return parts[0]?.trim() || 'Exercício';
  };

  // Helper: Normaliza string para comparação
  const normalize = (str: string) => str?.toLowerCase().trim().normalize('NFD').replace(/[\u0300-\u036f]/g, '') || '';

  // Buscar dados COMPLETOS do treino ao compartilhar (exercise_logs + set_logs)
  // ESTRATÉGIA ROBUSTA: buscar por nome + validar que tem sets reais
  const handleShareWorkout = useCallback(async (item: WeeklyScheduleItem) => {
    if (!user?.id) {
      setShareWorkout(item.workout);
      return;
    }

    try {
      const sessionId = item.workout?.sessionId;
      let session: any = null;
      let exerciseLogs: any[] = [];

      // Função para buscar exercise_logs com set_logs de uma sessão
      const fetchExerciseLogs = async (sid: string) => {
        const { data: logs } = await supabase
          .from('exercise_logs')
          .select(`
            id,
            notes,
            order_index,
            completed,
            set_logs (
              set_number,
              weight,
              reps,
              rpe
            )
          `)
          .eq('session_id', sid)
          .order('order_index');
        return logs || [];
      };

      // Função para calcular volume a partir de exercise_logs
      const calculateVolume = (logs: any[]) => {
        return logs.reduce((total, log) => {
          const sets = log.set_logs || [];
          return total + sets.reduce((sum: number, s: any) => sum + (Number(s.weight || 0) * Number(s.reps || 0)), 0);
        }, 0);
      };

      // Função para contar sets totais
      const countSets = (logs: any[]) => {
        return logs.reduce((sum, log) => sum + (log.set_logs?.length || 0), 0);
      };

      // Função para contar sets COM peso real (weight > 0)
      const countSetsWithWeight = (logs: any[]) => {
        return logs.reduce((sum, log) => 
          sum + (log.set_logs?.filter((s: any) => Number(s.weight || 0) > 0).length || 0), 0);
      };

      // Função para validar se uma sessão tem dados reais de volume
      const hasRealVolume = (logs: any[], sessionData: any) => {
        const calcVol = calculateVolume(logs);
        const setsWithWeight = countSetsWithWeight(logs);
        const savedVol = Number(sessionData?.total_volume || 0);
        return setsWithWeight > 0 || calcVol > 0 || savedVol > 0;
      };

      if (sessionId) {
        // Tentar buscar sessão pelo ID direto
        const { data: sessionData } = await supabase
          .from('workout_sessions')
          .select('*')
          .eq('id', sessionId)
          .maybeSingle();
        
        session = sessionData;
        if (session) {
          exerciseLogs = await fetchExerciseLogs(sessionId);
          
          // VALIDAÇÃO: Se sessionId aponta para sessão SEM volume real, ignorar e buscar alternativa
          if (!hasRealVolume(exerciseLogs, session)) {
            logger.log(`⚠️ sessionId ${sessionId} aponta para sessão sem volume real, buscando alternativa...`);
            session = null;
            exerciseLogs = [];
          }
        }
      }

      // Se não tem sessionId OU a sessão não tem volume real → buscar por NOME
      if (!session) {
        logger.log('🔍 Buscando sessão por nome (sessionId ausente ou sem volume real)...');
        
        const itemName = normalize(item.workout?.name || '');
        
        // Buscar últimas 200 sessões completadas do usuário (janela ampla de 90 dias)
        const ninetyDaysAgo = new Date();
        ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
        
        const { data: recentSessions } = await supabase
          .from('workout_sessions')
          .select('*')
          .eq('user_id', user.id)
          .not('completed_at', 'is', null)
          .gte('completed_at', ninetyDaysAgo.toISOString())
          .order('completed_at', { ascending: false })
          .limit(200);

        if (recentSessions && recentSessions.length > 0) {
          // Filtrar por match de nome
          const matchingSessions = recentSessions.filter(s => {
            const sessionName = normalize(s.name || '');
            return sessionName.includes(itemName) || itemName.includes(sessionName) || 
                   sessionName === itemName;
          });

          logger.log(`📋 Encontradas ${matchingSessions.length} sessões com nome similar a "${item.workout?.name}"`);

          // Analisar cada candidata para calcular volume real e sets com peso
          const candidateSessions = matchingSessions.length > 0 ? matchingSessions : recentSessions.slice(0, 10);
          
          // Buscar logs de TODAS as candidatas em paralelo para ranking preciso
          const candidatesWithData = await Promise.all(
            candidateSessions.slice(0, 15).map(async (c) => {
              const logs = await fetchExerciseLogs(c.id);
              const calcVol = calculateVolume(logs);
              const setsWithWeight = countSetsWithWeight(logs);
              const savedVol = Number(c.total_volume || 0);
              return { 
                ...c, 
                logs, 
                calcVol, 
                setsWithWeight, 
                savedVol,
                bestVol: Math.max(calcVol, savedVol)
              };
            })
          );

          // Ordenar por: 1) setsWithWeight DESC, 2) bestVol DESC, 3) created_at DESC
          candidatesWithData.sort((a, b) => {
            if (b.setsWithWeight !== a.setsWithWeight) return b.setsWithWeight - a.setsWithWeight;
            if (b.bestVol !== a.bestVol) return b.bestVol - a.bestVol;
            return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
          });

          // Usar a melhor candidata com volume real
          const best = candidatesWithData.find(c => c.setsWithWeight > 0 || c.bestVol > 0);
          if (best) {
            session = best;
            exerciseLogs = best.logs;
            logger.log(`✅ Melhor sessão: "${best.name}" - ${best.setsWithWeight} sets com peso, ${best.bestVol}kg volume`);
          } else if (candidatesWithData.length > 0) {
            // Fallback: usar a mais recente mesmo sem volume
            const fallback = candidatesWithData[0];
            session = fallback;
            exerciseLogs = fallback.logs;
            logger.log(`⚠️ Usando fallback: "${fallback.name}" (sem volume real)`);
          }
        }
      }

      // Transformar exercise_logs para formato do ShareCard
      const exercises = exerciseLogs.map(log => {
        const sets = log.set_logs || [];
        const maxWeight = sets.length > 0 
          ? Math.max(...sets.map((s: any) => Number(s.weight || 0)))
          : 0;
        const avgReps = sets.length > 0
          ? Math.round(sets.reduce((sum: number, s: any) => sum + (Number(s.reps || 0)), 0) / sets.length)
          : 0;

        return {
          name: extractExerciseName(log.notes),
          sets: sets.length,
          reps: avgReps,
          weight: maxWeight,
        };
      });

      // Calcular volume total a partir dos sets reais (FONTE DE VERDADE)
      const calculatedVolume = calculateVolume(exerciseLogs);
      const totalSets = countSets(exerciseLogs);
      const setsWithWeight = countSetsWithWeight(exerciseLogs);

      // Determinar o melhor volume
      const sessionVolume = Number(session?.total_volume || 0);
      const itemVolume = Number(item.workout?.total_volume || 0);
      
      // Prioridade: sets com peso > volume calculado > volume salvo na sessão > volume do item
      const finalVolume = setsWithWeight > 0 && calculatedVolume > 0 
        ? calculatedVolume 
        : (sessionVolume > 0 ? sessionVolume : itemVolume);

      logger.log('📊 Volume final:', { 
        calculatedVolume, 
        sessionVolume, 
        itemVolume, 
        finalVolume,
        totalSets,
        setsWithWeight,
        sessionId: session?.id,
        sessionName: session?.name
      });

      setShareWorkout({
        ...item.workout,
        name: session?.name || item.workout?.name,
        focus: session?.focus || item.workout?.focus,
        exercises: exercises.length > 0 ? exercises : item.workout?.exercises,
        total_volume: finalVolume,
        totalVolume: finalVolume,
        duration_minutes: session?.duration_minutes || item.workout?.duration_minutes || 0,
        xp_earned: session?.xp_earned || item.workout?.xp_earned || 0,
        completed_at: session?.completed_at || item.completedAt,
      });
    } catch (error) {
      logger.error('Erro ao buscar dados do treino:', error);
      setShareWorkout(item.workout);
    }
  }, [user?.id]);

  const todayKey = useMemo(() => {
    const idx = new Date().getDay();
    const keys = ['sunday','monday','tuesday','wednesday','thursday','friday','saturday'];
    return keys[idx];
  }, []);

  const todaysNext = useMemo(() => {
    const list = schedule[todayKey] || [];
    return list.find(i => !i.completed) || list[0];
  }, [schedule, todayKey]);

  const totalScheduled = Object.values(schedule).reduce((sum, list) => sum + list.length, 0);
  const totalCompleted = Object.values(schedule).reduce((sum, list) => sum + list.filter(i => i.completed).length, 0);

  if (loading) {
    return (
      <Card className="p-6">
        <div className="flex items-center justify-center gap-3 text-txt-2">
          Carregando agenda...
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Destaque do dia */}
      {todaysNext && viewMode === 'week' && (
        <Card className="p-6 bg-gradient-to-r from-accent/20 to-accent/10 border-accent/30">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-accent/20 rounded-full">
                <Dumbbell className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-txt mb-1">🎯 Treino de Hoje</h3>
                <p className="text-lg font-semibold text-accent">{todaysNext.workout.name}</p>
                <p className="text-txt-2">{todaysNext.workout.focus}</p>
                <div className="flex items-center gap-4 mt-2 text-sm text-txt-3">
                  <span className="flex items-center gap-1"><Target className="w-4 h-4" />{todaysNext.workout.exercises?.length || 0} exercícios</span>
                </div>
              </div>
            </div>
            {!todaysNext.completed && (
              <Button onClick={() => startWorkout(todayKey, todaysNext.id)} className="bg-accent text-accent-ink hover:bg-accent/90 px-8 py-3 text-lg" size="lg">
                <Play className="w-5 h-5 mr-2" />
                Começar Agora
              </Button>
            )}
          </div>
        </Card>
      )}

      {/* View Mode Tabs */}
      <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as 'week' | 'month')} className="w-full">
        <TabsList className="grid w-full max-w-xs grid-cols-2">
          <TabsTrigger value="week" className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            Semana
          </TabsTrigger>
          <TabsTrigger value="month" className="flex items-center gap-2">
            <CalendarDays className="w-4 h-4" />
            Mês
          </TabsTrigger>
        </TabsList>

        <TabsContent value="week" className="mt-4">
          {/* Grade semanal com datas reais */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-7 gap-4">
            {DAYS_OF_WEEK.map((day) => {
              const list = schedule[day.key] || [];
              const isToday = todayKey === day.key;
              const dayDate = weekDates[day.key];
              const formattedDate = dayDate ? format(dayDate, 'dd/MM', { locale: ptBR }) : '';
              
              return (
                <Card key={day.key} className={`p-4 transition-all ${isToday ? 'ring-2 ring-accent bg-accent/5' : ''}`}>
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <h4 className="font-semibold text-txt text-sm">{day.short}</h4>
                      <span className="text-xs text-txt-3">{formattedDate}</span>
                      {isToday && (
                        <Badge variant="outline" className="text-xs mt-1 bg-accent/20 text-accent border-accent/30 block w-fit">Hoje</Badge>
                      )}
                    </div>
                    {list.length > 0 && (
                      <Button variant="ghost" size="sm" onClick={() => clearDay(day.key)} className="text-txt-3 hover:text-red-400 p-1">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>

                  <div className="space-y-2 min-h-[120px]">
                    {list.map((item) => (
                      <div key={item.id} className={`p-2 rounded-lg bg-surface/60 border ${item.completed ? 'border-green-500/30' : 'border-line'} relative group`}>
                        <button onClick={() => removeOneFromDay(day.key, item.id)} className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <X className="w-3 h-3 text-txt-3 hover:text-red-400" />
                        </button>
                        <div className="pr-4">
                          <h5 className="font-medium text-txt text-sm line-clamp-1">{item.workout.name}</h5>
                          <p className="text-xs text-txt-2">{item.workout.focus}</p>
                          <div className="flex items-center justify-between mt-2">
                            <div className="flex items-center gap-2 text-xs text-txt-3">
                              <span className="flex items-center gap-1"><Target className="w-3 h-3" />{item.workout.exercises?.length || 0}</span>
                              <span className="flex items-center gap-1"><Clock className="w-3 h-3" />~{item.workout.duration_minutes || Math.round((item.workout.exercises?.length || 0) * 4)}min</span>
                            </div>
                            {!item.completed ? (
                              <Button size="sm" className="h-7 px-2 text-xs bg-accent/20 text-accent hover:bg-accent/30" onClick={() => startWorkout(day.key, item.id)}>
                                <Play className="w-3 h-3 mr-1" /> Iniciar
                              </Button>
                            ) : (
                              <div className="flex items-center gap-1">
                                <Button 
                                  size="sm" 
                                  variant="ghost" 
                                  className="h-6 w-6 p-0 text-accent hover:bg-accent/20"
                                  onClick={() => handleShareWorkout(item)}
                                >
                                  <Share2 className="w-3 h-3" />
                                </Button>
                                <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-[10px]">Concluído</Badge>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}

                    <Button
                      onClick={() => { setSelectedDay(day.key); setShowAddDialog(true); }}
                      size="sm"
                      variant="outline"
                      className="w-full h-8 text-xs border-dashed"
                    >
                      <Plus className="w-3 h-3 mr-1" /> Adicionar
                    </Button>
                  </div>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="month" className="mt-4">
          <Card className="p-6">
            <WorkoutRoutineCalendar workouts={completedWorkouts} />
          </Card>
        </TabsContent>
      </Tabs>

      {/* Resumo */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-txt">Resumo da Semana</h3>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleManualSync}
            disabled={syncing}
            className="text-accent border-accent/30 hover:bg-accent/10"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${syncing ? 'animate-spin' : ''}`} />
            {syncing ? 'Sincronizando...' : 'Sincronizar'}
          </Button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-accent">{totalScheduled}</div>
            <div className="text-sm text-txt-2">Treinos Agendados</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-400">{totalCompleted}</div>
            <div className="text-sm text-txt-2">Concluídos</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-400">{totalScheduled - totalCompleted}</div>
            <div className="text-sm text-txt-2">Pendentes</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-txt">{availableWorkouts.length}</div>
            <div className="text-sm text-txt-2">Treinos Disponíveis</div>
          </div>
        </div>
      </Card>

      {/* Dialog de seleção */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-2xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>
              Escolher treino para {selectedDay && DAYS_OF_WEEK.find(d => d.key === selectedDay)?.label}
            </DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-96 pr-3">
            <div className="space-y-3">
              {availableWorkouts.map((workout) => {
                const badge = getSourceBadge(workout.source);
                const BadgeIcon = badge.icon;
                return (
                  <Card key={workout.id} className="p-4 cursor-pointer hover:bg-accent/10 transition-colors border hover:border-accent/30" onClick={() => selectedDay && addWorkoutToDay(selectedDay, workout)}>
                    <div className="flex items-center justify-between">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3 mb-2">
                          <Dumbbell className="w-5 h-5 text-accent" />
                          <h4 className="font-semibold text-txt">{workout.name}</h4>
                          <Badge variant="outline" className={`text-xs ${badge.className}`}>
                            <BadgeIcon className="w-3 h-3 mr-1" />
                            {badge.label}
                          </Badge>
                        </div>
                        <p className="text-sm text-txt-2 mb-2">{workout.focus || 'Treino Personalizado'}</p>
                        <div className="flex items-center gap-4 text-xs text-txt-3">
                          <span className="flex items-center gap-1"><Target className="w-3 h-3" />{workout.exercises?.length || 0} exercícios</span>
                        </div>
                      </div>
                      <Play className="w-5 h-5 text-accent" />
                    </div>
                  </Card>
                );
              })}
              {availableWorkouts.length === 0 && (
                <div className="text-center py-8">
                  <Dumbbell className="w-12 h-12 text-txt-3 mx-auto mb-4" />
                  <p className="text-txt-2">Nenhum treino disponível</p>
                </div>
              )}
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>

      {/* Share Card Modal - VoltWorkoutShareCard (Treino Individual) */}
      {shareWorkout && (
        <StravaStyleShareCard
          workout={{
            name: shareWorkout.name,
            focus: shareWorkout.focus || 'Treino',
            exercises: shareWorkout.exercises || [],
            total_volume: shareWorkout.total_volume || shareWorkout.totalVolume || 0,
            duration_minutes: shareWorkout.duration_minutes || Math.round((shareWorkout.exercises?.length || 0) * 4),
            completed_at: new Date().toISOString(),
          }}
          onClose={() => setShareWorkout(null)}
        />
      )}
    </div>
  );
}
