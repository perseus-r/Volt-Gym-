import React, { useEffect } from 'react';
import { motion, AnimatePresence, PanInfo } from 'framer-motion';
import { X } from 'lucide-react';
import { cn } from '@/lib/utils';

interface MobileSheetProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
  title?: string;
  snapPoints?: number[]; // Percentage heights [30, 60, 90]
  initialSnap?: number; // Index of initial snap point
  showHandle?: boolean;
  className?: string;
}

export function MobileSheet({
  isOpen,
  onClose,
  children,
  title,
  snapPoints = [30, 60, 90],
  initialSnap = 1,
  showHandle = true,
  className
}: MobileSheetProps) {
  const [currentSnap, setCurrentSnap] = React.useState(initialSnap);
  const [isDragging, setIsDragging] = React.useState(false);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  const handleDragEnd = (_: any, info: PanInfo) => {
    setIsDragging(false);
    const { offset, velocity } = info;

    // Swipe down to close
    if (offset.y > 100 || velocity.y > 500) {
      onClose();
      return;
    }

    // Swipe up to expand
    if (offset.y < -100 || velocity.y < -500) {
      if (currentSnap < snapPoints.length - 1) {
        setCurrentSnap(currentSnap + 1);
      }
      return;
    }

    // Find nearest snap point
    const currentHeight = snapPoints[currentSnap];
    const draggedHeight = currentHeight - (offset.y / window.innerHeight) * 100;
    
    let nearestSnap = 0;
    let minDiff = Infinity;
    
    snapPoints.forEach((snap, index) => {
      const diff = Math.abs(snap - draggedHeight);
      if (diff < minDiff) {
        minDiff = diff;
        nearestSnap = index;
      }
    });

    setCurrentSnap(nearestSnap);
  };

  const currentHeight = snapPoints[currentSnap];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[90]"
          />

          {/* Sheet */}
          <motion.div
            drag="y"
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={0.2}
            onDragStart={() => setIsDragging(true)}
            onDragEnd={handleDragEnd}
            initial={{ y: '100%' }}
            animate={{ 
              y: isDragging ? undefined : `${100 - currentHeight}%`,
            }}
            exit={{ y: '100%' }}
            transition={{
              type: 'spring',
              damping: 30,
              stiffness: 300
            }}
            className={cn(
              'fixed bottom-0 left-0 right-0 z-[100]',
              'glass-intense border-t border-white/10',
              'rounded-t-3xl overflow-hidden',
              'shadow-2xl',
              className
            )}
            style={{ maxHeight: '90vh' }}
          >
            {/* Handle */}
            {showHandle && (
              <div className="flex justify-center pt-3 pb-2">
                <div className="w-12 h-1.5 bg-txt-3/50 rounded-full" />
              </div>
            )}

            {/* Header */}
            {title && (
              <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
                <h3 className="text-card-title font-bold text-txt">
                  {title}
                </h3>
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={onClose}
                  className="p-2 rounded-xl hover:bg-white/10 transition-colors"
                >
                  <X className="w-5 h-5 text-txt-2" />
                </motion.button>
              </div>
            )}

            {/* Content */}
            <div 
              className="overflow-y-auto p-6"
              style={{ 
                maxHeight: `calc(${currentHeight}vh - ${title ? '80px' : '40px'})`,
              }}
            >
              {children}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
