import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  Play, 
  Pause, 
  Check, 
  SkipForward, 
  X, 
  Timer, 
  Dumbbell, 
  Target,
  Plus,
  Minus,
  Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { VoltCard } from '@/components/VoltCard';
import { toast } from 'sonner';
import { WorkoutSummaryCard } from '@/components/WorkoutSummaryCard';
import YouTubePlayer from '@/components/YouTubePlayer';
import { useExerciseVideo } from '@/hooks/useExerciseVideo';

interface UnifiedWorkoutSessionProps {
  workout: any;
  onComplete: (workoutData: any) => void;
  onClose: () => void;
}

export function UnifiedWorkoutSession({ workout, onComplete, onClose }: UnifiedWorkoutSessionProps) {
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);
  const [currentSet, setCurrentSet] = useState(1);
  const [weight, setWeight] = useState(0);
  const [reps, setReps] = useState(0);
  const [isResting, setIsResting] = useState(false);
  const [restTime, setRestTime] = useState(0);
  const [completedSets, setCompletedSets] = useState<Set<string>>(new Set());
  const [sessionData, setSessionData] = useState<any[]>([]);
  const [startTime] = useState(Date.now());
  const [showSummary, setShowSummary] = useState(false);
  const [completedWorkout, setCompletedWorkout] = useState<any>(null);

  const currentExercise = workout.exercises[currentExerciseIndex];
  const totalExercises = workout.exercises.length;
  const progress = ((currentExerciseIndex + 1) / totalExercises) * 100;

  // Fetch video for current exercise automatically
  const { data: exerciseVideo } = useExerciseVideo(currentExercise?.name);

  // Rest timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isResting && restTime > 0) {
      timer = setTimeout(() => setRestTime(prev => prev - 1), 1000);
    } else if (isResting && restTime === 0) {
      setIsResting(false);
      toast.success("Descanso terminado! Próxima série 💪");
    }
    return () => clearTimeout(timer);
  }, [isResting, restTime]);

  // Initialize exercise data
  useEffect(() => {
    if (currentExercise) {
      setWeight(currentExercise.weight || 0);
      setCurrentSet(1);
      setReps(0);
    }
  }, [currentExerciseIndex, currentExercise]);

  const handleCompleteSet = () => {
    if (!weight || !reps) {
      toast.error('Preencha peso e repetições');
      return;
    }

    const setId = `${currentExerciseIndex}-${currentSet}`;
    const newCompletedSets = new Set(completedSets);
    newCompletedSets.add(setId);
    setCompletedSets(newCompletedSets);

    // Save set data
    const setData = {
      exercise: currentExercise.name,
      set: currentSet,
      weight,
      reps,
      completed: true
    };

    setSessionData(prev => [...prev, setData]);

    if (currentSet < (currentExercise.sets || 3)) {
      // Next set
      setCurrentSet(prev => prev + 1);
      setIsResting(true);
      setRestTime(currentExercise.rest || 90);
      setReps(0);
      toast.success(`Série ${currentSet} concluída! 🔥`);
    } else {
      // Next exercise
      handleNextExercise();
    }
  };

  const handleNextExercise = () => {
    if (currentExerciseIndex < totalExercises - 1) {
      setCurrentExerciseIndex(prev => prev + 1);
      setCurrentSet(1);
      setIsResting(false);
      toast.success(`${currentExercise.name} concluído! Próximo exercício 🚀`);
    } else {
      handleCompleteWorkout();
    }
  };

  const handleCompleteWorkout = async () => {
    const duration = Math.round((Date.now() - startTime) / 60000);
    const totalVolume = sessionData.reduce((sum, set) => sum + (set.weight * set.reps), 0);
    
    // Group sets by exercise
    const exerciseGroups = sessionData.reduce((acc, set) => {
      if (!acc[set.exercise]) {
        acc[set.exercise] = [];
      }
      acc[set.exercise].push({ weight: set.weight, reps: set.reps });
      return acc;
    }, {} as Record<string, Array<{weight: number, reps: number}>>);

    const workoutData = {
      name: workout.name || workout.focus,
      focus: workout.focus,
      exercises: Object.entries(exerciseGroups).map(([name, sets]) => ({
        name,
        sets: Array.isArray(sets) ? sets.length : 0,
        reps: Array.isArray(sets) && sets.length > 0 ? sets[0].reps : 0,
        weight: Array.isArray(sets) && sets.length > 0 ? sets[0].weight : 0,
        notes: ''
      })),
      duration_minutes: duration,
      completed_at: new Date().toISOString(),
      total_volume: totalVolume
    };

    // Save workout
    await onComplete(workoutData);
    
    // Show summary card if workout has exercises
    if (workoutData.exercises && workoutData.exercises.length > 0) {
      setCompletedWorkout(workoutData);
      setShowSummary(true);
    } else {
      onClose();
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Summary screen after workout
  if (showSummary && completedWorkout) {
    return (
      <WorkoutSummaryCard
        workout={completedWorkout}
        onClose={() => {
          setShowSummary(false);
          onClose();
        }}
      />
    );
  }

  // Rest screen
  if (isResting) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
        <VoltCard className="p-8 text-center max-w-md w-full border-accent/20">
          <motion.div
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 1, repeat: Infinity }}
            className="w-24 h-24 mx-auto bg-gradient-to-r from-accent to-primary rounded-full flex items-center justify-center mb-6"
          >
            <Timer className="w-12 h-12 text-accent-ink" />
          </motion.div>
          
          <h3 className="text-2xl font-bold text-txt mb-2">Descansando</h3>
          <p className="text-txt-2 mb-6">Prepare-se para a próxima série</p>
          
          <div className="text-6xl font-black text-accent mb-4">
            {formatTime(restTime)}
          </div>
          
          <Progress value={((90 - restTime) / 90) * 100} className="h-3 mb-6" />
          
          <div className="flex gap-3">
            <Button 
              onClick={() => setIsResting(false)} 
              variant="outline" 
              className="flex-1"
            >
              Pular Descanso
            </Button>
            <Button onClick={onClose} variant="ghost" className="flex-1">
              Pausar Treino
            </Button>
          </div>
        </VoltCard>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-bg overflow-y-auto">
      {/* Header */}
      <div className="sticky top-0 bg-bg/95 backdrop-blur border-b border-line p-4">
        <div className="flex items-center justify-between max-w-2xl mx-auto">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-xl font-bold text-txt">{workout.name || workout.focus}</h1>
              <p className="text-sm text-txt-2">
                Exercício {currentExerciseIndex + 1} de {totalExercises}
              </p>
            </div>
          </div>
          
          <Badge className="bg-accent/20 text-accent">
            <Clock className="w-4 h-4 mr-1" />
            {Math.round((Date.now() - startTime) / 60000)} min
          </Badge>
        </div>
        
        <Progress value={progress} className="mt-4 h-2" />
      </div>

      {/* Main Content */}
      <div className="max-w-2xl mx-auto p-4 space-y-6 pb-24">
        {/* Current Exercise */}
        <VoltCard className="p-6">
          <div className="text-center mb-6">
            {/* Video Player - Automatic display */}
            {exerciseVideo?.videoUrl && (
              <div className="mb-4 rounded-xl overflow-hidden border border-line/30">
                <YouTubePlayer
                  url={exerciseVideo.videoUrl}
                  title={currentExercise.name}
                  clickToPlay={true}
                  className="aspect-video w-full"
                />
              </div>
            )}

            <div className="w-16 h-16 bg-gradient-to-r from-accent to-primary rounded-full flex items-center justify-center mx-auto mb-4">
              <Dumbbell className="w-8 h-8 text-accent-ink" />
            </div>
            
            <h2 className="text-2xl font-bold text-txt mb-2">
              {currentExercise.name}
            </h2>
            
            <div className="flex items-center justify-center gap-4 text-txt-2 text-sm">
              <div className="flex items-center gap-1">
                <Target className="w-4 h-4" />
                <span>Série {currentSet}/{currentExercise.sets || 3}</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                <span>{currentExercise.rest || 90}s descanso</span>
              </div>
            </div>
          </div>

          {/* Weight Input */}
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-txt-2 mb-2 block">Peso (kg)</label>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setWeight(prev => Math.max(0, prev - 2.5))}
                  className="w-12 h-12"
                >
                  <Minus className="w-4 h-4" />
                </Button>
                
                <Input
                  type="number"
                  value={weight}
                  onChange={(e) => setWeight(Number(e.target.value))}
                  className="text-center text-lg font-semibold h-12"
                  placeholder="0"
                />
                
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setWeight(prev => prev + 2.5)}
                  className="w-12 h-12"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Reps Input */}
            <div>
              <label className="text-sm font-medium text-txt-2 mb-2 block">Repetições</label>
              <Input
                type="number"
                value={reps}
                onChange={(e) => setReps(Number(e.target.value))}
                className="text-center text-lg h-12"
                placeholder="0"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3 mt-6">
            <Button
              onClick={handleCompleteSet}
              disabled={!weight || !reps}
              className="w-full bg-accent hover:bg-accent/90 text-accent-ink font-semibold py-4 h-14 text-lg"
            >
              <Check className="w-5 h-5 mr-2" />
              Completar Série {currentSet}
            </Button>
            
            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                onClick={handleNextExercise}
                className="h-12"
              >
                <SkipForward className="w-4 h-4 mr-2" />
                Pular Exercício
              </Button>
              
              <Button
                onClick={handleCompleteWorkout}
                variant="outline"
                className="border-accent text-accent h-12"
              >
                <Check className="w-4 h-4 mr-2" />
                Finalizar Treino
              </Button>
            </div>
          </div>

          {/* Completed Sets */}
          {completedSets.size > 0 && (
            <div className="mt-4 pt-4 border-t border-line/20">
              <p className="text-sm text-txt-2 mb-2">Séries completadas:</p>
              <div className="flex gap-2 flex-wrap">
                {Array.from(completedSets).map((setId) => (
                  <Badge key={setId} variant="secondary" className="bg-accent/20 text-accent">
                    {setId.split('-')[1]}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </VoltCard>

        {/* Exercise List */}
        <VoltCard className="p-4">
          <h3 className="font-semibold text-txt mb-3">Exercícios do Treino</h3>
          <div className="space-y-2">
            {workout.exercises.map((exercise: any, index: number) => (
              <div
                key={index}
                className={`flex items-center justify-between p-3 rounded-xl transition-colors ${
                  index === currentExerciseIndex
                    ? 'bg-accent/20 border border-accent/40'
                    : index < currentExerciseIndex
                    ? 'bg-green-500/10 border border-green-500/20'
                    : 'bg-surface border border-line/20'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                    index === currentExerciseIndex
                      ? 'bg-accent text-accent-ink'
                      : index < currentExerciseIndex
                      ? 'bg-green-500 text-white'
                      : 'bg-surface text-txt-2'
                  }`}>
                    {index < currentExerciseIndex ? <Check className="w-4 h-4" /> : index + 1}
                  </div>
                  <div>
                    <h4 className="font-medium text-txt">{exercise.name}</h4>
                    <p className="text-sm text-txt-2">
                      {exercise.sets || 3} séries • {exercise.reps || '8-10'} reps
                    </p>
                  </div>
                </div>
                
                {index === currentExerciseIndex && (
                  <Badge className="bg-accent/20 text-accent">
                    Atual
                  </Badge>
                )}
              </div>
            ))}
          </div>
        </VoltCard>
      </div>
    </div>
  );
}