import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="py-12 px-4 border-t border-line bg-surface">
      <div className="container-custom">
        <div className="text-center">
          <div className="text-2xl font-bold mb-4">
            <span className="text-red-500">⚡</span>
            <span className="text-white">VOLT</span>
          </div>
          <p className="text-text-2 mb-6">
            Feito com ⚡ para revolucionar seus treinos
          </p>
          
          <div className="flex flex-wrap justify-center gap-8 text-sm text-text-2">
            <Link to="/terms" className="hover:text-white transition-colors">
              Termos
            </Link>
            <Link to="/privacy" className="hover:text-white transition-colors">
              Privacidade  
            </Link>
            <Link to="/contact" className="hover:text-white transition-colors">
              Contato
            </Link>
            <Link to="/social" className="hover:text-white transition-colors">
              Redes
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
