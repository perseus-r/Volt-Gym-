import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface Tab {
  id: string;
  label: string;
  icon?: React.ReactNode;
}

interface VoltTabsSystemProps {
  tabs: Tab[];
  activeTab: string;
  onTabChange: (tabId: string) => void;
  className?: string;
}

export function VoltTabsSystem({ tabs, activeTab, onTabChange, className }: VoltTabsSystemProps) {
  return (
    <div className={cn("relative", className)}>
      <div className="flex gap-2 p-1 bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 overflow-x-auto scrollbar-hide">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={cn(
              "relative px-6 py-3 rounded-xl font-medium transition-all duration-300 whitespace-nowrap",
              "flex items-center gap-2 min-w-fit",
              activeTab === tab.id
                ? "text-txt"
                : "text-txt-2 hover:text-txt hover:bg-white/5"
            )}
          >
            {tab.icon}
            <span>{tab.label}</span>

            {activeTab === tab.id && (
              <motion.div
                layoutId="activeTab"
                className="absolute inset-0 bg-gradient-to-r from-accent/20 to-accent-2/20 backdrop-blur-sm rounded-xl border border-accent/20"
                initial={false}
                transition={{
                  type: "spring",
                  stiffness: 500,
                  damping: 30
                }}
              />
            )}

            {activeTab === tab.id && (
              <motion.div
                className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-accent to-accent-2"
                layoutId="underline"
                initial={false}
                transition={{
                  type: "spring",
                  stiffness: 500,
                  damping: 30
                }}
              />
            )}
          </button>
        ))}
      </div>
    </div>
  );
}
