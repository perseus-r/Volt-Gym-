import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Target, Dumbbell, TrendingUp, TrendingDown, Minus, Play, History, ChevronDown, ChevronUp, CheckCircle2 } from 'lucide-react';
import { VideoPlayer } from '@/components/VideoPlayer';
import { ExercisePerformanceHistory } from './ExercisePerformanceHistory';

interface MobileExerciseCardProps {
  exerciseName: string;
  currentSet: number;
  totalSets: number;
  targetReps: number;
  targetWeight?: number;
  lastSetInfo?: {
    weight: number;
    reps: number;
    rpe?: number;
  };
  videoUrl?: string | null;
  thumbnailUrl?: string | null;
  compact?: boolean;
  isComplete?: boolean;
  // New props for history
  exerciseHistory?: Array<{
    date: string;
    weight: number;
    reps: number;
    rpe?: number;
  }>;
  personalRecord?: {
    weight: number;
    reps: number;
    date: string;
  };
}

export function MobileExerciseCard({
  exerciseName,
  currentSet,
  totalSets,
  targetReps,
  targetWeight,
  lastSetInfo,
  videoUrl,
  thumbnailUrl,
  compact = false,
  isComplete = false,
  exerciseHistory = [],
  personalRecord,
}: MobileExerciseCardProps) {
  const [showHistory, setShowHistory] = useState(false);
  // Calculate comparison with target
  const getWeightComparison = () => {
    if (!lastSetInfo || !targetWeight) return null;
    const diff = lastSetInfo.weight - targetWeight;
    if (diff > 0) return { type: 'up', value: diff };
    if (diff < 0) return { type: 'down', value: Math.abs(diff) };
    return { type: 'same', value: 0 };
  };

  const comparison = getWeightComparison();

  // Compact mode for better mobile space usage
  if (compact) {
    return (
      <div className="relative overflow-hidden rounded-xl session-glass-intense p-3">
        {/* Exercise Complete Overlay */}
        <AnimatePresence>
          {isComplete && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="absolute inset-0 z-10 bg-emerald-500/10 backdrop-blur-[2px] rounded-xl flex items-center justify-center"
            >
              <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/20 border border-emerald-500/30">
                <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                <span className="font-semibold text-emerald-500">Exercício Completo!</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        {/* Gradient accent line */}
        <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-primary via-primary/80 to-primary/50" />

        <div className="flex gap-3">
          {/* Video/Thumbnail - Small */}
          {(videoUrl || thumbnailUrl) && (
            <div className="w-20 h-20 flex-shrink-0 rounded-lg overflow-hidden border border-border/30">
              {videoUrl ? (
                <VideoPlayer
                  url={videoUrl}
                  title={exerciseName}
                  clickToPlay={true}
                  fallbackThumbnail={thumbnailUrl}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="relative w-full h-full">
                  <img 
                    src={thumbnailUrl!} 
                    alt={exerciseName}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                    <Play className="w-4 h-4 text-white" />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Content */}
          <div className="flex-1 min-w-0">
            {/* Name + Set indicator */}
            <div className="flex items-center gap-2 mb-1.5">
              <Dumbbell className="w-4 h-4 text-primary flex-shrink-0" />
              <h2 className="font-bold text-sm truncate">{exerciseName}</h2>
            </div>

            {/* Set pills compact */}
            <div className="flex gap-1 mb-2">
              {Array.from({ length: totalSets }).map((_, i) => (
                <div
                  key={i}
                  className={`h-1.5 rounded-full transition-all ${
                    i < currentSet - 1
                      ? 'w-5 bg-primary'
                      : i === currentSet - 1
                      ? 'w-5 bg-primary/50'
                      : 'w-3 bg-secondary/50'
                  }`}
                />
              ))}
            </div>

            {/* Target + last set inline */}
            <div className="flex items-center gap-2 text-xs">
              <span className="text-muted-foreground">Série {currentSet}/{totalSets}:</span>
              <span className="font-semibold">{targetReps} reps</span>
              {targetWeight && (
                <span className="font-semibold text-primary">@ {targetWeight}kg</span>
              )}
              
              {lastSetInfo && comparison && comparison.type !== 'same' && (
                <span className={`flex items-center gap-0.5 ${
                  comparison.type === 'up' ? 'text-emerald-500' : 'text-orange-500'
                }`}>
                  {comparison.type === 'up' ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                  {comparison.type === 'up' ? '+' : '-'}{comparison.value}kg
                </span>
              )}
            </div>
            
            {/* History toggle button - compact */}
            {exerciseHistory.length > 0 && (
              <button
                onClick={() => setShowHistory(!showHistory)}
                className="flex items-center gap-1 text-[10px] text-primary mt-1.5"
              >
                <History className="w-3 h-3" />
                <span>{showHistory ? 'Ocultar' : 'Histórico'}</span>
                {showHistory ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
              </button>
            )}
          </div>
        </div>
        
        {/* Collapsible history */}
        <AnimatePresence>
          {showHistory && exerciseHistory.length > 0 && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden mt-2 pt-2 border-t border-border/30"
            >
              <ExercisePerformanceHistory
                exerciseName={exerciseName}
                history={exerciseHistory}
                personalRecord={personalRecord}
                compact
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  // Original full-size layout
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative overflow-hidden rounded-2xl session-glass-intense p-5"
    >
      {/* Gradient accent line */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-primary/80 to-primary/50" />

      {/* Video Player - Automatic display */}
      {videoUrl && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mb-4 rounded-xl overflow-hidden border border-border/30"
        >
          <VideoPlayer
            url={videoUrl}
            title={exerciseName}
            clickToPlay={true}
            fallbackThumbnail={thumbnailUrl}
            className="w-full"
          />
        </motion.div>
      )}

      {/* Thumbnail fallback when no video */}
      {!videoUrl && thumbnailUrl && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="mb-4 rounded-xl overflow-hidden border border-border/30 relative aspect-video"
        >
          <img 
            src={thumbnailUrl} 
            alt={exerciseName}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
            <div className="w-12 h-12 rounded-full bg-primary/80 flex items-center justify-center">
              <Play className="w-6 h-6 text-primary-foreground ml-1" />
            </div>
          </div>
        </motion.div>
      )}

      {/* Exercise name */}
      <div className="flex items-center justify-center gap-2 mb-4">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
          <Dumbbell className="w-5 h-5 text-primary" />
        </div>
        <h2 className="text-xl font-bold">{exerciseName}</h2>
      </div>

      {/* Set indicator pills */}
      <div className="flex justify-center gap-2 mb-4">
        {Array.from({ length: totalSets }).map((_, i) => (
          <motion.div
            key={i}
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: i * 0.05 }}
            className={`h-2 rounded-full transition-all ${
              i < currentSet - 1
                ? 'w-8 bg-primary'
                : i === currentSet - 1
                ? 'w-8 bg-primary/50 volt-pulse'
                : 'w-4 bg-secondary/50'
            }`}
          />
        ))}
      </div>

      {/* Current set badge */}
      <div className="flex justify-center mb-4">
        <motion.div
          key={currentSet}
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-primary/20 to-primary/10 border border-primary/30"
        >
          <Target className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium">
            Série <span className="text-lg font-bold text-primary">{currentSet}</span> de {totalSets}
          </span>
        </motion.div>
      </div>

      {/* Target info */}
      <div className="text-center mb-3">
        <div className="text-muted-foreground text-sm mb-1">Meta desta série</div>
        <div className="flex items-center justify-center gap-3">
          <span className="text-2xl font-bold text-foreground">
            {targetReps} reps
          </span>
          {targetWeight && (
            <>
              <span className="text-muted-foreground">@</span>
              <span className="text-2xl font-bold text-primary">
                {targetWeight}kg
              </span>
            </>
          )}
        </div>
      </div>

      {/* Last set comparison */}
      {lastSetInfo && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 pt-4 border-t border-border/30"
        >
          <div className="flex items-center justify-center gap-4">
            <div className="text-center">
              <div className="text-xs text-muted-foreground mb-1">Última série</div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">
                  {lastSetInfo.weight}kg × {lastSetInfo.reps}
                </span>
                {lastSetInfo.rpe && (
                  <span className="text-xs text-muted-foreground px-2 py-0.5 rounded-full bg-secondary/30">
                    RPE {lastSetInfo.rpe}
                  </span>
                )}
              </div>
            </div>

            {comparison && comparison.type !== 'same' && (
              <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                comparison.type === 'up' 
                  ? 'bg-emerald-500/10 text-emerald-500'
                  : 'bg-orange-500/10 text-orange-500'
              }`}>
                {comparison.type === 'up' ? (
                  <TrendingUp className="w-3 h-3" />
                ) : (
                  <TrendingDown className="w-3 h-3" />
                )}
                <span>{comparison.type === 'up' ? '+' : '-'}{comparison.value}kg</span>
              </div>
            )}

            {comparison && comparison.type === 'same' && (
              <div className="flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                <Minus className="w-3 h-3" />
                <span>Igual</span>
              </div>
            )}
          </div>
        </motion.div>
      )}

      {/* History toggle button - full size */}
      {exerciseHistory.length > 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="mt-4"
        >
          <button
            onClick={() => setShowHistory(!showHistory)}
            className="w-full flex items-center justify-center gap-2 py-2 text-sm text-primary hover:bg-primary/5 rounded-xl transition-colors"
          >
            <History className="w-4 h-4" />
            <span>{showHistory ? 'Ocultar histórico' : 'Ver histórico de performance'}</span>
            {showHistory ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
          
          <AnimatePresence>
            {showHistory && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden mt-3"
              >
                <ExercisePerformanceHistory
                  exerciseName={exerciseName}
                  history={exerciseHistory}
                  personalRecord={personalRecord}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}
    </motion.div>
  );
}
