import { motion } from 'framer-motion';
import { X, Clock, Dumbbell, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { SessionStats } from '@/types/workout.unified';

interface SessionHeaderProps {
  workoutName: string;
  stats: SessionStats;
  onClose: () => void;
}

export function SessionHeader({ workoutName, stats, onClose }: SessionHeaderProps) {
  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <motion.div
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="glass-intense sticky top-0 z-50 border-b border-white/10"
    >
      <div className="container max-w-4xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-xl font-bold text-txt-1">{workoutName}</h2>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="text-txt-2 hover:text-txt-1"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="grid grid-cols-4 gap-3">
          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-txt-3 text-xs mb-1">
              <Clock className="w-3 h-3" />
              <span>Tempo</span>
            </div>
            <div className="text-accent text-lg font-bold">{formatDuration(stats.durationSeconds)}</div>
          </div>

          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-txt-3 text-xs mb-1">
              <Dumbbell className="w-3 h-3" />
              <span>Volume</span>
            </div>
            <div className="text-accent text-lg font-bold">{stats.totalVolume.toFixed(0)}kg</div>
          </div>

          <div className="text-center">
            <div className="flex items-center justify-center gap-1 text-txt-3 text-xs mb-1">
              <Zap className="w-3 h-3" />
              <span>Séries</span>
            </div>
            <div className="text-accent text-lg font-bold">{stats.completedSets}/{stats.totalSets}</div>
          </div>

          <div className="text-center">
            <div className="text-txt-3 text-xs mb-1">RPE Médio</div>
            <div className="text-accent text-lg font-bold">{stats.avgRpe || 0}</div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
