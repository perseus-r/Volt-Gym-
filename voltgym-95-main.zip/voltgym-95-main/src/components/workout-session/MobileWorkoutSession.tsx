import { useState, useCallback, useMemo, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Trophy } from 'lucide-react';
import confetti from 'canvas-confetti';
import { MobileRestScreen } from './MobileRestScreen';
import { WorkoutCompletionScreen } from './WorkoutCompletionScreen';
import { WarmUpScreen } from './WarmUpScreen';
import { SessionBackgroundEffects } from './SessionBackgroundEffects';
import { VideoFullscreenModal } from './VideoFullscreenModal';
import { StravaStyleShareCard } from '@/components/share/StravaStyleShareCard';
import { WorkoutSessionWizard } from './wizard/WorkoutSessionWizard';
import { useHapticFeedback } from '@/hooks/useHapticFeedback';
import { useExerciseVideo } from '@/hooks/useExerciseVideo';
import { useHideFloatingNav } from '@/contexts/UIChromeContext';
import { useBodyScrollLock } from '@/hooks/useBodyScrollLock';
import { useVisualViewportVars } from '@/hooks/useVisualViewportVars';
import '@/styles/workout-session.css';
type Objetivo = 'massa' | 'definicao' | 'forca' | 'saude' | null;

interface Exercise {
  id: string;
  name: string;
  targetSets: number;
  targetReps: number;
  targetWeight?: number;
  restSeconds: number;
}

interface CompletedSet {
  exerciseId: string;
  setNumber: number;
  weight: number;
  reps: number;
  rpe: number;
  completedAt: Date;
}

interface MobileWorkoutSessionProps {
  workoutName: string;
  exercises: Exercise[];
  onComplete: (data: { completedSets: CompletedSet[]; duration: number }) => void;
  onClose: () => void;
  showWarmUp?: boolean;
  workoutFocus?: string;
  objetivo?: Objetivo;
  exerciseBestWeights?: Record<string, number>;
}

export function MobileWorkoutSession({
  workoutName,
  exercises,
  onComplete,
  onClose,
  showWarmUp = true,
  workoutFocus,
  objetivo = null,
  exerciseBestWeights = {},
}: MobileWorkoutSessionProps) {
  const { trigger } = useHapticFeedback();
  
  // Hide floating nav button when workout session is active
  useHideFloatingNav(true);
  
  // Lock body scroll to prevent Safari viewport shifting
  useBodyScrollLock(true);
  
  // Set CSS vars for visual viewport (fixes iOS Safari bottom bar issue)
  useVisualViewportVars(true);
  
  // Warm-up state
  const [isWarmUpActive, setIsWarmUpActive] = useState(showWarmUp);
  
  // Session state
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);
  const [completedSets, setCompletedSets] = useState<CompletedSet[]>([]);
  const [startTime] = useState(Date.now());
  const [elapsedTime, setElapsedTime] = useState(0);
  
  // Video fullscreen state
  const [isVideoFullscreen, setIsVideoFullscreen] = useState(false);
  
  // Rest timer state
  const [restTimer, setRestTimer] = useState({
    isActive: false,
    timeLeft: 0,
    totalTime: 0,
  });
  
  // Completion state
  const [isCompleted, setIsCompleted] = useState(false);
  const [showShareCard, setShowShareCard] = useState(false);
  
  // PR celebration state
  const [showPRBadge, setShowPRBadge] = useState(false);
  const [prExerciseName, setPrExerciseName] = useState('');
  
  const [shouldAdvanceAfterRest, setShouldAdvanceAfterRest] = useState(false);
  
  const celebratePR = useCallback((exerciseName: string) => {
    trigger('success');
    setPrExerciseName(exerciseName);
    setShowPRBadge(true);
    
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#FFD700', '#FFA500', '#FF6347', '#9370DB', '#00CED1'],
    });
    
    setTimeout(() => setShowPRBadge(false), 3000);
  }, [trigger]);

  const currentExercise = exercises[currentExerciseIndex];
  
  // Fetch video for current exercise
  const { data: exerciseVideo } = useExerciseVideo(currentExercise?.name);
  
  // Fetch video for next exercise (for rest screen)
  const nextExercise = exercises[currentExerciseIndex + 1];
  const { data: nextExerciseVideo } = useExerciseVideo(nextExercise?.name);
  
  const currentSetNumber = useMemo(() => {
    if (!currentExercise) return 1;
    const setsForExercise = completedSets.filter(s => s.exerciseId === currentExercise.id);
    return setsForExercise.length + 1;
  }, [completedSets, currentExercise]);

  const isExerciseComplete = currentSetNumber > (currentExercise?.targetSets || 0);

  const lastSetInfo = useMemo(() => {
    const setsForExercise = completedSets.filter(s => s.exerciseId === currentExercise?.id);
    if (setsForExercise.length === 0) return undefined;
    const lastSet = setsForExercise[setsForExercise.length - 1];
    return {
      weight: lastSet.weight,
      reps: lastSet.reps,
      rpe: lastSet.rpe,
    };
  }, [completedSets, currentExercise?.id]);

  // Timer effect
  useEffect(() => {
    const interval = setInterval(() => {
      setElapsedTime(Math.floor((Date.now() - startTime) / 1000));
    }, 1000);
    return () => clearInterval(interval);
  }, [startTime]);

  const startRestTimer = useCallback((seconds: number) => {
    setRestTimer({
      isActive: true,
      timeLeft: seconds,
      totalTime: seconds,
    });
  }, []);

  const adjustRestTime = useCallback((delta: number) => {
    setRestTimer(prev => ({
      ...prev,
      timeLeft: Math.max(0, prev.timeLeft + delta),
      totalTime: delta > 0 ? prev.totalTime + delta : prev.totalTime,
    }));
  }, []);

  const goToNextExercise = useCallback(() => {
    if (currentExerciseIndex < exercises.length - 1) {
      trigger('light');
      setCurrentExerciseIndex(prev => prev + 1);
    }
  }, [currentExerciseIndex, exercises.length, trigger]);

  const goToPreviousExercise = useCallback(() => {
    if (currentExerciseIndex > 0) {
      trigger('light');
      setCurrentExerciseIndex(prev => prev - 1);
    }
  }, [currentExerciseIndex, trigger]);

  const handleSkipExercise = useCallback(() => {
    if (currentExerciseIndex < exercises.length - 1) {
      trigger('light');
      setCurrentExerciseIndex(prev => prev + 1);
    }
  }, [currentExerciseIndex, exercises.length, trigger]);

  // Rest timer effect
  useEffect(() => {
    if (!restTimer.isActive || restTimer.timeLeft <= 0) return;
    
    const interval = setInterval(() => {
      setRestTimer(prev => {
        if (prev.timeLeft <= 1) {
          trigger('success');
          return { ...prev, isActive: false, timeLeft: 0 };
        }
        return { ...prev, timeLeft: prev.timeLeft - 1 };
      });
    }, 1000);
    
    return () => clearInterval(interval);
  }, [restTimer.isActive, restTimer.timeLeft, trigger]);

  // Auto-advance after rest
  useEffect(() => {
    if (!restTimer.isActive && restTimer.timeLeft === 0 && shouldAdvanceAfterRest) {
      goToNextExercise();
      setShouldAdvanceAfterRest(false);
    }
  }, [restTimer.isActive, restTimer.timeLeft, shouldAdvanceAfterRest, goToNextExercise]);

  const handleSetComplete = useCallback((data: { weight: number; reps: number; rpe: number }) => {
    if (!currentExercise) return;
    
    trigger('success');
    
    const newSet: CompletedSet = {
      exerciseId: currentExercise.id,
      setNumber: currentSetNumber,
      weight: data.weight,
      reps: data.reps,
      rpe: data.rpe,
      completedAt: new Date(),
    };
    
    setCompletedSets(prev => [...prev, newSet]);
    
    const bestWeight = exerciseBestWeights[currentExercise.id];
    if (bestWeight && data.weight > bestWeight) {
      celebratePR(currentExercise.name);
    }

    const isLastExercise = currentExerciseIndex === exercises.length - 1;
    const isLastSet = currentSetNumber >= currentExercise.targetSets;

    if (isLastExercise && isLastSet) {
      setIsCompleted(true);
    } else if (isLastSet) {
      setShouldAdvanceAfterRest(true);
      startRestTimer(currentExercise.restSeconds);
    } else {
      setShouldAdvanceAfterRest(false);
      startRestTimer(currentExercise.restSeconds);
    }
  }, [currentExercise, currentExerciseIndex, currentSetNumber, exercises.length, trigger, startRestTimer, exerciseBestWeights, celebratePR]);

  const skipRest = useCallback(() => {
    trigger('light');
    
    if (shouldAdvanceAfterRest) {
      goToNextExercise();
      setShouldAdvanceAfterRest(false);
    }
    
    setRestTimer(prev => ({ ...prev, isActive: false, timeLeft: 0 }));
  }, [trigger, shouldAdvanceAfterRest, goToNextExercise]);

  const handleFinishWorkout = useCallback(() => {
    const duration = Math.floor((Date.now() - startTime) / 1000);
    onComplete({ completedSets, duration });
  }, [completedSets, onComplete, startTime]);

  const stats = useMemo(() => ({
    duration: elapsedTime,
    totalVolume: completedSets.reduce((sum, s) => sum + s.weight * s.reps, 0),
    completedSets: completedSets.length,
    averageRpe: completedSets.length > 0 
      ? completedSets.reduce((sum, s) => sum + s.rpe, 0) / completedSets.length 
      : 0,
  }), [completedSets, elapsedTime]);

  const shareData = useMemo(() => ({
    name: workoutName,
    exercises: exercises.map(ex => ({
      name: ex.name,
      sets: ex.targetSets,
      reps: ex.targetReps,
      weight: ex.targetWeight,
    })),
    duration: Math.floor(elapsedTime / 60),
    totalVolume: completedSets.reduce((sum, s) => sum + s.weight * s.reps, 0),
    completedAt: new Date().toISOString(),
  }), [workoutName, exercises, elapsedTime, completedSets]);

  const handleShare = useCallback(() => {
    setShowShareCard(true);
  }, []);

  // Build content
  let content: React.ReactNode = null;

  // Show warm-up screen first
  if (isWarmUpActive) {
    content = (
      <WarmUpScreen
        isOpen={isWarmUpActive}
        workoutFocus={workoutFocus}
        onSkip={() => setIsWarmUpActive(false)}
        onComplete={() => setIsWarmUpActive(false)}
      />
    );
  } else if (isCompleted) {
    content = (
      <>
        <WorkoutCompletionScreen
          workoutName={workoutName}
          stats={stats}
          onShare={handleShare}
          onClose={handleFinishWorkout}
          objetivo={objetivo}
        />
        {showShareCard && shareData && (
          <StravaStyleShareCard
            workout={{
              name: shareData.name || workoutName,
              focus: workoutFocus || 'Treino',
              duration_minutes: Math.round(stats.duration / 60),
              total_volume: stats.totalVolume,
              exercises: exercises.map(e => ({ name: e.name, sets: e.targetSets, reps: e.targetReps })),
              completed_at: new Date().toISOString(),
            }}
            onClose={() => setShowShareCard(false)}
          />
        )}
      </>
    );
  } else if (!exercises.length) {
    // Guard: empty exercises
    content = (
      <div className="fixed inset-0 z-50 bg-background flex flex-col items-center justify-center p-6">
        <p className="text-muted-foreground text-center mb-4">Treino sem exercícios configurados.</p>
        <button
          onClick={onClose}
          className="px-6 py-3 rounded-xl bg-primary text-primary-foreground font-semibold"
        >
          Fechar
        </button>
      </div>
    );
  } else if (!currentExercise) {
    // Guard: currentExercise undefined
    console.error('[MobileWorkoutSession] currentExercise undefined', { currentExerciseIndex, exercisesLength: exercises.length });
    if (currentExerciseIndex !== 0) {
      setCurrentExerciseIndex(0);
    }
    return null;
  } else {
    // Main workout session
    content = (
      <div className="fixed inset-0 z-[110] bg-background overflow-hidden">
        {/* Dynamic Background Effects */}
        <SessionBackgroundEffects objetivo={objetivo} intensity="medium" />
        
        {/* Video Fullscreen Modal */}
        {exerciseVideo?.videoUrl && (
          <VideoFullscreenModal
            isOpen={isVideoFullscreen}
            onClose={() => setIsVideoFullscreen(false)}
            videoUrl={exerciseVideo.videoUrl}
            thumbnailUrl={exerciseVideo.thumbnailUrl}
            title={currentExercise.name}
          />
        )}

        {/* PR Celebration Badge */}
        <AnimatePresence>
          {showPRBadge && (
            <motion.div
              initial={{ opacity: 0, scale: 0.5, y: -50 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.5, y: -50 }}
              className="fixed top-20 left-1/2 -translate-x-1/2 z-[100] pointer-events-none"
            >
              <div className="flex items-center gap-3 px-6 py-4 rounded-2xl bg-gradient-to-r from-yellow-500 to-orange-500 shadow-2xl shadow-yellow-500/50">
                <motion.div
                  animate={{ rotate: [0, -10, 10, -10, 10, 0], scale: [1, 1.2, 1] }}
                  transition={{ duration: 0.5, type: 'tween' }}
                >
                  <Trophy className="w-8 h-8 text-white" />
                </motion.div>
                <div>
                  <div className="text-white font-bold text-lg">NOVO PR! 🎉</div>
                  <div className="text-white/80 text-sm">{prExerciseName}</div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Rest Screen Overlay */}
        <MobileRestScreen
          isActive={restTimer.isActive}
          timeLeft={restTimer.timeLeft}
          totalTime={restTimer.totalTime}
          nextExercise={nextExercise?.name}
          nextExerciseDetails={nextExercise ? `${nextExercise.targetSets} séries × ${nextExercise.targetReps} reps` : undefined}
          nextExerciseVideoUrl={nextExerciseVideo?.videoUrl}
          nextExerciseThumbnail={nextExerciseVideo?.thumbnailUrl}
          onSkip={skipRest}
          onAdjustTime={adjustRestTime}
          objetivo={objetivo}
        />

        {/* Wizard - Main content */}
        <WorkoutSessionWizard
          key={`${currentExercise.id}-${currentSetNumber}`}
          exercise={currentExercise}
          currentSet={currentSetNumber}
          exerciseIndex={currentExerciseIndex}
          totalExercises={exercises.length}
          videoUrl={exerciseVideo?.videoUrl || null}
          thumbnailUrl={exerciseVideo?.thumbnailUrl || null}
          lastSetInfo={lastSetInfo}
          onSetComplete={handleSetComplete}
          onClose={onClose}
          onExpandVideo={() => setIsVideoFullscreen(true)}
          defaultWeight={lastSetInfo?.weight || currentExercise.targetWeight}
          defaultReps={lastSetInfo?.reps || currentExercise.targetReps}
          onNextExercise={goToNextExercise}
          onPreviousExercise={goToPreviousExercise}
          onSkipExercise={handleSkipExercise}
          canGoNext={currentExerciseIndex < exercises.length - 1}
          canGoPrevious={currentExerciseIndex > 0}
        />
      </div>
    );
  }

  // Render via Portal to escape PageEntranceAnimation transform context
  return createPortal(content, document.body);
}
