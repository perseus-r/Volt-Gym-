import { useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Volume2, VolumeX } from 'lucide-react';
import { useState } from 'react';
import { VideoPlayer } from '@/components/VideoPlayer';
import { useHapticFeedback } from '@/hooks/useHapticFeedback';

interface VideoFullscreenModalProps {
  isOpen: boolean;
  onClose: () => void;
  videoUrl: string;
  thumbnailUrl?: string | null;
  title: string;
}

export function VideoFullscreenModal({
  isOpen,
  onClose,
  videoUrl,
  thumbnailUrl,
  title,
}: VideoFullscreenModalProps) {
  const { trigger } = useHapticFeedback();
  const [isMuted, setIsMuted] = useState(false);
  const [startY, setStartY] = useState<number | null>(null);
  const [offsetY, setOffsetY] = useState(0);

  // Auto-unmute when opening
  useEffect(() => {
    if (isOpen) {
      setIsMuted(false);
      trigger('medium');
    }
  }, [isOpen, trigger]);

  // Handle swipe down to close
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    setStartY(e.touches[0].clientY);
  }, []);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (startY === null) return;
    const currentY = e.touches[0].clientY;
    const diff = currentY - startY;
    if (diff > 0) {
      setOffsetY(diff);
    }
  }, [startY]);

  const handleTouchEnd = useCallback(() => {
    if (offsetY > 100) {
      onClose();
      trigger('light');
    }
    setStartY(null);
    setOffsetY(0);
  }, [offsetY, onClose, trigger]);

  const handleClose = useCallback(() => {
    trigger('light');
    onClose();
  }, [onClose, trigger]);

  const toggleMute = useCallback(() => {
    trigger('light');
    setIsMuted(prev => !prev);
  }, [trigger]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] bg-black flex flex-col"
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        >
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="absolute top-0 left-0 right-0 z-10 flex items-center justify-between px-4 py-3"
            style={{ paddingTop: 'calc(env(safe-area-inset-top, 0px) + 0.75rem)' }}
          >
            {/* Title */}
            <div className="flex-1 min-w-0 mr-4">
              <h2 className="text-white font-semibold truncate">{title}</h2>
              <p className="text-white/60 text-xs">Arraste para baixo para fechar</p>
            </div>

            {/* Controls */}
            <div className="flex items-center gap-2">
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={toggleMute}
                className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center"
              >
                {isMuted ? (
                  <VolumeX className="w-5 h-5 text-white" />
                ) : (
                  <Volume2 className="w-5 h-5 text-white" />
                )}
              </motion.button>

              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={handleClose}
                className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center"
              >
                <X className="w-5 h-5 text-white" />
              </motion.button>
            </div>
          </motion.div>

          {/* Video Container */}
          <motion.div
            style={{ y: offsetY }}
            animate={{ y: 0 }}
            className="flex-1 flex items-center justify-center"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full h-full max-h-[70vh] flex items-center justify-center"
            >
              <VideoPlayer
                url={videoUrl}
                title={title}
                clickToPlay={true}
                autoPlay={true}
                loop={true}
                muted={isMuted}
                fallbackThumbnail={thumbnailUrl}
                className="w-full max-h-full object-contain"
              />
            </motion.div>
          </motion.div>

          {/* Swipe indicator */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: offsetY > 0 ? Math.min(offsetY / 100, 1) : 0 }}
            className="absolute bottom-20 left-1/2 -translate-x-1/2"
          >
            <div className="px-4 py-2 rounded-full bg-white/20 backdrop-blur-sm">
              <span className="text-white text-sm">Solte para fechar</span>
            </div>
          </motion.div>

          {/* Bottom safe area */}
          <div 
            className="flex-shrink-0" 
            style={{ height: 'env(safe-area-inset-bottom, 20px)' }}
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export default VideoFullscreenModal;
