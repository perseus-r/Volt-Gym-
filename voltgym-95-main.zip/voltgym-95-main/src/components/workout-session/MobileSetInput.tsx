import { motion } from 'framer-motion';
import { Minus, Plus } from 'lucide-react';
import { useHapticFeedback } from '@/hooks/useHapticFeedback';

interface MobileSetInputProps {
  label: string;
  value: number;
  onChange: (value: number) => void;
  step?: number;
  min?: number;
  max?: number;
  unit?: string;
  presets?: number[];
  compact?: boolean;
}

export function MobileSetInput({
  label,
  value,
  onChange,
  step = 1,
  min = 0,
  max = 999,
  unit = '',
  presets = [],
  compact = false,
}: MobileSetInputProps) {
  const { trigger } = useHapticFeedback();

  const handleIncrement = () => {
    if (value < max) {
      trigger('light');
      onChange(Math.min(value + step, max));
    }
  };

  const handleDecrement = () => {
    if (value > min) {
      trigger('light');
      onChange(Math.max(value - step, min));
    }
  };

  const handlePreset = (preset: number) => {
    trigger('selection');
    onChange(preset);
  };

  // Compact mode: side-by-side layout
  if (compact) {
    return (
      <div className="space-y-2">
        <span className="text-[10px] text-muted-foreground uppercase tracking-wider font-medium">{label}</span>
        
        <div className="flex items-center justify-between gap-2">
          <button
            onClick={handleDecrement}
            disabled={value <= min}
            className="w-10 h-10 rounded-xl bg-secondary/30 border border-border/20 flex items-center justify-center disabled:opacity-30 active:scale-95 transition-transform"
          >
            <Minus className="w-4 h-4" />
          </button>

          <div className="flex-1 text-center">
            <motion.span
              key={value}
              initial={{ scale: 1.1 }}
              animate={{ scale: 1 }}
              className="text-3xl font-bold tabular-nums"
            >
              {value}
            </motion.span>
            {unit && (
              <span className="text-sm text-muted-foreground ml-1">{unit}</span>
            )}
          </div>

          <button
            onClick={handleIncrement}
            disabled={value >= max}
            className="w-10 h-10 rounded-xl bg-secondary/30 border border-border/20 flex items-center justify-center disabled:opacity-30 active:scale-95 transition-transform"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>

        {presets.length > 0 && (
          <div className="flex gap-1.5 overflow-x-auto pb-1">
            {presets.slice(0, 4).map((preset) => (
              <button
                key={preset}
                onClick={() => handlePreset(preset)}
                className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all flex-shrink-0 ${
                  value === preset
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary/20 text-muted-foreground active:bg-secondary/40'
                }`}
              >
                {preset}{unit}
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }

  // Original full-size layout
  return (
    <div className="space-y-3">
      <span className="text-xs text-muted-foreground uppercase tracking-wider font-medium">{label}</span>
      
      <div className="flex items-center justify-center gap-4">
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={handleDecrement}
          disabled={value <= min}
          className="w-14 h-14 rounded-2xl bg-secondary/30 border border-border/20 flex items-center justify-center disabled:opacity-30 active:bg-secondary/50 transition-colors"
        >
          <Minus className="w-6 h-6" />
        </motion.button>

        <div className="min-w-[120px] text-center relative">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-20 h-20 rounded-full bg-primary/5 blur-xl" />
          </div>
          
          <motion.span
            key={value}
            initial={{ scale: 1.3, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: 'spring', stiffness: 500, damping: 30 }}
            className="relative text-5xl font-bold tabular-nums"
          >
            {value}
          </motion.span>
          {unit && (
            <span className="relative text-lg text-muted-foreground ml-1 font-medium">{unit}</span>
          )}
        </div>

        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={handleIncrement}
          disabled={value >= max}
          className="w-14 h-14 rounded-2xl bg-secondary/30 border border-border/20 flex items-center justify-center disabled:opacity-30 active:bg-secondary/50 transition-colors"
        >
          <Plus className="w-6 h-6" />
        </motion.button>
      </div>

      {presets.length > 0 && (
        <div className="flex justify-center gap-2 flex-wrap">
          {presets.map((preset) => (
            <motion.button
              key={preset}
              whileTap={{ scale: 0.95 }}
              onClick={() => handlePreset(preset)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                value === preset
                  ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/25'
                  : 'bg-secondary/20 text-muted-foreground hover:bg-secondary/40 border border-border/20'
              }`}
            >
              {preset}{unit}
            </motion.button>
          ))}
        </div>
      )}
    </div>
  );
}
