import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Trophy, Calendar, Minus } from 'lucide-react';

interface HistorySet {
  date: string;
  weight: number;
  reps: number;
  rpe?: number;
}

interface ExercisePerformanceHistoryProps {
  exerciseName: string;
  history: HistorySet[];
  personalRecord?: {
    weight: number;
    reps: number;
    date: string;
  };
  compact?: boolean;
}

export function ExercisePerformanceHistory({
  exerciseName,
  history,
  personalRecord,
  compact = false,
}: ExercisePerformanceHistoryProps) {
  // Calculate trend
  const getTrend = () => {
    if (history.length < 2) return null;
    const latest = history[0].weight * history[0].reps;
    const previous = history[1].weight * history[1].reps;
    const diff = latest - previous;
    const percentage = ((diff / previous) * 100).toFixed(1);
    
    if (diff > 0) return { type: 'up', value: percentage };
    if (diff < 0) return { type: 'down', value: Math.abs(Number(percentage)).toFixed(1) };
    return { type: 'same', value: '0' };
  };

  const trend = getTrend();

  // Generate sparkline data
  const maxVolume = Math.max(...history.map(h => h.weight * h.reps));
  const sparklinePoints = history.slice(0, 5).reverse().map((h, i) => {
    const volume = h.weight * h.reps;
    const y = 24 - (volume / maxVolume) * 20;
    const x = i * 15;
    return `${x},${y}`;
  }).join(' ');

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
  };

  if (compact) {
    return (
      <motion.div
        initial={{ opacity: 0, height: 0 }}
        animate={{ opacity: 1, height: 'auto' }}
        exit={{ opacity: 0, height: 0 }}
        className="overflow-hidden"
      >
        <div className="pt-3 mt-3 border-t border-border/30">
          <div className="flex items-center justify-between gap-4">
            {/* Last sessions compact */}
            <div className="flex-1 min-w-0">
              <span className="text-xs text-muted-foreground mb-1 block">Últimas sessões</span>
              <div className="flex gap-2">
                {history.slice(0, 3).map((set, idx) => (
                  <div 
                    key={idx}
                    className="text-xs px-2 py-1 rounded-md bg-secondary/30"
                  >
                    <span className="font-medium">{set.weight}kg</span>
                    <span className="text-muted-foreground">×{set.reps}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Trend badge */}
            {trend && (
              <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                trend.type === 'up' 
                  ? 'bg-emerald-500/10 text-emerald-500'
                  : trend.type === 'down'
                  ? 'bg-orange-500/10 text-orange-500'
                  : 'bg-secondary/30 text-muted-foreground'
              }`}>
                {trend.type === 'up' && <TrendingUp className="w-3 h-3" />}
                {trend.type === 'down' && <TrendingDown className="w-3 h-3" />}
                {trend.type === 'same' && <Minus className="w-3 h-3" />}
                <span>{trend.type === 'up' ? '+' : trend.type === 'down' ? '-' : ''}{trend.value}%</span>
              </div>
            )}
          </div>

          {/* PR display */}
          {personalRecord && (
            <div className="flex items-center gap-2 mt-2 text-xs">
              <Trophy className="w-3 h-3 text-yellow-500" />
              <span className="text-yellow-500 font-medium">
                PR: {personalRecord.weight}kg × {personalRecord.reps}
              </span>
              <span className="text-muted-foreground">({formatDate(personalRecord.date)})</span>
            </div>
          )}
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-4 rounded-xl bg-secondary/20 border border-border/30"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-muted-foreground" />
          <span className="text-sm font-medium">Histórico</span>
        </div>
        
        {/* Sparkline */}
        {history.length >= 3 && (
          <svg width="60" height="24" className="text-primary">
            <polyline
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              points={sparklinePoints}
            />
          </svg>
        )}

        {/* Trend */}
        {trend && (
          <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
            trend.type === 'up' 
              ? 'bg-emerald-500/10 text-emerald-500'
              : trend.type === 'down'
              ? 'bg-orange-500/10 text-orange-500'
              : 'bg-secondary/30 text-muted-foreground'
          }`}>
            {trend.type === 'up' && <TrendingUp className="w-3 h-3" />}
            {trend.type === 'down' && <TrendingDown className="w-3 h-3" />}
            {trend.type === 'same' && <Minus className="w-3 h-3" />}
            <span>{trend.type === 'up' ? '+' : trend.type === 'down' ? '-' : ''}{trend.value}%</span>
          </div>
        )}
      </div>

      {/* History list */}
      <div className="space-y-2">
        {history.slice(0, 3).map((set, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.1 }}
            className={`flex items-center justify-between p-2 rounded-lg ${
              idx === 0 ? 'bg-primary/10 border border-primary/20' : 'bg-secondary/30'
            }`}
          >
            <span className="text-xs text-muted-foreground">{formatDate(set.date)}</span>
            <div className="flex items-center gap-2">
              <span className="font-medium text-sm">{set.weight}kg × {set.reps}</span>
              {set.rpe && (
                <span className="text-xs px-1.5 py-0.5 rounded bg-secondary/50">
                  RPE {set.rpe}
                </span>
              )}
            </div>
          </motion.div>
        ))}
      </div>

      {/* PR Highlight */}
      {personalRecord && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
          className="mt-3 p-3 rounded-lg bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border border-yellow-500/20"
        >
          <div className="flex items-center gap-2">
            <motion.div
              animate={{ rotate: [0, -10, 10, 0], scale: [1, 1.1, 1] }}
              transition={{ duration: 1, repeat: Infinity, repeatDelay: 2, type: 'tween' }}
            >
              <Trophy className="w-4 h-4 text-yellow-500" />
            </motion.div>
            <span className="text-sm font-bold text-yellow-500">Personal Record</span>
          </div>
          <div className="mt-1 flex items-center justify-between">
            <span className="text-lg font-bold">{personalRecord.weight}kg × {personalRecord.reps}</span>
            <span className="text-xs text-muted-foreground">{formatDate(personalRecord.date)}</span>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}
