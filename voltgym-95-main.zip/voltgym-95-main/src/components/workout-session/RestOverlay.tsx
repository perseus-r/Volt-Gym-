import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';

interface RestOverlayProps {
  isActive: boolean;
  timeLeft: number;
  totalTime: number;
  nextExercise?: string;
  onSkip: () => void;
}

export function RestOverlay({ isActive, timeLeft, totalTime, nextExercise, onSkip }: RestOverlayProps) {
  if (!isActive) return null;

  const progress = ((totalTime - timeLeft) / totalTime) * 100;
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-bg-1/95 backdrop-blur-xl flex items-center justify-center p-4"
      >
        <motion.div
          initial={{ scale: 0.9, y: 20 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.9, y: 20 }}
          className="glass-ultra max-w-md w-full p-8 rounded-3xl border border-white/20 text-center"
        >
          <div className="mb-6">
            <div className="text-txt-3 text-sm mb-2">Descanso</div>
            <motion.div
              className="text-8xl font-bold text-accent mb-4"
              animate={{
                scale: timeLeft <= 3 ? [1, 1.1, 1] : 1,
              }}
              transition={{ duration: 0.5, repeat: timeLeft <= 3 ? Infinity : 0 }}
            >
              {formatTime(timeLeft)}
            </motion.div>
          </div>

          <div className="mb-6">
            <Progress value={progress} className="h-3" />
          </div>

          {/* Breathing Animation */}
          <div className="mb-6">
            <div className="text-xs text-txt-3 mb-3">Respire fundo</div>
            <motion.div
              className="w-20 h-20 mx-auto rounded-full border-4 border-accent/50"
              animate={{
                scale: [1, 1.3, 1],
                opacity: [0.5, 1, 0.5],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />
          </div>

          {nextExercise && (
            <div className="mb-6 p-4 bg-bg-2/50 rounded-xl">
              <div className="text-xs text-txt-3 mb-1">Próximo exercício</div>
              <div className="text-lg font-semibold text-txt-1">{nextExercise}</div>
            </div>
          )}

          <Button
            onClick={onSkip}
            variant="outline"
            className="w-full"
          >
            Pular Descanso
          </Button>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
