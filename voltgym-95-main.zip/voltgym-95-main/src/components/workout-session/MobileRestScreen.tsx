import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { SkipForward, Plus, Minus, Wind, Dumbbell, Play } from 'lucide-react';
import { useHapticFeedback } from '@/hooks/useHapticFeedback';
import '@/styles/workout-session.css';

type Objetivo = 'massa' | 'definicao' | 'forca' | 'saude' | null;

interface MobileRestScreenProps {
  isActive: boolean;
  timeLeft: number;
  totalTime: number;
  nextExercise?: string;
  nextExerciseDetails?: string;
  nextExerciseVideoUrl?: string | null;
  nextExerciseThumbnail?: string | null;
  onSkip: () => void;
  onAdjustTime: (delta: number) => void;
  objetivo?: Objetivo;
}

export function MobileRestScreen({
  isActive,
  timeLeft,
  totalTime,
  nextExercise,
  nextExerciseDetails,
  nextExerciseVideoUrl,
  nextExerciseThumbnail,
  onSkip,
  onAdjustTime,
  objetivo,
}: MobileRestScreenProps) {
  const { trigger } = useHapticFeedback();
  const [breatheIn, setBreatheIn] = useState(true);

  // Breathing animation cycle (4s in, 4s out)
  useEffect(() => {
    if (!isActive) return;
    const interval = setInterval(() => {
      setBreatheIn(prev => !prev);
    }, 4000);
    return () => clearInterval(interval);
  }, [isActive]);

  // Haptic feedback at key moments
  useEffect(() => {
    if (!isActive) return;
    if (timeLeft === 10) trigger('warning');
    if (timeLeft === 3) trigger('warning');
    if (timeLeft === 0) trigger('success');
  }, [timeLeft, isActive, trigger]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = totalTime > 0 ? ((totalTime - timeLeft) / totalTime) * 100 : 0;
  const circumference = 2 * Math.PI * 110;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  const handleSkip = () => {
    trigger('medium');
    onSkip();
  };

  const handleAdjustTime = (delta: number) => {
    trigger('light');
    onAdjustTime(delta);
  };

  const isUrgent = timeLeft <= 10;

  return (
    <AnimatePresence>
      {isActive && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[80] flex flex-col"
          style={{ background: 'hsl(var(--background))' }}
        >
          {/* Header - Breathing indicator sutil com safe-area */}
          <div 
            className="px-6 pt-4"
            style={{ paddingTop: 'calc(env(safe-area-inset-top, 0px) + 1rem)' }}
          >
            <motion.div 
              animate={{ opacity: breatheIn ? 0.8 : 0.4 }}
              transition={{ duration: 2 }}
              className="flex items-center justify-center gap-2 text-muted-foreground"
            >
              <Wind className="w-4 h-4" />
              <span className="text-sm">
                {breatheIn ? 'Inspire...' : 'Expire...'}
              </span>
            </motion.div>
          </div>

          {/* Timer Section - Centralizado com controles integrados */}
          <div className="flex-1 flex flex-col items-center justify-center">
            <div className="relative flex items-center justify-center">
              {/* Breathing pulse background */}
              <motion.div
                animate={{ 
                  scale: breatheIn ? 1.15 : 1,
                  opacity: breatheIn ? 0.3 : 0.15
                }}
                transition={{ duration: 4, ease: 'easeInOut' }}
                className="absolute w-72 h-72 rounded-full bg-gradient-to-br from-primary/20 to-primary/5 pointer-events-none"
              />

              {/* Shimmer ring effect */}
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
                className="absolute w-60 h-60 rounded-full pointer-events-none"
                style={{
                  background: `conic-gradient(from 0deg, transparent, ${isUrgent ? 'hsl(var(--destructive) / 0.3)' : 'hsl(var(--primary) / 0.3)'}, transparent)`,
                }}
              />

              {/* Glow effect */}
              <motion.div
                animate={{ 
                  boxShadow: isUrgent 
                    ? ['0 0 40px hsl(var(--destructive) / 0.3)', '0 0 80px hsl(var(--destructive) / 0.5)', '0 0 40px hsl(var(--destructive) / 0.3)']
                    : ['0 0 40px hsl(var(--primary) / 0.2)', '0 0 60px hsl(var(--primary) / 0.3)', '0 0 40px hsl(var(--primary) / 0.2)']
                }}
                transition={{ duration: 2, repeat: Infinity }}
                className="absolute w-56 h-56 rounded-full pointer-events-none"
              />

              {/* Progress ring with gradient */}
              <svg className="w-56 h-56 transform -rotate-90 timer-ring-glow">
                <defs>
                  <linearGradient id="timerGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor={isUrgent ? 'hsl(var(--destructive))' : 'hsl(var(--primary))'} />
                    <stop offset="100%" stopColor={isUrgent ? 'hsl(0, 84%, 70%)' : 'hsl(var(--accent))'} />
                  </linearGradient>
                </defs>
                <circle
                  cx="112"
                  cy="112"
                  r="110"
                  fill="none"
                  stroke="hsl(var(--secondary))"
                  strokeWidth="6"
                />
                <motion.circle
                  cx="112"
                  cy="112"
                  r="110"
                  fill="none"
                  stroke="url(#timerGradient)"
                  strokeWidth="6"
                  strokeLinecap="round"
                  strokeDasharray={circumference}
                  animate={{ strokeDashoffset }}
                  transition={{ duration: 0.5, ease: 'easeOut' }}
                />
              </svg>

              {/* Center tap area - tap to extend */}
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => handleAdjustTime(30)}
                className="absolute w-44 h-44 rounded-full flex flex-col items-center justify-center bg-background/5 hover:bg-background/10 transition-colors"
              >
                <motion.span
                  key={timeLeft}
                  initial={{ scale: 1.1 }}
                  animate={{ scale: 1 }}
                  className={`text-6xl font-bold tabular-nums ${
                    isUrgent ? 'text-destructive' : 'text-foreground'
                  }`}
                >
                  {formatTime(timeLeft)}
                </motion.span>
                <span className="text-xs text-muted-foreground mt-2 font-medium">
                  Toque para +30s
                </span>
              </motion.button>
            </div>

            {/* Time adjustment - Integrado ao timer */}
            <div className="flex items-center justify-center gap-3 mt-8">
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => handleAdjustTime(-15)}
                className="px-5 py-2.5 rounded-xl bg-secondary/40 border border-border/30 flex items-center gap-2 active:bg-secondary/60 transition-colors min-h-[44px]"
              >
                <Minus className="w-4 h-4" />
                <span className="text-sm font-medium">15s</span>
              </motion.button>

              <div className="w-1.5 h-1.5 rounded-full bg-muted-foreground/30" />

              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => handleAdjustTime(30)}
                className="px-5 py-2.5 rounded-xl bg-secondary/40 border border-border/30 flex items-center gap-2 active:bg-secondary/60 transition-colors min-h-[44px]"
              >
                <Plus className="w-4 h-4" />
                <span className="text-sm font-medium">30s</span>
              </motion.button>
            </div>
          </div>

          {/* Bottom Section - Card + Botão destacado com safe-area */}
          <div 
            className="px-6 space-y-4 pb-4"
            style={{ paddingBottom: 'calc(env(safe-area-inset-bottom, 0px) + 1rem)' }}
          >
            {/* Next exercise preview - Card maior */}
            {nextExercise && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="p-5 rounded-2xl session-glass border border-border/30"
              >
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-xl bg-primary/15 flex items-center justify-center">
                    <Dumbbell className="w-7 h-7 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="text-xs text-muted-foreground uppercase tracking-wider font-medium">
                      Próximo exercício
                    </span>
                    <p className="text-lg font-bold mt-0.5 truncate">{nextExercise}</p>
                    {nextExerciseDetails && (
                      <p className="text-sm text-muted-foreground">{nextExerciseDetails}</p>
                    )}
                  </div>
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                    <Play className="w-5 h-5 text-primary fill-primary" />
                  </div>
                </div>
              </motion.div>
            )}

            {/* Skip button - DESTAQUE com gradiente e glow - SEMPRE acessível */}
            <motion.button
              whileTap={{ scale: 0.98 }}
              onClick={(e) => {
                e.stopPropagation();
                handleSkip();
              }}
              className="relative w-full py-5 rounded-2xl bg-gradient-to-r from-primary to-primary/80 text-primary-foreground flex items-center justify-center gap-3 shadow-lg shadow-primary/25 active:shadow-primary/40 transition-all min-h-[56px]"
            >
              <motion.div
                animate={{ x: [0, 4, 0] }}
                transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
              >
                <SkipForward className="w-6 h-6" />
              </motion.div>
              <span className="text-lg font-bold">Pular Descanso</span>
            </motion.button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
