import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, Plus, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { WeightSelector } from './WeightSelector';
import { VariationsPanel } from './VariationsPanel';
import { DropSetGuide } from './DropSetGuide';
import { RestPauseGuide } from './RestPauseGuide';
import { TempoTrainer } from './TempoTrainer';
import { WorkoutSet } from '@/types/workout.unified';
import { 
  VariationType, 
  DropSetConfig,
  RestPauseConfig,
  ClusterSetConfig,
  TempoConfig
} from '@/types/variations.types';

interface SetTrackerProps {
  sets: WorkoutSet[];
  targetSets: number;
  targetReps: number;
  lastWeight?: number;
  onCompleteSet: (setData: any) => void;
  onStartRest: (seconds: number) => void;
}

export function SetTracker({ 
  sets, 
  targetSets, 
  targetReps,
  lastWeight = 20,
  onCompleteSet,
  onStartRest
}: SetTrackerProps) {
  const [weight, setWeight] = useState(lastWeight);
  const [reps, setReps] = useState(targetReps);
  const [rpe, setRpe] = useState(7);
  const [variationType, setVariationType] = useState<VariationType>('normal');
  const [showVariationGuide, setShowVariationGuide] = useState(false);
  const [dropSetConfig, setDropSetConfig] = useState<DropSetConfig | null>(null);
  const [restPauseConfig, setRestPauseConfig] = useState<RestPauseConfig | null>(null);
  const [clusterConfig, setClusterConfig] = useState<ClusterSetConfig | null>(null);
  const [tempoConfig, setTempoConfig] = useState<TempoConfig | null>(null);

  const handleCompleteSet = () => {
    // Check if it's an AMRAP set (last set)
    const isLastSet = sets.length + 1 === targetSets;
    
    onCompleteSet({ 
      weight, 
      reps, 
      rpe, 
      notes: '',
      variationType,
      isAMRAP: variationType === 'amrap' && isLastSet
    });
    onStartRest(90);
  };

  const handleVariationTypeChange = (type: VariationType) => {
    setVariationType(type);
    
    // Auto-open guide for advanced variations
    if (['drop_set', 'rest_pause', 'tempo'].includes(type)) {
      setShowVariationGuide(true);
    } else {
      setShowVariationGuide(false);
    }
  };

  const handleVariationComplete = (data?: any) => {
    if (data) {
      onCompleteSet({
        ...data,
        rpe,
        notes: `${variationType} - ${JSON.stringify(data)}`
      });
    }
    setShowVariationGuide(false);
    setVariationType('normal');
  };

  const canAddSet = sets.length < targetSets;
  const nextSetNumber = sets.length + 1;
  const isLastSet = nextSetNumber === targetSets;

  // Show variation guide for specific types
  if (showVariationGuide && variationType === 'drop_set' && dropSetConfig) {
    return (
      <DropSetGuide
        config={dropSetConfig}
        onComplete={handleVariationComplete}
        onCancel={() => {
          setShowVariationGuide(false);
          setVariationType('normal');
        }}
      />
    );
  }

  if (showVariationGuide && variationType === 'rest_pause' && restPauseConfig) {
    return (
      <RestPauseGuide
        config={restPauseConfig}
        onComplete={handleVariationComplete}
        onCancel={() => {
          setShowVariationGuide(false);
          setVariationType('normal');
        }}
      />
    );
  }

  if (showVariationGuide && variationType === 'tempo' && tempoConfig) {
    return (
      <TempoTrainer
        config={tempoConfig}
        onComplete={handleVariationComplete}
        onCancel={() => {
          setShowVariationGuide(false);
          setVariationType('normal');
        }}
      />
    );
  }

  return (
    <div className="space-y-6">
      {/* Completed Sets */}
      <AnimatePresence>
        {sets.map((set, idx) => (
          <motion.div
            key={set.id}
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 20, opacity: 0 }}
            className="glass-subtle p-4 rounded-xl border border-green-500/30"
          >
            <div className="flex items-center gap-4">
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-green-500/20 border border-green-500/50">
                <Check className="w-5 h-5 text-green-400" />
              </div>
              
              <div className="flex-1">
                <div className="flex items-center gap-3 text-sm flex-wrap">
                  <span className="text-txt-2">Série {set.setNumber}</span>
                  <span className="text-accent font-bold">{set.weight}kg</span>
                  <span className="text-txt-3">×</span>
                  <span className="text-accent font-bold">{set.reps} reps</span>
                  <span className="text-txt-3">•</span>
                  <span className="text-txt-2">RPE {set.rpe}</span>
                  {(set as any).variationType && (set as any).variationType !== 'normal' && (
                    <>
                      <span className="text-txt-3">•</span>
                      <Zap className="w-3 h-3 text-orange-400" />
                    </>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Current Set Form */}
      {canAddSet && (
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="space-y-4"
        >
          {/* Variations Panel */}
          <VariationsPanel
            currentType={isLastSet && variationType === 'normal' ? 'amrap' : variationType}
            onSelectType={handleVariationTypeChange}
            onConfigureDropSet={(config) => {
              setDropSetConfig(config);
              setShowVariationGuide(true);
            }}
            onConfigureRestPause={(config) => {
              setRestPauseConfig(config);
              setShowVariationGuide(true);
            }}
            onConfigureCluster={setClusterConfig}
            onConfigureTempo={(config) => {
              setTempoConfig(config);
              setShowVariationGuide(true);
            }}
          />

          {/* Standard Set Input */}
          <motion.div
            className="glass-premium p-6 rounded-2xl border border-accent/30"
          >
            <h4 className="text-lg font-semibold text-txt-1 mb-4 flex items-center gap-2">
              Série {nextSetNumber} de {targetSets}
              {isLastSet && variationType === 'amrap' && (
                <span className="text-xs text-red-400 font-normal">(AMRAP - Máximo de reps)</span>
              )}
            </h4>

            <div className="space-y-4">
              <WeightSelector
                value={weight}
                onChange={setWeight}
                label="Peso (kg)"
              />

              <div className="space-y-2">
                <Label className="text-txt-2 text-sm">Repetições</Label>
                <Input
                  type="number"
                  value={reps}
                  onChange={(e) => setReps(parseInt(e.target.value) || 0)}
                  min={1}
                  max={50}
                  className="h-12 text-center text-xl font-bold text-txt bg-bg-2/50 border-white/10 focus:border-accent/50"
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-txt-2 text-sm">RPE (Esforço)</Label>
                  <span className="text-accent text-xl font-bold">{rpe}</span>
                </div>
                <Slider
                  value={[rpe]}
                  onValueChange={(val) => setRpe(val[0])}
                  min={1}
                  max={10}
                  step={1}
                  className="py-4"
                />
                <div className="flex justify-between text-xs text-txt-3">
                  <span>Fácil</span>
                  <span>Moderado</span>
                  <span>Máximo</span>
                </div>
              </div>

              <Button
                onClick={handleCompleteSet}
                className="w-full h-12 text-lg font-semibold bg-gradient-to-r from-accent to-accent-2 hover:opacity-90"
              >
                <Plus className="w-5 h-5 mr-2" />
                {variationType === 'amrap' && isLastSet ? 'Finalizar AMRAP' : 'Completar Série'}
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}

      {!canAddSet && (
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="glass-premium p-6 rounded-2xl border border-green-500/30 text-center"
        >
          <div className="text-4xl mb-2">✅</div>
          <div className="text-lg font-semibold text-txt-1">Exercício Completo!</div>
          <div className="text-sm text-txt-3 mt-1">Todas as séries foram realizadas</div>
        </motion.div>
      )}
    </div>
  );
}
