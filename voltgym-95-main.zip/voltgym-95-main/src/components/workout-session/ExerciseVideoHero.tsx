import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, Maximize2, Volume2, VolumeX, Dumbbell, Loader2 } from 'lucide-react';
import { VideoPlayer } from '@/components/VideoPlayer';

interface ExerciseVideoHeroProps {
  videoUrl: string | null;
  thumbnailUrl: string | null;
  exerciseName: string;
  onExpand?: () => void;
  autoPlay?: boolean;
  loop?: boolean;
}

export function ExerciseVideoHero({
  videoUrl,
  thumbnailUrl,
  exerciseName,
  onExpand,
  autoPlay = true,
  loop = true,
}: ExerciseVideoHeroProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [isMuted, setIsMuted] = useState(true);
  const [hasError, setHasError] = useState(false);

  const handleLoad = useCallback(() => {
    setIsLoading(false);
    setHasError(false);
  }, []);

  const handleError = useCallback(() => {
    setIsLoading(false);
    setHasError(true);
  }, []);

  const toggleMute = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    setIsMuted(prev => !prev);
  }, []);

  const handleExpand = useCallback(() => {
    onExpand?.();
  }, [onExpand]);

  // No video available - show elegant fallback
  if (!videoUrl && !thumbnailUrl) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative w-full aspect-video rounded-2xl overflow-hidden session-glass-intense flex flex-col items-center justify-center gap-3"
      >
        {/* Gradient background */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-primary/5" />
        
        {/* Animated icon */}
        <motion.div
          animate={{ 
            scale: [1, 1.05, 1],
            rotate: [-2, 2, -2]
          }}
          transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
          className="w-16 h-16 rounded-2xl bg-primary/15 flex items-center justify-center"
        >
          <Dumbbell className="w-8 h-8 text-primary/60" />
        </motion.div>
        
        <span className="text-sm text-muted-foreground font-medium">
          Vídeo demonstrativo indisponível
        </span>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="relative w-full aspect-video rounded-2xl overflow-hidden video-hero-glow"
      onClick={handleExpand}
    >
      {/* Loading skeleton */}
      <AnimatePresence>
        {isLoading && (
          <motion.div
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-10 bg-secondary/50 flex items-center justify-center"
          >
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Video or Thumbnail */}
      {videoUrl && !hasError ? (
        <VideoPlayer
          url={videoUrl}
          title={exerciseName}
          clickToPlay={false}
          autoPlay={autoPlay}
          loop={loop}
          muted={isMuted}
          fallbackThumbnail={thumbnailUrl}
          className="w-full h-full object-cover"
          onLoad={handleLoad}
          onError={handleError}
        />
      ) : thumbnailUrl ? (
        <img
          src={thumbnailUrl}
          alt={exerciseName}
          className="w-full h-full object-cover"
          onLoad={handleLoad}
          onError={handleError}
        />
      ) : null}

      {/* Gradient overlay for better UI visibility */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />
      
      {/* Top gradient for controls */}
      <div className="absolute inset-x-0 top-0 h-16 bg-gradient-to-b from-black/40 to-transparent pointer-events-none" />

      {/* Loop indicator badge */}
      {loop && videoUrl && (
        <motion.div
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-black/50 backdrop-blur-sm flex items-center gap-1.5"
        >
          <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
          <span className="text-[10px] text-white/80 font-medium uppercase tracking-wider">
            Em loop
          </span>
        </motion.div>
      )}

      {/* Controls */}
      <div className="absolute top-3 right-3 flex items-center gap-2">
        {/* Mute/Unmute button */}
        {videoUrl && (
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={toggleMute}
            className="w-9 h-9 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center transition-colors hover:bg-black/70"
          >
            {isMuted ? (
              <VolumeX className="w-4 h-4 text-white/80" />
            ) : (
              <Volume2 className="w-4 h-4 text-white/80" />
            )}
          </motion.button>
        )}

        {/* Expand button */}
        {onExpand && (
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={(e) => {
              e.stopPropagation();
              handleExpand();
            }}
            className="w-9 h-9 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center transition-colors hover:bg-black/70"
          >
            <Maximize2 className="w-4 h-4 text-white/80" />
          </motion.button>
        )}
      </div>

      {/* Play icon for thumbnails */}
      {!videoUrl && thumbnailUrl && (
        <motion.div
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute inset-0 flex items-center justify-center pointer-events-none"
        >
          <div className="w-16 h-16 rounded-full bg-primary/90 flex items-center justify-center shadow-lg shadow-primary/25">
            <Play className="w-7 h-7 text-primary-foreground ml-1" />
          </div>
        </motion.div>
      )}

      {/* Bottom info - Exercise name hint */}
      <div className="absolute bottom-3 left-3 right-3">
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-white/70 text-xs font-medium"
        >
          Toque para expandir
        </motion.p>
      </div>

      {/* Glow border animation */}
      <div className="absolute inset-0 rounded-2xl pointer-events-none video-hero-border" />
    </motion.div>
  );
}

export default ExerciseVideoHero;
