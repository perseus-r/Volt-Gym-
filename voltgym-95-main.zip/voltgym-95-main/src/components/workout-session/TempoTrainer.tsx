import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Play, 
  Pause, 
  RotateCcw,
  ChevronRight,
  Volume2,
  VolumeX
} from 'lucide-react';
import { TempoConfig } from '@/types/variations.types';

interface TempoTrainerProps {
  config: TempoConfig;
  onComplete: () => void;
  onCancel: () => void;
}

export function TempoTrainer({ config, onComplete, onCancel }: TempoTrainerProps) {
  const [currentPhase, setCurrentPhase] = useState<'eccentric' | 'pause1' | 'concentric' | 'pause2'>('eccentric');
  const [timeLeft, setTimeLeft] = useState(config.eccentric);
  const [isActive, setIsActive] = useState(false);
  const [repsCompleted, setRepsCompleted] = useState(0);
  const [soundEnabled, setSoundEnabled] = useState(true);

  const phases = [
    { name: 'eccentric', label: 'Descida', duration: config.eccentric, color: 'bg-blue-500' },
    { name: 'pause1', label: 'Pausa', duration: config.pause1, color: 'bg-yellow-500' },
    { name: 'concentric', label: 'Subida', duration: config.concentric, color: 'bg-green-500' },
    { name: 'pause2', label: 'Pausa', duration: config.pause2, color: 'bg-yellow-500' },
  ];

  const currentPhaseData = phases.find(p => p.name === currentPhase)!;
  const totalTime = config.eccentric + config.pause1 + config.concentric + config.pause2;
  const currentPhaseIndex = phases.findIndex(p => p.name === currentPhase);
  const progressPercent = ((totalTime - timeLeft) / totalTime) * 100;

  // Metronome beep
  const playBeep = (frequency: number = 800) => {
    if (!soundEnabled) return;
    
    const audioContext = new AudioContext();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.frequency.value = frequency;
    oscillator.type = 'sine';

    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);

    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.1);
  };

  useEffect(() => {
    if (!isActive) return;

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          // Move to next phase
          const nextPhaseIndex = (currentPhaseIndex + 1) % phases.length;
          
          if (nextPhaseIndex === 0) {
            // Completed one rep
            setRepsCompleted(r => r + 1);
            playBeep(1000); // Higher pitch for rep completion
          } else {
            playBeep(600); // Lower pitch for phase change
          }
          
          const nextPhase = phases[nextPhaseIndex];
          setCurrentPhase(nextPhase.name as any);
          return nextPhase.duration;
        }
        
        // Beep every second
        if (prev <= 3) {
          playBeep(400);
        }
        
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isActive, currentPhase]);

  const handleStartPause = () => {
    setIsActive(!isActive);
  };

  const handleReset = () => {
    setIsActive(false);
    setCurrentPhase('eccentric');
    setTimeLeft(config.eccentric);
    setRepsCompleted(0);
  };

  const handleNextRep = () => {
    setCurrentPhase('eccentric');
    setTimeLeft(config.eccentric);
    setRepsCompleted(r => r + 1);
  };

  return (
    <Card className="session-glass-intense p-6 border-accent/30 animate-fade-in">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-bold text-white">Tempo Training</h3>
            <p className="text-sm text-muted-foreground">
              Padrão: {config.eccentric}-{config.pause1}-{config.concentric}-{config.pause2}
            </p>
          </div>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => setSoundEnabled(!soundEnabled)}
          >
            {soundEnabled ? (
              <Volume2 className="w-5 h-5 text-accent" />
            ) : (
              <VolumeX className="w-5 h-5 text-muted-foreground" />
            )}
          </Button>
        </div>

        {/* Reps Counter */}
        <div className="text-center">
          <div className="text-4xl font-bold text-white">{repsCompleted}</div>
          <div className="text-sm text-muted-foreground">repetições completas</div>
        </div>

        {/* Current Phase */}
        <div className="text-center space-y-3">
          <Badge 
            variant="outline" 
            className={`text-lg px-6 py-2 ${currentPhaseData.color} border-none text-white`}
          >
            {currentPhaseData.label}
          </Badge>
          
          <div className="text-6xl font-bold text-white font-mono">
            {timeLeft}s
          </div>
        </div>

        {/* Progress Bar */}
        <div className="space-y-2">
          <Progress value={progressPercent} className="h-3" />
          <div className="flex justify-between text-xs text-muted-foreground">
            {phases.map((phase, idx) => (
              <span 
                key={phase.name}
                className={idx === currentPhaseIndex ? 'text-accent font-bold' : ''}
              >
                {phase.label}
              </span>
            ))}
          </div>
        </div>

        {/* Controls */}
        <div className="grid grid-cols-3 gap-3">
          <Button
            variant="outline"
            onClick={handleReset}
            className="flex flex-col gap-1 h-auto py-3"
          >
            <RotateCcw className="w-5 h-5" />
            <span className="text-xs">Reset</span>
          </Button>

          <Button
            onClick={handleStartPause}
            className={`flex flex-col gap-1 h-auto py-3 ${
              isActive ? 'bg-orange-500 hover:bg-orange-600' : 'bg-accent hover:bg-accent/90'
            }`}
          >
            {isActive ? (
              <>
                <Pause className="w-5 h-5" />
                <span className="text-xs">Pausar</span>
              </>
            ) : (
              <>
                <Play className="w-5 h-5" />
                <span className="text-xs">Iniciar</span>
              </>
            )}
          </Button>

          <Button
            variant="outline"
            onClick={handleNextRep}
            disabled={isActive}
            className="flex flex-col gap-1 h-auto py-3"
          >
            <ChevronRight className="w-5 h-5" />
            <span className="text-xs">Próx Rep</span>
          </Button>
        </div>

        {/* Actions */}
        <div className="flex gap-3 pt-4 border-t border-white/10">
          <Button
            variant="outline"
            onClick={onCancel}
            className="flex-1"
          >
            Cancelar
          </Button>
          <Button
            onClick={onComplete}
            className="flex-1 bg-green-500 hover:bg-green-600"
          >
            Concluir Série
          </Button>
        </div>
      </div>
    </Card>
  );
}
