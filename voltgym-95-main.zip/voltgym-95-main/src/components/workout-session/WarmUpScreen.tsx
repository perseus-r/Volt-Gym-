import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Flame, 
  Play, 
  SkipForward, 
  Timer, 
  ChevronRight,
  Heart,
  Wind
} from 'lucide-react';
import { useHapticFeedback } from '@/hooks/useHapticFeedback';
import { Button } from '@/components/ui/button';

interface WarmUpExercise {
  name: string;
  duration: string;
  description?: string;
}

interface WarmUpScreenProps {
  isOpen: boolean;
  workoutFocus?: string;
  onSkip: () => void;
  onComplete: () => void;
}

// Default warm-up exercises based on workout focus
const getWarmUpExercises = (focus?: string): WarmUpExercise[] => {
  const generalWarmUp: WarmUpExercise[] = [
    { name: 'Polichinelos', duration: '30s', description: 'Aqueça o corpo todo' },
    { name: 'Círculos de braço', duration: '20s', description: 'Mobilidade de ombros' },
    { name: 'Agachamento sem peso', duration: '30s', description: 'Ative as pernas' },
    { name: 'Rotação de tronco', duration: '20s', description: 'Mobilidade de coluna' },
  ];

  const upperBodyWarmUp: WarmUpExercise[] = [
    { name: 'Círculos de ombro', duration: '30s', description: 'Mobilidade de ombros' },
    { name: 'Flexões de parede', duration: '10 reps', description: 'Ative o peitoral' },
    { name: 'Band pull-aparts', duration: '15 reps', description: 'Aqueça as costas' },
    { name: 'Rotação de punho', duration: '20s', description: 'Prepare os pulsos' },
  ];

  const lowerBodyWarmUp: WarmUpExercise[] = [
    { name: 'Marcha no lugar', duration: '30s', description: 'Aumente a frequência cardíaca' },
    { name: 'Afundos dinâmicos', duration: '10 cada', description: 'Mobilidade de quadril' },
    { name: 'Agachamento com pausa', duration: '8 reps', description: 'Ative os glúteos' },
    { name: 'Círculos de tornozelo', duration: '20s', description: 'Mobilidade de tornozelos' },
  ];

  const lowerFocus = focus?.toLowerCase() || '';
  if (lowerFocus.includes('perna') || lowerFocus.includes('leg') || lowerFocus.includes('glúteo')) {
    return lowerBodyWarmUp;
  }
  if (lowerFocus.includes('peito') || lowerFocus.includes('costas') || lowerFocus.includes('ombro') || lowerFocus.includes('braço')) {
    return upperBodyWarmUp;
  }
  return generalWarmUp;
};

export function WarmUpScreen({
  isOpen,
  workoutFocus,
  onSkip,
  onComplete,
}: WarmUpScreenProps) {
  const { trigger } = useHapticFeedback();
  const [timeLeft, setTimeLeft] = useState(180); // 3 minutes
  const [isActive, setIsActive] = useState(false);
  const [breatheIn, setBreatheIn] = useState(true);
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);

  const exercises = getWarmUpExercises(workoutFocus);

  // Timer countdown
  useEffect(() => {
    if (!isActive || timeLeft <= 0) return;

    const interval = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          trigger('success');
          setIsActive(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isActive, timeLeft, trigger]);

  // Breathing animation
  useEffect(() => {
    if (!isOpen) return;
    const interval = setInterval(() => {
      setBreatheIn(prev => !prev);
    }, 4000);
    return () => clearInterval(interval);
  }, [isOpen]);

  // Auto advance exercises
  useEffect(() => {
    if (!isActive) return;
    const exerciseTime = Math.floor(180 / exercises.length);
    const elapsed = 180 - timeLeft;
    const newIndex = Math.min(Math.floor(elapsed / exerciseTime), exercises.length - 1);
    if (newIndex !== currentExerciseIndex) {
      setCurrentExerciseIndex(newIndex);
      trigger('light');
    }
  }, [timeLeft, isActive, exercises.length, currentExerciseIndex, trigger]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleStart = () => {
    trigger('medium');
    setIsActive(true);
  };

  const handleSkip = () => {
    trigger('light');
    onSkip();
  };

  const handleComplete = () => {
    trigger('success');
    onComplete();
  };

  const progress = ((180 - timeLeft) / 180) * 100;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex flex-col bg-background"
        >
          {/* Animated gradient background - pointer-events-none para não bloquear cliques */}
          <div className="absolute inset-0 bg-gradient-to-br from-orange-500/10 via-background to-red-500/10 pointer-events-none" />
          
          {/* Breathing pulse - pointer-events-none */}
          <motion.div
            animate={{ 
              scale: breatheIn ? 1.1 : 1,
              opacity: breatheIn ? 0.15 : 0.08
            }}
            transition={{ duration: 4, ease: 'easeInOut' }}
            className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-gradient-to-br from-orange-500/30 to-red-500/20 blur-3xl pointer-events-none"
          />

          {/* Header - STICKY com safe-area correto */}
          <div 
            className="relative flex-shrink-0 px-6 pt-4"
            style={{ paddingTop: 'calc(env(safe-area-inset-top, 0px) + 1rem)' }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <motion.div
                  animate={{ 
                    scale: [1, 1.2, 1],
                    rotate: [-5, 5, -5]
                  }}
                  transition={{ duration: 1, repeat: Infinity }}
                >
                  <Flame className="w-6 h-6 text-orange-500" />
                </motion.div>
                <h1 className="text-xl font-bold">Aquecimento</h1>
              </div>
              
              {/* Botão Pular - SEMPRE visível e clicável */}
              <Button
                variant="ghost"
                size="sm"
                onClick={handleSkip}
                className="text-muted-foreground z-10 min-h-[44px] min-w-[80px]"
              >
                <SkipForward className="w-4 h-4 mr-1" />
                Pular
              </Button>
            </div>

            {/* Breathing guide */}
            <motion.div 
              animate={{ opacity: breatheIn ? 0.8 : 0.4 }}
              transition={{ duration: 2 }}
              className="flex items-center justify-center gap-2 text-muted-foreground mt-4"
            >
              <Wind className="w-4 h-4" />
              <span className="text-sm">
                {breatheIn ? 'Inspire profundamente...' : 'Expire lentamente...'}
              </span>
            </motion.div>
          </div>

          {/* Timer section - SCROLLABLE */}
          <div className="relative flex-1 flex flex-col items-center px-6 py-4 overflow-y-auto">
            {/* Progress ring */}
            <div className="relative mb-6 flex-shrink-0">
              <svg className="w-48 h-48 transform -rotate-90">
                <circle
                  cx="96"
                  cy="96"
                  r="88"
                  fill="none"
                  stroke="hsl(var(--secondary))"
                  strokeWidth="8"
                />
                <motion.circle
                  cx="96"
                  cy="96"
                  r="88"
                  fill="none"
                  stroke="url(#warmupGradient)"
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={2 * Math.PI * 88}
                  animate={{ 
                    strokeDashoffset: 2 * Math.PI * 88 * (1 - progress / 100)
                  }}
                />
                <defs>
                  <linearGradient id="warmupGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="hsl(25, 95%, 53%)" />
                    <stop offset="100%" stopColor="hsl(0, 84%, 60%)" />
                  </linearGradient>
                </defs>
              </svg>

              {/* Timer display */}
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <motion.span
                  key={timeLeft}
                  initial={{ scale: 1.1 }}
                  animate={{ scale: 1 }}
                  className="text-5xl font-bold tabular-nums"
                >
                  {formatTime(timeLeft)}
                </motion.span>
                <div className="flex items-center gap-1 text-muted-foreground mt-2">
                  <Timer className="w-4 h-4" />
                  <span className="text-sm">
                    {isActive ? 'Aquecendo...' : 'Pronto?'}
                  </span>
                </div>
              </div>
            </div>

            {/* Current exercise highlight */}
            {isActive && (
              <motion.div
                key={currentExerciseIndex}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center mb-4 flex-shrink-0"
              >
                <span className="text-sm text-orange-400 font-medium">
                  Exercício {currentExerciseIndex + 1}/{exercises.length}
                </span>
                <h2 className="text-2xl font-bold mt-1">
                  {exercises[currentExerciseIndex].name}
                </h2>
                <p className="text-muted-foreground text-sm mt-1">
                  {exercises[currentExerciseIndex].description}
                </p>
              </motion.div>
            )}

            {/* Exercise list */}
            <div className="w-full max-w-sm space-y-2">
              {exercises.map((exercise, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className={`flex items-center justify-between p-3 rounded-xl transition-all ${
                    idx === currentExerciseIndex && isActive
                      ? 'bg-orange-500/20 border border-orange-500/30'
                      : idx < currentExerciseIndex
                      ? 'bg-secondary/30 opacity-50'
                      : 'bg-secondary/20'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      idx === currentExerciseIndex && isActive
                        ? 'bg-orange-500 text-white'
                        : idx < currentExerciseIndex
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : 'bg-secondary'
                    }`}>
                      {idx < currentExerciseIndex ? (
                        <motion.div
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                        >
                          ✓
                        </motion.div>
                      ) : (
                        <span className="text-sm font-bold">{idx + 1}</span>
                      )}
                    </div>
                    <span className={`text-sm font-medium ${
                      idx === currentExerciseIndex && isActive ? 'text-foreground' : 'text-muted-foreground'
                    }`}>
                      {exercise.name}
                    </span>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {exercise.duration}
                  </span>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Bottom actions - FIXED com safe-area correto */}
          <div 
            className="relative flex-shrink-0 px-6 pb-4 space-y-3"
            style={{ paddingBottom: 'calc(env(safe-area-inset-bottom, 0px) + 1rem)' }}
          >
            {!isActive ? (
              <>
                <Button
                  onClick={handleStart}
                  className="w-full h-14 text-lg font-bold bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
                >
                  <Play className="w-5 h-5 mr-2" />
                  Iniciar Aquecimento
                </Button>
                <Button
                  variant="outline"
                  onClick={handleComplete}
                  className="w-full min-h-[48px]"
                >
                  <Heart className="w-4 h-4 mr-2" />
                  Já estou aquecido
                </Button>
              </>
            ) : (
              <>
                <Button
                  onClick={handleComplete}
                  className="w-full h-14 text-lg font-bold bg-gradient-to-r from-emerald-500 to-teal-500"
                >
                  <ChevronRight className="w-5 h-5 mr-2" />
                  Começar Treino
                </Button>
                {/* Botão redundante de pular - SEMPRE acessível */}
                <Button
                  variant="ghost"
                  onClick={handleSkip}
                  className="w-full min-h-[44px] text-muted-foreground"
                >
                  <SkipForward className="w-4 h-4 mr-2" />
                  Pular aquecimento
                </Button>
              </>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
