import { motion, AnimatePresence } from 'framer-motion';
import { Progress } from '@/components/ui/progress';
import { RestTimerState } from '@/types/workout.unified';
import { Button } from '@/components/ui/button';
import { Play, Pause, X, Volume2, VolumeX } from 'lucide-react';

interface RestTimerProps {
  timer: RestTimerState;
  onSkip: () => void;
}

export function RestTimer({ timer, onSkip }: RestTimerProps) {
  if (!timer.isActive) return null;

  const progress = ((timer.totalTime - timer.timeLeft) / timer.totalTime) * 100;
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getTimerColor = () => {
    if (timer.timeLeft <= 10) return 'text-red-400';
    if (timer.timeLeft <= 30) return 'text-yellow-400';
    return 'text-accent';
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: 20, opacity: 0, scale: 0.95 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        exit={{ y: 20, opacity: 0, scale: 0.95 }}
        className="glass-intense p-6 rounded-2xl border border-white/20"
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-400 animate-pulse" />
            <span className="text-sm text-txt-3">Descanso</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onSkip}
            className="text-txt-3 hover:text-txt-1"
          >
            <X className="w-4 h-4 mr-1" />
            Pular
          </Button>
        </div>

        <div className="flex items-center justify-center mb-4">
          <div className={`text-6xl font-bold ${getTimerColor()} transition-colors`}>
            {formatTime(timer.timeLeft)}
          </div>
        </div>

        <Progress value={progress} className="h-2 mb-4" />

        {timer.nextExercise && (
          <div className="text-center text-sm text-txt-3 mt-4">
            Próximo: <span className="text-txt-1 font-semibold">{timer.nextExercise}</span>
          </div>
        )}
      </motion.div>
    </AnimatePresence>
  );
}
