import { motion, AnimatePresence } from 'framer-motion';
import { Check, Circle, ChevronDown, ChevronUp, Dumbbell } from 'lucide-react';
import { useState } from 'react';

interface Exercise {
  id: string;
  name: string;
  targetSets: number;
  completedSets: number;
}

interface MobileExerciseListProps {
  exercises: Exercise[];
  currentIndex: number;
  onSelectExercise: (index: number) => void;
}

export function MobileExerciseList({
  exercises,
  currentIndex,
  onSelectExercise,
}: MobileExerciseListProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  const getStatus = (exercise: Exercise, index: number) => {
    if (exercise.completedSets >= exercise.targetSets) return 'completed';
    if (index === currentIndex) return 'current';
    return 'pending';
  };

  return (
    <div className="w-full">
      {/* Toggle button */}
      <motion.button
        whileTap={{ scale: 0.98 }}
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between px-4 py-3 rounded-xl bg-secondary/30 mb-2"
      >
        <div className="flex items-center gap-2">
          <Dumbbell className="w-4 h-4 text-primary" />
          <span className="text-sm font-medium">
            {exercises.filter(e => e.completedSets >= e.targetSets).length} de {exercises.length} exercícios
          </span>
        </div>
        {isExpanded ? (
          <ChevronUp className="w-4 h-4 text-muted-foreground" />
        ) : (
          <ChevronDown className="w-4 h-4 text-muted-foreground" />
        )}
      </motion.button>

      {/* Exercise list */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="space-y-2 py-2">
              {exercises.map((exercise, index) => {
                const status = getStatus(exercise, index);
                
                return (
                  <motion.button
                    key={exercise.id}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => {
                      onSelectExercise(index);
                      setIsExpanded(false);
                    }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${
                      status === 'current'
                        ? 'bg-primary/10 border border-primary/30'
                        : 'bg-secondary/20'
                    }`}
                  >
                    {/* Status icon */}
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                      status === 'completed'
                        ? 'bg-emerald-500/20'
                        : status === 'current'
                        ? 'bg-primary/20'
                        : 'bg-secondary/50'
                    }`}>
                      {status === 'completed' ? (
                        <Check className="w-3.5 h-3.5 text-emerald-500" />
                      ) : status === 'current' ? (
                        <Circle className="w-3 h-3 fill-primary text-primary" />
                      ) : (
                        <Circle className="w-3 h-3 text-muted-foreground" />
                      )}
                    </div>

                    {/* Exercise info */}
                    <div className="flex-1 text-left">
                      <p className={`text-sm font-medium ${
                        status === 'completed' ? 'text-muted-foreground line-through' : ''
                      }`}>
                        {exercise.name}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {exercise.completedSets}/{exercise.targetSets} séries
                      </p>
                    </div>

                    {/* Progress indicator */}
                    <div className="w-12 h-1.5 rounded-full bg-secondary/50 overflow-hidden">
                      <motion.div
                        className="h-full bg-primary rounded-full"
                        initial={{ width: 0 }}
                        animate={{ 
                          width: `${(exercise.completedSets / exercise.targetSets) * 100}%` 
                        }}
                      />
                    </div>
                  </motion.button>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
