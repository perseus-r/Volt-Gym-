import { Mic, MicOff, Volume2, VolumeX } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface VoiceCoachProps {
  isConnected: boolean;
  isLoading: boolean;
  isSpeaking: boolean;
  onToggle: () => void;
}

export function VoiceCoach({ isConnected, isLoading, isSpeaking, onToggle }: VoiceCoachProps) {
  return (
    <Card className="session-glass-intense p-3 border-accent/30">
      <div className="flex items-center gap-3">
        <div className={`p-2 rounded-full ${isSpeaking ? 'bg-accent animate-pulse' : 'bg-accent/20'}`}>
          {isSpeaking ? (
            <Volume2 className="w-4 h-4 text-white" />
          ) : (
            <VolumeX className="w-4 h-4 text-accent" />
          )}
        </div>

        <div className="flex-1">
          <div className="text-sm font-medium text-white">IA Coach</div>
          <div className="text-xs text-muted-foreground">
            {isLoading ? 'Conectando...' : isConnected ? 'Ativo' : 'Desativado'}
          </div>
        </div>

        <Button
          size="sm"
          variant={isConnected ? 'default' : 'outline'}
          onClick={onToggle}
          disabled={isLoading}
          className={isConnected ? 'bg-accent hover:bg-accent/90' : ''}
        >
          {isConnected ? (
            <><Mic className="w-4 h-4 mr-2" /> Desativar</>
          ) : (
            <><MicOff className="w-4 h-4 mr-2" /> Ativar</>
          )}
        </Button>
      </div>
    </Card>
  );
}
