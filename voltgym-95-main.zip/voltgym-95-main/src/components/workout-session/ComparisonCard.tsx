import { TrendingUp, Award, Calendar } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface ComparisonData {
  currentWeight: number;
  currentReps: number;
  lastWeight?: number;
  lastReps?: number;
  lastDate?: string;
  isPR: boolean;
  improvement: number; // percentage
}

interface ComparisonCardProps {
  data: ComparisonData;
}

export function ComparisonCard({ data }: ComparisonCardProps) {
  const { currentWeight, currentReps, lastWeight, lastReps, lastDate, isPR, improvement } = data;

  if (!lastWeight) {
    return (
      <Card className="session-glass-intense p-4 border-accent/20">
        <div className="flex items-center gap-2 text-accent">
          <Award className="w-5 h-5" />
          <span className="text-sm font-medium">Primeiro registro deste exercício! 🎉</span>
        </div>
      </Card>
    );
  }

  return (
    <Card className={`session-glass-intense p-4 ${isPR ? 'border-yellow-500/50 volt-pulse' : 'border-accent/20'}`}>
      <div className="space-y-3">
        {isPR && (
          <div className="flex items-center gap-2 text-yellow-400 animate-fade-in">
            <Award className="w-5 h-5" />
            <span className="text-sm font-bold">RECORDE PESSOAL! 🏆</span>
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          {/* Hoje */}
          <div className="space-y-1">
            <div className="text-xs text-muted-foreground">Hoje</div>
            <div className="text-xl font-bold text-white">
              {currentWeight}kg × {currentReps}
            </div>
          </div>

          {/* Última vez */}
          <div className="space-y-1">
            <div className="text-xs text-muted-foreground flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              {lastDate && format(new Date(lastDate), "dd 'de' MMM", { locale: ptBR })}
            </div>
            <div className="text-xl font-bold text-muted-foreground">
              {lastWeight}kg × {lastReps}
            </div>
          </div>
        </div>

        {/* Progresso */}
        {improvement !== 0 && (
          <div className="flex items-center gap-2 pt-2 border-t border-white/10">
            <TrendingUp className={`w-4 h-4 ${improvement > 0 ? 'text-green-400' : 'text-orange-400'}`} />
            <span className={`text-sm font-medium ${improvement > 0 ? 'text-green-400' : 'text-orange-400'}`}>
              {improvement > 0 ? '+' : ''}{improvement.toFixed(1)}% volume
            </span>
            {improvement > 0 && (
              <Badge variant="outline" className="ml-auto bg-green-500/20 text-green-400 border-green-500/30">
                Evolução 🚀
              </Badge>
            )}
          </div>
        )}
      </div>
    </Card>
  );
}
