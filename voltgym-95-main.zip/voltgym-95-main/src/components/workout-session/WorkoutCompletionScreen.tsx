import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Trophy, Clock, Dumbbell, Flame, TrendingUp, Share2, Home, Star, Zap, Target } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useHapticFeedback } from '@/hooks/useHapticFeedback';
import '@/styles/workout-session.css';

interface WorkoutStats {
  duration: number;
  totalVolume: number;
  completedSets: number;
  averageRpe: number;
  caloriesBurned?: number;
}

interface PersonalRecord {
  exerciseName: string;
  value: string;
}

type Objetivo = 'massa' | 'definicao' | 'forca' | 'saude' | null;

interface WorkoutCompletionScreenProps {
  workoutName: string;
  stats: WorkoutStats;
  personalRecords?: PersonalRecord[];
  onShare?: () => void;
  onClose: () => void;
  objetivo?: Objetivo;
}

export function WorkoutCompletionScreen({
  workoutName,
  stats,
  personalRecords = [],
  onShare,
  onClose,
  objetivo,
}: WorkoutCompletionScreenProps) {
  const { trigger } = useHapticFeedback();
  const [showContent, setShowContent] = useState(false);

  useEffect(() => {
    // Epic celebration confetti - more intense
    const duration = 4000;
    const end = Date.now() + duration;
    const colors = ['#37A0F4', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'];

    // Initial burst
    confetti({
      particleCount: 100,
      spread: 100,
      origin: { y: 0.6 },
      colors,
    });

    const frame = () => {
      confetti({
        particleCount: 4,
        angle: 60,
        spread: 55,
        origin: { x: 0, y: 0.7 },
        colors,
      });
      confetti({
        particleCount: 4,
        angle: 120,
        spread: 55,
        origin: { x: 1, y: 0.7 },
        colors,
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };

    frame();
    trigger('success');

    // Delay showing content for dramatic effect
    setTimeout(() => setShowContent(true), 300);
  }, [trigger]);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    if (mins >= 60) {
      const hours = Math.floor(mins / 60);
      const remainingMins = mins % 60;
      return `${hours}h ${remainingMins}min`;
    }
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleShare = () => {
    trigger('light');
    onShare?.();
  };

  const handleClose = () => {
    trigger('light');
    onClose();
  };

  // Estimate XP gained (example calculation)
  const xpGained = Math.round(stats.completedSets * 10 + stats.totalVolume / 100);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 z-50 bg-background flex flex-col py-safe overflow-y-auto"
    >
      {/* Background glow */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
      </div>

      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: showContent ? 1 : 0, y: showContent ? 0 : -20 }}
        transition={{ delay: 0.2 }}
        className="flex-shrink-0 px-6 pt-8 text-center relative z-10"
      >
        {/* Trophy with epic glow */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', delay: 0.3, stiffness: 200 }}
          className="relative inline-block mb-6"
        >
          <div className="epic-glow">
            <div className="w-28 h-28 rounded-full bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center border border-primary/30">
              <Trophy className="w-14 h-14 text-primary" />
            </div>
          </div>
        </motion.div>

        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: showContent ? 1 : 0, y: showContent ? 0 : 20 }}
          transition={{ delay: 0.4 }}
        >
          <h1 className="text-3xl font-bold mb-2">Treino Completo!</h1>
          <p className="text-muted-foreground">{workoutName}</p>
        </motion.div>

        {/* XP Badge */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: showContent ? 1 : 0 }}
          transition={{ delay: 0.6, type: 'spring' }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-primary/20 to-primary/10 border border-primary/30 mt-4"
        >
          <Zap className="w-4 h-4 text-primary" />
          <span className="text-sm font-bold text-primary">+{xpGained} XP</span>
        </motion.div>
      </motion.div>

      {/* Stats Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: showContent ? 1 : 0, y: showContent ? 0 : 20 }}
        transition={{ delay: 0.5 }}
        className="px-6 py-8 relative z-10"
      >
        <div className="grid grid-cols-2 gap-3 max-w-sm mx-auto">
          <StatCard 
            icon={Clock} 
            label="Duração" 
            value={formatDuration(stats.duration)}
            color="primary"
          />
          <StatCard 
            icon={Dumbbell} 
            label="Volume Total" 
            value={`${stats.totalVolume.toLocaleString()}kg`}
            color="emerald"
          />
          <StatCard 
            icon={Target} 
            label="Séries" 
            value={stats.completedSets.toString()}
            color="orange"
          />
          <StatCard 
            icon={Flame} 
            label="RPE Médio" 
            value={stats.averageRpe.toFixed(1)}
            color="red"
          />
        </div>
      </motion.div>

      {/* Personal Records */}
      {personalRecords.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: showContent ? 1 : 0, y: showContent ? 0 : 20 }}
          transition={{ delay: 0.6 }}
          className="px-6 pb-4 relative z-10"
        >
          <div className="max-w-sm mx-auto">
            <div className="flex items-center gap-2 mb-3">
              <Star className="w-5 h-5 text-yellow-500" />
              <span className="text-sm font-bold uppercase tracking-wider">Novos Recordes!</span>
            </div>
            <div className="space-y-2">
              {personalRecords.map((pr, index) => (
                <motion.div
                  key={index}
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: 0.7 + index * 0.1 }}
                  className="flex items-center justify-between bg-gradient-to-r from-yellow-500/10 to-yellow-500/5 rounded-xl px-4 py-3 border border-yellow-500/20"
                >
                  <span className="text-sm font-medium">{pr.exerciseName}</span>
                  <span className="text-sm font-bold text-yellow-500">{pr.value}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      )}

      {/* Spacer */}
      <div className="flex-1" />

      {/* Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: showContent ? 1 : 0, y: showContent ? 0 : 20 }}
        transition={{ delay: 0.8 }}
        className="px-6 pb-8 space-y-3 relative z-10"
      >
        {onShare && (
          <motion.button
            whileTap={{ scale: 0.98 }}
            onClick={handleShare}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-primary to-primary/80 text-primary-foreground flex items-center justify-center gap-2 font-semibold shadow-lg shadow-primary/25"
          >
            <Share2 className="w-5 h-5" />
            Compartilhar
          </motion.button>
        )}

        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={handleClose}
          className="w-full py-4 rounded-2xl bg-secondary/30 border border-border/20 flex items-center justify-center gap-2 font-semibold active:bg-secondary/50 transition-colors"
        >
          <Home className="w-5 h-5" />
          Voltar ao Início
        </motion.button>
      </motion.div>
    </motion.div>
  );
}

function StatCard({ 
  icon: Icon, 
  label, 
  value, 
  color 
}: { 
  icon: any; 
  label: string; 
  value: string;
  color: 'primary' | 'emerald' | 'orange' | 'red';
}) {
  const colorClasses = {
    primary: 'bg-primary/10 text-primary border-primary/20',
    emerald: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
    orange: 'bg-orange-500/10 text-orange-500 border-orange-500/20',
    red: 'bg-red-500/10 text-red-500 border-red-500/20',
  };

  const iconClasses = {
    primary: 'text-primary',
    emerald: 'text-emerald-500',
    orange: 'text-orange-500',
    red: 'text-red-500',
  };

  return (
    <motion.div 
      whileHover={{ scale: 1.02 }}
      className={`rounded-2xl p-4 text-center border stat-card-hover ${colorClasses[color]}`}
    >
      <Icon className={`w-5 h-5 mx-auto mb-2 ${iconClasses[color]}`} />
      <p className="text-2xl font-bold text-foreground">{value}</p>
      <p className="text-xs text-muted-foreground mt-1">{label}</p>
    </motion.div>
  );
}
