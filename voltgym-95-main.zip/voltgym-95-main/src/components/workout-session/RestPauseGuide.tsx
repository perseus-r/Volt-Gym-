import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Pause, Award } from 'lucide-react';
import { RestPauseConfig } from '@/types/variations.types';

interface RestPauseGuideProps {
  config: RestPauseConfig;
  onComplete: (data: any) => void;
  onCancel: () => void;
}

export function RestPauseGuide({ config, onComplete, onCancel }: RestPauseGuideProps) {
  const [currentMiniSet, setCurrentMiniSet] = useState(0);
  const [completedSets, setCompletedSets] = useState<number[]>([]);
  const [currentReps, setCurrentReps] = useState(0);
  const [isResting, setIsResting] = useState(false);
  const [restTimeLeft, setRestTimeLeft] = useState(0);

  const isLastMiniSet = currentMiniSet === config.miniSets;
  const progressPercent = ((currentMiniSet) / config.miniSets) * 100;

  const handleCompleteMiniSet = () => {
    setCompletedSets([...completedSets, currentReps]);

    if (isLastMiniSet) {
      // Complete entire rest-pause set
      onComplete({
        type: 'rest_pause',
        miniSets: [...completedSets, currentReps],
        totalReps: [...completedSets, currentReps].reduce((sum, r) => sum + r, 0)
      });
    } else {
      // Rest and continue
      setIsResting(true);
      setRestTimeLeft(config.pauseSeconds);
      setCurrentReps(0);

      const interval = setInterval(() => {
        setRestTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            setIsResting(false);
            setCurrentMiniSet(currentMiniSet + 1);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
  };

  if (isResting) {
    return (
      <Card className="session-glass-intense p-6 border-purple-500/50 animate-fade-in">
        <div className="text-center space-y-6">
          <Pause className="w-16 h-16 text-purple-400 mx-auto animate-pulse" />
          
          <div>
            <h3 className="text-lg font-bold text-white mb-2">Rest-Pause</h3>
            <p className="text-sm text-muted-foreground">
              Respire fundo e prepare-se
            </p>
          </div>

          <div className="text-6xl font-bold text-purple-400">
            {restTimeLeft}s
          </div>

          <Progress value={((config.pauseSeconds - restTimeLeft) / config.pauseSeconds) * 100} className="h-3" />
        </div>
      </Card>
    );
  }

  return (
    <Card className="session-glass-intense p-6 border-purple-500/50 animate-fade-in">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-purple-500/20">
              <Pause className="w-6 h-6 text-purple-400" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Rest-Pause</h3>
              <p className="text-sm text-muted-foreground">
                Mini-set {currentMiniSet + 1} de {config.miniSets}
              </p>
            </div>
          </div>
          <Badge variant="outline" className="bg-purple-500/20 text-purple-400 border-purple-500/30">
            Pausa: {config.pauseSeconds}s
          </Badge>
        </div>

        {/* Progress */}
        <div className="space-y-2">
          <Progress value={progressPercent} className="h-3" />
          <div className="flex justify-between text-xs text-muted-foreground">
            {Array.from({ length: config.miniSets }, (_, i) => (
              <span 
                key={i}
                className={i === currentMiniSet ? 'text-purple-400 font-bold' : i < currentMiniSet ? 'text-green-400' : ''}
              >
                Set {i + 1}
              </span>
            ))}
          </div>
        </div>

        {/* Completed Mini-Sets */}
        {completedSets.length > 0 && (
          <div className="space-y-2">
            <div className="text-xs font-semibold text-muted-foreground">Mini-Sets Completados</div>
            {completedSets.map((reps, idx) => (
              <div key={idx} className="flex items-center justify-between p-2 bg-green-500/10 rounded border border-green-500/30">
                <span className="text-sm text-white">Mini-set {idx + 1}</span>
                <span className="text-sm font-bold text-green-400">{reps} reps</span>
              </div>
            ))}
          </div>
        )}

        {/* Current Reps */}
        <div className="text-center space-y-2">
          <div className="text-sm text-muted-foreground">
            {currentMiniSet === 0 ? 'Série inicial' : `Mini-set ${currentMiniSet + 1}`}
          </div>
          <div className="flex items-center justify-center gap-4">
            <Button
              variant="outline"
              onClick={() => setCurrentReps(Math.max(0, currentReps - 1))}
              className="h-16 w-16 text-xl"
            >
              -
            </Button>
            <div className="text-6xl font-bold text-white min-w-[120px]">
              {currentReps}
            </div>
            <Button
              variant="outline"
              onClick={() => setCurrentReps(currentReps + 1)}
              className="h-16 w-16 text-xl"
            >
              +
            </Button>
          </div>
          <div className="text-xs text-muted-foreground">repetições</div>
        </div>

        {/* Total so far */}
        <div className="text-center p-3 bg-bg-2/50 rounded border border-white/10">
          <div className="text-sm text-muted-foreground">Total até agora</div>
          <div className="text-2xl font-bold text-purple-400">
            {[...completedSets, currentReps].reduce((sum, r) => sum + r, 0)} reps
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={onCancel}
            className="flex-1"
          >
            Cancelar
          </Button>
          <Button
            onClick={handleCompleteMiniSet}
            disabled={currentReps === 0}
            className="flex-1 bg-purple-500 hover:bg-purple-600"
          >
            {isLastMiniSet ? (
              <>
                <Award className="w-4 h-4 mr-2" />
                Finalizar
              </>
            ) : (
              'Próximo Mini-Set'
            )}
          </Button>
        </div>
      </div>
    </Card>
  );
}
