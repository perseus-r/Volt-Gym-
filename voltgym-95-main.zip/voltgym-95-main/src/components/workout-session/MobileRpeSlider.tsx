import { motion } from 'framer-motion';
import { useHapticFeedback } from '@/hooks/useHapticFeedback';

interface MobileRpeSliderProps {
  value: number;
  onChange: (value: number) => void;
  compact?: boolean;
}

const RPE_CONFIG = [
  { value: 1, label: 'Fácil', emoji: '😴' },
  { value: 2, label: 'Fácil', emoji: '😌' },
  { value: 3, label: 'Leve', emoji: '🙂' },
  { value: 4, label: 'Moderado', emoji: '😊' },
  { value: 5, label: 'Controlado', emoji: '💪' },
  { value: 6, label: 'Desafiador', emoji: '😤' },
  { value: 7, label: 'Difícil', emoji: '🔥' },
  { value: 8, label: 'Intenso', emoji: '😰' },
  { value: 9, label: 'Máximo', emoji: '🥵' },
  { value: 10, label: 'Limite', emoji: '💀' },
];

export function MobileRpeSlider({ value, onChange, compact = false }: MobileRpeSliderProps) {
  const { trigger } = useHapticFeedback();
  const currentConfig = RPE_CONFIG.find(r => r.value === value) || RPE_CONFIG[6];

  const handleSelect = (rpeValue: number) => {
    trigger('selection');
    onChange(rpeValue);
  };

  const getGradientColor = (rpeValue: number) => {
    if (rpeValue <= 3) return 'from-emerald-500 to-emerald-400';
    if (rpeValue <= 5) return 'from-lime-500 to-yellow-400';
    if (rpeValue <= 7) return 'from-yellow-500 to-orange-500';
    if (rpeValue <= 9) return 'from-orange-500 to-red-500';
    return 'from-red-500 to-red-600';
  };

  // Compact mode
  if (compact) {
    return (
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-[10px] text-muted-foreground uppercase tracking-wider">RPE</span>
          <div className="flex items-center gap-1">
            <span className="text-base">{currentConfig.emoji}</span>
            <span className="text-xs font-medium">{currentConfig.label}</span>
          </div>
        </div>

        {/* Compact slider */}
        <div className="relative h-9 rounded-xl bg-secondary/30 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/10 via-yellow-500/10 to-red-500/10" />
          
          <motion.div
            className={`absolute top-0.5 bottom-0.5 rounded-lg bg-gradient-to-r ${getGradientColor(value)}`}
            initial={false}
            animate={{
              left: `${((value - 1) / 9) * 100}%`,
              width: '10%',
            }}
            transition={{ type: 'spring', stiffness: 400, damping: 30 }}
          />

          <div className="absolute inset-0 flex">
            {RPE_CONFIG.map((rpe) => (
              <button
                key={rpe.value}
                onClick={() => handleSelect(rpe.value)}
                className="flex-1 flex items-center justify-center relative z-10 active:scale-95 transition-transform"
              >
                <span className={`text-xs font-bold tabular-nums ${
                  value === rpe.value ? 'text-white' : 'text-muted-foreground'
                }`}>
                  {rpe.value}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Original full-size layout
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground uppercase tracking-wider">
          RPE (Esforço Percebido)
        </span>
        <motion.div
          key={value}
          initial={{ scale: 1.2 }}
          animate={{ scale: 1 }}
          className="flex items-center gap-2"
        >
          <span className="text-2xl">{currentConfig.emoji}</span>
          <span className="text-sm font-medium text-foreground">
            {currentConfig.label}
          </span>
        </motion.div>
      </div>

      <div className="relative h-14 rounded-2xl bg-secondary/30 overflow-hidden">
        <div className="absolute inset-0 flex">
          <div className="flex-1 bg-gradient-to-r from-emerald-500/20 via-yellow-500/20 to-red-500/20" />
        </div>

        <motion.div
          className={`absolute top-1 bottom-1 rounded-xl bg-gradient-to-r ${getGradientColor(value)} shadow-lg`}
          initial={false}
          animate={{
            left: `${((value - 1) / 9) * 100}%`,
            width: '10%',
          }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
        />

        <div className="absolute inset-0 flex">
          {RPE_CONFIG.map((rpe) => (
            <motion.button
              key={rpe.value}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleSelect(rpe.value)}
              className="flex-1 flex items-center justify-center relative z-10"
            >
              <motion.span
                className={`text-sm font-bold tabular-nums transition-all ${
                  value === rpe.value ? 'text-white scale-110' : 'text-muted-foreground'
                }`}
              >
                {rpe.value}
              </motion.span>
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  );
}
