import { motion } from 'framer-motion';
import { X, ChevronLeft } from 'lucide-react';
import { useHapticFeedback } from '@/hooks/useHapticFeedback';

interface WizardProgressHeaderProps {
  title?: string;
  currentStep: number;
  totalSteps: number;
  onBack?: () => void;
  onClose?: () => void;
  showBackButton?: boolean;
}

export function WizardProgressHeader({
  title,
  currentStep,
  totalSteps,
  onBack,
  onClose,
  showBackButton = true,
}: WizardProgressHeaderProps) {
  const { trigger } = useHapticFeedback();

  const handleBack = () => {
    trigger('light');
    onBack?.();
  };

  const handleClose = () => {
    trigger('light');
    onClose?.();
  };

  return (
    <header 
      className="relative flex-shrink-0 px-3 pb-3 z-10"
      style={{ paddingTop: 'calc(env(safe-area-inset-top, 0px) + 0.75rem)' }}
    >
      <div className="flex items-center justify-between">
        {/* Left button */}
        {showBackButton && onBack ? (
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={handleBack}
            className="w-9 h-9 rounded-full bg-secondary/50 flex items-center justify-center active:bg-secondary/70 transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </motion.button>
        ) : onClose ? (
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={handleClose}
            className="w-9 h-9 rounded-full bg-secondary/50 flex items-center justify-center active:bg-secondary/70 transition-colors"
          >
            <X className="w-4 h-4" />
          </motion.button>
        ) : (
          <div className="w-9" />
        )}

        {/* Title */}
        {title && (
          <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            {title}
          </h2>
        )}

        {/* Progress dots */}
        <div className="flex items-center gap-1">
          {Array.from({ length: totalSteps }).map((_, i) => (
            <motion.div
              key={i}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: i * 0.05 }}
              className={`rounded-full transition-all ${
                i < currentStep
                  ? 'w-1.5 h-1.5 bg-primary'
                  : i === currentStep
                  ? 'w-2.5 h-2.5 bg-primary/70'
                  : 'w-1.5 h-1.5 bg-secondary/50'
              }`}
            />
          ))}
        </div>
      </div>
    </header>
  );
}
