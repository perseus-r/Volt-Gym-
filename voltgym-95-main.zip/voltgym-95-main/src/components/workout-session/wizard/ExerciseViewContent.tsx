import { motion } from 'framer-motion';
import { Dumbbell, ChevronLeft, ChevronRight } from 'lucide-react';
import { ExerciseVideoHero } from '../ExerciseVideoHero';
import { Button } from '@/components/ui/button';

interface ExerciseViewContentProps {
  exerciseName: string;
  currentSet: number;
  totalSets: number;
  targetReps: number;
  targetWeight?: number;
  videoUrl: string | null;
  thumbnailUrl: string | null;
  exerciseIndex: number;
  totalExercises: number;
  onExpandVideo?: () => void;
  onNextExercise?: () => void;
  onPreviousExercise?: () => void;
  onSkipExercise?: () => void;
  canGoNext?: boolean;
  canGoPrevious?: boolean;
}

export function ExerciseViewContent({
  exerciseName,
  currentSet,
  totalSets,
  targetReps,
  targetWeight,
  videoUrl,
  thumbnailUrl,
  exerciseIndex,
  totalExercises,
  onExpandVideo,
  onNextExercise,
  onPreviousExercise,
  onSkipExercise,
  canGoNext,
  canGoPrevious,
}: ExerciseViewContentProps) {
  return (
    <div className="flex flex-col h-full px-3">
      {/* Video Hero - 55% of screen */}
      <div className="flex-1 max-h-[55vh]">
        <ExerciseVideoHero
          videoUrl={videoUrl}
          thumbnailUrl={thumbnailUrl}
          exerciseName={exerciseName}
          onExpand={onExpandVideo}
          autoPlay={true}
          loop={true}
        />
      </div>

      {/* Exercise info */}
      <div className="py-4 text-center">
        {/* Exercise counter */}
        <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">
          Exercício {exerciseIndex + 1} de {totalExercises}
        </p>

        {/* Exercise name */}
        <div className="flex items-center justify-center gap-2 mb-2">
          <div className="w-9 h-9 rounded-lg bg-primary/15 flex items-center justify-center">
            <Dumbbell className="w-4 h-4 text-primary" />
          </div>
          <h1 className="text-xl font-bold">{exerciseName}</h1>
        </div>

        {/* Set indicator */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-secondary/30 border border-border/30 mb-3">
          <span className="text-xs text-muted-foreground">Série</span>
          <span className="text-base font-bold text-primary">{currentSet}</span>
          <span className="text-xs text-muted-foreground">de {totalSets}</span>
        </div>

        {/* Target info */}
        <p className="text-sm text-muted-foreground">
          Meta: <span className="font-semibold text-foreground">{targetReps} reps</span>
          {targetWeight && (
            <>
              <span className="mx-1">@</span>
              <span className="font-semibold text-primary">{targetWeight}kg</span>
            </>
          )}
        </p>

        {/* Set pills */}
        <div className="flex justify-center gap-1.5 mt-3">
          {Array.from({ length: totalSets }).map((_, i) => (
            <motion.div
              key={i}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: i * 0.05 }}
              className={`h-1.5 rounded-full transition-all ${
                i < currentSet - 1
                  ? 'w-6 bg-primary'
                  : i === currentSet - 1
                  ? 'w-6 bg-primary/50'
                  : 'w-3 bg-secondary/50'
              }`}
            />
          ))}
        </div>

        {/* Navigation buttons */}
        {(canGoPrevious || canGoNext) && (
          <div className="flex justify-center gap-3 mt-4">
            {canGoPrevious && onPreviousExercise && (
              <Button
                variant="outline"
                size="sm"
                onClick={onPreviousExercise}
                className="gap-1"
              >
                <ChevronLeft className="w-4 h-4" />
                Anterior
              </Button>
            )}
            
            {canGoNext && onSkipExercise && (
              <Button
                variant="outline"
                size="sm"
                onClick={onSkipExercise}
                className="gap-1"
              >
                Pular
                <ChevronRight className="w-4 h-4" />
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
