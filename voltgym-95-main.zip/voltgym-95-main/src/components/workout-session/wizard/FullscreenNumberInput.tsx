import { motion } from 'framer-motion';
import { Minus, Plus } from 'lucide-react';
import { useHapticFeedback } from '@/hooks/useHapticFeedback';

interface FullscreenNumberInputProps {
  value: number;
  onChange: (value: number) => void;
  unit?: string;
  step?: number;
  min?: number;
  max?: number;
  presets?: number[];
  contextInfo?: string;
}

export function FullscreenNumberInput({
  value,
  onChange,
  unit = '',
  step = 1,
  min = 0,
  max = 999,
  presets = [],
  contextInfo,
}: FullscreenNumberInputProps) {
  const { trigger } = useHapticFeedback();

  const handleIncrement = () => {
    if (value < max) {
      trigger('light');
      onChange(Math.min(value + step, max));
    }
  };

  const handleDecrement = () => {
    if (value > min) {
      trigger('light');
      onChange(Math.max(value - step, min));
    }
  };

  const handlePreset = (preset: number) => {
    trigger('selection');
    onChange(preset);
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center px-4">
      {/* Giant number display */}
      <div className="relative mb-6">
        {/* Glow effect behind number */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-32 h-32 rounded-full bg-primary/10 blur-3xl" />
        </div>
        
        <motion.div
          key={value}
          initial={{ scale: 1.1, opacity: 0.8 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 400, damping: 25 }}
          className="relative text-center"
        >
          <span className="text-6xl font-bold tabular-nums text-foreground">
            {value}
          </span>
          {unit && (
            <span className="text-xl text-muted-foreground font-medium ml-1">
              {unit}
            </span>
          )}
        </motion.div>
      </div>

      {/* +/- Buttons */}
      <div className="flex items-center justify-center gap-12 mb-6">
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={handleDecrement}
          disabled={value <= min}
          className="w-16 h-16 rounded-xl bg-secondary/40 border border-border/30 flex items-center justify-center disabled:opacity-30 active:bg-secondary/60 transition-colors"
        >
          <Minus className="w-6 h-6" />
        </motion.button>

        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={handleIncrement}
          disabled={value >= max}
          className="w-16 h-16 rounded-xl bg-secondary/40 border border-border/30 flex items-center justify-center disabled:opacity-30 active:bg-secondary/60 transition-colors"
        >
          <Plus className="w-6 h-6" />
        </motion.button>
      </div>

      {/* Presets */}
      {presets.length > 0 && (
        <div className="flex justify-center gap-2 flex-wrap mb-4">
          {presets.map((preset) => (
            <motion.button
              key={preset}
              whileTap={{ scale: 0.95 }}
              onClick={() => handlePreset(preset)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                value === preset
                  ? 'bg-primary text-primary-foreground shadow-md shadow-primary/25'
                  : 'bg-secondary/30 text-muted-foreground border border-border/30 active:bg-secondary/50'
              }`}
            >
              {preset}{unit}
            </motion.button>
          ))}
        </div>
      )}

      {/* Context info */}
      {contextInfo && (
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-xs text-muted-foreground text-center"
        >
          {contextInfo}
        </motion.p>
      )}
    </div>
  );
}
