import { motion } from 'framer-motion';
import { ChevronRight } from 'lucide-react';
import { WizardProgressHeader } from './WizardProgressHeader';
import { WizardFooter } from './WizardFooter';
import { FullscreenNumberInput } from './FullscreenNumberInput';

interface RepsInputPageProps {
  reps: number;
  onChange: (reps: number) => void;
  targetReps?: number;
  onNext: () => void;
  onBack: () => void;
}

export function RepsInputPage({
  reps,
  onChange,
  targetReps,
  onNext,
  onBack,
}: RepsInputPageProps) {
  const presets = [6, 8, 10, 12, 15, 20];

  const contextInfo = targetReps
    ? `Meta: ${targetReps} repetições`
    : undefined;

  return (
    <motion.div
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -100 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      className="flex-1 flex flex-col bg-background min-h-0"
    >
      <WizardProgressHeader
        title="REPETIÇÕES"
        currentStep={2}
        totalSteps={4}
        onBack={onBack}
        showBackButton={true}
      />

      <FullscreenNumberInput
        value={reps}
        onChange={onChange}
        step={1}
        min={1}
        max={100}
        presets={presets}
        contextInfo={contextInfo}
      />

      <WizardFooter
        label="Próximo"
        onClick={onNext}
        icon={<ChevronRight className="w-5 h-5" />}
      />
    </motion.div>
  );
}
