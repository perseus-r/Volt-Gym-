import { motion } from 'framer-motion';
import { Dumbbell, Play } from 'lucide-react';
import { WizardProgressHeader } from './WizardProgressHeader';
import { WizardFooter } from './WizardFooter';
import { ExerciseVideoHero } from '../ExerciseVideoHero';

interface ExerciseViewPageProps {
  exerciseName: string;
  currentSet: number;
  totalSets: number;
  targetReps: number;
  targetWeight?: number;
  videoUrl: string | null;
  thumbnailUrl: string | null;
  exerciseIndex: number;
  totalExercises: number;
  onStart: () => void;
  onClose: () => void;
  onExpandVideo?: () => void;
}

export function ExerciseViewPage({
  exerciseName,
  currentSet,
  totalSets,
  targetReps,
  targetWeight,
  videoUrl,
  thumbnailUrl,
  exerciseIndex,
  totalExercises,
  onStart,
  onClose,
  onExpandVideo,
}: ExerciseViewPageProps) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -100 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      className="flex-1 flex flex-col bg-background min-h-0"
    >
      <WizardProgressHeader
        currentStep={0}
        totalSteps={4}
        onClose={onClose}
        showBackButton={false}
      />

      {/* Video Hero - 60% of screen */}
      <div className="flex-1 px-4 flex flex-col">
        <div className="flex-1 max-h-[60vh]">
          <ExerciseVideoHero
            videoUrl={videoUrl}
            thumbnailUrl={thumbnailUrl}
            exerciseName={exerciseName}
            onExpand={onExpandVideo}
            autoPlay={true}
            loop={true}
          />
        </div>

        {/* Exercise info */}
        <div className="py-6 text-center">
          {/* Exercise counter */}
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-2">
            Exercício {exerciseIndex + 1} de {totalExercises}
          </p>

          {/* Exercise name */}
          <div className="flex items-center justify-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-primary/15 flex items-center justify-center">
              <Dumbbell className="w-5 h-5 text-primary" />
            </div>
            <h1 className="text-2xl font-bold">{exerciseName}</h1>
          </div>

          {/* Set indicator */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/30 border border-border/30 mb-4">
            <span className="text-sm text-muted-foreground">Série</span>
            <span className="text-lg font-bold text-primary">{currentSet}</span>
            <span className="text-sm text-muted-foreground">de {totalSets}</span>
          </div>

          {/* Target info */}
          <p className="text-muted-foreground">
            Meta: <span className="font-semibold text-foreground">{targetReps} reps</span>
            {targetWeight && (
              <>
                <span className="mx-2">@</span>
                <span className="font-semibold text-primary">{targetWeight}kg</span>
              </>
            )}
          </p>

          {/* Set pills */}
          <div className="flex justify-center gap-2 mt-4">
            {Array.from({ length: totalSets }).map((_, i) => (
              <motion.div
                key={i}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: i * 0.05 }}
                className={`h-2 rounded-full transition-all ${
                  i < currentSet - 1
                    ? 'w-8 bg-primary'
                    : i === currentSet - 1
                    ? 'w-8 bg-primary/50'
                    : 'w-4 bg-secondary/50'
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      <WizardFooter
        label="Iniciar Série"
        onClick={onStart}
        icon={<Play className="w-5 h-5" />}
      />
    </motion.div>
  );
}
