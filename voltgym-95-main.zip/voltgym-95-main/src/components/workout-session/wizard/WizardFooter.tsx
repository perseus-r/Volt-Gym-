import { motion, AnimatePresence } from 'framer-motion';
import { createPortal } from 'react-dom';
import { useState, useCallback, useEffect } from 'react';
import { useHapticFeedback } from '@/hooks/useHapticFeedback';
import { cn } from '@/lib/utils';
import { Check } from 'lucide-react';

interface WizardFooterProps {
  label: string;
  onClick: () => void;
  disabled?: boolean;
  variant?: 'primary' | 'success';
  icon?: React.ReactNode;
  loading?: boolean;
}

interface Ripple {
  id: number;
  x: number;
  y: number;
}

export function WizardFooter({
  label,
  onClick,
  disabled = false,
  variant = 'primary',
  icon,
  loading = false,
}: WizardFooterProps) {
  const { trigger } = useHapticFeedback();
  const [ripples, setRipples] = useState<Ripple[]>([]);
  const [isPressed, setIsPressed] = useState(false);

  const handleClick = useCallback((e: React.MouseEvent<HTMLButtonElement>) => {
    if (disabled || loading) return;

    // Create ripple at click position
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const id = Date.now();
    
    setRipples(prev => [...prev, { id, x, y }]);
    setTimeout(() => {
      setRipples(prev => prev.filter(r => r.id !== id));
    }, 600);

    trigger('success');
    onClick();
  }, [disabled, loading, onClick, trigger]);

  // Animate icon on variant change
  const [prevVariant, setPrevVariant] = useState(variant);
  const [iconKey, setIconKey] = useState(0);
  
  useEffect(() => {
    if (variant !== prevVariant) {
      setIconKey(k => k + 1);
      setPrevVariant(variant);
    }
  }, [variant, prevVariant]);

  const footerContent = (
    <motion.footer 
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ 
        type: 'spring', 
        stiffness: 300, 
        damping: 25, 
        delay: 0.15 
      }}
      className={cn(
        "fixed left-0 right-0 px-4 pt-3 z-[1000]",
        "pointer-events-auto"
      )}
      style={{ 
        bottom: 'calc(env(safe-area-inset-bottom, 0px) + var(--vv-bottom, 0px) + var(--ios-toolbar-bottom, 0px))',
        paddingBottom: '0.75rem'
      }}
    >
      {/* Backdrop blur layer */}
      <div className="absolute inset-0 bg-background/80 backdrop-blur-xl -z-10" />
      
      {/* Top separator line */}
      <motion.div 
        className="absolute top-0 left-4 right-4 h-px"
        style={{
          background: 'linear-gradient(90deg, transparent, hsl(var(--primary) / 0.3), transparent)'
        }}
        animate={{ opacity: [0.3, 0.6, 0.3] }}
        transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
      />

      <motion.button
        onMouseDown={() => setIsPressed(true)}
        onMouseUp={() => setIsPressed(false)}
        onMouseLeave={() => setIsPressed(false)}
        onTouchStart={() => setIsPressed(true)}
        onTouchEnd={() => setIsPressed(false)}
        whileTap={{ scale: disabled ? 1 : 0.98 }}
        onClick={handleClick}
        disabled={disabled || loading}
        className={cn(
          "relative w-full h-12 rounded-xl font-semibold text-base",
          "flex items-center justify-center gap-2",
          "overflow-hidden transition-colors",
          disabled && "opacity-50 cursor-not-allowed"
        )}
      >
        {/* Animated gradient background */}
        <motion.div
          className="absolute inset-0 -z-10"
          animate={{
            background: variant === 'success'
              ? 'linear-gradient(135deg, hsl(160 84% 39%), hsl(168 76% 42%), hsl(160 84% 39%))'
              : 'linear-gradient(135deg, hsl(var(--primary)), hsl(var(--primary) / 0.8), hsl(var(--primary)))',
            backgroundSize: '200% 200%',
            backgroundPosition: ['0% 50%', '100% 50%', '0% 50%']
          }}
          transition={{ 
            background: { duration: 0.4 },
            backgroundPosition: { duration: 3, repeat: Infinity, ease: 'linear' }
          }}
        />

        {/* Pulsating glow shadow */}
        <motion.div
          className="absolute inset-0 rounded-2xl -z-20"
          animate={{
            boxShadow: variant === 'success'
              ? [
                  '0 4px 20px -4px rgba(16, 185, 129, 0.4)',
                  '0 8px 30px -4px rgba(16, 185, 129, 0.6)',
                  '0 4px 20px -4px rgba(16, 185, 129, 0.4)'
                ]
              : [
                  '0 4px 20px -4px hsl(var(--primary) / 0.3)',
                  '0 8px 30px -4px hsl(var(--primary) / 0.5)',
                  '0 4px 20px -4px hsl(var(--primary) / 0.3)'
                ]
          }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        />

        {/* Shimmer effect */}
        <motion.div
          className="absolute inset-0 -z-5"
          style={{
            background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.2) 50%, transparent 100%)',
            backgroundSize: '200% 100%',
          }}
          animate={{
            backgroundPosition: ['-100% 0%', '200% 0%']
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            repeatDelay: 3,
            ease: 'easeInOut'
          }}
        />

        {/* Ripple effects */}
        <AnimatePresence>
          {ripples.map(ripple => (
            <motion.span
              key={ripple.id}
              initial={{ scale: 0, opacity: 0.5 }}
              animate={{ scale: 4, opacity: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.6, ease: 'easeOut' }}
              className="absolute rounded-full bg-white/30 pointer-events-none"
              style={{
                left: ripple.x - 50,
                top: ripple.y - 50,
                width: 100,
                height: 100,
              }}
            />
          ))}
        </AnimatePresence>

        {/* Loading spinner */}
        {loading && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1, rotate: 360 }}
            transition={{ rotate: { duration: 1, repeat: Infinity, ease: 'linear' } }}
            className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full"
          />
        )}

        {/* Animated icon */}
        {!loading && icon && (
          <AnimatePresence mode="wait">
            <motion.span
              key={iconKey}
              initial={{ scale: 0, rotate: -180, opacity: 0 }}
              animate={{ scale: 1, rotate: 0, opacity: 1 }}
              exit={{ scale: 0, rotate: 180, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 500, damping: 25 }}
              className="flex items-center justify-center"
            >
              {variant === 'success' ? (
                <motion.div
                  initial={{ pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                >
                  <Check className="w-5 h-5" strokeWidth={3} />
                </motion.div>
              ) : (
                <motion.div
                  animate={{ x: [0, 3, 0] }}
                  transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
                >
                  {icon}
                </motion.div>
              )}
            </motion.span>
          </AnimatePresence>
        )}

        {/* Label with press effect */}
        <motion.span
          className="text-primary-foreground relative z-10"
          animate={{ 
            y: isPressed ? 1 : 0,
            opacity: loading ? 0.7 : 1 
          }}
          transition={{ duration: 0.1 }}
        >
          {label}
        </motion.span>
      </motion.button>
    </motion.footer>
  );

  // Render via portal to document.body to escape any containing blocks
  if (typeof document !== 'undefined') {
    return createPortal(footerContent, document.body);
  }

  return footerContent;
}
