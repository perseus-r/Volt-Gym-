import { motion } from 'framer-motion';
import { ChevronRight } from 'lucide-react';
import { WizardProgressHeader } from './WizardProgressHeader';
import { WizardFooter } from './WizardFooter';
import { FullscreenNumberInput } from './FullscreenNumberInput';
import { useMemo } from 'react';

interface WeightInputPageProps {
  weight: number;
  onChange: (weight: number) => void;
  lastSetInfo?: { weight: number; reps: number };
  onNext: () => void;
  onBack: () => void;
}

export function WeightInputPage({
  weight,
  onChange,
  lastSetInfo,
  onNext,
  onBack,
}: WeightInputPageProps) {
  const presets = useMemo(() => {
    const base = Math.round(weight / 5) * 5;
    return [base - 10, base - 5, base, base + 5, base + 10].filter(w => w > 0);
  }, [weight]);

  const contextInfo = lastSetInfo
    ? `Última série: ${lastSetInfo.weight}kg × ${lastSetInfo.reps} reps`
    : undefined;

  return (
    <motion.div
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -100 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      className="flex-1 flex flex-col bg-background min-h-0"
    >
      <WizardProgressHeader
        title="PESO"
        currentStep={1}
        totalSteps={4}
        onBack={onBack}
        showBackButton={true}
      />

      <FullscreenNumberInput
        value={weight}
        onChange={onChange}
        unit="kg"
        step={2.5}
        min={0}
        max={500}
        presets={presets}
        contextInfo={contextInfo}
      />

      <WizardFooter
        label="Próximo"
        onClick={onNext}
        icon={<ChevronRight className="w-5 h-5" />}
      />
    </motion.div>
  );
}
