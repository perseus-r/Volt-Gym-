import { useState, useCallback } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Play, ChevronRight, Check } from 'lucide-react';
import { ExerciseViewContent } from './ExerciseViewContent';
import { WeightInputContent } from './WeightInputContent';
import { RepsInputContent } from './RepsInputContent';
import { RpeInputContent } from './RpeInputContent';
import { WizardProgressHeader } from './WizardProgressHeader';
import { WizardFooter } from './WizardFooter';
import { useHapticFeedback } from '@/hooks/useHapticFeedback';

type WizardStep = 'view' | 'weight' | 'reps' | 'rpe';

interface Exercise {
  id: string;
  name: string;
  targetSets: number;
  targetReps: number;
  targetWeight?: number;
  restSeconds: number;
}

interface SetData {
  weight: number;
  reps: number;
  rpe: number;
}

interface WorkoutSessionWizardProps {
  exercise: Exercise;
  currentSet: number;
  exerciseIndex: number;
  totalExercises: number;
  videoUrl: string | null;
  thumbnailUrl: string | null;
  lastSetInfo?: { weight: number; reps: number; rpe: number };
  onSetComplete: (data: SetData) => void;
  onClose: () => void;
  onExpandVideo?: () => void;
  defaultWeight?: number;
  defaultReps?: number;
  onNextExercise?: () => void;
  onPreviousExercise?: () => void;
  onSkipExercise?: () => void;
  canGoNext?: boolean;
  canGoPrevious?: boolean;
}

const STEP_CONFIG = {
  view: { index: 0, title: undefined, showBack: false },
  weight: { index: 1, title: 'PESO', showBack: true },
  reps: { index: 2, title: 'REPETIÇÕES', showBack: true },
  rpe: { index: 3, title: 'INTENSIDADE', showBack: true },
};

export function WorkoutSessionWizard({
  exercise,
  currentSet,
  exerciseIndex,
  totalExercises,
  videoUrl,
  thumbnailUrl,
  lastSetInfo,
  onSetComplete,
  onClose,
  onExpandVideo,
  defaultWeight,
  defaultReps,
  onNextExercise,
  onPreviousExercise,
  onSkipExercise,
  canGoNext,
  canGoPrevious,
}: WorkoutSessionWizardProps) {
  const { trigger } = useHapticFeedback();
  
  const [step, setStep] = useState<WizardStep>('view');
  const [weight, setWeight] = useState(defaultWeight || exercise.targetWeight || 20);
  const [reps, setReps] = useState(defaultReps || exercise.targetReps || 12);
  const [rpe, setRpe] = useState(7);

  const exerciseKey = `${exercise.id}-${currentSet}`;
  const stepConfig = STEP_CONFIG[step];

  const goToStep = useCallback((nextStep: WizardStep) => {
    trigger('light');
    setStep(nextStep);
  }, [trigger]);

  const handleBack = useCallback(() => {
    const backMap: Record<WizardStep, WizardStep> = {
      view: 'view',
      weight: 'view',
      reps: 'weight',
      rpe: 'reps',
    };
    goToStep(backMap[step]);
  }, [step, goToStep]);

  const handleComplete = useCallback(() => {
    trigger('success');
    onSetComplete({ weight, reps, rpe });
    setStep('view');
  }, [weight, reps, rpe, onSetComplete, trigger]);

  // Footer config based on step
  const getFooterConfig = () => {
    switch (step) {
      case 'view':
        return {
          label: 'Iniciar Série',
          onClick: () => goToStep('weight'),
          icon: <Play className="w-5 h-5" />,
          variant: 'primary' as const,
        };
      case 'weight':
        return {
          label: 'Próximo',
          onClick: () => goToStep('reps'),
          icon: <ChevronRight className="w-5 h-5" />,
          variant: 'primary' as const,
        };
      case 'reps':
        return {
          label: 'Próximo',
          onClick: () => goToStep('rpe'),
          icon: <ChevronRight className="w-5 h-5" />,
          variant: 'primary' as const,
        };
      case 'rpe':
        return {
          label: 'Completar Série',
          onClick: handleComplete,
          icon: <Check className="w-5 h-5" />,
          variant: 'success' as const,
        };
    }
  };

  const footerConfig = getFooterConfig();

  return (
    <div 
      className="fixed inset-0 flex flex-col z-[110] bg-background"
      style={{ 
        paddingTop: 'env(safe-area-inset-top, 0px)'
      }}
    >
      {/* Fixed Header */}
      <WizardProgressHeader
        title={stepConfig.title}
        currentStep={stepConfig.index}
        totalSteps={4}
        onClose={step === 'view' ? onClose : undefined}
        onBack={stepConfig.showBack ? handleBack : undefined}
        showBackButton={stepConfig.showBack}
      />

      {/* Scrollable Content Area - with bottom padding to clear fixed footer */}
      <div 
        className="flex-1 min-h-0 overflow-auto overscroll-contain"
        style={{
          paddingBottom: 'calc(88px + env(safe-area-inset-bottom, 0px))'
        }}
      >
        <AnimatePresence mode="wait">
          {step === 'view' && (
            <motion.div
              key={`view-${exerciseKey}`}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="h-full"
            >
              <ExerciseViewContent
                exerciseName={exercise.name}
                currentSet={currentSet}
                totalSets={exercise.targetSets}
                targetReps={exercise.targetReps}
                targetWeight={exercise.targetWeight}
                videoUrl={videoUrl}
                thumbnailUrl={thumbnailUrl}
                exerciseIndex={exerciseIndex}
                totalExercises={totalExercises}
                onExpandVideo={onExpandVideo}
                onNextExercise={onNextExercise}
                onPreviousExercise={onPreviousExercise}
                onSkipExercise={onSkipExercise}
                canGoNext={canGoNext}
                canGoPrevious={canGoPrevious}
              />
            </motion.div>
          )}

          {step === 'weight' && (
            <motion.div
              key={`weight-${exerciseKey}`}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="h-full"
            >
              <WeightInputContent
                weight={weight}
                onChange={setWeight}
                lastSetInfo={lastSetInfo}
              />
            </motion.div>
          )}

          {step === 'reps' && (
            <motion.div
              key={`reps-${exerciseKey}`}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="h-full"
            >
              <RepsInputContent
                reps={reps}
                onChange={setReps}
                targetReps={exercise.targetReps}
              />
            </motion.div>
          )}

          {step === 'rpe' && (
            <motion.div
              key={`rpe-${exerciseKey}`}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="h-full"
            >
              <RpeInputContent
                rpe={rpe}
                onChange={setRpe}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Fixed Footer - positioned independently via CSS */}
      <WizardFooter
        label={footerConfig.label}
        onClick={footerConfig.onClick}
        icon={footerConfig.icon}
        variant={footerConfig.variant}
      />
    </div>
  );
}
