import { useMemo } from 'react';
import { FullscreenNumberInput } from './FullscreenNumberInput';

interface WeightInputContentProps {
  weight: number;
  onChange: (weight: number) => void;
  lastSetInfo?: { weight: number; reps: number };
}

export function WeightInputContent({
  weight,
  onChange,
  lastSetInfo,
}: WeightInputContentProps) {
  const presets = useMemo(() => {
    const base = Math.round(weight / 5) * 5;
    return [base - 10, base - 5, base, base + 5, base + 10].filter(w => w > 0);
  }, [weight]);

  const contextInfo = lastSetInfo
    ? `Última série: ${lastSetInfo.weight}kg × ${lastSetInfo.reps} reps`
    : undefined;

  return (
    <div className="flex-1 flex flex-col h-full">
      <FullscreenNumberInput
        value={weight}
        onChange={onChange}
        unit="kg"
        step={2.5}
        min={0}
        max={500}
        presets={presets}
        contextInfo={contextInfo}
      />
    </div>
  );
}
