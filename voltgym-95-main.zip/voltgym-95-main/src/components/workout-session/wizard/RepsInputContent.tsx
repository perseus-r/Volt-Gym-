import { FullscreenNumberInput } from './FullscreenNumberInput';

interface RepsInputContentProps {
  reps: number;
  onChange: (reps: number) => void;
  targetReps?: number;
}

export function RepsInputContent({
  reps,
  onChange,
  targetReps,
}: RepsInputContentProps) {
  const presets = [6, 8, 10, 12, 15, 20];

  const contextInfo = targetReps
    ? `Meta: ${targetReps} repetições`
    : undefined;

  return (
    <div className="flex-1 flex flex-col h-full">
      <FullscreenNumberInput
        value={reps}
        onChange={onChange}
        step={1}
        min={1}
        max={100}
        presets={presets}
        contextInfo={contextInfo}
      />
    </div>
  );
}
