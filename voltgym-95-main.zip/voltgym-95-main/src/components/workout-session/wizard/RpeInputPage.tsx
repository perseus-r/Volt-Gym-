import { motion } from 'framer-motion';
import { Check } from 'lucide-react';
import { WizardProgressHeader } from './WizardProgressHeader';
import { WizardFooter } from './WizardFooter';
import { useHapticFeedback } from '@/hooks/useHapticFeedback';

interface RpeInputPageProps {
  rpe: number;
  onChange: (rpe: number) => void;
  onComplete: () => void;
  onBack: () => void;
}

const RPE_CONFIG = [
  { value: 1, label: 'Muito Fácil', emoji: '😴', description: 'Quase nenhum esforço' },
  { value: 2, label: 'Fácil', emoji: '😌', description: 'Esforço mínimo' },
  { value: 3, label: 'Leve', emoji: '🙂', description: 'Peso leve' },
  { value: 4, label: 'Moderado', emoji: '😊', description: 'Peso confortável' },
  { value: 5, label: 'Controlado', emoji: '💪', description: 'Começando a sentir' },
  { value: 6, label: 'Desafiador', emoji: '😤', description: '+4 reps restantes' },
  { value: 7, label: 'Difícil', emoji: '🔥', description: '+3 reps restantes' },
  { value: 8, label: 'Intenso', emoji: '😰', description: '+2 reps restantes' },
  { value: 9, label: 'Máximo', emoji: '🥵', description: '+1 rep restante' },
  { value: 10, label: 'Falha', emoji: '💀', description: 'Não conseguiria mais' },
];

export function RpeInputPage({
  rpe,
  onChange,
  onComplete,
  onBack,
}: RpeInputPageProps) {
  const { trigger } = useHapticFeedback();
  const currentConfig = RPE_CONFIG.find(r => r.value === rpe) || RPE_CONFIG[6];

  const handleSelect = (value: number) => {
    trigger('selection');
    onChange(value);
  };

  const getGradientColor = (rpeValue: number) => {
    if (rpeValue <= 3) return 'from-emerald-500 to-emerald-400';
    if (rpeValue <= 5) return 'from-lime-500 to-yellow-400';
    if (rpeValue <= 7) return 'from-yellow-500 to-orange-500';
    if (rpeValue <= 9) return 'from-orange-500 to-red-500';
    return 'from-red-500 to-red-600';
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -100 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      className="flex-1 flex flex-col bg-background min-h-0"
    >
      <WizardProgressHeader
        title="INTENSIDADE"
        currentStep={3}
        totalSteps={4}
        onBack={onBack}
        showBackButton={true}
      />

      <div className="flex-1 flex flex-col items-center justify-center px-6">
        {/* Current RPE display */}
        <div className="text-center mb-8">
          <motion.div
            key={rpe}
            initial={{ scale: 1.2 }}
            animate={{ scale: 1 }}
            className="text-7xl mb-2"
          >
            {currentConfig.emoji}
          </motion.div>
          
          <motion.div
            key={`${rpe}-value`}
            initial={{ scale: 1.1, opacity: 0.8 }}
            animate={{ scale: 1, opacity: 1 }}
            className="text-6xl font-bold mb-2"
          >
            {rpe}
          </motion.div>
          
          <p className="text-xl font-semibold text-foreground mb-1">
            {currentConfig.label}
          </p>
          <p className="text-sm text-muted-foreground">
            {currentConfig.description}
          </p>
        </div>

        {/* RPE Slider */}
        <div className="w-full max-w-md">
          <div className="relative h-16 rounded-2xl bg-secondary/30 overflow-hidden">
            {/* Background gradient */}
            <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/15 via-yellow-500/15 to-red-500/15" />
            
            {/* Selected indicator */}
            <motion.div
              className={`absolute top-1 bottom-1 rounded-xl bg-gradient-to-r ${getGradientColor(rpe)} shadow-lg`}
              initial={false}
              animate={{
                left: `${((rpe - 1) / 9) * 100}%`,
                width: '10%',
              }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            />

            {/* Buttons */}
            <div className="absolute inset-0 flex">
              {RPE_CONFIG.map((config) => (
                <motion.button
                  key={config.value}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleSelect(config.value)}
                  className="flex-1 flex items-center justify-center relative z-10"
                >
                  <span className={`text-lg font-bold tabular-nums transition-all ${
                    rpe === config.value ? 'text-white scale-110' : 'text-muted-foreground'
                  }`}>
                    {config.value}
                  </span>
                </motion.button>
              ))}
            </div>
          </div>

          {/* Scale labels */}
          <div className="flex justify-between mt-2 px-1">
            <span className="text-xs text-muted-foreground">Fácil</span>
            <span className="text-xs text-muted-foreground">Máximo</span>
          </div>
        </div>
      </div>

      <WizardFooter
        label="Completar Série"
        onClick={onComplete}
        variant="success"
        icon={<Check className="w-5 h-5" />}
      />
    </motion.div>
  );
}
