import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, CheckCircle2, Award } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { SessionHeader } from './SessionHeader';
import { ExerciseCard } from './ExerciseCard';
import { SetTracker } from './SetTracker';
import { RestTimer } from './RestTimer';
import { RestOverlay } from './RestOverlay';
import { StatsPanel } from './StatsPanel';
import { LoadSuggestion } from './LoadSuggestion';
import { ComparisonCard } from './ComparisonCard';
import { VoiceCoach } from './VoiceCoach';
import { useSessionState } from '@/hooks/useSessionState';
import { useSessionPersistence } from '@/hooks/useSessionPersistence';
import { useProgressiveLoad } from '@/hooks/useProgressiveLoad';
import { useVoiceCoach } from '@/hooks/useVoiceCoach';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import confetti from 'canvas-confetti';

interface WorkoutSessionControllerProps {
  workout: any;
  onClose: () => void;
  onComplete: () => void;
}

export function WorkoutSessionController({ 
  workout, 
  onClose, 
  onComplete 
}: WorkoutSessionControllerProps) {
  const { user } = useAuth();
  const [showRestOverlay, setShowRestOverlay] = useState(false);
  const [showLoadSuggestion, setShowLoadSuggestion] = useState(false);
  const [comparisonData, setComparisonData] = useState<any>(null);
  const [appliedWeight, setAppliedWeight] = useState<number | null>(null);
  const { saveSession } = useSessionPersistence();

  const {
    exercises,
    currentExerciseIndex,
    currentExercise,
    setCurrentExerciseIndex,
    completeSet,
    restTimer,
    startRestTimer,
    skipRest,
    nextExercise,
    previousExercise,
    calculateStats,
  } = useSessionState(workout.exercises || []);

  const stats = calculateStats();

  // Progressive load suggestion
  const { suggestion, isLoading: loadingSuggestion, reload: reloadSuggestion } = useProgressiveLoad(
    currentExercise?.name || '',
    user?.id || ''
  );

  // Voice coach
  const voiceCoach = useVoiceCoach({
    enabled: true,
    userName: user?.user_metadata?.display_name || user?.email?.split('@')[0] || 'atleta',
    currentExercise: currentExercise?.name,
    currentSet: currentExercise?.sets.length + 1,
    totalSets: currentExercise?.targetSets,
    lastRPE: currentExercise?.sets[currentExercise?.sets.length - 1]?.rpe
  });

  // Update voice coach context when exercise changes
  useEffect(() => {
    if (voiceCoach.isConnected && currentExercise) {
      voiceCoach.sendContext({
        currentExercise: currentExercise.name,
        currentSet: currentExercise.sets.length + 1,
        totalSets: currentExercise.targetSets,
        lastRPE: currentExercise.sets[currentExercise.sets.length - 1]?.rpe
      });
    }
  }, [currentExercise, voiceCoach.isConnected]);

  // Show load suggestion when exercise changes
  useEffect(() => {
    if (currentExercise && suggestion && !appliedWeight) {
      setShowLoadSuggestion(true);
      calculateComparison();
    }
  }, [currentExercise?.id, suggestion]);

  const calculateComparison = () => {
    if (!suggestion) return;

    const currentWeight = appliedWeight || suggestion.suggestedWeight;
    const currentReps = currentExercise?.targetReps || 10;
    
    const comparison = {
      currentWeight,
      currentReps,
      lastWeight: suggestion.lastWeight,
      lastReps: suggestion.lastReps,
      lastDate: suggestion.lastDate,
      isPR: false,
      improvement: 0
    };

    if (suggestion.lastWeight && suggestion.lastReps) {
      const currentVolume = currentWeight * currentReps;
      const lastVolume = suggestion.lastWeight * suggestion.lastReps;
      comparison.improvement = ((currentVolume - lastVolume) / lastVolume) * 100;
      comparison.isPR = currentVolume > lastVolume;
    }

    setComparisonData(comparison);
  };

  const handleApplySuggestion = (weight: number) => {
    setAppliedWeight(weight);
    setShowLoadSuggestion(false);
    calculateComparison();
    toast.success(`Carga de ${weight}kg aplicada!`);
  };

  const handleCompleteSet = (setData: any) => {
    if (!currentExercise) return;
    
    completeSet(currentExercise.id, setData);

    // Check if PR
    if (comparisonData?.isPR && setData.weight >= comparisonData.currentWeight) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#FFD700', '#FFA500', '#FF6347']
      });
      toast.success('🏆 RECORDE PESSOAL BATIDO!', {
        duration: 5000,
      });
      
      if (voiceCoach.isConnected) {
        voiceCoach.speak(`BOOM! Recorde pessoal batido! Isso sim é evolução!`);
      }
    } else if (voiceCoach.isConnected) {
      // Regular completion message
      const rpeMessage = setData.rpe >= 9 
        ? 'Uau! Intenso! Descansa bem, você merece.'
        : setData.rpe >= 7
        ? 'Ótima série! Você tem mais gás, hein?'
        : 'Boa! Acelera um pouco na próxima!';
      
      voiceCoach.speak(rpeMessage);
    }
    
    // Start rest timer if not last set
    const completedSets = currentExercise.sets.length + 1;
    if (completedSets < currentExercise.targetSets) {
      const nextExerciseName = exercises[currentExerciseIndex + 1]?.name;
      startRestTimer(currentExercise.restSeconds, nextExerciseName);
      setShowRestOverlay(true);
      
      if (voiceCoach.isConnected) {
        voiceCoach.speak(`Descansa ${currentExercise.restSeconds} segundos. Você consegue!`);
      }
    } else {
      // Exercise completed
      toast.success(`${currentExercise.name} concluído! 🎉`);
      
      if (voiceCoach.isConnected) {
        voiceCoach.speak(`${currentExercise.name} destruído! Partiu próximo exercício!`);
      }
      
      // Auto advance to next exercise after 1.5s
      setTimeout(() => {
        if (currentExerciseIndex < exercises.length - 1) {
          nextExercise();
          setAppliedWeight(null);
          setShowLoadSuggestion(true);
        }
      }, 1500);
    }
  };

  const handleSkipRest = () => {
    skipRest();
    setShowRestOverlay(false);
  };

  const handleFinishWorkout = async () => {
    const session = {
      name: workout.name,
      workoutName: workout.name,
      workoutFocus: workout.focus || '',
      exercises: exercises,
      startedAt: new Date().toISOString(),
      completedAt: new Date().toISOString(),
      durationSeconds: stats.durationSeconds,
      totalVolume: stats.totalVolume,
      avgRpe: stats.avgRpe,
      notes: '',
    };

    const saved = await saveSession(session);
    if (saved) {
      if (voiceCoach.isConnected) {
        voiceCoach.speak('Treino finalizado! Excelente trabalho! Você evoluiu mais hoje!');
      }
      
      confetti({
        particleCount: 150,
        spread: 90,
        origin: { y: 0.5 }
      });
      
      voiceCoach.disconnect();
      onComplete();
      onClose();
    }
  };

  const handleVoiceCoachToggle = () => {
    if (voiceCoach.isConnected) {
      voiceCoach.disconnect();
    } else {
      voiceCoach.connect();
    }
  };

  const allExercisesComplete = exercises.every(ex => ex.completed);

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[95vh] overflow-y-auto p-0 bg-bg-1 border-white/10">
        <RestOverlay
          isActive={showRestOverlay}
          timeLeft={restTimer.timeLeft}
          totalTime={restTimer.totalTime}
          nextExercise={restTimer.nextExercise}
          onSkip={handleSkipRest}
        />

        <SessionHeader
          workoutName={workout.name}
          stats={stats}
          onClose={onClose}
        />

        <div className="container max-w-4xl mx-auto px-4 py-6 space-y-6">
          {/* Voice Coach */}
          <VoiceCoach
            isConnected={voiceCoach.isConnected}
            isLoading={voiceCoach.isLoading}
            isSpeaking={voiceCoach.isSpeaking}
            onToggle={handleVoiceCoachToggle}
          />

          {/* Current Exercise */}
          {currentExercise && (
            <ExerciseCard
              exercise={currentExercise}
              exerciseNumber={currentExerciseIndex + 1}
              totalExercises={exercises.length}
            />
          )}

          {/* Load Suggestion */}
          {showLoadSuggestion && suggestion && !appliedWeight && (
            <LoadSuggestion
              suggestedWeight={suggestion.suggestedWeight}
              reason={suggestion.reason}
              confidence={suggestion.confidence}
              lastWeight={suggestion.lastWeight}
              lastReps={suggestion.lastReps}
              lastRpe={suggestion.lastRpe}
              onAccept={handleApplySuggestion}
              onDismiss={() => setShowLoadSuggestion(false)}
            />
          )}

          {/* Comparison Card */}
          {comparisonData && (
            <ComparisonCard data={comparisonData} />
          )}

          {/* Rest Timer (inline) */}
          {restTimer.isActive && !showRestOverlay && (
            <RestTimer timer={restTimer} onSkip={handleSkipRest} />
          )}

          {/* Set Tracker */}
          {currentExercise && !currentExercise.completed && (
            <SetTracker
              sets={currentExercise.sets}
              targetSets={currentExercise.targetSets}
              targetReps={currentExercise.targetReps}
              lastWeight={appliedWeight || currentExercise.targetWeight}
              onCompleteSet={handleCompleteSet}
              onStartRest={startRestTimer}
            />
          )}

          {/* Stats Panel */}
          <StatsPanel stats={stats} />

          {/* Navigation */}
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              onClick={previousExercise}
              disabled={currentExerciseIndex === 0}
              className="flex-1"
            >
              <ChevronLeft className="w-4 h-4 mr-2" />
              Anterior
            </Button>

            {allExercisesComplete ? (
              <Button
                onClick={handleFinishWorkout}
                className="flex-1 bg-gradient-to-r from-green-500 to-green-600 hover:opacity-90"
              >
                <CheckCircle2 className="w-4 h-4 mr-2" />
                Finalizar Treino
              </Button>
            ) : (
              <Button
                variant="outline"
                onClick={nextExercise}
                disabled={currentExerciseIndex === exercises.length - 1}
                className="flex-1"
              >
                Próximo
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            )}
          </div>

          {/* Exercise Progress List */}
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-txt-3">Progresso dos Exercícios</h4>
            {exercises.map((ex, idx) => (
              <motion.button
                key={ex.id}
                onClick={() => setCurrentExerciseIndex(idx)}
                className={`w-full p-3 rounded-lg text-left transition-all ${
                  idx === currentExerciseIndex
                    ? 'bg-accent/20 border border-accent/50'
                    : 'bg-bg-2/50 border border-white/10 hover:bg-bg-2'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      ex.completed 
                        ? 'bg-green-500/20 text-green-400' 
                        : idx === currentExerciseIndex
                        ? 'bg-accent/20 text-accent'
                        : 'bg-bg-3 text-txt-3'
                    }`}>
                      {ex.completed ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-txt-1">{ex.name}</div>
                      <div className="text-xs text-txt-3">
                        {ex.sets.length}/{ex.targetSets} séries
                      </div>
                    </div>
                  </div>
                </div>
              </motion.button>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
