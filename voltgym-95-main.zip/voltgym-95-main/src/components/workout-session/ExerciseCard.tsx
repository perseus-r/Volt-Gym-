import { motion } from 'framer-motion';
import { Dumbbell, Target, Clock } from 'lucide-react';
import { SessionExercise } from '@/types/workout.unified';
import { Progress } from '@/components/ui/progress';

interface ExerciseCardProps {
  exercise: SessionExercise;
  exerciseNumber: number;
  totalExercises: number;
}

export function ExerciseCard({ exercise, exerciseNumber, totalExercises }: ExerciseCardProps) {
  const progress = (exercise.sets.length / exercise.targetSets) * 100;

  return (
    <motion.div
      initial={{ scale: 0.95, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className="glass-premium p-6 rounded-2xl border border-white/10"
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <Dumbbell className="w-5 h-5 text-accent" />
            <span className="text-xs text-txt-3">
              Exercício {exerciseNumber} de {totalExercises}
            </span>
          </div>
          <h3 className="text-2xl font-bold text-txt-1 mb-2">{exercise.name}</h3>
          
          <div className="flex items-center gap-4 text-sm text-txt-2">
            <div className="flex items-center gap-1">
              <Target className="w-4 h-4" />
              <span>{exercise.targetSets} séries × {exercise.targetReps} reps</span>
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              <span>{exercise.restSeconds}s descanso</span>
            </div>
          </div>
        </div>

        <div className="text-right">
          <div className="text-3xl font-bold text-accent">
            {exercise.sets.length}/{exercise.targetSets}
          </div>
          <div className="text-xs text-txt-3">séries</div>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-txt-3">
          <span>Progresso</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      {exercise.sets.length > 0 && (
        <div className="mt-4 pt-4 border-t border-white/10">
          <div className="text-xs text-txt-3 mb-2">Última série</div>
          <div className="text-sm text-txt-2">
            {exercise.sets[exercise.sets.length - 1].weight}kg × {exercise.sets[exercise.sets.length - 1].reps} reps
            {' '}• RPE {exercise.sets[exercise.sets.length - 1].rpe}
          </div>
        </div>
      )}
    </motion.div>
  );
}
