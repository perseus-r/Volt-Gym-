import { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Minus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface WeightSelectorProps {
  value: number;
  onChange: (value: number) => void;
  label?: string;
  step?: number;
  min?: number;
  max?: number;
}

export function WeightSelector({ 
  value, 
  onChange, 
  label = 'Peso (kg)',
  step = 2.5,
  min = 0,
  max = 500
}: WeightSelectorProps) {
  const [inputValue, setInputValue] = useState(value.toString());

  const handleIncrement = () => {
    const newValue = Math.min(value + step, max);
    onChange(newValue);
    setInputValue(newValue.toString());
  };

  const handleDecrement = () => {
    const newValue = Math.max(value - step, min);
    onChange(newValue);
    setInputValue(newValue.toString());
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setInputValue(val);
    
    const numVal = parseFloat(val);
    if (!isNaN(numVal) && numVal >= min && numVal <= max) {
      onChange(numVal);
    }
  };

  return (
    <div className="space-y-2">
      <Label className="text-txt-2 text-sm">{label}</Label>
      <div className="flex items-center gap-2">
        <Button
          type="button"
          variant="outline"
          size="icon"
          onClick={handleDecrement}
          className="h-12 w-12 rounded-xl border-white/10 hover:border-accent/50 transition-colors"
        >
          <Minus className="w-4 h-4" />
        </Button>

        <div className="flex-1 relative">
          <Input
            type="number"
            value={inputValue}
            onChange={handleInputChange}
            step={step}
            min={min}
            max={max}
            className="h-12 text-center text-2xl font-bold text-txt bg-bg-2/50 border-white/10 focus:border-accent/50"
          />
          <motion.div
            className="absolute inset-0 rounded-lg pointer-events-none"
            animate={{
              boxShadow: [
                '0 0 0px rgba(0, 191, 255, 0)',
                '0 0 20px rgba(0, 191, 255, 0.3)',
                '0 0 0px rgba(0, 191, 255, 0)',
              ],
            }}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </div>

        <Button
          type="button"
          variant="outline"
          size="icon"
          onClick={handleIncrement}
          className="h-12 w-12 rounded-xl border-white/10 hover:border-accent/50 transition-colors"
        >
          <Plus className="w-4 h-4" />
        </Button>
      </div>

      <div className="flex gap-2">
        {[0.5, 1, 2.5, 5].map((increment) => (
          <Button
            key={increment}
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => {
              const newValue = value + increment;
              if (newValue <= max) {
                onChange(newValue);
                setInputValue(newValue.toString());
              }
            }}
            className="flex-1 text-xs text-txt-3 hover:text-accent"
          >
            +{increment}kg
          </Button>
        ))}
      </div>
    </div>
  );
}
