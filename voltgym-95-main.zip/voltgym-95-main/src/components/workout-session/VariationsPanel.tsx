import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  TrendingDown, 
  Pause, 
  Zap, 
  Clock, 
  RefreshCw, 
  Flame,
  ChevronRight,
  Plus,
  Minus
} from 'lucide-react';
import {
  VariationType,
  DropSetConfig,
  RestPauseConfig,
  ClusterSetConfig,
  TempoConfig,
  VARIATION_LABELS,
  VARIATION_DESCRIPTIONS
} from '@/types/variations.types';

interface VariationsPanelProps {
  currentType: VariationType;
  onSelectType: (type: VariationType) => void;
  onConfigureDropSet?: (config: DropSetConfig) => void;
  onConfigureRestPause?: (config: RestPauseConfig) => void;
  onConfigureCluster?: (config: ClusterSetConfig) => void;
  onConfigureTempo?: (config: TempoConfig) => void;
}

export function VariationsPanel({
  currentType,
  onSelectType,
  onConfigureDropSet,
  onConfigureRestPause,
  onConfigureCluster,
  onConfigureTempo
}: VariationsPanelProps) {
  const [showConfig, setShowConfig] = useState(false);

  const variations: { type: VariationType; icon: any; color: string }[] = [
    { type: 'normal', icon: Zap, color: 'text-blue-400' },
    { type: 'drop_set', icon: TrendingDown, color: 'text-orange-400' },
    { type: 'rest_pause', icon: Pause, color: 'text-purple-400' },
    { type: 'cluster', icon: RefreshCw, color: 'text-green-400' },
    { type: 'tempo', icon: Clock, color: 'text-yellow-400' },
    { type: 'amrap', icon: Flame, color: 'text-red-400' },
  ];

  return (
    <Card className="session-glass-intense p-4 border-accent/20">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-white">Técnica Avançada</h3>
            <p className="text-xs text-muted-foreground">
              {VARIATION_DESCRIPTIONS[currentType]}
            </p>
          </div>
          {currentType !== 'normal' && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setShowConfig(!showConfig)}
              className="text-accent hover:text-accent/80"
            >
              {showConfig ? 'Fechar' : 'Configurar'}
            </Button>
          )}
        </div>

        {/* Variation Type Selection */}
        <div className="grid grid-cols-3 gap-2">
          {variations.map(({ type, icon: Icon, color }) => (
            <Button
              key={type}
              size="sm"
              variant={currentType === type ? 'default' : 'outline'}
              onClick={() => onSelectType(type)}
              className={`flex flex-col gap-1 h-auto py-3 ${
                currentType === type 
                  ? 'bg-accent/20 border-accent text-white' 
                  : 'border-white/10'
              }`}
            >
              <Icon className={`w-4 h-4 ${currentType === type ? 'text-accent' : color}`} />
              <span className="text-xs">{VARIATION_LABELS[type]}</span>
            </Button>
          ))}
        </div>

        {/* Configuration Panels */}
        {showConfig && currentType === 'drop_set' && (
          <DropSetConfigPanel onSave={onConfigureDropSet} />
        )}
        {showConfig && currentType === 'rest_pause' && (
          <RestPauseConfigPanel onSave={onConfigureRestPause} />
        )}
        {showConfig && currentType === 'cluster' && (
          <ClusterConfigPanel onSave={onConfigureCluster} />
        )}
        {showConfig && currentType === 'tempo' && (
          <TempoConfigPanel onSave={onConfigureTempo} />
        )}
      </div>
    </Card>
  );
}

// Drop Set Configuration
function DropSetConfigPanel({ onSave }: { onSave?: (config: DropSetConfig) => void }) {
  const [drops, setDrops] = useState([
    { weight: 100, targetReps: 'failure' as const, restSeconds: 10 },
    { weight: 80, targetReps: 'failure' as const, restSeconds: 10 },
    { weight: 60, targetReps: 'failure' as const, restSeconds: 0 },
  ]);

  const addDrop = () => {
    const lastWeight = drops[drops.length - 1]?.weight || 100;
    setDrops([...drops, { 
      weight: Math.max(20, lastWeight - 20), 
      targetReps: 'failure', 
      restSeconds: 10 
    }]);
  };

  const removeDrop = (index: number) => {
    if (drops.length > 2) {
      setDrops(drops.filter((_, i) => i !== index));
    }
  };

  return (
    <div className="space-y-3 p-3 bg-bg-2/50 rounded-lg border border-white/10">
      <div className="flex items-center justify-between">
        <Label className="text-sm text-white">Configurar Drop Sets</Label>
        <Button size="sm" variant="ghost" onClick={addDrop}>
          <Plus className="w-4 h-4" />
        </Button>
      </div>

      {drops.map((drop, index) => (
        <div key={index} className="flex items-center gap-2 p-2 bg-bg-3/50 rounded">
          <Badge variant="outline" className="text-xs">Drop {index + 1}</Badge>
          <Input
            type="number"
            value={drop.weight}
            onChange={(e) => {
              const newDrops = [...drops];
              newDrops[index].weight = parseFloat(e.target.value);
              setDrops(newDrops);
            }}
            className="w-20 h-8 text-sm"
            placeholder="kg"
          />
          <span className="text-xs text-muted-foreground">→ falha</span>
          {index < drops.length - 1 && (
            <>
              <span className="text-xs text-muted-foreground">•</span>
              <span className="text-xs text-accent">{drop.restSeconds}s</span>
            </>
          )}
          {drops.length > 2 && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => removeDrop(index)}
              className="ml-auto"
            >
              <Minus className="w-3 h-3" />
            </Button>
          )}
        </div>
      ))}

      <Button
        size="sm"
        onClick={() => onSave?.({ drops, currentDrop: 0 })}
        className="w-full bg-accent hover:bg-accent/90"
      >
        Aplicar
      </Button>
    </div>
  );
}

// Rest-Pause Configuration
function RestPauseConfigPanel({ onSave }: { onSave?: (config: RestPauseConfig) => void }) {
  const [config, setConfig] = useState({
    initialReps: 15,
    pauseSeconds: 10,
    miniSets: 3
  });

  return (
    <div className="space-y-3 p-3 bg-bg-2/50 rounded-lg border border-white/10">
      <Label className="text-sm text-white">Configurar Rest-Pause</Label>
      
      <div className="space-y-2">
        <div className="flex justify-between text-xs">
          <span className="text-muted-foreground">Reps iniciais</span>
          <span className="text-white font-medium">{config.initialReps}</span>
        </div>
        <Slider
          value={[config.initialReps]}
          onValueChange={([v]) => setConfig({ ...config, initialReps: v })}
          min={10}
          max={20}
          step={1}
        />
      </div>

      <div className="space-y-2">
        <div className="flex justify-between text-xs">
          <span className="text-muted-foreground">Pausa entre mini-sets</span>
          <span className="text-white font-medium">{config.pauseSeconds}s</span>
        </div>
        <Slider
          value={[config.pauseSeconds]}
          onValueChange={([v]) => setConfig({ ...config, pauseSeconds: v })}
          min={10}
          max={20}
          step={5}
        />
      </div>

      <div className="space-y-2">
        <div className="flex justify-between text-xs">
          <span className="text-muted-foreground">Número de mini-sets</span>
          <span className="text-white font-medium">{config.miniSets}</span>
        </div>
        <Slider
          value={[config.miniSets]}
          onValueChange={([v]) => setConfig({ ...config, miniSets: v })}
          min={2}
          max={5}
          step={1}
        />
      </div>

      <Button
        size="sm"
        onClick={() => onSave?.({ ...config, currentMiniSet: 0 })}
        className="w-full bg-accent hover:bg-accent/90"
      >
        Aplicar
      </Button>
    </div>
  );
}

// Cluster Configuration
function ClusterConfigPanel({ onSave }: { onSave?: (config: ClusterSetConfig) => void }) {
  const [config, setConfig] = useState({
    repsPerCluster: 5,
    clusters: 3,
    restSeconds: 15
  });

  return (
    <div className="space-y-3 p-3 bg-bg-2/50 rounded-lg border border-white/10">
      <Label className="text-sm text-white">Configurar Cluster Sets</Label>
      
      <div className="space-y-2">
        <div className="flex justify-between text-xs">
          <span className="text-muted-foreground">Reps por cluster</span>
          <span className="text-white font-medium">{config.repsPerCluster}</span>
        </div>
        <Slider
          value={[config.repsPerCluster]}
          onValueChange={([v]) => setConfig({ ...config, repsPerCluster: v })}
          min={3}
          max={10}
          step={1}
        />
      </div>

      <div className="space-y-2">
        <div className="flex justify-between text-xs">
          <span className="text-muted-foreground">Número de clusters</span>
          <span className="text-white font-medium">{config.clusters}</span>
        </div>
        <Slider
          value={[config.clusters]}
          onValueChange={([v]) => setConfig({ ...config, clusters: v })}
          min={2}
          max={6}
          step={1}
        />
      </div>

      <div className="space-y-2">
        <div className="flex justify-between text-xs">
          <span className="text-muted-foreground">Descanso entre clusters</span>
          <span className="text-white font-medium">{config.restSeconds}s</span>
        </div>
        <Slider
          value={[config.restSeconds]}
          onValueChange={([v]) => setConfig({ ...config, restSeconds: v })}
          min={10}
          max={30}
          step={5}
        />
      </div>

      <Button
        size="sm"
        onClick={() => onSave?.({ ...config, currentCluster: 0 })}
        className="w-full bg-accent hover:bg-accent/90"
      >
        Aplicar
      </Button>
    </div>
  );
}

// Tempo Configuration
function TempoConfigPanel({ onSave }: { onSave?: (config: TempoConfig) => void }) {
  const [config, setConfig] = useState({
    eccentric: 3,
    pause1: 1,
    concentric: 2,
    pause2: 1
  });

  return (
    <div className="space-y-3 p-3 bg-bg-2/50 rounded-lg border border-white/10">
      <Label className="text-sm text-white">Configurar Tempo Training</Label>
      
      <div className="grid grid-cols-4 gap-2">
        <div className="text-center">
          <Label className="text-xs text-muted-foreground">Descida</Label>
          <Input
            type="number"
            value={config.eccentric}
            onChange={(e) => setConfig({ ...config, eccentric: parseInt(e.target.value) || 0 })}
            className="h-12 text-center text-lg font-bold"
          />
        </div>
        <div className="text-center">
          <Label className="text-xs text-muted-foreground">Pausa</Label>
          <Input
            type="number"
            value={config.pause1}
            onChange={(e) => setConfig({ ...config, pause1: parseInt(e.target.value) || 0 })}
            className="h-12 text-center text-lg font-bold"
          />
        </div>
        <div className="text-center">
          <Label className="text-xs text-muted-foreground">Subida</Label>
          <Input
            type="number"
            value={config.concentric}
            onChange={(e) => setConfig({ ...config, concentric: parseInt(e.target.value) || 0 })}
            className="h-12 text-center text-lg font-bold"
          />
        </div>
        <div className="text-center">
          <Label className="text-xs text-muted-foreground">Pausa</Label>
          <Input
            type="number"
            value={config.pause2}
            onChange={(e) => setConfig({ ...config, pause2: parseInt(e.target.value) || 0 })}
            className="h-12 text-center text-lg font-bold"
          />
        </div>
      </div>

      <div className="text-center p-2 bg-bg-3/50 rounded">
        <span className="text-lg font-mono text-accent">
          {config.eccentric}-{config.pause1}-{config.concentric}-{config.pause2}
        </span>
      </div>

      <Button
        size="sm"
        onClick={() => onSave?.({ 
          ...config, 
          currentPhase: 'eccentric',
          metronomeActive: false
        })}
        className="w-full bg-accent hover:bg-accent/90"
      >
        Aplicar
      </Button>
    </div>
  );
}
