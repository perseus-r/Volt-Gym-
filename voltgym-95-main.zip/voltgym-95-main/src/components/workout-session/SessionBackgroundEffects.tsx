import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

type Objetivo = 'massa' | 'definicao' | 'forca' | 'saude' | null;

interface SessionBackgroundEffectsProps {
  objetivo?: Objetivo;
  intensity?: 'low' | 'medium' | 'high';
}

const gradientColors: Record<NonNullable<Objetivo>, { from: string; to: string; glow: string }> = {
  massa: {
    from: 'from-emerald-500/15',
    to: 'to-teal-500/10',
    glow: 'bg-emerald-500/20',
  },
  definicao: {
    from: 'from-blue-500/15',
    to: 'to-violet-500/10',
    glow: 'bg-blue-500/20',
  },
  forca: {
    from: 'from-red-500/15',
    to: 'to-orange-500/10',
    glow: 'bg-red-500/20',
  },
  saude: {
    from: 'from-violet-500/15',
    to: 'to-purple-500/10',
    glow: 'bg-violet-500/20',
  },
};

const defaultColors = {
  from: 'from-primary/15',
  to: 'to-primary/5',
  glow: 'bg-primary/20',
};

export function SessionBackgroundEffects({ 
  objetivo, 
  intensity = 'medium' 
}: SessionBackgroundEffectsProps) {
  const [breatheIn, setBreatheIn] = useState(true);

  // Breathing animation cycle
  useEffect(() => {
    const interval = setInterval(() => {
      setBreatheIn(prev => !prev);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const colors = objetivo ? gradientColors[objetivo] : defaultColors;
  
  const opacityScale = {
    low: { in: 0.1, out: 0.05 },
    medium: { in: 0.15, out: 0.08 },
    high: { in: 0.2, out: 0.1 },
  };

  const scale = opacityScale[intensity];

  return (
    <>
      {/* Base gradient overlay */}
      <div 
        className={`absolute inset-0 bg-gradient-to-br ${colors.from} via-transparent ${colors.to} pointer-events-none`}
      />
      
      {/* Breathing pulse - top */}
      <motion.div
        animate={{ 
          scale: breatheIn ? 1.15 : 1,
          opacity: breatheIn ? scale.in : scale.out
        }}
        transition={{ duration: 4, ease: 'easeInOut' }}
        className={`absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] rounded-full ${colors.glow} blur-3xl pointer-events-none`}
      />
      
      {/* Secondary breathing pulse - bottom */}
      <motion.div
        animate={{ 
          scale: breatheIn ? 1 : 1.1,
          opacity: breatheIn ? scale.out : scale.in * 0.7
        }}
        transition={{ duration: 4, ease: 'easeInOut' }}
        className={`absolute bottom-1/4 right-1/4 w-[300px] h-[300px] rounded-full ${colors.glow} blur-3xl pointer-events-none opacity-50`}
      />

      {/* Subtle animated particles effect */}
      <motion.div
        animate={{ 
          backgroundPosition: ['0% 0%', '100% 100%']
        }}
        transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
        className="absolute inset-0 opacity-[0.02] pointer-events-none"
        style={{
          backgroundImage: 'radial-gradient(circle at center, currentColor 1px, transparent 1px)',
          backgroundSize: '40px 40px',
        }}
      />
    </>
  );
}

export default SessionBackgroundEffects;
