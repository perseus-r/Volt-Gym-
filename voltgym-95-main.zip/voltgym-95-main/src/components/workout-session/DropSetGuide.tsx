import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { TrendingDown, ChevronRight, Award } from 'lucide-react';
import { DropSetConfig } from '@/types/variations.types';
import { WeightSelector } from './WeightSelector';

interface DropSetGuideProps {
  config: DropSetConfig;
  onComplete: (data: any) => void;
  onCancel: () => void;
}

export function DropSetGuide({ config, onComplete, onCancel }: DropSetGuideProps) {
  const [currentDrop, setCurrentDrop] = useState(0);
  const [completedDrops, setCompletedDrops] = useState<any[]>([]);
  const [currentWeight, setCurrentWeight] = useState(config.drops[0].weight);
  const [currentReps, setCurrentReps] = useState(0);
  const [isResting, setIsResting] = useState(false);
  const [restTimeLeft, setRestTimeLeft] = useState(0);

  const currentDropData = config.drops[currentDrop];
  const isLastDrop = currentDrop === config.drops.length - 1;
  const totalDrops = config.drops.length;
  const progressPercent = ((currentDrop + 1) / totalDrops) * 100;

  const handleCompleteDrop = () => {
    const dropData = {
      drop: currentDrop + 1,
      weight: currentWeight,
      reps: currentReps,
      targetReps: currentDropData.targetReps
    };

    setCompletedDrops([...completedDrops, dropData]);

    if (isLastDrop) {
      // Complete entire drop set
      onComplete({
        type: 'drop_set',
        drops: [...completedDrops, dropData],
        totalVolume: [...completedDrops, dropData].reduce((sum, d) => sum + (d.weight * d.reps), 0)
      });
    } else {
      // Move to next drop after rest
      const nextDrop = currentDrop + 1;
      const restTime = currentDropData.restSeconds;

      if (restTime > 0) {
        setIsResting(true);
        setRestTimeLeft(restTime);

        const interval = setInterval(() => {
          setRestTimeLeft((prev) => {
            if (prev <= 1) {
              clearInterval(interval);
              setIsResting(false);
              setCurrentDrop(nextDrop);
              setCurrentWeight(config.drops[nextDrop].weight);
              setCurrentReps(0);
              return 0;
            }
            return prev - 1;
          });
        }, 1000);
      } else {
        setCurrentDrop(nextDrop);
        setCurrentWeight(config.drops[nextDrop].weight);
        setCurrentReps(0);
      }
    }
  };

  if (isResting) {
    return (
      <Card className="session-glass-intense p-6 border-orange-500/50 animate-fade-in">
        <div className="text-center space-y-6">
          <TrendingDown className="w-16 h-16 text-orange-400 mx-auto animate-pulse" />
          
          <div>
            <h3 className="text-lg font-bold text-white mb-2">Preparando Drop...</h3>
            <p className="text-sm text-muted-foreground">
              Reduza para {config.drops[currentDrop + 1].weight}kg
            </p>
          </div>

          <div className="text-6xl font-bold text-orange-400">
            {restTimeLeft}s
          </div>

          <Progress value={((currentDropData.restSeconds - restTimeLeft) / currentDropData.restSeconds) * 100} className="h-3" />
        </div>
      </Card>
    );
  }

  return (
    <Card className="session-glass-intense p-6 border-orange-500/50 animate-fade-in">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-orange-500/20">
              <TrendingDown className="w-6 h-6 text-orange-400" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Drop Set</h3>
              <p className="text-sm text-muted-foreground">
                Drop {currentDrop + 1} de {totalDrops}
              </p>
            </div>
          </div>
          <Badge variant="outline" className="bg-orange-500/20 text-orange-400 border-orange-500/30">
            {currentDropData.targetReps === 'failure' ? 'Até a falha' : `${currentDropData.targetReps} reps`}
          </Badge>
        </div>

        {/* Progress */}
        <div className="space-y-2">
          <Progress value={progressPercent} className="h-3" />
          <div className="flex justify-between text-xs text-muted-foreground">
            {config.drops.map((drop, idx) => (
              <span 
                key={idx}
                className={idx === currentDrop ? 'text-orange-400 font-bold' : idx < currentDrop ? 'text-green-400' : ''}
              >
                {drop.weight}kg
              </span>
            ))}
          </div>
        </div>

        {/* Completed Drops */}
        {completedDrops.length > 0 && (
          <div className="space-y-2">
            <div className="text-xs font-semibold text-muted-foreground">Drops Completados</div>
            {completedDrops.map((drop, idx) => (
              <div key={idx} className="flex items-center justify-between p-2 bg-green-500/10 rounded border border-green-500/30">
                <span className="text-sm text-white">Drop {drop.drop}</span>
                <span className="text-sm font-bold text-green-400">{drop.weight}kg × {drop.reps} reps</span>
              </div>
            ))}
          </div>
        )}

        {/* Current Drop Controls */}
        <div className="space-y-4">
          <WeightSelector
            value={currentWeight}
            onChange={setCurrentWeight}
            step={2.5}
            label="Peso Atual"
          />

          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">Repetições Executadas</label>
            <div className="flex items-center gap-3">
              <Button
                variant="outline"
                onClick={() => setCurrentReps(Math.max(0, currentReps - 1))}
                className="h-12 w-12"
              >
                -
              </Button>
              <div className="flex-1 text-center">
                <div className="text-4xl font-bold text-white">{currentReps}</div>
                {currentDropData.targetReps === 'failure' && (
                  <div className="text-xs text-orange-400">até a falha</div>
                )}
              </div>
              <Button
                variant="outline"
                onClick={() => setCurrentReps(currentReps + 1)}
                className="h-12 w-12"
              >
                +
              </Button>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={onCancel}
            className="flex-1"
          >
            Cancelar
          </Button>
          <Button
            onClick={handleCompleteDrop}
            disabled={currentReps === 0}
            className="flex-1 bg-orange-500 hover:bg-orange-600"
          >
            {isLastDrop ? (
              <>
                <Award className="w-4 h-4 mr-2" />
                Finalizar Drop Set
              </>
            ) : (
              <>
                Próximo Drop
                <ChevronRight className="w-4 h-4 ml-2" />
              </>
            )}
          </Button>
        </div>
      </div>
    </Card>
  );
}
