import { motion } from 'framer-motion';
import { SessionStats } from '@/types/workout.unified';
import { Dumbbell, Flame, Zap, TrendingUp } from 'lucide-react';

interface StatsPanelProps {
  stats: SessionStats;
}

export function StatsPanel({ stats }: StatsPanelProps) {
  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    return `${mins} min`;
  };

  const getIntensityLabel = (rpe: number) => {
    if (rpe >= 8) return 'Alta';
    if (rpe >= 6) return 'Moderada';
    return 'Leve';
  };

  const statItems = [
    {
      icon: Dumbbell,
      label: 'Volume Total',
      value: `${stats.totalVolume.toFixed(0)}kg`,
      color: 'text-accent',
    },
    {
      icon: Zap,
      label: 'Séries',
      value: `${stats.completedSets}/${stats.totalSets}`,
      color: 'text-green-400',
    },
    {
      icon: Flame,
      label: 'Calorias',
      value: `~${stats.estimatedCalories}`,
      color: 'text-orange-400',
    },
    {
      icon: TrendingUp,
      label: 'Intensidade',
      value: getIntensityLabel(stats.avgRpe),
      color: 'text-purple-400',
    },
  ];

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="glass-subtle p-4 rounded-xl border border-white/10"
    >
      <h3 className="text-sm font-semibold text-txt-2 mb-3">Estatísticas da Sessão</h3>
      
      <div className="grid grid-cols-2 gap-3">
        {statItems.map((item, idx) => (
          <motion.div
            key={item.label}
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: idx * 0.1 }}
            className="bg-bg-2/50 p-3 rounded-lg"
          >
            <div className="flex items-center gap-2 mb-1">
              <item.icon className={`w-4 h-4 ${item.color}`} />
              <span className="text-xs text-txt-3">{item.label}</span>
            </div>
            <div className={`text-lg font-bold ${item.color}`}>
              {item.value}
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
