import { Brain, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface LoadSuggestionProps {
  suggestedWeight: number;
  reason: string;
  confidence: 'high' | 'medium' | 'low';
  lastWeight?: number;
  lastReps?: number;
  lastRpe?: number;
  onAccept: (weight: number) => void;
  onDismiss: () => void;
}

export function LoadSuggestion({
  suggestedWeight,
  reason,
  confidence,
  lastWeight,
  lastReps,
  lastRpe,
  onAccept,
  onDismiss
}: LoadSuggestionProps) {
  const confidenceColors = {
    high: 'bg-green-500/20 text-green-400 border-green-500/30',
    medium: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
    low: 'bg-orange-500/20 text-orange-400 border-orange-500/30'
  };

  const getTrendIcon = () => {
    if (!lastWeight) return <Brain className="w-4 h-4" />;
    if (suggestedWeight > lastWeight) return <TrendingUp className="w-4 h-4 text-green-400" />;
    if (suggestedWeight < lastWeight) return <TrendingDown className="w-4 h-4 text-orange-400" />;
    return <Minus className="w-4 h-4 text-blue-400" />;
  };

  const getChangePercent = () => {
    if (!lastWeight || lastWeight === 0) return null;
    const change = ((suggestedWeight - lastWeight) / lastWeight) * 100;
    return change.toFixed(1);
  };

  const changePercent = getChangePercent();

  return (
    <Card className="session-glass-intense p-4 border-accent/30 animate-fade-in">
      <div className="flex items-start gap-3">
        <div className="p-2 rounded-lg bg-accent/20 text-accent">
          <Brain className="w-5 h-5" />
        </div>
        
        <div className="flex-1 space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-muted-foreground">IA sugere</span>
            <Badge variant="outline" className={confidenceColors[confidence]}>
              {confidence === 'high' ? 'Alta' : confidence === 'medium' ? 'Média' : 'Baixa'} confiança
            </Badge>
          </div>

          <div className="flex items-baseline gap-2">
            {getTrendIcon()}
            <span className="text-2xl font-bold text-white">{suggestedWeight}kg</span>
            {changePercent && (
              <span className={`text-sm ${parseFloat(changePercent) > 0 ? 'text-green-400' : 'text-orange-400'}`}>
                {parseFloat(changePercent) > 0 ? '+' : ''}{changePercent}%
              </span>
            )}
          </div>

          {lastWeight && (
            <div className="text-xs text-muted-foreground">
              Última vez: {lastWeight}kg × {lastReps} reps {lastRpe && `• RPE ${lastRpe}`}
            </div>
          )}

          <p className="text-sm text-muted-foreground leading-relaxed">
            {reason}
          </p>

          <div className="flex gap-2 pt-2">
            <Button
              size="sm"
              onClick={() => onAccept(suggestedWeight)}
              className="bg-accent hover:bg-accent/90 text-white"
            >
              Aplicar
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={onDismiss}
              className="text-muted-foreground hover:text-white"
            >
              Dispensar
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}
