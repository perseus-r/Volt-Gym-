import React, { useState, useEffect } from 'react';
import { getYouTubeId, toEmbedUrl, getThumbnailUrl } from '../utils/youtube';
import { Play } from 'lucide-react';
import { cn } from '@/lib/utils';

type Props = {
  url?: string | null;
  title?: string;
  start?: number;
  className?: string;
  clickToPlay?: boolean;
};

export default function YouTubePlayer({
  url,
  title = 'Vídeo',
  start = 0,
  className = '',
  clickToPlay = true,
}: Props) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [thumbnailSrc, setThumbnailSrc] = useState<string | null>(null);
  const id = getYouTubeId(url || '');

  

  useEffect(() => {
    if (!id) return;
    
    setIsPlaying(false);
    setThumbnailSrc(null);
    
    const img = new Image();
    img.onload = () => setThumbnailSrc(img.src);
    img.onerror = () => setThumbnailSrc(null);
    img.src = getThumbnailUrl(id, 'hq');
  }, [id]);

  // Invalid URL state
  if (!id) {
    return (
      <div
        className={cn(
          "aspect-video rounded-2xl border border-border bg-muted/10 flex items-center justify-center p-4",
          className
        )}
      >
        <span className="text-sm text-muted-foreground">
          Link de YouTube inválido
        </span>
      </div>
    );
  }

  // Click-to-play overlay
  if (clickToPlay && !isPlaying) {
    return (
      <div
        className={cn(
          "relative w-full aspect-video rounded-2xl overflow-hidden cursor-pointer group bg-black",
          className
        )}
        onClick={() => setIsPlaying(true)}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => e.key === 'Enter' && setIsPlaying(true)}
        aria-label={`Reproduzir: ${title}`}
      >
        {/* Thumbnail (if loaded) or black background */}
        {thumbnailSrc && (
          <img
            src={thumbnailSrc}
            alt={title}
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
        )}

        {/* Dark overlay */}
        <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors" />

        {/* Play button - always visible */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-destructive flex items-center justify-center shadow-lg transition-transform group-hover:scale-110">
            <Play className="w-7 h-7 sm:w-8 sm:h-8 text-destructive-foreground fill-current ml-1" />
          </div>
        </div>
      </div>
    );
  }

  // Playing: render iframe
  const src = toEmbedUrl(id, {
    nocookie: false,
    start,
    autoplay: clickToPlay,
  });

  return (
    <div
      className={cn(
        "relative w-full aspect-video rounded-2xl overflow-hidden bg-black",
        className
      )}
    >
      <iframe
        src={src}
        title={title}
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowFullScreen
        className="absolute inset-0 w-full h-full border-0"
      />
    </div>
  );
}
