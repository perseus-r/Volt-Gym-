import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { useVibration } from '@/hooks/useVibration';

interface HapticFeedbackProps {
  children: React.ReactNode;
  intensity?: 'light' | 'medium' | 'heavy';
  hapticType?: 'click' | 'success' | 'error' | 'pulse';
  className?: string;
  disabled?: boolean;
  onClick?: () => void;
}

export function HapticFeedback({
  children,
  intensity = 'medium',
  hapticType = 'click',
  className,
  disabled = false,
  onClick
}: HapticFeedbackProps) {
  const { vibrateClick, vibrateSuccess, vibrateError, vibratePulse } = useVibration();

  const handleClick = () => {
    if (disabled) return;

    // Trigger haptic feedback
    switch (hapticType) {
      case 'click':
        vibrateClick();
        break;
      case 'success':
        vibrateSuccess();
        break;
      case 'error':
        vibrateError();
        break;
      case 'pulse':
        vibratePulse();
        break;
    }

    // Execute onClick callback
    onClick?.();
  };

  const scaleIntensity = {
    light: 0.99,
    medium: 0.98,
    heavy: 0.96
  };

  return (
    <motion.div
      whileTap={{ scale: disabled ? 1 : scaleIntensity[intensity] }}
      transition={{ 
        duration: 0.15,
        ease: 'easeOut'
      }}
      onClick={handleClick}
      className={cn(
        'relative',
        !disabled && 'cursor-pointer active:opacity-90',
        disabled && 'opacity-50 cursor-not-allowed',
        className
      )}
      style={{
        WebkitTapHighlightColor: 'transparent',
        touchAction: 'manipulation'
      }}
    >
      {children}
      
      {/* Visual feedback overlay */}
      <motion.div
        className="absolute inset-0 rounded-inherit bg-white pointer-events-none"
        initial={{ opacity: 0 }}
        whileTap={{ opacity: disabled ? 0 : 0.1 }}
        transition={{ duration: 0.1 }}
      />
    </motion.div>
  );
}
