import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Target } from 'lucide-react';
import { toast } from 'sonner';
import { WorkoutTemplateCardMobile } from '@/components/workout/WorkoutTemplateCardPremium';

interface WorkoutTemplate {
  id: string;
  name: string;
  description: string;
  focus: string;
  target_muscle_groups: string[];
  difficulty_level: number;
  estimated_duration: number;
  is_public: boolean;
  template_exercises: {
    id: string;
    order_index: number;
    sets: number;
    reps_target: string;
    rest_seconds: number;
    exercises: {
      name: string;
      primary_muscles: string[];
      equipment: string;
    };
  }[];
}

export const MobileWorkoutTemplates = ({ onStartWorkout }) => {
  const [templates, setTemplates] = useState<WorkoutTemplate[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadWorkoutTemplates();
  }, []);

  const loadWorkoutTemplates = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('workout_templates')
        .select(`
          *,
          template_exercises (
            *,
            exercises (
              name,
              primary_muscles,
              equipment
            )
          )
        `)
        .eq('is_public', true)
        .order('name');

      if (error) throw error;

      setTemplates(data || []);
    } catch (error) {
      console.error('Erro ao carregar templates:', error);
      toast.error('Erro ao carregar templates de treino');
    } finally {
      setLoading(false);
    }
  };

  const handleStartTemplate = (template: WorkoutTemplate) => {
    const workout = {
      id: template.id,
      name: template.name,
      focus: template.focus,
      exercises: template.template_exercises
        .sort((a, b) => a.order_index - b.order_index)
        .map(te => ({
          name: te.exercises.name,
          sets: te.sets,
          reps: te.reps_target || '8-12',
          rest_s: te.rest_seconds || 90,
          equipment: te.exercises.equipment,
          primary_muscles: te.exercises.primary_muscles
        }))
    };

    onStartWorkout(workout);
    toast.success(`🔥 ${template.name} iniciado!`);
  };


  if (loading) {
    return (
      <div className="space-y-3">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="glass-card p-4 animate-pulse">
            <div className="h-4 bg-surface rounded w-3/4 mb-2"></div>
            <div className="h-3 bg-surface rounded w-1/2 mb-3"></div>
            <div className="h-8 bg-surface rounded w-full"></div>
          </div>
        ))}
      </div>
    );
  }

  if (templates.length === 0) {
    return (
      <div className="text-center py-8">
        <Target className="w-12 h-12 text-txt-3 mx-auto mb-4" />
        <p className="text-txt-2">Nenhum template disponível</p>
      </div>
    );
  }

  return (
    <div className="space-y-3 md:space-y-4">
      <div className="text-center mb-4">
        <h2 className="text-lg font-semibold text-txt mb-2">
          🏋️ Templates de Treino
        </h2>
        <p className="text-sm text-txt-2">
          Treinos prontos criados por especialistas
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {templates.map((template) => (
          <WorkoutTemplateCardMobile
            key={template.id}
            name={template.name}
            description={template.description}
            category={template.focus}
            difficulty={template.difficulty_level}
            exerciseCount={template.template_exercises?.length || 0}
            duration={template.estimated_duration}
            muscleGroups={template.target_muscle_groups || []}
            onStart={() => handleStartTemplate(template)}
          />
        ))}
      </div>
    </div>
  );
};

export default MobileWorkoutTemplates;