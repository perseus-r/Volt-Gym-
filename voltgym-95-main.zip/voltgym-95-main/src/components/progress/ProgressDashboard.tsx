/**
 * ProgressDashboard - Página de visualização de progresso e evolução
 * 
 * Exibe:
 * - Estatísticas da semana atual vs anterior
 * - Gráficos de evolução de volume e consistência
 * - PRs conquistados
 * - Histórico de semanas
 */

import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  TrendingUp, 
  TrendingDown, 
  Trophy, 
  Target, 
  Calendar, 
  Dumbbell, 
  Flame,
  Clock,
  ChevronRight,
  RefreshCw,
  Award,
  BarChart3
} from 'lucide-react';
import { useWeeklyProgress } from '@/hooks/useWeeklyProgress';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Area, AreaChart } from 'recharts';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { cn } from '@/lib/utils';

interface ProgressDashboardProps {
  className?: string;
}

export function ProgressDashboard({ className }: ProgressDashboardProps) {
  const {
    currentWeek,
    previousWeek,
    volumeChangePercent,
    workoutsChangePercent,
    recentPRs,
    totalPRsThisWeek,
    chartData,
    archivedWeeks,
    loading,
    refresh,
  } = useWeeklyProgress();
  
  const [activeTab, setActiveTab] = useState('overview');

  const formatVolume = (value: number) => {
    if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `${(value / 1000).toFixed(1)}K`;
    return value.toFixed(0);
  };

  const formatChange = (value: number) => {
    const sign = value >= 0 ? '+' : '';
    return `${sign}${value.toFixed(1)}%`;
  };

  if (loading) {
    return (
      <div className={cn("flex items-center justify-center p-8", className)}>
        <RefreshCw className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className={cn("space-y-6", className)}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Seu Progresso</h2>
          <p className="text-sm text-muted-foreground">{currentWeek?.weekLabel || 'Esta semana'}</p>
        </div>
        <Button variant="outline" size="sm" onClick={refresh}>
          <RefreshCw className="w-4 h-4 mr-2" />
          Atualizar
        </Button>
      </div>

      {/* Main Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Volume Total */}
        <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Dumbbell className="w-4 h-4 text-primary" />
              <span className="text-xs text-muted-foreground">Volume Total</span>
            </div>
            <div className="text-2xl font-bold text-foreground">
              {formatVolume(currentWeek?.totalVolume || 0)}kg
            </div>
            <div className={cn(
              "flex items-center gap-1 text-xs mt-1",
              volumeChangePercent >= 0 ? "text-green-500" : "text-red-500"
            )}>
              {volumeChangePercent >= 0 ? (
                <TrendingUp className="w-3 h-3" />
              ) : (
                <TrendingDown className="w-3 h-3" />
              )}
              {formatChange(volumeChangePercent)} vs semana anterior
            </div>
          </CardContent>
        </Card>

        {/* Treinos */}
        <Card className="bg-gradient-to-br from-accent/10 to-accent/5 border-accent/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="w-4 h-4 text-accent" />
              <span className="text-xs text-muted-foreground">Treinos</span>
            </div>
            <div className="text-2xl font-bold text-foreground">
              {currentWeek?.workoutsCompleted || 0}
            </div>
            <div className={cn(
              "flex items-center gap-1 text-xs mt-1",
              workoutsChangePercent >= 0 ? "text-green-500" : "text-red-500"
            )}>
              {workoutsChangePercent >= 0 ? (
                <TrendingUp className="w-3 h-3" />
              ) : (
                <TrendingDown className="w-3 h-3" />
              )}
              {formatChange(workoutsChangePercent)} vs semana anterior
            </div>
          </CardContent>
        </Card>

        {/* PRs */}
        <Card className="bg-gradient-to-br from-yellow-500/10 to-yellow-500/5 border-yellow-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Trophy className="w-4 h-4 text-yellow-500" />
              <span className="text-xs text-muted-foreground">PRs Esta Semana</span>
            </div>
            <div className="text-2xl font-bold text-foreground">
              {totalPRsThisWeek}
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              recordes pessoais
            </div>
          </CardContent>
        </Card>

        {/* Consistência */}
        <Card className="bg-gradient-to-br from-green-500/10 to-green-500/5 border-green-500/20">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Target className="w-4 h-4 text-green-500" />
              <span className="text-xs text-muted-foreground">Consistência</span>
            </div>
            <div className="text-2xl font-bold text-foreground">
              {currentWeek?.consistencyScore?.toFixed(0) || 0}%
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              meta: 4 treinos/semana
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3 bg-muted/50">
          <TabsTrigger value="overview">
            <BarChart3 className="w-4 h-4 mr-2" />
            Evolução
          </TabsTrigger>
          <TabsTrigger value="prs">
            <Trophy className="w-4 h-4 mr-2" />
            PRs
          </TabsTrigger>
          <TabsTrigger value="history">
            <Calendar className="w-4 h-4 mr-2" />
            Histórico
          </TabsTrigger>
        </TabsList>

        {/* Evolution Tab */}
        <TabsContent value="overview" className="space-y-4 mt-4">
          {/* Volume Chart */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Dumbbell className="w-4 h-4 text-primary" />
                Evolução de Volume (kg)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData.volume}>
                    <defs>
                      <linearGradient id="volumeGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                        <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="week" 
                      tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }}
                      axisLine={{ stroke: 'hsl(var(--border))' }}
                    />
                    <YAxis 
                      tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }}
                      axisLine={{ stroke: 'hsl(var(--border))' }}
                      tickFormatter={formatVolume}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                      labelStyle={{ color: 'hsl(var(--foreground))' }}
                      formatter={(value: number) => [`${formatVolume(value)}kg`, 'Volume']}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="value" 
                      stroke="hsl(var(--primary))" 
                      fill="url(#volumeGradient)"
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Workouts Chart */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Calendar className="w-4 h-4 text-accent" />
                Treinos por Semana
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[160px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData.workouts}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="week" 
                      tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }}
                    />
                    <YAxis 
                      tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                      formatter={(value: number) => [value, 'Treinos']}
                    />
                    <Bar 
                      dataKey="value" 
                      fill="hsl(var(--accent))" 
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Consistency Chart */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Target className="w-4 h-4 text-green-500" />
                Consistência (%)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[160px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData.consistency}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="week" 
                      tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }}
                    />
                    <YAxis 
                      domain={[0, 100]}
                      tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }}
                    />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: 'hsl(var(--card))',
                        border: '1px solid hsl(var(--border))',
                        borderRadius: '8px',
                      }}
                      formatter={(value: number) => [`${value.toFixed(0)}%`, 'Consistência']}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="value" 
                      stroke="#22c55e" 
                      strokeWidth={2}
                      dot={{ fill: '#22c55e', strokeWidth: 2 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* PRs Tab */}
        <TabsContent value="prs" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Trophy className="w-4 h-4 text-yellow-500" />
                Recordes Pessoais Recentes
              </CardTitle>
            </CardHeader>
            <CardContent>
              {recentPRs.length > 0 ? (
                <ScrollArea className="h-[300px]">
                  <div className="space-y-3">
                    {recentPRs.map((pr, index) => (
                      <div 
                        key={pr.id || index}
                        className="flex items-center justify-between p-3 bg-muted/30 rounded-lg border border-border/50"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-yellow-500/20 flex items-center justify-center">
                            <Award className="w-5 h-5 text-yellow-500" />
                          </div>
                          <div>
                            <p className="font-medium text-foreground">{pr.exercise_name}</p>
                            <p className="text-xs text-muted-foreground">
                              {format(new Date(pr.achieved_at), "d 'de' MMM, HH:mm", { locale: ptBR })}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-foreground">{pr.weight}kg</p>
                          <p className="text-xs text-muted-foreground">{pr.reps} reps</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              ) : (
                <div className="text-center py-8">
                  <Trophy className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                  <p className="text-muted-foreground">Nenhum PR esta semana</p>
                  <p className="text-xs text-muted-foreground/70 mt-1">
                    Continue treinando para quebrar recordes!
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* History Tab */}
        <TabsContent value="history" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Calendar className="w-4 h-4 text-primary" />
                Histórico de Semanas
              </CardTitle>
            </CardHeader>
            <CardContent>
              {archivedWeeks.length > 0 ? (
                <ScrollArea className="h-[300px]">
                  <div className="space-y-3">
                    {archivedWeeks.map((week, index) => (
                      <div 
                        key={index}
                        className="flex items-center justify-between p-3 bg-muted/30 rounded-lg border border-border/50"
                      >
                        <div>
                          <p className="font-medium text-foreground">{week.weekLabel}</p>
                          <div className="flex items-center gap-3 mt-1">
                            <Badge variant="outline" className="text-xs">
                              <Dumbbell className="w-3 h-3 mr-1" />
                              {week.stats.workoutsCompleted} treinos
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              <Trophy className="w-3 h-3 mr-1" />
                              {week.stats.prsAchieved} PRs
                            </Badge>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-foreground">
                            {formatVolume(week.stats.totalVolume)}kg
                          </p>
                          <p className="text-xs text-muted-foreground">volume total</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              ) : (
                <div className="text-center py-8">
                  <Calendar className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                  <p className="text-muted-foreground">Nenhum histórico ainda</p>
                  <p className="text-xs text-muted-foreground/70 mt-1">
                    Complete sua primeira semana de treinos
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
