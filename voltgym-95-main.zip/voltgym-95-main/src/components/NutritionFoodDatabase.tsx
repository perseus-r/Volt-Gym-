import React, { useState, useEffect } from 'react';
import { Search, Plus, X, Filter } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { VoltCard } from '@/components/VoltCard';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { motion, AnimatePresence } from 'framer-motion';
import { ScrollArea } from '@/components/ui/scroll-area';

interface Food {
  id: string;
  name: string;
  category: string;
  calories_per_100g: number;
  protein_per_100g: number;
  carbs_per_100g: number;
  fat_per_100g: number;
  fiber_per_100g?: number;
}

interface NutritionFoodDatabaseProps {
  onAddFood: (food: Food, amount: number) => void;
}

const categoryColors = {
  proteina: 'bg-red-500/20 text-red-300',
  carboidrato: 'bg-yellow-500/20 text-yellow-300',
  gordura: 'bg-green-500/20 text-green-300',
  vegetal: 'bg-emerald-500/20 text-emerald-300',
  fruta: 'bg-pink-500/20 text-pink-300',
  bebida: 'bg-blue-500/20 text-blue-300',
  outro: 'bg-gray-500/20 text-gray-300'
};

const categoryLabels = {
  proteina: 'Proteína',
  carboidrato: 'Carboidrato',
  gordura: 'Gordura',
  vegetal: 'Vegetal',
  fruta: 'Fruta',
  bebida: 'Bebida',
  outro: 'Outro'
};

export function NutritionFoodDatabase({ onAddFood }: NutritionFoodDatabaseProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [foods, setFoods] = useState<Food[]>([]);
  const [filteredFoods, setFilteredFoods] = useState<Food[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedFood, setSelectedFood] = useState<Food | null>(null);
  const [amount, setAmount] = useState('100');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadFoods();
  }, []);

  useEffect(() => {
    filterFoods();
  }, [searchQuery, selectedCategory, foods]);

  const loadFoods = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('nutrition_foods')
      .select('*')
      .order('name');

    if (error) {
      console.error('Error loading foods:', error);
      toast({
        title: 'Erro',
        description: 'Não foi possível carregar os alimentos',
        variant: 'destructive'
      });
    } else {
      setFoods(data || []);
    }
    setLoading(false);
  };

  const filterFoods = () => {
    let filtered = foods;

    if (searchQuery) {
      filtered = filtered.filter(food =>
        food.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(food => food.category === selectedCategory);
    }

    setFilteredFoods(filtered);
  };

  const handleAddFood = () => {
    if (!selectedFood) return;
    
    const amountNum = parseInt(amount) || 100;
    onAddFood(selectedFood, amountNum);
    setSelectedFood(null);
    setAmount('100');
    
    toast({
      title: 'Alimento adicionado',
      description: `${amountNum}g de ${selectedFood.name}`,
    });
  };

  const quickAdd = (food: Food, grams: number) => {
    onAddFood(food, grams);
    toast({
      title: 'Adicionado rapidamente',
      description: `${grams}g de ${food.name}`,
    });
  };

  const categories = ['all', 'proteina', 'carboidrato', 'gordura', 'vegetal', 'fruta', 'bebida'];

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-txt-3" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar alimento..."
            className="pl-10"
          />
        </div>
      </div>

      <ScrollArea className="flex gap-2 overflow-x-auto pb-2">
        <div className="flex gap-2 min-w-max">
          {categories.map((cat) => (
            <Badge
              key={cat}
              variant={selectedCategory === cat ? 'default' : 'outline'}
              className="cursor-pointer whitespace-nowrap"
              onClick={() => setSelectedCategory(cat)}
            >
              {cat === 'all' ? 'Todos' : categoryLabels[cat as keyof typeof categoryLabels]}
            </Badge>
          ))}
        </div>
      </ScrollArea>

      {loading ? (
        <div className="text-center py-8 text-txt-3">Carregando...</div>
      ) : (
        <ScrollArea className="h-[400px]">
          <div className="space-y-2">
            <AnimatePresence mode="popLayout">
              {filteredFoods.map((food) => (
                <motion.div
                  key={food.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  layout
                >
                  <VoltCard
                    className="p-3 cursor-pointer hover:border-accent transition-colors"
                    onClick={() => setSelectedFood(food)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <p className="font-medium text-sm">{food.name}</p>
                          <Badge className={categoryColors[food.category as keyof typeof categoryColors]}>
                            {categoryLabels[food.category as keyof typeof categoryLabels]}
                          </Badge>
                        </div>
                        <div className="flex gap-4 text-xs text-txt-3">
                          <span>{food.calories_per_100g} kcal</span>
                          <span>P: {food.protein_per_100g}g</span>
                          <span>C: {food.carbs_per_100g}g</span>
                          <span>G: {food.fat_per_100g}g</span>
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            quickAdd(food, 100);
                          }}
                        >
                          +100g
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            quickAdd(food, 200);
                          }}
                        >
                          +200g
                        </Button>
                      </div>
                    </div>
                  </VoltCard>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </ScrollArea>
      )}

      {selectedFood && (
        <VoltCard className="p-4 border-2 border-accent" glow>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">{selectedFood.name}</h3>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setSelectedFood(null)}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>

            <div className="flex gap-2 items-end">
              <div className="flex-1">
                <label className="text-xs text-txt-3 mb-1 block">Quantidade (g)</label>
                <Input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  min="1"
                />
              </div>
              <Button onClick={handleAddFood}>
                <Plus className="w-4 h-4 mr-2" />
                Adicionar
              </Button>
            </div>

            <div className="grid grid-cols-2 gap-2 text-sm">
              <div className="bg-surface/50 rounded p-2">
                <p className="text-txt-3 text-xs">Calorias</p>
                <p className="font-semibold">
                  {Math.round((selectedFood.calories_per_100g * parseInt(amount || '0')) / 100)} kcal
                </p>
              </div>
              <div className="bg-surface/50 rounded p-2">
                <p className="text-txt-3 text-xs">Proteína</p>
                <p className="font-semibold">
                  {Math.round((selectedFood.protein_per_100g * parseInt(amount || '0')) / 100)}g
                </p>
              </div>
              <div className="bg-surface/50 rounded p-2">
                <p className="text-txt-3 text-xs">Carboidrato</p>
                <p className="font-semibold">
                  {Math.round((selectedFood.carbs_per_100g * parseInt(amount || '0')) / 100)}g
                </p>
              </div>
              <div className="bg-surface/50 rounded p-2">
                <p className="text-txt-3 text-xs">Gordura</p>
                <p className="font-semibold">
                  {Math.round((selectedFood.fat_per_100g * parseInt(amount || '0')) / 100)}g
                </p>
              </div>
            </div>
          </div>
        </VoltCard>
      )}
    </div>
  );
}
