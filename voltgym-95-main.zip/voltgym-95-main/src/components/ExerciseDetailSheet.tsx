import { BottomSheet } from './BottomSheet';
import { VoltCard } from './VoltCard';
import { PremiumBadge } from './PremiumBadge';
import { VoltButton } from './VoltButton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Dumbbell, Heart, Share2, CheckCircle, AlertCircle, Target, Youtube, VideoOff } from 'lucide-react';
import { motion } from 'framer-motion';
import YouTubePlayer from './YouTubePlayer';
import { getYouTubeId } from '@/utils/youtube';

interface ExerciseDetailSheetProps {
  isOpen: boolean;
  onClose: () => void;
  exercise: {
    id: string;
    name: string;
    category_id?: string;
    primary_muscles?: string[];
    secondary_muscles?: string[];
    equipment?: string;
    difficulty_level?: number;
    instructions?: string[];
    form_tips?: string[];
    demo_video_url?: string;
    thumbnail_url?: string;
    youtube_url?: string;
    youtube_video_id?: string;
  } | null;
  onAddToWorkout?: () => void;
  onToggleFavorite?: () => void;
  isFavorite?: boolean;
}

export function ExerciseDetailSheet({
  isOpen,
  onClose,
  exercise,
  onAddToWorkout,
  onToggleFavorite,
  isFavorite = false
}: ExerciseDetailSheetProps) {
  if (!exercise) return null;

  const getDifficultyLabel = (level: number) => {
    const labels = ['Iniciante', 'Intermediário', 'Avançado', 'Expert'];
    return labels[level - 1] || 'Intermediário';
  };

  const getDifficultyColor = (level: number) => {
    const colors = ['success', 'info', 'warning', 'error'];
    return colors[level - 1] || 'info';
  };

  return (
    <BottomSheet isOpen={isOpen} onClose={onClose} title={exercise.name}>
      <div className="space-y-stack-lg p-gutter">
        {/* Thumbnail */}
        {exercise.thumbnail_url && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative w-full aspect-video rounded-2xl overflow-hidden"
          >
            <img 
              src={exercise.thumbnail_url} 
              alt={exercise.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-bg/80 to-transparent" />
          </motion.div>
        )}

        {/* Header Info */}
        <VoltCard variant="glass" className="card-padding-sm">
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1">
              <h3 className="text-card-title mb-2">{exercise.name}</h3>
              <div className="flex items-center gap-2 flex-wrap">
                {exercise.difficulty_level && (
                  <PremiumBadge variant={getDifficultyColor(exercise.difficulty_level) as any}>
                    {getDifficultyLabel(exercise.difficulty_level)}
                  </PremiumBadge>
                )}
                {exercise.equipment && (
                  <Badge variant="outline" className="text-label">
                    <Dumbbell className="w-3 h-3 mr-1" />
                    {exercise.equipment}
                  </Badge>
                )}
              </div>
            </div>

            {/* Favorite Button */}
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={onToggleFavorite}
              className="p-2 rounded-xl glass-subtle hover-scale"
            >
              <Heart 
                className={`w-5 h-5 transition-colors ${
                  isFavorite ? 'fill-accent text-accent' : 'text-txt-3'
                }`}
              />
            </motion.button>
          </div>
        </VoltCard>

        {/* Muscles */}
        {(exercise.primary_muscles || exercise.secondary_muscles) && (
          <VoltCard variant="glass" className="card-padding-sm">
            <div className="space-y-3">
              {exercise.primary_muscles && exercise.primary_muscles.length > 0 && (
                <div>
                  <p className="text-label text-txt-3 mb-2">Músculos Primários</p>
                  <div className="flex flex-wrap gap-2">
                    {exercise.primary_muscles.map((muscle, idx) => (
                      <Badge key={idx} className="bg-accent/20 text-accent border-accent/50">
                        <Target className="w-3 h-3 mr-1" />
                        {muscle}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
              {exercise.secondary_muscles && exercise.secondary_muscles.length > 0 && (
                <div>
                  <p className="text-label text-txt-3 mb-2">Músculos Secundários</p>
                  <div className="flex flex-wrap gap-2">
                    {exercise.secondary_muscles.map((muscle, idx) => (
                      <Badge key={idx} variant="outline" className="text-txt-2">
                        {muscle}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </VoltCard>
        )}

        {/* Vídeo Demonstrativo */}
        {(exercise.youtube_url || exercise.youtube_video_id) && (
          <VoltCard variant="glass" className="card-padding-md">
            <div className="space-y-3">
              <h3 className="text-base font-semibold text-txt flex items-center gap-2">
                <Youtube className="w-5 h-5 text-accent" />
                Vídeo Demonstrativo
              </h3>
              
              <YouTubePlayer
                url={exercise.youtube_url || `https://www.youtube.com/watch?v=${exercise.youtube_video_id}`}
                title={exercise.name}
                className="w-full"
              />
            </div>
          </VoltCard>
        )}

        {!exercise.youtube_url && !exercise.youtube_video_id && (
          <VoltCard variant="glass" className="card-padding-md">
            <div className="text-center py-8 text-txt-3">
              <VideoOff className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p className="text-body-premium">Este exercício ainda não tem vídeo demonstrativo</p>
            </div>
          </VoltCard>
        )}

        {/* Tabs Content */}
        <Tabs defaultValue="instructions" className="w-full">
          <TabsList className="w-full glass-subtle grid grid-cols-2 p-1">
            <TabsTrigger value="instructions" className="text-label glass-glow">
              Execução
            </TabsTrigger>
            <TabsTrigger value="tips" className="text-label glass-glow">
              Dicas
            </TabsTrigger>
          </TabsList>

          <TabsContent value="instructions" className="mt-stack-md">
            <VoltCard variant="glass" className="card-padding-md">
              {exercise.instructions && exercise.instructions.length > 0 ? (
                <ol className="space-y-3">
                  {exercise.instructions.map((instruction, idx) => (
                    <li key={idx} className="flex gap-3">
                      <span className="flex-shrink-0 w-6 h-6 rounded-lg bg-accent/20 text-accent flex items-center justify-center text-sm font-bold">
                        {idx + 1}
                      </span>
                      <p className="text-body-premium text-txt-2 flex-1">{instruction}</p>
                    </li>
                  ))}
                </ol>
              ) : (
                <p className="text-body-premium text-txt-3 text-center py-4">
                  Instruções não disponíveis
                </p>
              )}
            </VoltCard>
          </TabsContent>

          <TabsContent value="tips" className="mt-stack-md">
            <VoltCard variant="glass" className="card-padding-md">
              {exercise.form_tips && exercise.form_tips.length > 0 ? (
                <ul className="space-y-3">
                  {exercise.form_tips.map((tip, idx) => (
                    <li key={idx} className="flex gap-3">
                      <CheckCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                      <p className="text-body-premium text-txt-2 flex-1">{tip}</p>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-body-premium text-txt-3 text-center py-4">
                  Dicas não disponíveis
                </p>
              )}
            </VoltCard>
          </TabsContent>
        </Tabs>

        {/* Action Buttons */}
        <div className="flex gap-3 pt-stack-sm sticky bottom-0 bg-bg/80 backdrop-blur-xl pb-safe">
          <VoltButton
            variant="outline"
            onClick={() => {
              if (navigator.share) {
                navigator.share({
                  title: exercise.name,
                  text: `Confira o exercício ${exercise.name} no VOLT!`
                });
              }
            }}
            className="flex-1"
          >
            <Share2 className="w-4 h-4 mr-2" />
            Compartilhar
          </VoltButton>
          
          {onAddToWorkout && (
            <VoltButton
              onClick={() => {
                onAddToWorkout();
                onClose();
              }}
              className="flex-1"
            >
              <Dumbbell className="w-4 h-4 mr-2" />
              Adicionar ao Treino
            </VoltButton>
          )}
        </div>
      </div>
    </BottomSheet>
  );
}