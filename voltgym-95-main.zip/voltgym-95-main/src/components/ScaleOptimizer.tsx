/**
 * ScaleOptimizer - Performance Monitoring Component
 * 
 * IMPORTANT: Realtime is NO LONGER disabled here.
 * This component now only monitors performance metrics without
 * breaking sync functionality.
 */

import React, { useEffect, useState } from 'react';

interface LoadMetrics {
  activeUsers: number;
  responseTime: number;
  memoryUsage: number;
}

export const ScaleOptimizer: React.FC = () => {
  const [metrics, setMetrics] = useState<LoadMetrics>({
    activeUsers: 0,
    responseTime: 0,
    memoryUsage: 0,
  });

  useEffect(() => {
    // Memory optimization - only cleanup, no realtime disabling
    const optimizeMemory = () => {
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.getRegistrations().then(registrations => {
          registrations.forEach(registration => {
            if (registration.waiting) {
              registration.waiting.postMessage({ type: 'SKIP_WAITING' });
            }
          });
        });
      }
    };

    // Run memory optimization periodically
    const memoryInterval = setInterval(optimizeMemory, 300000); // Every 5 min

    // Simulate load metrics for monitoring
    const metricsInterval = setInterval(() => {
      const performance = window.performance;
      const memory = (performance as any).memory;
      
      setMetrics({
        activeUsers: Math.floor(Math.random() * 100) + 1,
        responseTime: Math.floor(Math.random() * 50) + 10,
        memoryUsage: memory ? Math.round(memory.usedJSHeapSize / 1048576) : 0,
      });
    }, 30000);

    return () => {
      clearInterval(memoryInterval);
      clearInterval(metricsInterval);
    };
  }, []);

  // Minimal UI - just for monitoring, hidden by default
  return null;
};

export default ScaleOptimizer;
