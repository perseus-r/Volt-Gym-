import React, { useEffect, useState, useRef } from "react";
import { motion, useSpring, useTransform, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";
import { hapticLight, hapticMedium, hapticSuccess } from "@/utils/haptics";

/**
 * MicroInteractions - Premium micro-interaction components
 * Features:
 * - Animated counters with easing
 * - Haptic feedback visual indicators
 * - Breathing animations
 * - Success/Error state transitions
 * - Shimmer skeleton loaders
 */

// ============================================
// ANIMATED COUNTER
// ============================================

interface AnimatedCounterProps {
  value: number;
  duration?: number;
  className?: string;
  prefix?: string;
  suffix?: string;
  decimals?: number;
  onComplete?: () => void;
}

export const AnimatedCounter: React.FC<AnimatedCounterProps> = ({
  value,
  duration = 1,
  className,
  prefix = "",
  suffix = "",
  decimals = 0,
  onComplete,
}) => {
  const spring = useSpring(0, {
    stiffness: 100,
    damping: 30,
    duration: duration * 1000,
  });

  const display = useTransform(spring, (current) =>
    `${prefix}${current.toFixed(decimals)}${suffix}`
  );

  const [displayValue, setDisplayValue] = useState(`${prefix}0${suffix}`);

  useEffect(() => {
    spring.set(value);
    
    const unsubscribe = display.on("change", (latest) => {
      setDisplayValue(latest);
    });

    const timeout = setTimeout(() => {
      onComplete?.();
    }, duration * 1000);

    return () => {
      unsubscribe();
      clearTimeout(timeout);
    };
  }, [value, spring, display, duration, onComplete]);

  return (
    <motion.span
      className={cn("tabular-nums", className)}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      {displayValue}
    </motion.span>
  );
};

// ============================================
// BREATHING ANIMATION
// ============================================

interface BreathingProps {
  children: React.ReactNode;
  className?: string;
  intensity?: "subtle" | "normal" | "strong";
  speed?: "slow" | "normal" | "fast";
}

const breathingIntensity = {
  subtle: { scale: [1, 1.02, 1], opacity: [1, 0.9, 1] },
  normal: { scale: [1, 1.05, 1], opacity: [1, 0.85, 1] },
  strong: { scale: [1, 1.08, 1], opacity: [1, 0.8, 1] },
};

const breathingSpeed = {
  slow: 4,
  normal: 2.5,
  fast: 1.5,
};

export const Breathing: React.FC<BreathingProps> = ({
  children,
  className,
  intensity = "subtle",
  speed = "normal",
}) => {
  return (
    <motion.div
      className={className}
      animate={breathingIntensity[intensity]}
      transition={{
        duration: breathingSpeed[speed],
        repeat: Infinity,
        ease: "easeInOut",
      }}
    >
      {children}
    </motion.div>
  );
};

// ============================================
// HAPTIC BUTTON
// ============================================

interface HapticButtonProps {
  hapticType?: "light" | "medium" | "success";
  children: React.ReactNode;
  className?: string;
  variant?: "default" | "pulse" | "glow";
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  type?: "button" | "submit" | "reset";
  disabled?: boolean;
}

export const HapticButton: React.FC<HapticButtonProps> = ({
  hapticType = "light",
  children,
  className,
  variant = "default",
  onClick,
  ...props
}) => {
  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    // Trigger haptic
    switch (hapticType) {
      case "medium":
        hapticMedium();
        break;
      case "success":
        hapticSuccess();
        break;
      default:
        hapticLight();
    }
    onClick?.(e);
  };

  const pulseVariant = variant === "pulse" && (
    <motion.span
      className="absolute inset-0 rounded-[inherit] bg-accent/30"
      animate={{ scale: [1, 1.5], opacity: [0.5, 0] }}
      transition={{ duration: 1.5, repeat: Infinity }}
    />
  );

  const glowVariant = variant === "glow" && (
    <motion.span
      className="absolute inset-0 rounded-[inherit] blur-xl bg-accent/40 -z-10"
      animate={{ opacity: [0.4, 0.7, 0.4] }}
      transition={{ duration: 2, repeat: Infinity }}
    />
  );

  return (
    <motion.button
      className={cn("relative", className)}
      whileTap={{ scale: 0.95 }}
      whileHover={{ scale: 1.02 }}
      transition={{ type: "spring", stiffness: 400, damping: 17 }}
      onClick={handleClick}
      type={props.type || "button"}
      disabled={props.disabled}
    >
      {pulseVariant}
      {glowVariant}
      {children}
    </motion.button>
  );
};

// ============================================
// STATE TRANSITION
// ============================================

type TransitionState = "idle" | "loading" | "success" | "error";

interface StateTransitionProps {
  state: TransitionState;
  children: React.ReactNode;
  className?: string;
  successContent?: React.ReactNode;
  errorContent?: React.ReactNode;
  loadingContent?: React.ReactNode;
}

export const StateTransition: React.FC<StateTransitionProps> = ({
  state,
  children,
  className,
  successContent,
  errorContent,
  loadingContent,
}) => {
  const stateColors = {
    idle: "",
    loading: "text-txt-2",
    success: "text-success",
    error: "text-destructive",
  };

  const stateIcons = {
    loading: loadingContent || (
      <motion.div
        className="w-5 h-5 border-2 border-current border-t-transparent rounded-full"
        animate={{ rotate: 360 }}
        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
      />
    ),
    success: successContent || (
      <motion.svg
        className="w-5 h-5"
        viewBox="0 0 24 24"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 0.5 }}
      >
        <motion.path
          d="M5 13l4 4L19 7"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </motion.svg>
    ),
    error: errorContent || (
      <motion.svg
        className="w-5 h-5"
        viewBox="0 0 24 24"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: "spring", stiffness: 500, damping: 25 }}
      >
        <path
          d="M18 6L6 18M6 6l12 12"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
        />
      </motion.svg>
    ),
  };

  return (
    <div className={cn("relative", className)}>
      <AnimatePresence mode="wait">
        {state === "idle" ? (
          <motion.div
            key="idle"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {children}
          </motion.div>
        ) : (
          <motion.div
            key={state}
            className={cn("flex items-center justify-center", stateColors[state])}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ type: "spring", stiffness: 500, damping: 30 }}
          >
            {stateIcons[state]}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

// ============================================
// SHIMMER SKELETON
// ============================================

interface ShimmerSkeletonProps {
  className?: string;
  variant?: "text" | "circle" | "rect" | "card";
  lines?: number;
}

export const ShimmerSkeleton: React.FC<ShimmerSkeletonProps> = ({
  className,
  variant = "rect",
  lines = 1,
}) => {
  const baseClasses = "relative overflow-hidden bg-white/5 animate-pulse";
  
  const shimmerOverlay = (
    <div 
      className="absolute inset-0 -translate-x-full animate-[shimmer_2s_infinite]"
      style={{
        background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.08), transparent)"
      }}
    />
  );

  if (variant === "text") {
    return (
      <div className={cn("space-y-2", className)}>
        {Array.from({ length: lines }).map((_, i) => (
          <div
            key={i}
            className={cn(
              baseClasses,
              "h-4 rounded-md",
              i === lines - 1 ? "w-3/4" : "w-full"
            )}
          >
            {shimmerOverlay}
          </div>
        ))}
      </div>
    );
  }

  if (variant === "circle") {
    return (
      <div className={cn(baseClasses, "w-12 h-12 rounded-full", className)}>
        {shimmerOverlay}
      </div>
    );
  }

  if (variant === "card") {
    return (
      <div className={cn(baseClasses, "rounded-2xl p-4", className)}>
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-white/10" />
            <div className="flex-1 space-y-2">
              <div className="h-3 bg-white/10 rounded w-1/2" />
              <div className="h-2 bg-white/10 rounded w-1/3" />
            </div>
          </div>
          <div className="h-20 bg-white/5 rounded-xl" />
          <div className="flex gap-2">
            <div className="h-8 bg-white/10 rounded-lg flex-1" />
            <div className="h-8 bg-white/10 rounded-lg w-20" />
          </div>
        </div>
        {shimmerOverlay}
      </div>
    );
  }

  return (
    <div className={cn(baseClasses, "h-20 rounded-xl", className)}>
      {shimmerOverlay}
    </div>
  );
};

// ============================================
// RIPPLE EFFECT
// ============================================

interface RippleEffectProps {
  children: React.ReactNode;
  className?: string;
  color?: string;
}

export const RippleEffect: React.FC<RippleEffectProps> = ({
  children,
  className,
  color = "rgba(255,255,255,0.3)",
}) => {
  const [ripples, setRipples] = useState<Array<{ x: number; y: number; id: number }>>([]);
  const containerRef = useRef<HTMLDivElement>(null);

  const createRipple = (e: React.MouseEvent) => {
    const container = containerRef.current;
    if (!container) return;

    const rect = container.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const id = Date.now();

    setRipples((prev) => [...prev, { x, y, id }]);
    hapticLight();

    setTimeout(() => {
      setRipples((prev) => prev.filter((r) => r.id !== id));
    }, 600);
  };

  return (
    <div
      ref={containerRef}
      className={cn("relative overflow-hidden", className)}
      onClick={createRipple}
    >
      {children}
      <AnimatePresence>
        {ripples.map((ripple) => (
          <motion.span
            key={ripple.id}
            className="absolute rounded-full pointer-events-none"
            style={{
              left: ripple.x,
              top: ripple.y,
              backgroundColor: color,
              transform: "translate(-50%, -50%)",
            }}
            initial={{ width: 0, height: 0, opacity: 0.5 }}
            animate={{ width: 200, height: 200, opacity: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          />
        ))}
      </AnimatePresence>
    </div>
  );
};

// ============================================
// NUMBER TICKER
// ============================================

interface NumberTickerProps {
  value: number;
  className?: string;
  direction?: "up" | "down";
}

export const NumberTicker: React.FC<NumberTickerProps> = ({
  value,
  className,
  direction = "up",
}) => {
  const [displayValue, setDisplayValue] = useState(value);
  const prevValue = useRef(value);

  useEffect(() => {
    if (value !== prevValue.current) {
      prevValue.current = value;
      setDisplayValue(value);
    }
  }, [value]);

  return (
    <span className={cn("inline-flex overflow-hidden", className)}>
      <AnimatePresence mode="popLayout">
        <motion.span
          key={displayValue}
          initial={{ 
            y: direction === "up" ? 20 : -20, 
            opacity: 0 
          }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ 
            y: direction === "up" ? -20 : 20, 
            opacity: 0 
          }}
          transition={{ 
            type: "spring", 
            stiffness: 500, 
            damping: 30 
          }}
        >
          {displayValue}
        </motion.span>
      </AnimatePresence>
    </span>
  );
};

// ============================================
// PULSE DOT
// ============================================

interface PulseDotProps {
  color?: "accent" | "success" | "warning" | "error";
  size?: "sm" | "md" | "lg";
  className?: string;
}

export const PulseDot: React.FC<PulseDotProps> = ({
  color = "accent",
  size = "md",
  className,
}) => {
  const colors = {
    accent: "bg-accent",
    success: "bg-success",
    warning: "bg-warning",
    error: "bg-destructive",
  };

  const sizes = {
    sm: "w-2 h-2",
    md: "w-3 h-3",
    lg: "w-4 h-4",
  };

  return (
    <span className={cn("relative inline-flex", className)}>
      <span className={cn("rounded-full", colors[color], sizes[size])} />
      <motion.span
        className={cn(
          "absolute inset-0 rounded-full",
          colors[color]
        )}
        animate={{ scale: [1, 2], opacity: [0.5, 0] }}
        transition={{ duration: 1.5, repeat: Infinity }}
      />
    </span>
  );
};

export default {
  AnimatedCounter,
  Breathing,
  HapticButton,
  StateTransition,
  ShimmerSkeleton,
  RippleEffect,
  NumberTicker,
  PulseDot,
};
