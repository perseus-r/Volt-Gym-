import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, XCircle, AlertCircle, Info, X } from 'lucide-react';
import { cn } from '@/lib/utils';

export interface ToastProps {
  id: string;
  title?: string;
  description?: string;
  variant?: 'success' | 'error' | 'warning' | 'info';
  duration?: number;
  onClose?: () => void;
}

interface PremiumToastItemProps extends ToastProps {
  onDismiss: (id: string) => void;
}

function PremiumToastItem({
  id,
  title,
  description,
  variant = 'info',
  duration = 5000,
  onDismiss,
  onClose
}: PremiumToastItemProps) {
  const [progress, setProgress] = useState(100);
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    if (isHovered) return;

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev <= 0) {
          clearInterval(interval);
          onDismiss(id);
          onClose?.();
          return 0;
        }
        return prev - (100 / (duration / 50));
      });
    }, 50);

    return () => clearInterval(interval);
  }, [duration, id, onDismiss, onClose, isHovered]);

  const icons = {
    success: CheckCircle2,
    error: XCircle,
    warning: AlertCircle,
    info: Info,
  };

  const Icon = icons[variant];

  const variantStyles = {
    success: 'bg-success/10 border-success/30 text-success',
    error: 'bg-error/10 border-error/30 text-error',
    warning: 'bg-warning/10 border-warning/30 text-warning',
    info: 'bg-accent/10 border-accent/30 text-accent',
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, x: 100, scale: 0.9 }}
      transition={{ 
        duration: 0.3,
        ease: [0.4, 0, 0.2, 1]
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={cn(
        'relative w-full max-w-md overflow-hidden rounded-2xl',
        'glass-ultra backdrop-blur-xl',
        'border shadow-xl',
        variantStyles[variant]
      )}
    >
      {/* Content */}
      <div className="p-4 pr-12">
        <div className="flex items-start gap-3">
          {/* Animated Icon */}
          <motion.div
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ 
              delay: 0.1,
              type: 'spring',
              stiffness: 200,
              damping: 15
            }}
          >
            <Icon className="w-5 h-5" strokeWidth={2} />
          </motion.div>

          {/* Text content */}
          <div className="flex-1 space-y-1">
            {title && (
              <p className="text-card-title text-txt font-semibold">
                {title}
              </p>
            )}
            {description && (
              <p className="text-body-sm text-txt-2">
                {description}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Close button */}
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => {
          onDismiss(id);
          onClose?.();
        }}
        className="absolute top-4 right-4 p-1 rounded-lg hover:bg-white/10 transition-colors"
      >
        <X className="w-4 h-4 text-txt-3" />
      </motion.button>

      {/* Progress bar */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/10">
        <motion.div
          className={cn(
            'h-full',
            variant === 'success' && 'bg-success',
            variant === 'error' && 'bg-error',
            variant === 'warning' && 'bg-warning',
            variant === 'info' && 'bg-accent'
          )}
          initial={{ width: '100%' }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.05, ease: 'linear' }}
        />
      </div>
    </motion.div>
  );
}

// Toast Container Component
interface PremiumToastContainerProps {
  toasts: ToastProps[];
  onDismiss: (id: string) => void;
}

export function PremiumToastContainer({ toasts, onDismiss }: PremiumToastContainerProps) {
  return (
    <div className="fixed top-0 right-0 z-[100] p-4 pointer-events-none">
      <div className="flex flex-col gap-3 items-end pointer-events-auto">
        <AnimatePresence mode="popLayout">
          {toasts.map((toast) => (
            <PremiumToastItem
              key={toast.id}
              {...toast}
              onDismiss={onDismiss}
            />
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}

// Custom Hook for Toast Management
export function usePremiumToast() {
  const [toasts, setToasts] = useState<ToastProps[]>([]);

  const showToast = (toast: Omit<ToastProps, 'id'>) => {
    const id = Math.random().toString(36).substring(7);
    setToasts((prev) => [...prev, { ...toast, id }]);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((toast) => toast.id !== id));
  };

  const success = (title: string, description?: string) => {
    showToast({ title, description, variant: 'success' });
  };

  const error = (title: string, description?: string) => {
    showToast({ title, description, variant: 'error' });
  };

  const warning = (title: string, description?: string) => {
    showToast({ title, description, variant: 'warning' });
  };

  const info = (title: string, description?: string) => {
    showToast({ title, description, variant: 'info' });
  };

  return {
    toasts,
    showToast,
    dismissToast,
    success,
    error,
    warning,
    info,
  };
}
