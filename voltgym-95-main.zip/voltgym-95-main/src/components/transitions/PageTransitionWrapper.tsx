import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLocation } from 'react-router-dom';
import { pageTransitions, easings, durations } from '@/utils/animations';

interface PageTransitionWrapperProps {
  children: React.ReactNode;
  variant?: 'default' | 'slide' | 'fade';
}

export function PageTransitionWrapper({ 
  children, 
  variant = 'default' 
}: PageTransitionWrapperProps) {
  const location = useLocation();
  
  const selectedVariant = pageTransitions[variant];

  return (
    <AnimatePresence mode="wait" initial={false}>
      <motion.div
        key={location.pathname}
        {...selectedVariant}
        style={{
          willChange: 'transform, opacity',
          backfaceVisibility: 'hidden',
          WebkitFontSmoothing: 'antialiased',
        }}
        className="w-full h-full"
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
}

interface TabTransitionProps {
  children: React.ReactNode;
  isActive: boolean;
  className?: string;
}

export function TabTransition({ 
  children, 
  isActive, 
  className = '' 
}: TabTransitionProps) {
  return (
    <AnimatePresence mode="wait">
      {isActive && (
        <motion.div
          initial={{ opacity: 0, y: 12, scale: 0.96 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -12, scale: 1.04 }}
          transition={{
            duration: durations.normal,
            ease: easings.apple,
          }}
          style={{
            willChange: 'transform, opacity',
            backfaceVisibility: 'hidden',
          }}
          className={className}
        >
          {children}
        </motion.div>
      )}
    </AnimatePresence>
  );
}

interface StaggeredListProps {
  children: React.ReactNode[];
  className?: string;
  staggerDelay?: number;
}

export function StaggeredList({ 
  children, 
  className = '', 
  staggerDelay = 0.05 
}: StaggeredListProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: staggerDelay,
        delayChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20, scale: 0.95 },
    visible: { 
      opacity: 1, 
      y: 0, 
      scale: 1,
      transition: {
        duration: durations.normal,
        ease: easings.apple,
      }
    },
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className={className}
    >
      {children.map((child, index) => (
        <motion.div
          key={index}
          variants={itemVariants}
          style={{
            willChange: 'transform, opacity',
            backfaceVisibility: 'hidden',
          }}
        >
          {child}
        </motion.div>
      ))}
    </motion.div>
  );
}
