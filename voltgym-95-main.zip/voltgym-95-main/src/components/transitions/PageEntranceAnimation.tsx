import { ReactNode } from 'react';
import { motion } from 'framer-motion';

interface PageEntranceAnimationProps {
  children: ReactNode;
}

// Fast page transition - opacity only to avoid breaking fixed positioning
export function PageEntranceAnimation({ children }: PageEntranceAnimationProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ 
        duration: 0.15, 
        ease: 'easeOut'
      }}
    >
      {children}
    </motion.div>
  );
}
