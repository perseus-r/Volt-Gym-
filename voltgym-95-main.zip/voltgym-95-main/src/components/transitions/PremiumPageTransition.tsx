import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence, Variants } from 'framer-motion';
import { useLocation } from 'react-router-dom';
import { haptic } from '@/utils/haptics';
import { useReducedMotion } from '@/hooks/useReducedMotion';
import { useRouteTheme } from '@/hooks/usePageTheme';

interface PremiumPageTransitionProps {
  children: React.ReactNode;
  variant?: 'slide' | 'fade' | 'scale' | 'youcan' | 'ios' | 'colored';
}

export function PremiumPageTransition({ 
  children, 
  variant = 'youcan' 
}: PremiumPageTransitionProps) {
  const location = useLocation();
  const [direction, setDirection] = useState<'forward' | 'backward'>('forward');
  const [prevPathname, setPrevPathname] = useState(location.pathname);
  const { shouldReduceMotion, shouldDisableBlur, tier, durationMultiplier } = useReducedMotion();
  const theme = useRouteTheme(location.pathname);

  // Detect navigation direction
  useEffect(() => {
    const paths = ['/dashboard', '/treinos', '/progresso', '/ia-coach', '/perfil'];
    const prevIndex = paths.indexOf(prevPathname);
    const currIndex = paths.indexOf(location.pathname);
    
    if (prevIndex !== -1 && currIndex !== -1) {
      setDirection(currIndex > prevIndex ? 'forward' : 'backward');
    }
    
    setPrevPathname(location.pathname);
    
    // Trigger haptic feedback on navigation
    haptic.light();
  }, [location.pathname]);

  // If motion should be reduced, use instant transition
  if (shouldReduceMotion) {
    return <div className="w-full">{children}</div>;
  }

  // Optimized spring settings based on device tier
  const springConfig = tier === 'high' 
    ? { stiffness: 380, damping: 38, mass: 0.8 }
    : tier === 'medium'
      ? { stiffness: 500, damping: 50, mass: 0.5 } // Faster, less bouncy
      : { stiffness: 600, damping: 60, mass: 0.3 }; // Even faster for low-end

  // YouCan/Apple style - horizontal slide (NO BLUR on mobile)
  const youcanVariants: Variants = {
    initial: {
      x: direction === 'forward' ? '50%' : '-50%', // Reduced distance
      opacity: 0,
      // Only apply blur on high-end devices
      ...(shouldDisableBlur ? {} : { filter: 'blur(4px)' }),
    },
    animate: {
      x: 0,
      opacity: 1,
      filter: 'blur(0px)',
      transition: {
        type: 'spring',
        ...springConfig,
      },
    },
    exit: {
      x: direction === 'forward' ? '-20%' : '20%', // Reduced exit distance
      opacity: 0,
      // Only apply blur on high-end devices
      ...(shouldDisableBlur ? {} : { filter: 'blur(4px)' }),
      transition: {
        type: 'spring',
        ...springConfig,
      },
    },
  };

  // Slide variant - clean horizontal slide (optimized)
  const slideVariants: Variants = {
    initial: {
      x: direction === 'forward' ? '30%' : '-30%',
      opacity: 0,
    },
    animate: {
      x: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 400,
        damping: 40,
      },
    },
    exit: {
      x: direction === 'forward' ? '-30%' : '30%',
      opacity: 0,
      transition: {
        duration: 0.15 * durationMultiplier,
      },
    },
  };

  // Fade variant - simple fade (most performant)
  const fadeVariants: Variants = {
    initial: {
      opacity: 0,
    },
    animate: {
      opacity: 1,
      transition: {
        duration: 0.2 * durationMultiplier,
        ease: [0.4, 0, 0.2, 1],
      },
    },
    exit: {
      opacity: 0,
      transition: {
        duration: 0.1 * durationMultiplier,
        ease: [0.4, 0, 1, 1],
      },
    },
  };

  // Scale variant - zoom effect (optimized)
  const scaleVariants: Variants = {
    initial: {
      scale: 0.96,
      opacity: 0,
    },
    animate: {
      scale: 1,
      opacity: 1,
      transition: {
        duration: 0.2 * durationMultiplier,
        ease: [0.4, 0, 0.2, 1],
      },
    },
    exit: {
      scale: 0.98,
      opacity: 0,
      transition: {
        duration: 0.15 * durationMultiplier,
        ease: [0.4, 0, 1, 1],
      },
    },
  };

  // iOS style - push/pop with scale and shadow
  const iosVariants: Variants = {
    initial: {
      x: direction === 'forward' ? '100%' : '-30%',
      scale: direction === 'forward' ? 1 : 0.92,
      opacity: direction === 'forward' ? 1 : 0.5,
    },
    animate: {
      x: 0,
      scale: 1,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 300,
        damping: 30,
        mass: 0.8,
      },
    },
    exit: {
      x: direction === 'forward' ? '-30%' : '100%',
      scale: direction === 'forward' ? 0.92 : 1,
      opacity: direction === 'forward' ? 0.5 : 1,
      transition: {
        type: 'spring',
        stiffness: 300,
        damping: 30,
      },
    },
  };

  const variantsMap = {
    youcan: youcanVariants,
    slide: slideVariants,
    fade: fadeVariants,
    scale: scaleVariants,
    ios: iosVariants,
  };

  const selectedVariant = variantsMap[variant];

  return (
    <AnimatePresence mode="wait" initial={false}>
      <motion.div
        key={location.pathname}
        className="relative w-full"
      >
        {/* Colored overlay during transition */}
        <motion.div
          className="fixed inset-0 pointer-events-none z-40"
          initial={{ opacity: 0.5 }}
          animate={{ opacity: 0 }}
          exit={{ opacity: 0.3 }}
          transition={{ duration: 0.25 }}
          style={{
            background: theme.gradientSubtle,
          }}
        />
        
        {/* Main content with animation */}
        <motion.div
          variants={selectedVariant}
          initial="initial"
          animate="animate"
          exit="exit"
          style={{
            willChange: tier === 'high' ? 'transform, opacity' : 'auto',
            backfaceVisibility: 'hidden',
            WebkitFontSmoothing: 'antialiased',
            position: 'relative',
            width: '100%',
            // iOS-style shadow during transition
            ...(variant === 'ios' ? {
              boxShadow: '0 0 40px rgba(0,0,0,0.3)',
              borderRadius: tier === 'high' ? '12px' : '0',
            } : {}),
          }}
        >
          {children}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// Loading overlay for page transitions - visual only, no text
export function PageLoadingOverlay() {
  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center bg-background/60 backdrop-blur-sm"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.15 }}
    >
      {/* Pulsating glow only - no text */}
      <motion.div
        className="w-24 h-24 rounded-full blur-3xl"
        style={{ background: 'linear-gradient(135deg, hsl(var(--accent)), hsl(var(--primary)))' }}
        animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0.6, 0.3] }}
        transition={{ duration: 1.2, repeat: Infinity, ease: 'easeInOut' }}
      />
    </motion.div>
  );
}
