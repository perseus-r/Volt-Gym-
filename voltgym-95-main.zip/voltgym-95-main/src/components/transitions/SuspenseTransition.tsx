// Simple loading skeleton for Suspense fallback - CSS shimmer only
export function SuspenseTransition() {
  return (
    <div className="min-h-screen bg-background p-4 pt-6">
      <div className="space-y-3 max-w-md mx-auto">
        <div className="h-10 rounded-xl bg-surface/40 shimmer" />
        <div className="h-28 rounded-2xl bg-surface/30 shimmer" />
        <div className="h-14 rounded-xl bg-surface/25 shimmer" />
      </div>
    </div>
  );
}
