import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLocation } from 'react-router-dom';
import { pageVariants, pageSlideVariants, pageFadeVariants } from '@/utils/motion-variants';

interface RouteTransitionProps {
  children: React.ReactNode;
  variant?: 'default' | 'slide' | 'fade';
}

export function RouteTransition({ children, variant = 'default' }: RouteTransitionProps) {
  const location = useLocation();

  const variantMap = {
    default: pageVariants,
    slide: pageSlideVariants,
    fade: pageFadeVariants,
  };

  return (
    <AnimatePresence mode="wait" initial={false}>
      <motion.div
        key={location.pathname}
        variants={variantMap[variant]}
        initial="initial"
        animate="animate"
        exit="exit"
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
}

// Wrapper component to be used in App.tsx
export function RouteTransitionWrapper({ children }: { children: React.ReactNode }) {
  return <RouteTransition variant="default">{children}</RouteTransition>;
}
