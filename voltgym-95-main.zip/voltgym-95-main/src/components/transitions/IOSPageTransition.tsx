import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence, useMotionValue, useTransform, PanInfo } from 'framer-motion';
import { useNavigate, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';

interface IOSPageTransitionProps {
  children: React.ReactNode;
  enableSwipeBack?: boolean;
  parallaxIntensity?: number;
  className?: string;
}

// Track navigation direction
let navigationDirection: 'forward' | 'back' = 'forward';
let previousPath: string = '/';

export function setNavigationDirection(direction: 'forward' | 'back') {
  navigationDirection = direction;
}

export function IOSPageTransition({
  children,
  enableSwipeBack = true,
  parallaxIntensity = 0.3,
  className,
}: IOSPageTransitionProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const [isExiting, setIsExiting] = useState(false);
  
  const x = useMotionValue(0);
  const opacity = useTransform(x, [0, 150], [1, 0.5]);
  const scale = useTransform(x, [0, 300], [1, 0.95]);
  const backgroundX = useTransform(x, [0, 300], [-100 * parallaxIntensity, 0]);
  const blur = useTransform(x, [0, 150], [0, 8]);
  
  // Swipe threshold
  const SWIPE_THRESHOLD = 100;
  const VELOCITY_THRESHOLD = 500;

  useEffect(() => {
    previousPath = location.pathname;
  }, [location.pathname]);

  const handleDragEnd = (event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    const { offset, velocity } = info;
    
    // Only allow swipe from left edge
    if (offset.x > SWIPE_THRESHOLD || velocity.x > VELOCITY_THRESHOLD) {
      setIsExiting(true);
      setNavigationDirection('back');
      
      // Haptic feedback
      if ('vibrate' in navigator) {
        navigator.vibrate(10);
      }
      
      setTimeout(() => {
        navigate(-1);
      }, 100);
    }
  };

  // Page transition variants
  const pageVariants = {
    initial: {
      x: navigationDirection === 'forward' ? '100%' : '-30%',
      opacity: navigationDirection === 'forward' ? 1 : 0.5,
      scale: navigationDirection === 'forward' ? 1 : 0.95,
    },
    animate: {
      x: 0,
      opacity: 1,
      scale: 1,
    },
    exit: {
      x: navigationDirection === 'back' ? '100%' : '-30%',
      opacity: navigationDirection === 'back' ? 1 : 0.5,
      scale: navigationDirection === 'back' ? 1 : 0.95,
    },
  };

  const springTransition = {
    type: 'spring' as const,
    stiffness: 300,
    damping: 30,
    mass: 0.8,
  };

  // Shadow that appears during swipe
  const shadowVariants = {
    initial: { opacity: 0 },
    animate: { opacity: 0 },
    exit: { opacity: 0.3 },
  };

  return (
    <div className={cn('relative min-h-[100dvh] overflow-hidden', className)}>
      {/* Background layer with parallax */}
      <motion.div
        className="absolute inset-0 bg-background"
        style={{ x: backgroundX }}
      />

      {/* Main content with swipe gesture */}
      <AnimatePresence mode="wait" initial={false}>
        <motion.div
          key={location.pathname}
          initial={pageVariants.initial}
          animate={pageVariants.animate}
          exit={pageVariants.exit}
          transition={springTransition}
          drag={enableSwipeBack ? 'x' : false}
          dragDirectionLock
          dragConstraints={{ left: 0, right: 0 }}
          dragElastic={{ left: 0, right: 0.5 }}
          onDragEnd={handleDragEnd}
          style={{
            x: enableSwipeBack ? x : 0,
            scale: enableSwipeBack ? scale : 1,
          }}
          className="relative min-h-[100dvh] bg-background"
        >
          {/* Edge shadow during drag */}
          <motion.div
            className="absolute left-0 top-0 bottom-0 w-8 pointer-events-none"
            style={{
              background: 'linear-gradient(to right, rgba(0,0,0,0.15), transparent)',
              opacity: useTransform(x, [0, 50], [0, 1]),
            }}
          />

          {/* Blur overlay during swipe */}
          <motion.div
            className="absolute inset-0 pointer-events-none bg-background/20"
            style={{
              backdropFilter: `blur(${blur}px)`,
              opacity: useTransform(x, [0, 100], [0, 0.3]),
            }}
          />

          {children}
        </motion.div>
      </AnimatePresence>

      {/* Shadow overlay for previous page effect */}
      <motion.div
        className="absolute inset-0 bg-black pointer-events-none"
        variants={shadowVariants}
        initial="initial"
        animate="animate"
        exit="exit"
      />
    </div>
  );
}

// Hook for swipe navigation
export function useSwipeNavigation(options: {
  onSwipeBack?: () => void;
  threshold?: number;
} = {}) {
  const navigate = useNavigate();
  const { onSwipeBack, threshold = 100 } = options;
  
  const [startX, setStartX] = useState(0);
  const [currentX, setCurrentX] = useState(0);
  const [isSwiping, setIsSwiping] = useState(false);

  const handleTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    // Only start swipe if touching left edge (first 30px)
    if (touch.clientX < 30) {
      setStartX(touch.clientX);
      setCurrentX(touch.clientX);
      setIsSwiping(true);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isSwiping) return;
    const touch = e.touches[0];
    setCurrentX(touch.clientX);
  };

  const handleTouchEnd = () => {
    if (!isSwiping) return;
    
    const diff = currentX - startX;
    if (diff > threshold) {
      setNavigationDirection('back');
      
      // Haptic feedback
      if ('vibrate' in navigator) {
        navigator.vibrate(10);
      }
      
      if (onSwipeBack) {
        onSwipeBack();
      } else {
        navigate(-1);
      }
    }
    
    setIsSwiping(false);
    setStartX(0);
    setCurrentX(0);
  };

  return {
    swipeOffset: currentX - startX,
    isSwiping,
    handlers: {
      onTouchStart: handleTouchStart,
      onTouchMove: handleTouchMove,
      onTouchEnd: handleTouchEnd,
    },
  };
}
