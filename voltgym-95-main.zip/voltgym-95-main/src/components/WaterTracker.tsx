import React, { useState, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import { Droplet, Plus } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export const WaterTracker = React.memo(function WaterTracker() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [consumed, setConsumed] = useState(0);
  const [goal, setGoal] = useState(2000);
  const [logs, setLogs] = useState<{ time: string; ml: number }[]>([]);

  useEffect(() => {
    if (!user) return;
    loadTodayWater();
  }, [user]);

  const loadTodayWater = async () => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const { data, error } = await supabase
        .from('water_logs')
        .select('*')
        .eq('user_id', user!.id)
        .eq('date', today)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setConsumed(data.ml_consumed);
        setGoal(data.goal_ml);
        setLogs((data.logs as { time: string; ml: number }[]) || []);
      }
    } catch (error) {
      console.error('Error loading water data:', error);
    }
  };

  const addWater = async (ml: number) => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const newConsumed = consumed + ml;
      const newLogs = [...logs, { time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }), ml }];

      const { error } = await supabase
        .from('water_logs')
        .upsert({
          user_id: user!.id,
          date: today,
          ml_consumed: newConsumed,
          goal_ml: goal,
          logs: newLogs
        }, {
          onConflict: 'user_id,date'
        });

      if (error) throw error;

      setConsumed(newConsumed);
      setLogs(newLogs);

      // Feedback positivo
      if (newConsumed >= goal) {
        toast({
          title: "🎉 Meta Atingida!",
          description: "Parabéns! Você atingiu sua meta de água hoje.",
        });
      } else {
        toast({
          title: "💧 Água Adicionada",
          description: `+${ml}ml registrados. Faltam ${goal - newConsumed}ml.`,
        });
      }
    } catch (error) {
      console.error('Error adding water:', error);
      toast({
        title: "Erro",
        description: "Não foi possível registrar. Tente novamente.",
        variant: "destructive"
      });
    }
  };

  const percentage = Math.min((consumed / goal) * 100, 100);
  const glassHeight = `${percentage}%`;

  return (
    <Card className="p-6 bg-surface/50 border-border">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
          <Droplet className="h-5 w-5 text-blue-500" />
          Hidratação
        </h3>
      </div>

      <div className="flex items-center gap-6">
        {/* Water Glass Visualization */}
        <div className="relative w-24 h-40">
          {/* Glass outline */}
          <div className="absolute inset-0 border-4 border-blue-500/30 rounded-b-3xl rounded-t-lg overflow-hidden">
            {/* Water fill */}
            <motion.div
              initial={{ height: 0 }}
              animate={{ height: glassHeight }}
              transition={{ duration: 0.5, ease: "easeOut" }}
              className="absolute bottom-0 w-full bg-gradient-to-t from-blue-500 to-blue-400"
            />
          </div>
          {/* Bubbles */}
          {percentage > 0 && (
            <>
              <motion.div
                animate={{ y: [-40, 0], opacity: [0, 1, 0] }}
                transition={{ duration: 2, repeat: Infinity, delay: 0 }}
                className="absolute bottom-8 left-4 w-2 h-2 bg-white/40 rounded-full"
              />
              <motion.div
                animate={{ y: [-40, 0], opacity: [0, 1, 0] }}
                transition={{ duration: 2, repeat: Infinity, delay: 0.5 }}
                className="absolute bottom-12 right-6 w-1.5 h-1.5 bg-white/40 rounded-full"
              />
            </>
          )}
        </div>

        {/* Stats */}
        <div className="flex-1">
          <div className="text-3xl font-bold text-foreground mb-1">
            {consumed}<span className="text-lg text-muted-foreground">ml</span>
          </div>
          <div className="text-sm text-muted-foreground mb-4">
            Meta: {goal}ml ({percentage.toFixed(0)}%)
          </div>

          {/* Quick Add Buttons */}
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={() => addWater(250)}
              className="flex-1"
            >
              +250ml
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => addWater(500)}
              className="flex-1"
            >
              +500ml
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => addWater(1000)}
              className="flex-1"
            >
              +1L
            </Button>
          </div>
        </div>
      </div>

      {/* Today's Logs */}
      {logs.length > 0 && (
        <div className="mt-4 pt-4 border-t border-border">
          <div className="text-xs text-muted-foreground mb-2">Hoje</div>
          <div className="flex flex-wrap gap-2">
            {logs.slice(-5).reverse().map((log, index) => (
              <div
                key={index}
                className="text-xs bg-blue-500/10 text-blue-500 px-2 py-1 rounded"
              >
                {log.time}: {log.ml}ml
              </div>
            ))}
          </div>
        </div>
      )}
    </Card>
  );
});