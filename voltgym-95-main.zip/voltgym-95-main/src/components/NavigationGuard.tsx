import { useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useUserRole } from '@/hooks/useUserRole';
import { useAuth } from '@/contexts/AuthContext';

export function NavigationGuard({ children }: { children: React.ReactNode }) {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const { role, loading } = useUserRole();
  const lastRedirect = useRef<string | null>(null);

  useEffect(() => {
    if (loading || !user) return;

    const currentPath = location.pathname;
    
    // Anti-loop protection: don't redirect to same destination twice in a row
    if (lastRedirect.current === currentPath) {
      return;
    }
    
    // Public paths (no auth required)
    const publicPaths = ['/', '/auth', '/login', '/cadastro', '/invite', '/convite', '/s', '/pt/pricing', '/pricing'];
    if (publicPaths.some(path => currentPath.startsWith(path))) {
      return;
    }

    // Shared paths (accessible to all authenticated users)
    const sharedPaths = ['/loja', '/comunidade', '/servicos', '/perfil', '/settings'];
    if (sharedPaths.some(path => currentPath.startsWith(path))) {
      return;
    }

    // Athlete onboarding routes - PTs should go to PT area, not athlete onboarding
    const athleteOnboardingPaths = ['/onboarding', '/onboarding-linked', '/complete-profile'];
    if (role === 'personal_trainer' && athleteOnboardingPaths.some(path => currentPath === path || currentPath.startsWith(path + '/'))) {
      lastRedirect.current = '/pt';
      navigate('/pt', { replace: true });
      return;
    }

    // Redirect only if user tries to access another role's area
    if (role === 'admin' && !currentPath.startsWith('/admin') && !sharedPaths.some(p => currentPath.startsWith(p))) {
      lastRedirect.current = '/admin';
      navigate('/admin', { replace: true });
      return;
    }

    if (role === 'personal_trainer' && !currentPath.startsWith('/pt') && !currentPath.startsWith('/ia-coach') && !sharedPaths.some(p => currentPath.startsWith(p))) {
      lastRedirect.current = '/pt';
      navigate('/pt', { replace: true });
      return;
    }

    if (role === 'athlete' && !currentPath.startsWith('/athlete') && !currentPath.startsWith('/dashboard') && !currentPath.startsWith('/treinos') && !currentPath.startsWith('/progresso') && !currentPath.startsWith('/ia-coach') && !currentPath.startsWith('/historico') && !currentPath.startsWith('/onboarding') && !sharedPaths.some(p => currentPath.startsWith(p))) {
      lastRedirect.current = '/dashboard';
      navigate('/dashboard', { replace: true });
      return;
    }
    
    // Reset redirect tracker if we didn't redirect
    lastRedirect.current = null;
  }, [role, loading, location.pathname, navigate, user]);

  return <>{children}</>;
}
