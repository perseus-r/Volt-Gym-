import { FloatingNavButton } from './FloatingNavButton';

/**
 * AppNavigation - Botão flutuante global para navegação
 * Aparece em todas as páginas exceto no dashboard/menu
 */
export function AppNavigation() {
  return <FloatingNavButton />;
}
