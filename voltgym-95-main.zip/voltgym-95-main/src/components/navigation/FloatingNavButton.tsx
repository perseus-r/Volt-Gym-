import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Home } from 'lucide-react';
import { cn } from '@/lib/utils';
import { hapticLight } from '@/utils/haptics';
import { useUIChrome } from '@/contexts/UIChromeContext';

/**
 * FloatingNavButton - Botão flutuante de navegação para o Hub
 * 
 * PADRÃO DE VISIBILIDADE (fonte única de verdade):
 * - Visível: todas as páginas EXCETO as listadas abaixo
 * - Oculto: Hub/Dashboard (destino), Auth, Onboarding, Sessões de treino
 * 
 * O único override permitido é via useHideFloatingNav (usado em MobileWorkoutSession)
 */

// Rotas onde o botão NUNCA deve aparecer
const HIDDEN_ROUTES = [
  '/',           // Landing page
  '/dashboard',  // Hub/Menu (destino do botão)
  '/auth',       // Login/Cadastro
  '/onboarding', // Onboarding
  '/comecar',    // Seleção de conta
];

// Prefixos de rotas onde o botão NUNCA deve aparecer
const HIDDEN_PREFIXES = [
  '/workout-session',  // Sessão de treino
  '/treino-sessao',    // Sessão de treino (PT)
];

// Páginas com input na parte inferior (chat interfaces)
const BOTTOM_INPUT_PREFIXES = ['/ia-coach', '/nutricao'];

export function FloatingNavButton() {
  const navigate = useNavigate();
  const location = useLocation();
  const [isNavigating, setIsNavigating] = useState(false);
  const [mounted, setMounted] = useState(false);
  
  // Hook especial APENAS para sessões de treino ativas
  const { hideFloatingNav } = useUIChrome();
  
  useEffect(() => {
    setMounted(true);
  }, []);
  
  // Reset navigation state when route changes
  useEffect(() => {
    setIsNavigating(false);
  }, [location.pathname]);
  
  // Lógica centralizada de visibilidade (ÚNICA fonte de verdade)
  const isHiddenByRoute = HIDDEN_ROUTES.includes(location.pathname);
  const isHiddenByPrefix = HIDDEN_PREFIXES.some(prefix => location.pathname.startsWith(prefix));
  const shouldHide = isHiddenByRoute || isHiddenByPrefix || hideFloatingNav;
  
  // Check if current page has bottom input
  const hasBottomInput = BOTTOM_INPUT_PREFIXES.some(
    prefix => location.pathname.startsWith(prefix)
  );
  
  const handleClick = () => {
    if (isNavigating) return;
    setIsNavigating(true);
    hapticLight();
    
    const fallbackTimer = setTimeout(() => {
      setIsNavigating(false);
    }, 1200);
    
    setTimeout(() => {
      navigate('/dashboard');
      clearTimeout(fallbackTimer);
    }, 100);
  };

  // Dynamic bottom position with iOS toolbar support
  const bottomPosition = hasBottomInput 
    ? 'calc(100px + env(safe-area-inset-bottom, 0px) + var(--ios-toolbar-bottom, 0px))'
    : 'calc(1.5rem + env(safe-area-inset-bottom, 0px) + var(--ios-toolbar-bottom, 0px))';

  if (!mounted) return null;

  const button = (
    <AnimatePresence>
      {!shouldHide && (
        <motion.button
          initial={{ scale: 0, opacity: 0 }}
          animate={isNavigating ? { 
            scale: [1, 1.3, 0],
            opacity: [1, 0.8, 0],
          } : { scale: 1, opacity: 1 }}
          exit={{ scale: 0, opacity: 0 }}
          whileTap={{ scale: 0.9 }}
          transition={isNavigating ? { 
            duration: 0.3,
            ease: [0.4, 0, 0.2, 1],
            type: 'tween'
          } : { type: 'spring', stiffness: 300, damping: 20 }}
          onClick={handleClick}
          className={cn(
            "fixed z-[1000]",
            "w-14 h-14 rounded-full",
            "flex items-center justify-center",
            "cursor-pointer overflow-hidden",
            "bg-gradient-to-br from-primary via-primary to-blue-600"
          )}
          style={{ 
            bottom: bottomPosition,
            right: '1.5rem',
            boxShadow: '0 8px 32px hsl(var(--primary) / 0.4)',
            touchAction: 'manipulation',
            transition: 'bottom 0.2s ease-out'
          }}
        >
          {/* Subtle pulsating glow */}
          <motion.div
            className="absolute inset-0 rounded-full pointer-events-none"
            animate={{
              boxShadow: [
                '0 0 20px hsl(var(--primary) / 0.3)',
                '0 0 35px hsl(var(--primary) / 0.5)',
                '0 0 20px hsl(var(--primary) / 0.3)'
              ]
            }}
            transition={{
              duration: 2.5,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
          
          {/* Home icon */}
          <Home className="w-6 h-6 text-primary-foreground relative z-10" />
        </motion.button>
      )}
    </AnimatePresence>
  );

  return createPortal(button, document.body);
}
