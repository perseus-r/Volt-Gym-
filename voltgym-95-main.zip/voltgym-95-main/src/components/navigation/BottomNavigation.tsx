import { NavLink, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import { useMobileExperience } from '@/hooks/useMobileExperience';
import { useRoleBasedMenu, MenuItem } from '@/hooks/useRoleBasedMenu';
import { hapticLight } from '@/utils/haptics';

interface NavItemProps {
  item: MenuItem;
  isActive: boolean;
  index: number;
  total: number;
}

function NavItem({ item, isActive, index, total }: NavItemProps) {
  const Icon = item.icon;
  
  const handleClick = () => {
    hapticLight();
  };

  return (
    <NavLink
      to={item.path}
      onClick={handleClick}
      className={cn(
        "relative flex flex-col items-center justify-center",
        "py-2 px-1 flex-1",
        "touch-manipulation select-none",
        "transition-colors duration-200"
      )}
    >
      {/* Background glow when active */}
      <AnimatePresence>
        {isActive && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="absolute inset-x-2 top-1 bottom-1 rounded-2xl bg-primary/10"
          />
        )}
      </AnimatePresence>

      {/* Icon with animation */}
      <motion.div
        className="relative z-10"
        animate={isActive ? { y: -2 } : { y: 0 }}
        transition={{ type: 'spring', stiffness: 400, damping: 25 }}
      >
        <Icon 
          size={22}
          className={cn(
            "transition-colors duration-200",
            isActive 
              ? "text-primary" 
              : "text-muted-foreground"
          )}
          strokeWidth={isActive ? 2.5 : 2}
        />
        
        {/* Badge indicator */}
        {item.badge && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className={cn(
              "absolute -top-1 -right-2 min-w-[16px] h-4 px-1",
              "flex items-center justify-center",
              "text-[10px] font-bold rounded-full",
              item.badge === 'PRO' || item.badge === 'IA'
                ? "bg-gradient-to-r from-primary to-primary/80 text-primary-foreground"
                : item.badge === 'ADMIN' || item.badge === 'PT'
                  ? "bg-accent text-accent-foreground"
                  : "bg-destructive text-destructive-foreground"
            )}
          >
            {item.badge.length > 3 ? '!' : item.badge}
          </motion.div>
        )}
      </motion.div>

      {/* Label */}
      <motion.span
        className={cn(
          "text-[10px] mt-1 font-medium truncate max-w-full relative z-10",
          "transition-colors duration-200",
          isActive 
            ? "text-primary" 
            : "text-muted-foreground"
        )}
        animate={isActive ? { opacity: 1 } : { opacity: 0.8 }}
      >
        {item.title.length > 10 ? item.title.slice(0, 8) + '...' : item.title}
      </motion.span>
    </NavLink>
  );
}

export function BottomNavigation() {
  const location = useLocation();
  const { isMobile, safeAreaBottom, isKeyboardOpen } = useMobileExperience();
  const { items, loading } = useRoleBasedMenu();
  
  // Limit to 5 items for bottom nav
  const navItems = items.slice(0, 5);
  
  // Hide on certain pages (workout session, etc)
  const hiddenPaths = ['/workout-session', '/treino-sessao'];
  const shouldHide = hiddenPaths.some(path => location.pathname.startsWith(path));
  
  // Don't render on desktop, while loading, keyboard open, or hidden paths
  if (!isMobile || loading || isKeyboardOpen || shouldHide) {
    return null;
  }

  return (
    <motion.nav
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: 100, opacity: 0 }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      className="fixed bottom-0 left-0 right-0 z-50"
      style={{
        paddingBottom: Math.max(safeAreaBottom, 8),
      }}
    >
      {/* Glass background */}
      <div className="absolute inset-0 bg-background/80 backdrop-blur-xl border-t border-border/50" />
      
      {/* Top highlight line */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
      
      {/* Navigation items */}
      <div className="relative flex items-center justify-around">
        {navItems.map((item, index) => (
          <NavItem
            key={item.id}
            item={item}
            isActive={location.pathname === item.path || location.pathname.startsWith(item.path + '/')}
            index={index}
            total={navItems.length}
          />
        ))}
      </div>
      
      {/* Active indicator bar */}
      <ActiveIndicator 
        items={navItems} 
        currentPath={location.pathname}
      />
    </motion.nav>
  );
}

function ActiveIndicator({ items, currentPath }: { items: MenuItem[]; currentPath: string }) {
  const activeIndex = items.findIndex(
    item => currentPath === item.path || currentPath.startsWith(item.path + '/')
  );
  
  if (activeIndex === -1) return null;
  
  const itemWidth = 100 / items.length;
  const leftPosition = activeIndex * itemWidth + itemWidth / 2;

  return (
    <motion.div
      className="absolute top-0 w-12 h-0.5 bg-gradient-to-r from-primary/50 via-primary to-primary/50 rounded-full"
      initial={false}
      animate={{
        left: `calc(${leftPosition}% - 24px)`,
      }}
      transition={{
        type: 'spring',
        stiffness: 400,
        damping: 30,
      }}
    />
  );
}

export default BottomNavigation;
