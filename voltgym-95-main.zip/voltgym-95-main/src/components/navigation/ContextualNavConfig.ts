import { Home, Dumbbell, Brain, TrendingUp, Play, History, MessageCircle, FileText, HelpCircle, Scale, Activity, Target, Users, Settings, User, ShoppingBag, Zap, Grid3X3, Send, Paperclip, Info, Plus, BookOpen, Shield, Apple, Camera, Droplets, BarChart3, Utensils } from 'lucide-react';

export interface NavItemConfig {
  id: string;
  label: string;
  icon: any;
  path: string;
}

export interface SectionNavConfig {
  sectionId: string;
  pathPatterns: string[];
  leftItems: NavItemConfig[];
  rightItems: NavItemConfig[];
}

// Configuração de navegação contextual por seção
export const sectionNavConfigs: SectionNavConfig[] = [
  // Dashboard/Hub - Menu principal de atalhos
  {
    sectionId: 'hub',
    pathPatterns: ['/dashboard'],
    leftItems: [
      { id: 'treinos', label: 'Treinos', icon: Dumbbell, path: '/treinos' },
      { id: 'ia-coach', label: 'IA Coach', icon: Brain, path: '/ia-coach' },
    ],
    rightItems: [
      { id: 'progresso', label: 'Progresso', icon: TrendingUp, path: '/progresso' },
      { id: 'perfil', label: 'Perfil', icon: User, path: '/perfil' },
    ],
  },
  // Treinos - Ações de treino
  {
    sectionId: 'treinos',
    pathPatterns: ['/treinos', '/exercicios'],
    leftItems: [
      { id: 'iniciar', label: 'Iniciar', icon: Play, path: '/treinos' },
      { id: 'historico', label: 'Histórico', icon: History, path: '/progresso' },
    ],
    rightItems: [
      { id: 'exercicios', label: 'Exercícios', icon: Activity, path: '/exercicios' },
      { id: 'criar', label: 'Criar', icon: Plus, path: '/ia-coach' },
    ],
  },
  // IA Coach - Ações de IA
  {
    sectionId: 'ia-coach',
    pathPatterns: ['/ia-coach'],
    leftItems: [
      { id: 'novo', label: 'Novo', icon: Plus, path: '/ia-coach' },
      { id: 'treinos', label: 'Treinos', icon: Dumbbell, path: '/treinos' },
    ],
    rightItems: [
      { id: 'progresso', label: 'Progresso', icon: TrendingUp, path: '/progresso' },
      { id: 'perfil', label: 'Perfil', icon: User, path: '/perfil' },
    ],
  },
  // Progresso - Métricas
  {
    sectionId: 'progresso',
    pathPatterns: ['/progresso'],
    leftItems: [
      { id: 'peso', label: 'Peso', icon: Scale, path: '/progresso' },
      { id: 'volume', label: 'Volume', icon: TrendingUp, path: '/progresso' },
    ],
    rightItems: [
      { id: 'metas', label: 'Metas', icon: Target, path: '/progresso' },
      { id: 'share', label: 'Share', icon: Send, path: '/share' },
    ],
  },
  // Chat PT (Atleta) - Chat imersivo
  {
    sectionId: 'chat-atleta',
    pathPatterns: ['/chat-pt'],
    leftItems: [
      { id: 'enviar', label: 'Enviar', icon: Send, path: '/chat-pt' },
      { id: 'anexos', label: 'Anexos', icon: Paperclip, path: '/chat-pt' },
    ],
    rightItems: [
      { id: 'info', label: 'Info PT', icon: Info, path: '/chat-pt' },
      { id: 'historico', label: 'Histórico', icon: History, path: '/chat-pt' },
    ],
  },
  // Chat PT (Personal Trainer) - Chat imersivo
  {
    sectionId: 'chat-pt',
    pathPatterns: ['/pt/chat'],
    leftItems: [
      { id: 'enviar', label: 'Enviar', icon: Send, path: '/pt/chat' },
      { id: 'anexos', label: 'Anexos', icon: Paperclip, path: '/pt/chat' },
    ],
    rightItems: [
      { id: 'atleta', label: 'Atleta', icon: Users, path: '/pt/athletes' },
      { id: 'treinos', label: 'Treinos', icon: Dumbbell, path: '/pt/templates' },
    ],
  },
  // Personal Trainer Dashboard
  {
    sectionId: 'pt-dashboard',
    pathPatterns: ['/pt'],
    leftItems: [
      { id: 'atletas', label: 'Atletas', icon: Users, path: '/pt/athletes' },
      { id: 'ia-coach', label: 'IA Coach', icon: Brain, path: '/pt/ia-coach' },
    ],
    rightItems: [
      { id: 'templates', label: 'Templates', icon: BookOpen, path: '/pt/templates' },
      { id: 'convidar', label: 'Convidar', icon: Plus, path: '/pt/invite' },
    ],
  },
  // Personal Trainer Athletes
  {
    sectionId: 'pt-athletes',
    pathPatterns: ['/pt/athletes'],
    leftItems: [
      { id: 'lista', label: 'Lista', icon: Users, path: '/pt/athletes' },
      { id: 'chat', label: 'Chat', icon: MessageCircle, path: '/pt/chat' },
    ],
    rightItems: [
      { id: 'treinos', label: 'Treinos', icon: Dumbbell, path: '/pt/templates' },
      { id: 'convidar', label: 'Convidar', icon: Plus, path: '/pt/invite' },
    ],
  },
  // Nutrição
  {
    sectionId: 'nutricao',
    pathPatterns: ['/nutricao'],
    leftItems: [
      { id: 'dashboard', label: 'Dashboard', icon: BarChart3, path: '/nutricao' },
      { id: 'refeicoes', label: 'Refeições', icon: Utensils, path: '/nutricao' },
    ],
    rightItems: [
      { id: 'ia-nutri', label: 'IA Nutri', icon: Brain, path: '/nutricao' },
      { id: 'agua', label: 'Água', icon: Droplets, path: '/nutricao' },
    ],
  },
  // Loja
  {
    sectionId: 'loja',
    pathPatterns: ['/loja'],
    leftItems: [
      { id: 'produtos', label: 'Produtos', icon: ShoppingBag, path: '/loja' },
      { id: 'carrinho', label: 'Carrinho', icon: ShoppingBag, path: '/loja' },
    ],
    rightItems: [
      { id: 'pedidos', label: 'Pedidos', icon: History, path: '/loja' },
      { id: 'favoritos', label: 'Favoritos', icon: Target, path: '/loja' },
    ],
  },
  // Perfil
  {
    sectionId: 'perfil',
    pathPatterns: ['/perfil', '/settings'],
    leftItems: [
      { id: 'dados', label: 'Dados', icon: User, path: '/perfil' },
      { id: 'config', label: 'Config', icon: Settings, path: '/settings' },
    ],
    rightItems: [
      { id: 'assinatura', label: 'Assinatura', icon: Zap, path: '/pro' },
      { id: 'ajuda', label: 'Ajuda', icon: HelpCircle, path: '/settings' },
    ],
  },
  // Admin
  {
    sectionId: 'admin',
    pathPatterns: ['/admin'],
    leftItems: [
      { id: 'users', label: 'Usuários', icon: Users, path: '/admin' },
      { id: 'produtos', label: 'Produtos', icon: ShoppingBag, path: '/admin/products' },
    ],
    rightItems: [
      { id: 'analytics', label: 'Analytics', icon: TrendingUp, path: '/admin' },
      { id: 'config', label: 'Config', icon: Settings, path: '/admin' },
    ],
  },
];

// Função para encontrar a configuração de navegação baseada no path atual
export function getNavConfigForPath(pathname: string): SectionNavConfig {
  // Procurar configuração que match o path
  const config = sectionNavConfigs.find(config => 
    config.pathPatterns.some(pattern => {
      // Match exato ou começa com o pattern
      if (pattern === pathname) return true;
      if (pathname.startsWith(pattern + '/')) return true;
      return false;
    })
  );

  // Fallback para hub se não encontrar
  return config || sectionNavConfigs[0];
}
