import React, { useState, useEffect, ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronLeft, MoreVertical } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useMobileExperience } from '@/hooks/useMobileExperience';
import { hapticLight } from '@/utils/haptics';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

export interface HeaderAction {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  onClick: () => void;
  variant?: 'default' | 'destructive';
}

export interface UnifiedHeaderProps {
  title: string;
  subtitle?: string;
  showBack?: boolean;
  onBack?: () => void;
  actions?: HeaderAction[];
  rightContent?: ReactNode;
  transparent?: boolean;
  large?: boolean;
  className?: string;
}

export function UnifiedHeader({
  title,
  subtitle,
  showBack = false,
  onBack,
  actions = [],
  rightContent,
  transparent = false,
  large = false,
  className,
}: UnifiedHeaderProps) {
  const navigate = useNavigate();
  const { isMobile, safeAreaTop } = useMobileExperience();
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleBack = () => {
    hapticLight();
    if (onBack) {
      onBack();
    } else {
      navigate(-1);
    }
  };

  const handleActionClick = (action: HeaderAction) => {
    hapticLight();
    action.onClick();
  };

  // Determine background based on scroll and transparency
  const showBackground = !transparent || isScrolled;

  return (
    <motion.header
      className={cn(
        "sticky top-0 z-40 w-full",
        "transition-all duration-300 ease-out",
        showBackground
          ? "bg-background/95 backdrop-blur-lg border-b border-border/50 shadow-sm"
          : "bg-transparent",
        className
      )}
      style={{
        paddingTop: isMobile ? Math.max(safeAreaTop, 8) : 8,
      }}
      initial={false}
      animate={{
        backgroundColor: showBackground ? 'var(--background)' : 'transparent',
      }}
    >
      <div className="px-4">
        <div className={cn(
          "flex items-center justify-between",
          large ? "py-4" : "py-3"
        )}>
          {/* Left side: Back button + Title */}
          <div className="flex items-center gap-3 flex-1 min-w-0">
            {showBack && (
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={handleBack}
                className={cn(
                  "flex items-center justify-center",
                  "w-10 h-10 rounded-xl",
                  "bg-muted/50 hover:bg-muted",
                  "transition-colors duration-200"
                )}
              >
                <ChevronLeft className="w-5 h-5" />
              </motion.button>
            )}

            <div className="min-w-0 flex-1">
              <motion.h1
                className={cn(
                  "font-bold truncate",
                  large ? "text-2xl" : "text-lg",
                  isScrolled && large && "text-lg"
                )}
                layout
              >
                {title}
              </motion.h1>

              {subtitle && (
                <motion.p
                  className="text-sm text-muted-foreground truncate"
                  initial={{ opacity: 1, height: 'auto' }}
                  animate={{
                    opacity: isScrolled && large ? 0 : 1,
                    height: isScrolled && large ? 0 : 'auto',
                  }}
                  transition={{ duration: 0.2 }}
                >
                  {subtitle}
                </motion.p>
              )}
            </div>
          </div>

          {/* Right side: Actions */}
          <div className="flex items-center gap-2 ml-2">
            {rightContent}
            
            {actions.length === 1 && (
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={() => handleActionClick(actions[0])}
                className={cn(
                  "flex items-center justify-center",
                  "w-10 h-10 rounded-xl",
                  "bg-muted/50 hover:bg-muted",
                  "transition-colors duration-200"
                )}
              >
                {React.createElement(actions[0].icon, { className: "w-5 h-5" })}
              </motion.button>
            )}

            {actions.length > 1 && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <motion.button
                    whileTap={{ scale: 0.9 }}
                    className={cn(
                      "flex items-center justify-center",
                      "w-10 h-10 rounded-xl",
                      "bg-muted/50 hover:bg-muted",
                      "transition-colors duration-200"
                    )}
                  >
                    <MoreVertical className="w-5 h-5" />
                  </motion.button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  {actions.map((action, index) => (
                    <DropdownMenuItem
                      key={index}
                      onClick={() => handleActionClick(action)}
                      className={cn(
                        action.variant === 'destructive' && "text-destructive"
                      )}
                    >
                      {React.createElement(action.icon, { className: "w-4 h-4 mr-2" })}
                      {action.label}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>
      </div>
    </motion.header>
  );
}

export default UnifiedHeader;
