/**
 * ConsistencyCalendar - GitHub-style workout activity calendar
 * 
 * Shows workout activity over the last 60 days with color intensity
 * based on workout volume or simple presence.
 */

import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { ConsistencyData } from '@/hooks/usePerformanceInsights';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface ConsistencyCalendarProps {
  data: ConsistencyData[];
  className?: string;
}

export function ConsistencyCalendar({ data, className }: ConsistencyCalendarProps) {
  const weeks = React.useMemo(() => {
    const result: ConsistencyData[][] = [];
    let currentWeek: ConsistencyData[] = [];
    
    data.forEach((day, index) => {
      const date = new Date(day.date);
      const dayOfWeek = date.getDay();
      
      if (dayOfWeek === 0 && currentWeek.length > 0) {
        result.push(currentWeek);
        currentWeek = [];
      }
      
      currentWeek.push(day);
      
      if (index === data.length - 1) {
        result.push(currentWeek);
      }
    });
    
    return result;
  }, [data]);

  const getIntensityClass = (day: ConsistencyData): string => {
    if (!day.hasWorkout) return 'bg-muted/30';
    
    if (day.volume > 10000) return 'bg-accent';
    if (day.volume > 5000) return 'bg-accent/80';
    if (day.volume > 2000) return 'bg-accent/60';
    return 'bg-accent/40';
  };

  const weekdays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
  
  // Calculate total workouts
  const totalWorkouts = data.filter(d => d.hasWorkout).length;
  const totalVolume = data.reduce((sum, d) => sum + d.volume, 0);

  return (
    <div className={cn('space-y-4', className)}>
      {/* Header Stats */}
      <div className="flex items-center justify-between text-sm">
        <span className="text-muted-foreground">
          {totalWorkouts} treinos nos últimos 60 dias
        </span>
        <span className="text-muted-foreground">
          {Math.round(totalVolume / 1000)}t volume total
        </span>
      </div>

      {/* Calendar Grid */}
      <div className="flex gap-1">
        {/* Weekday labels */}
        <div className="flex flex-col gap-1 text-xs text-muted-foreground mr-2">
          {weekdays.map((day, i) => (
            <div key={i} className="h-3 flex items-center justify-end w-6">
              {i % 2 === 1 && day}
            </div>
          ))}
        </div>

        {/* Weeks */}
        <TooltipProvider>
          <div className="flex gap-1 overflow-x-auto pb-2">
            {weeks.map((week, weekIndex) => (
              <div key={weekIndex} className="flex flex-col gap-1">
                {week.map((day, dayIndex) => (
                  <Tooltip key={`${weekIndex}-${dayIndex}`}>
                    <TooltipTrigger asChild>
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ 
                          delay: (weekIndex * 7 + dayIndex) * 0.005,
                          type: 'spring',
                          stiffness: 300,
                        }}
                        className={cn(
                          'w-3 h-3 rounded-sm cursor-pointer transition-all hover:scale-125',
                          getIntensityClass(day)
                        )}
                      />
                    </TooltipTrigger>
                    <TooltipContent side="top" className="text-xs">
                      <p className="font-medium">
                        {new Date(day.date).toLocaleDateString('pt-BR', { 
                          weekday: 'short',
                          day: 'numeric',
                          month: 'short'
                        })}
                      </p>
                      {day.hasWorkout ? (
                        <p className="text-accent">
                          {day.volume > 0 ? `${Math.round(day.volume)}kg volume` : 'Treino realizado'}
                        </p>
                      ) : (
                        <p className="text-muted-foreground">Sem treino</p>
                      )}
                    </TooltipContent>
                  </Tooltip>
                ))}
              </div>
            ))}
          </div>
        </TooltipProvider>
      </div>

      {/* Legend */}
      <div className="flex items-center justify-end gap-2 text-xs text-muted-foreground">
        <span>Menos</span>
        <div className="flex gap-1">
          <div className="w-3 h-3 rounded-sm bg-muted/30" />
          <div className="w-3 h-3 rounded-sm bg-accent/40" />
          <div className="w-3 h-3 rounded-sm bg-accent/60" />
          <div className="w-3 h-3 rounded-sm bg-accent/80" />
          <div className="w-3 h-3 rounded-sm bg-accent" />
        </div>
        <span>Mais</span>
      </div>
    </div>
  );
}
