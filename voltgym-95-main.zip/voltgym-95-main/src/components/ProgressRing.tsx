import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface ProgressRingProps {
  percentage: number;
  size?: number;
  strokeWidth?: number;
  color?: string;
  trackColor?: string;
  label?: string;
  showPercentage?: boolean;
  icon?: React.ReactNode;
  animated?: boolean;
  className?: string;
}

export function ProgressRing({
  percentage,
  size = 120,
  strokeWidth = 8,
  color = 'hsl(var(--accent))',
  trackColor = 'rgba(255, 255, 255, 0.1)',
  label,
  showPercentage = true,
  icon,
  animated = true,
  className
}: ProgressRingProps) {
  const [currentPercentage, setCurrentPercentage] = useState(0);

  useEffect(() => {
    if (animated) {
      const timer = setTimeout(() => {
        setCurrentPercentage(percentage);
      }, 100);
      return () => clearTimeout(timer);
    } else {
      setCurrentPercentage(percentage);
    }
  }, [percentage, animated]);

  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (currentPercentage / 100) * circumference;

  return (
    <div className={cn('flex flex-col items-center gap-3', className)}>
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="transform -rotate-90">
          {/* Background track */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={trackColor}
            strokeWidth={strokeWidth}
            fill="none"
          />
          
          {/* Progress arc */}
          <motion.circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={color}
            strokeWidth={strokeWidth}
            fill="none"
            strokeLinecap="round"
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset: offset }}
            transition={{ 
              duration: 1,
              ease: [0.4, 0, 0.2, 1]
            }}
            style={{
              strokeDasharray: circumference,
              filter: 'drop-shadow(0 0 8px currentColor)'
            }}
          />
        </svg>

        {/* Center content */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          {icon && (
            <div className="mb-1 text-accent">
              {icon}
            </div>
          )}
          
          {showPercentage && (
            <motion.span
              className="text-stat"
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5, duration: 0.3 }}
            >
              {Math.round(currentPercentage)}%
            </motion.span>
          )}
        </div>
      </div>

      {label && (
        <span className="text-label text-center">
          {label}
        </span>
      )}
    </div>
  );
}
