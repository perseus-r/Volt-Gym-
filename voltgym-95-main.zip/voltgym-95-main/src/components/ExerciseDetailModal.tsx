import React from 'react';
import { motion } from 'framer-motion';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { WorkoutVideoPlayer } from './workout/WorkoutVideoPlayer';
import { Dumbbell, Target, Zap, ListOrdered, Lightbulb, Play } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

interface Exercise {
  id: string;
  name: string;
  youtube_url?: string | null;
  youtube_video_id?: string | null;
  thumbnail_url?: string | null;
  demo_video_url?: string | null;
  instructions?: string[] | null;
  form_tips?: string[] | null;
  primary_muscles?: string[] | null;
  secondary_muscles?: string[] | null;
  equipment?: string | null;
  difficulty_level?: number | null;
}

interface ExerciseDetailModalProps {
  exercise: Exercise | null;
  isOpen: boolean;
  onClose: () => void;
}

function getDifficultyText(level: number | null | undefined): string {
  switch (level) {
    case 1: return 'Iniciante';
    case 2: return 'Intermediário';
    case 3: return 'Avançado';
    default: return 'Não definido';
  }
}

function getDifficultyColor(level: number | null | undefined): string {
  switch (level) {
    case 1: return 'bg-green-500/10 text-green-600 dark:text-green-400 border-green-500/20';
    case 2: return 'bg-yellow-500/10 text-yellow-600 dark:text-yellow-400 border-yellow-500/20';
    case 3: return 'bg-red-500/10 text-red-600 dark:text-red-400 border-red-500/20';
    default: return 'bg-muted text-muted-foreground';
  }
}

export function ExerciseDetailModal({ exercise, isOpen, onClose }: ExerciseDetailModalProps) {
  if (!exercise) return null;

  // Determinar URL do vídeo (priorizar demo_video_url, depois youtube_url)
  const videoUrl = exercise.demo_video_url || exercise.youtube_url || 
    (exercise.youtube_video_id ? `https://youtube.com/watch?v=${exercise.youtube_video_id}` : '');
  const hasVideo = !!videoUrl;

  const thumbnailUrl = exercise.youtube_video_id
    ? `https://img.youtube.com/vi/${exercise.youtube_video_id}/hqdefault.jpg`
    : exercise.thumbnail_url;

  const hasInstructions = exercise.instructions && exercise.instructions.length > 0;
  const hasTips = exercise.form_tips && exercise.form_tips.length > 0;
  const hasMuscles = (exercise.primary_muscles && exercise.primary_muscles.length > 0) ||
                     (exercise.secondary_muscles && exercise.secondary_muscles.length > 0);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] p-0 overflow-hidden gap-0 bg-background border-border">
        {/* Video Player */}
        <div className="w-full bg-muted/30">
          {hasVideo ? (
            <WorkoutVideoPlayer
              videoUrl={videoUrl}
              thumbnail={thumbnailUrl || undefined}
              className="w-full rounded-none"
              clickToPlay={true}
              controls={true}
            />
          ) : (
            <div className="w-full aspect-video flex flex-col items-center justify-center bg-muted/30">
              <div className="w-16 h-16 rounded-full bg-muted/50 flex items-center justify-center mb-3">
                <Play className="w-8 h-8 text-muted-foreground" />
              </div>
              <p className="text-sm text-muted-foreground">Vídeo não disponível</p>
            </div>
          )}
        </div>

        <ScrollArea className="max-h-[calc(90vh-220px)]">
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="p-5 space-y-5"
          >
            {/* Header */}
            <div className="space-y-3">
              <DialogHeader className="p-0">
                <DialogTitle className="text-xl font-bold text-foreground">
                  {exercise.name}
                </DialogTitle>
              </DialogHeader>

              <div className="flex flex-wrap gap-2">
                {exercise.equipment && (
                  <Badge variant="secondary" className="gap-1.5">
                    <Dumbbell className="w-3.5 h-3.5" />
                    {exercise.equipment}
                  </Badge>
                )}
                <Badge className={cn("border gap-1.5", getDifficultyColor(exercise.difficulty_level))}>
                  <Zap className="w-3.5 h-3.5" />
                  {getDifficultyText(exercise.difficulty_level)}
                </Badge>
              </div>
            </div>

            {/* Muscles */}
            {hasMuscles && (
              <section className="space-y-3">
                <h3 className="flex items-center gap-2 text-sm font-semibold text-foreground">
                  <Target className="w-4 h-4 text-primary" />
                  Músculos Trabalhados
                </h3>
                
                <div className="space-y-2">
                  {exercise.primary_muscles && exercise.primary_muscles.length > 0 && (
                    <div className="flex flex-wrap gap-1.5">
                      {exercise.primary_muscles.map((muscle, idx) => (
                        <Badge 
                          key={idx} 
                          className="bg-primary/10 text-primary border-primary/20"
                        >
                          {muscle}
                        </Badge>
                      ))}
                    </div>
                  )}
                  
                  {exercise.secondary_muscles && exercise.secondary_muscles.length > 0 && (
                    <div className="flex flex-wrap gap-1.5">
                      {exercise.secondary_muscles.map((muscle, idx) => (
                        <Badge key={idx} variant="outline" className="text-muted-foreground">
                          {muscle}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </section>
            )}

            {/* Instructions */}
            {hasInstructions && (
              <section className="bg-muted/30 rounded-xl p-4 space-y-3">
                <h3 className="flex items-center gap-2 text-sm font-semibold text-foreground">
                  <ListOrdered className="w-4 h-4 text-primary" />
                  Como Executar
                </h3>
                <ol className="space-y-2.5">
                  {exercise.instructions?.map((instruction, idx) => (
                    <li key={idx} className="flex gap-3 text-sm text-muted-foreground">
                      <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/10 text-primary text-xs font-medium flex items-center justify-center">
                        {idx + 1}
                      </span>
                      <span className="pt-0.5">{instruction}</span>
                    </li>
                  ))}
                </ol>
              </section>
            )}

            {/* Tips */}
            {hasTips && (
              <section className="bg-yellow-500/5 border border-yellow-500/20 rounded-xl p-4 space-y-3">
                <h3 className="flex items-center gap-2 text-sm font-semibold text-foreground">
                  <Lightbulb className="w-4 h-4 text-yellow-500" />
                  Dicas Importantes
                </h3>
                <ul className="space-y-2">
                  {exercise.form_tips?.map((tip, idx) => (
                    <li key={idx} className="flex gap-2 text-sm text-muted-foreground">
                      <span className="text-yellow-500">•</span>
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </section>
            )}
          </motion.div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}