import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { User } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PremiumAvatarProps {
  src?: string | null;
  alt?: string;
  fallback?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  status?: 'online' | 'offline' | 'away' | 'busy';
  ring?: boolean;
  ringColor?: string;
  className?: string;
  onClick?: () => void;
}

export function PremiumAvatar({
  src,
  alt = 'Avatar',
  fallback,
  size = 'md',
  status,
  ring = false,
  ringColor = 'hsl(var(--accent))',
  className,
  onClick
}: PremiumAvatarProps) {
  const [imageError, setImageError] = useState(false);
  const showFallback = !src || imageError;

  const sizeStyles = {
    xs: 'w-8 h-8 text-xs',
    sm: 'w-10 h-10 text-sm',
    md: 'w-12 h-12 text-base',
    lg: 'w-16 h-16 text-lg',
    xl: 'w-20 h-20 text-xl',
    '2xl': 'w-24 h-24 text-2xl',
  };

  const statusColors = {
    online: 'bg-success',
    offline: 'bg-txt-3',
    away: 'bg-warning',
    busy: 'bg-error',
  };

  const statusSizes = {
    xs: 'w-2 h-2',
    sm: 'w-2.5 h-2.5',
    md: 'w-3 h-3',
    lg: 'w-3.5 h-3.5',
    xl: 'w-4 h-4',
    '2xl': 'w-5 h-5',
  };

  return (
    <div className={cn('relative inline-block', className)}>
      {/* Ring effect */}
      {ring && (
        <motion.div
          className="absolute inset-0 rounded-full"
          style={{
            padding: '3px',
            background: `linear-gradient(135deg, ${ringColor}, transparent)`,
          }}
          animate={{
            rotate: [0, 360],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: 'linear'
          }}
        >
          <div className="w-full h-full rounded-full bg-bg" />
        </motion.div>
      )}

      {/* Avatar container */}
      <motion.div
        whileHover={onClick ? { scale: 1.05 } : {}}
        whileTap={onClick ? { scale: 0.95 } : {}}
        onClick={onClick}
        className={cn(
          'relative overflow-hidden rounded-full',
          'bg-gradient-to-br from-surface to-card',
          'border-2 border-line',
          sizeStyles[size],
          onClick && 'cursor-pointer',
          'flex items-center justify-center',
          ring && 'relative z-10'
        )}
      >
        {/* Image */}
        {!showFallback && src ? (
          <img
            src={src}
            alt={alt}
            onError={() => setImageError(true)}
            className="w-full h-full object-cover"
          />
        ) : (
          // Fallback
          <div className="flex items-center justify-center w-full h-full text-txt-2 font-semibold">
            {fallback ? (
              <span>{fallback.charAt(0).toUpperCase()}</span>
            ) : (
              <User className="w-1/2 h-1/2" />
            )}
          </div>
        )}
      </motion.div>

      {/* Status indicator */}
      {status && (
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className={cn(
            'absolute bottom-0 right-0',
            'rounded-full border-2 border-bg',
            statusColors[status],
            statusSizes[size]
          )}
        >
          {/* Pulse for online status */}
          {status === 'online' && (
            <motion.span
              className="absolute inset-0 rounded-full bg-success"
              animate={{
                scale: [1, 1.5, 1],
                opacity: [0.5, 0, 0.5],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: 'easeInOut'
              }}
            />
          )}
        </motion.div>
      )}
    </div>
  );
}

// Avatar Group Component
interface PremiumAvatarGroupProps {
  avatars: Array<{
    src?: string | null;
    alt?: string;
    fallback?: string;
  }>;
  max?: number;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  className?: string;
}

export function PremiumAvatarGroup({
  avatars,
  max = 5,
  size = 'md',
  className
}: PremiumAvatarGroupProps) {
  const displayAvatars = avatars.slice(0, max);
  const remaining = Math.max(0, avatars.length - max);

  return (
    <div className={cn('flex items-center -space-x-3', className)}>
      {displayAvatars.map((avatar, index) => (
        <div
          key={index}
          className="relative"
          style={{ zIndex: displayAvatars.length - index }}
        >
          <PremiumAvatar
            {...avatar}
            size={size}
            ring
          />
        </div>
      ))}

      {/* Remaining count */}
      {remaining > 0 && (
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className={cn(
            'relative flex items-center justify-center',
            'rounded-full bg-surface border-2 border-line',
            'text-txt-2 font-semibold',
            size === 'xs' && 'w-8 h-8 text-xs',
            size === 'sm' && 'w-10 h-10 text-sm',
            size === 'md' && 'w-12 h-12 text-base',
            size === 'lg' && 'w-16 h-16 text-lg',
            size === 'xl' && 'w-20 h-20 text-xl',
            size === '2xl' && 'w-24 h-24 text-2xl'
          )}
          style={{ zIndex: 0 }}
        >
          +{remaining}
        </motion.div>
      )}
    </div>
  );
}
