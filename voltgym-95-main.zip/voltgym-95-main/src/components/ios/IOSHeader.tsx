import React from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, MoreHorizontal } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { setNavigationDirection } from '../transitions/IOSPageTransition';
import { usePageTheme } from '@/hooks/usePageTheme';

interface IOSHeaderProps {
  title: string;
  subtitle?: string;
  largeTitle?: boolean;
  showBack?: boolean;
  backLabel?: string;
  onBack?: () => void;
  trailing?: React.ReactNode;
  className?: string;
  transparent?: boolean;
  themed?: boolean;
}

export function IOSHeader({
  title,
  subtitle,
  largeTitle = false,
  showBack = false,
  backLabel = 'Voltar',
  onBack,
  trailing,
  className,
  transparent = false,
  themed = true,
}: IOSHeaderProps) {
  const navigate = useNavigate();
  const { theme, primaryClass } = usePageTheme();

  const handleBack = () => {
    setNavigationDirection('back');
    if (onBack) {
      onBack();
    } else {
      navigate(-1);
    }
  };

  return (
    <motion.header
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={cn(
        'sticky top-0 z-40',
        'pt-[env(safe-area-inset-top)]',
        !transparent && 'bg-background/80 backdrop-blur-xl border-b border-white/5',
        className
      )}
    >
      {/* Standard header bar */}
      <div className="flex items-center justify-between h-11 px-4">
        {/* Left - Back button */}
        <div className="flex-1 flex items-start">
          {showBack && (
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={handleBack}
              className={cn(
                "flex items-center gap-0.5 -ml-1 py-1 transition-colors duration-300",
                themed ? primaryClass : "text-accent"
              )}
            >
              <ChevronLeft className="w-6 h-6" />
              <span className="text-[17px]">{backLabel}</span>
            </motion.button>
          )}
        </div>

        {/* Center - Small title (when not using large title) */}
        {!largeTitle && (
          <div className="flex-shrink-0 text-center">
            <h1 className="text-[17px] font-semibold text-foreground truncate max-w-[200px]">
              {title}
            </h1>
          </div>
        )}

        {/* Right - Trailing content */}
        <div className="flex-1 flex justify-end items-center gap-2">
          {trailing}
        </div>
      </div>

      {/* Large title */}
      {largeTitle && (
        <div className="px-4 pb-2">
          <motion.h1
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.3 }}
            className="text-[34px] font-bold text-foreground leading-tight"
          >
            {title}
          </motion.h1>
          {subtitle && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="text-[15px] text-muted-foreground mt-0.5"
            >
              {subtitle}
            </motion.p>
          )}
        </div>
      )}
    </motion.header>
  );
}

// Compact version for scrolled state
export function IOSHeaderCompact({
  title,
  trailing,
  className,
}: {
  title: string;
  trailing?: React.ReactNode;
  className?: string;
}) {
  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        'sticky top-0 z-40',
        'pt-[env(safe-area-inset-top)]',
        'bg-background/80 backdrop-blur-xl border-b border-white/5',
        className
      )}
    >
      <div className="flex items-center justify-between h-11 px-4">
        <h1 className="text-[17px] font-semibold text-foreground">{title}</h1>
        {trailing}
      </div>
    </motion.header>
  );
}
