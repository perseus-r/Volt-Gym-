import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { LucideIcon } from 'lucide-react';

interface StatItem {
  label: string;
  value: string | number;
  icon?: LucideIcon;
  color?: 'blue' | 'green' | 'orange' | 'purple' | 'red' | 'yellow' | 'cyan';
}

interface IOSStatsWidgetProps {
  stats: StatItem[];
  columns?: 2 | 3 | 4;
  className?: string;
  compact?: boolean;
}

const colorStyles = {
  blue: {
    bg: 'from-blue-500/20 to-blue-600/10',
    icon: 'bg-blue-500/20 text-blue-400',
    border: 'border-blue-500/20',
  },
  green: {
    bg: 'from-green-500/20 to-green-600/10',
    icon: 'bg-green-500/20 text-green-400',
    border: 'border-green-500/20',
  },
  orange: {
    bg: 'from-orange-500/20 to-orange-600/10',
    icon: 'bg-orange-500/20 text-orange-400',
    border: 'border-orange-500/20',
  },
  purple: {
    bg: 'from-purple-500/20 to-purple-600/10',
    icon: 'bg-purple-500/20 text-purple-400',
    border: 'border-purple-500/20',
  },
  red: {
    bg: 'from-red-500/20 to-red-600/10',
    icon: 'bg-red-500/20 text-red-400',
    border: 'border-red-500/20',
  },
  yellow: {
    bg: 'from-yellow-500/20 to-yellow-600/10',
    icon: 'bg-yellow-500/20 text-yellow-400',
    border: 'border-yellow-500/20',
  },
  cyan: {
    bg: 'from-cyan-500/20 to-cyan-600/10',
    icon: 'bg-cyan-500/20 text-cyan-400',
    border: 'border-cyan-500/20',
  },
};

export function IOSStatsWidget({ stats, columns = 2, className, compact = false }: IOSStatsWidgetProps) {
  return (
    <div 
      className={cn(
        'grid',
        compact ? 'gap-2' : 'gap-3',
        columns === 2 && 'grid-cols-2',
        columns === 3 && 'grid-cols-3',
        columns === 4 && 'grid-cols-4',
        className
      )}
    >
      {stats.map((stat, index) => {
        const color = stat.color || 'blue';
        const styles = colorStyles[color];
        const Icon = stat.icon;
        
        return (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ 
              delay: index * 0.05,
              type: 'spring',
              stiffness: 300,
              damping: 25,
            }}
            className={cn(
              'relative overflow-hidden backdrop-blur-xl border',
              compact ? 'rounded-xl p-2.5' : 'rounded-2xl p-4',
              'bg-gradient-to-br',
              styles.bg,
              styles.border
            )}
          >
            {/* Icon */}
            {Icon && (
              <div className={cn(
                'rounded-lg flex items-center justify-center',
                compact ? 'w-6 h-6 mb-1.5' : 'w-8 h-8 mb-2',
                styles.icon
              )}>
                <Icon className={compact ? 'w-3 h-3' : 'w-4 h-4'} />
              </div>
            )}
            
            {/* Value with counter animation */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.1 + index * 0.05 }}
              className={cn(
                'font-bold text-foreground',
                compact ? 'text-lg' : 'text-2xl'
              )}
            >
              {stat.value}
            </motion.div>
            
            {/* Label */}
            <div className={cn(
              'text-muted-foreground mt-0.5',
              compact ? 'text-[10px]' : 'text-xs'
            )}>
              {stat.label}
            </div>

            {/* Subtle glow */}
            <div 
              className={cn(
                'absolute -top-10 -right-10 w-20 h-20 rounded-full blur-2xl opacity-20',
                color === 'blue' && 'bg-blue-500',
                color === 'green' && 'bg-green-500',
                color === 'orange' && 'bg-orange-500',
                color === 'purple' && 'bg-purple-500',
                color === 'red' && 'bg-red-500',
                color === 'yellow' && 'bg-yellow-500',
                color === 'cyan' && 'bg-cyan-500',
              )}
            />
          </motion.div>
        );
      })}
    </div>
  );
}

// Single stat card for standalone use
export function IOSStatCard({
  label,
  value,
  icon: Icon,
  color = 'blue',
  className,
}: StatItem & { className?: string }) {
  const styles = colorStyles[color];
  
  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -2 }}
      whileTap={{ scale: 0.98 }}
      className={cn(
        'relative overflow-hidden rounded-2xl p-4',
        'bg-gradient-to-br backdrop-blur-xl',
        'border cursor-pointer',
        styles.bg,
        styles.border,
        className
      )}
    >
      {Icon && (
        <div className={cn(
          'w-10 h-10 rounded-xl flex items-center justify-center mb-3',
          styles.icon
        )}>
          <Icon className="w-5 h-5" />
        </div>
      )}
      
      <div className="text-3xl font-bold text-foreground">{value}</div>
      <div className="text-sm text-muted-foreground mt-1">{label}</div>

      {/* Shine effect */}
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
    </motion.div>
  );
}
