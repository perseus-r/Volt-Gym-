import React from 'react';
import { motion } from 'framer-motion';
import { usePageTheme } from '@/hooks/usePageTheme';
import { cn } from '@/lib/utils';

interface ThemedBackgroundProps {
  children: React.ReactNode;
  intensity?: 'subtle' | 'medium' | 'strong';
  showGlow?: boolean;
  className?: string;
}

export function ThemedBackground({
  children,
  intensity = 'subtle',
  showGlow = true,
  className,
}: ThemedBackgroundProps) {
  const { theme, backgroundStyle, isTransitioning } = usePageTheme();

  const intensityOpacity = {
    subtle: 0.15,
    medium: 0.25,
    strong: 0.4,
  };

  const glowSize = {
    subtle: '60%',
    medium: '70%',
    strong: '80%',
  };

  return (
    <div className={cn('relative min-h-full w-full overflow-x-hidden', className)}>
      {/* Animated gradient background */}
      <motion.div
        className="pointer-events-none absolute inset-0 z-0"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.4, ease: 'easeOut' }}
        style={{
          background: theme.gradientSubtle,
        }}
        key={theme.name}
      />

      {/* Glow effect at top */}
      {showGlow && (
        <motion.div
          className="pointer-events-none absolute left-1/2 top-0 z-0 -translate-x-1/2"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
          style={{
            width: glowSize[intensity],
            height: '250px',
            background: `radial-gradient(ellipse at center top, ${theme.glow} 0%, transparent 65%)`,
            filter: 'blur(30px)',
          }}
          key={`glow-${theme.name}`}
        />
      )}

      {/* Top border accent */}
      {showGlow && (
        <motion.div
          className="pointer-events-none absolute inset-x-0 top-0 h-1 z-0"
          initial={{ opacity: 0, scaleX: 0 }}
          animate={{ opacity: 1, scaleX: 1 }}
          transition={{ duration: 0.4, ease: 'easeOut' }}
          style={{
            background: theme.gradient,
          }}
          key={`border-${theme.name}`}
        />
      )}

      {/* Subtle pulsating glow */}
      {showGlow && intensity !== 'subtle' && (
        <motion.div
          className="pointer-events-none absolute left-1/2 top-20 z-0 -translate-x-1/2"
          animate={{
            opacity: [0.3, 0.5, 0.3],
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 4,
            ease: 'easeInOut',
            repeat: Infinity,
          }}
          style={{
            width: '200px',
            height: '200px',
            background: `radial-gradient(circle, ${theme.glow} 0%, transparent 70%)`,
            filter: 'blur(60px)',
          }}
        />
      )}

      {/* Transition overlay */}
      <motion.div
        className="pointer-events-none absolute inset-0 z-0 bg-background"
        initial={{ opacity: 0 }}
        animate={{ opacity: isTransitioning ? 0.3 : 0 }}
        transition={{ duration: 0.2 }}
      />

      {/* Content */}
      <div className="relative z-10">{children}</div>
    </div>
  );
}

// Compact themed header glow - for use inside headers
export function ThemedHeaderGlow({ className }: { className?: string }) {
  const { theme } = usePageTheme();

  return (
    <motion.div
      className={cn(
        'pointer-events-none absolute inset-x-0 top-0 h-32',
        className
      )}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.4 }}
      style={{
        background: `linear-gradient(to bottom, ${theme.glow.replace('0.4', '0.15')} 0%, transparent 100%)`,
      }}
      key={theme.name}
    />
  );
}
