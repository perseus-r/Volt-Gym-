import React, { useRef, useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import { useHapticFeedback } from '@/hooks/useHapticFeedback';
import { usePageTheme } from '@/hooks/usePageTheme';

interface Segment {
  value: string;
  label: string;
  icon?: React.ReactNode;
}

interface IOSSegmentedControlProps {
  segments: Segment[];
  value: string;
  onChange: (value: string) => void;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  themed?: boolean;
}

export function IOSSegmentedControl({
  segments,
  value,
  onChange,
  className,
  size = 'md',
  themed = true,
}: IOSSegmentedControlProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [indicatorStyle, setIndicatorStyle] = useState({ left: 0, width: 0 });
  const haptic = useHapticFeedback();
  const { theme } = usePageTheme();

  // Calculate indicator position
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const activeIndex = segments.findIndex(s => s.value === value);
    const buttons = container.querySelectorAll('button');
    const activeButton = buttons[activeIndex];
    
    if (activeButton) {
      const containerRect = container.getBoundingClientRect();
      const buttonRect = activeButton.getBoundingClientRect();
      
      setIndicatorStyle({
        left: buttonRect.left - containerRect.left,
        width: buttonRect.width,
      });
    }
  }, [value, segments]);

  const handleSelect = (segmentValue: string) => {
    if (segmentValue !== value) {
      haptic.light();
      onChange(segmentValue);
    }
  };

  const sizeStyles = {
    sm: 'h-8 text-xs',
    md: 'h-9 text-sm',
    lg: 'h-10 text-base',
  };

  return (
    <div
      ref={containerRef}
      className={cn(
        'relative flex rounded-xl p-1',
        'bg-white/5 backdrop-blur-lg',
        'border border-white/10',
        className
      )}
    >
      {/* Animated background indicator */}
      <motion.div
        className="absolute top-1 bottom-1 rounded-lg shadow-sm"
        style={{
          background: themed ? `hsl(${theme.primary} / 0.2)` : 'rgba(255,255,255,0.1)',
          boxShadow: themed ? `0 0 20px ${theme.glow}` : 'none',
        }}
        animate={{
          left: indicatorStyle.left,
          width: indicatorStyle.width,
        }}
        transition={{
          type: 'spring',
          stiffness: 500,
          damping: 35,
        }}
      />

      {/* Segments */}
      {segments.map((segment) => {
        const isActive = segment.value === value;
        
        return (
          <motion.button
            key={segment.value}
            whileTap={{ scale: 0.97 }}
            onClick={() => handleSelect(segment.value)}
            className={cn(
              'relative flex-1 flex items-center justify-center gap-1.5 px-3 rounded-lg',
              'font-medium transition-colors duration-200',
              sizeStyles[size],
              isActive 
                ? 'text-foreground' 
                : 'text-muted-foreground hover:text-foreground/80'
            )}
          >
            {segment.icon && (
              <span className="flex-shrink-0">
                {segment.icon}
              </span>
            )}
            <span className="truncate">{segment.label}</span>
          </motion.button>
        );
      })}
    </div>
  );
}

// Pill variant for horizontal scrollable segments
export function IOSPillSegments({
  segments,
  value,
  onChange,
  className,
  themed = true,
}: IOSSegmentedControlProps) {
  const haptic = useHapticFeedback();
  const { theme } = usePageTheme();

  const handleSelect = (segmentValue: string) => {
    if (segmentValue !== value) {
      haptic.light();
      onChange(segmentValue);
    }
  };

  return (
    <div className={cn('flex gap-2 overflow-x-auto pb-1 -mx-4 px-4 scrollbar-hide', className)}>
      {segments.map((segment) => {
        const isActive = segment.value === value;
        
        return (
          <motion.button
            key={segment.value}
            whileTap={{ scale: 0.95 }}
            onClick={() => handleSelect(segment.value)}
            className={cn(
              'flex-shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-full',
              'text-sm font-medium transition-all duration-200',
              'border',
              isActive 
                ? 'text-foreground border-transparent' 
                : 'bg-white/5 text-muted-foreground border-white/10 hover:bg-white/10'
            )}
            style={isActive && themed ? {
              background: `hsl(${theme.primary})`,
              boxShadow: `0 4px 20px ${theme.glow}`,
            } : isActive ? {
              background: 'hsl(var(--accent))',
              boxShadow: '0 4px 20px rgba(55, 160, 244, 0.3)',
            } : undefined}
          >
            {segment.icon}
            {segment.label}
          </motion.button>
        );
      })}
    </div>
  );
}
