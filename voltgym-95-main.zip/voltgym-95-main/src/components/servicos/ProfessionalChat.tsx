import { useState, useEffect, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Send, Loader2 } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

interface Message {
  id: string;
  sender_user_id: string;
  receiver_user_id: string;
  message: string;
  is_read: boolean;
  created_at: string;
}

interface ProfessionalChatProps {
  appointmentId: string;
}

export function ProfessionalChat({ appointmentId }: ProfessionalChatProps) {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const [receiverId, setReceiverId] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (user && appointmentId) {
      loadMessages();
      setupRealtimeSubscription();
      identifyReceiver();
    }
  }, [user, appointmentId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const identifyReceiver = async () => {
    try {
      const { data: appointment } = await supabase
        .from('appointments')
        .select('client_user_id, professional_id, professional:professionals(user_id)')
        .eq('id', appointmentId)
        .single();

      if (appointment) {
        // Se eu sou o cliente, o receiver é o profissional
        if (appointment.client_user_id === user!.id) {
          setReceiverId(appointment.professional.user_id);
        } else {
          // Se eu sou o profissional, o receiver é o cliente
          setReceiverId(appointment.client_user_id);
        }
      }
    } catch (error) {
      console.error('Erro ao identificar destinatário:', error);
    }
  };

  const loadMessages = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('professional_messages')
        .select('*')
        .eq('appointment_id', appointmentId)
        .order('created_at', { ascending: true });

      if (error) throw error;
      setMessages(data || []);

      // Marcar mensagens recebidas como lidas
      await markAsRead();
    } catch (error: any) {
      console.error('Erro ao carregar mensagens:', error);
      toast.error('Erro ao carregar chat');
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async () => {
    try {
      await supabase
        .from('professional_messages')
        .update({ is_read: true })
        .eq('appointment_id', appointmentId)
        .eq('receiver_user_id', user!.id)
        .eq('is_read', false);
    } catch (error) {
      console.error('Erro ao marcar como lido:', error);
    }
  };

  const setupRealtimeSubscription = () => {
    const channel = supabase
      .channel(`chat:${appointmentId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'professional_messages',
          filter: `appointment_id=eq.${appointmentId}`,
        },
        (payload) => {
          const newMsg = payload.new as Message;
          setMessages((prev) => [...prev, newMsg]);

          // Auto-marcar como lida se for mensagem recebida
          if (newMsg.receiver_user_id === user!.id) {
            supabase
              .from('professional_messages')
              .update({ is_read: true })
              .eq('id', newMsg.id)
              .then();
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!newMessage.trim() || !receiverId) return;

    try {
      setSending(true);

      const { error } = await supabase
        .from('professional_messages')
        .insert([
          {
            appointment_id: appointmentId,
            sender_user_id: user!.id,
            receiver_user_id: receiverId,
            message: newMessage.trim(),
          },
        ]);

      if (error) throw error;

      setNewMessage('');
    } catch (error: any) {
      console.error('Erro ao enviar mensagem:', error);
      toast.error('Erro ao enviar mensagem');
    } finally {
      setSending(false);
    }
  };

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[500px]">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[600px]">
      {/* Header */}
      <div className="p-4 border-b border-line/20 bg-surface/50">
        <h3 className="font-semibold text-txt">Chat da Consulta</h3>
        <p className="text-sm text-txt-3">Converse com seu profissional ou cliente</p>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        <div className="space-y-4">
          {messages.length === 0 ? (
            <div className="text-center text-txt-3 py-12">
              <p>Nenhuma mensagem ainda.</p>
              <p className="text-sm mt-2">Inicie a conversa enviando uma mensagem!</p>
            </div>
          ) : (
            messages.map((msg) => {
              const isMe = msg.sender_user_id === user!.id;

              return (
                <div
                  key={msg.id}
                  className={`flex gap-3 ${isMe ? 'flex-row-reverse' : 'flex-row'}`}
                >
                  <Avatar className="w-8 h-8 flex-shrink-0">
                    <AvatarFallback className={isMe ? 'bg-accent/20 text-accent' : 'bg-surface text-txt'}>
                      {isMe ? 'V' : 'P'}
                    </AvatarFallback>
                  </Avatar>

                  <div className={`flex flex-col gap-1 max-w-[70%] ${isMe ? 'items-end' : 'items-start'}`}>
                    <div
                      className={`px-4 py-2 rounded-2xl ${
                        isMe
                          ? 'bg-accent text-white rounded-tr-sm'
                          : 'bg-surface/80 text-txt rounded-tl-sm'
                      }`}
                    >
                      <p className="text-sm break-words">{msg.message}</p>
                    </div>
                    <span className="text-xs text-txt-3 px-2">
                      {format(new Date(msg.created_at), "HH:mm", { locale: ptBR })}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="p-4 border-t border-line/20 bg-surface/30">
        <form onSubmit={sendMessage} className="flex gap-2">
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Digite sua mensagem..."
            disabled={sending}
            className="flex-1 bg-bg/50 border-line/30"
          />
          <Button type="submit" disabled={sending || !newMessage.trim()} className="gap-2">
            {sending ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </form>
      </div>
    </div>
  );
}