import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

interface ProfessionalFiltersProps {
  selectedSpecialty: string;
  onSpecialtyChange: (value: string) => void;
  sortBy: string;
  onSortChange: (value: string) => void;
}

export function ProfessionalFilters({
  selectedSpecialty,
  onSpecialtyChange,
  sortBy,
  onSortChange,
}: ProfessionalFiltersProps) {
  return (
    <div className="flex flex-col sm:flex-row gap-4">
      <div className="flex-1 space-y-2">
        <Label htmlFor="specialty" className="text-sm text-muted-foreground">
          Especialidade
        </Label>
        <Select value={selectedSpecialty} onValueChange={onSpecialtyChange}>
          <SelectTrigger id="specialty" className="bg-card/50">
            <SelectValue placeholder="Todas especialidades" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas especialidades</SelectItem>
            <SelectItem value="personal_trainer">Personal Trainer</SelectItem>
            <SelectItem value="nutritionist">Nutricionista</SelectItem>
            <SelectItem value="physiotherapist">Fisioterapeuta</SelectItem>
            <SelectItem value="sports_psychologist">Psicólogo Esportivo</SelectItem>
            <SelectItem value="general_coach">Coach Geral</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex-1 space-y-2">
        <Label htmlFor="sort" className="text-sm text-muted-foreground">
          Ordenar por
        </Label>
        <Select value={sortBy} onValueChange={onSortChange}>
          <SelectTrigger id="sort" className="bg-card/50">
            <SelectValue placeholder="Mais avaliados" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="rating">Mais Avaliados</SelectItem>
            <SelectItem value="price_low">Menor Preço</SelectItem>
            <SelectItem value="price_high">Maior Preço</SelectItem>
            <SelectItem value="experience">Maior Experiência</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
