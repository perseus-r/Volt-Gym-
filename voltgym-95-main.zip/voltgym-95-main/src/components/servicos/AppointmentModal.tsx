import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Calendar as CalendarIcon, Clock, DollarSign } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface AppointmentModalProps {
  professional: any;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const serviceTypes = [
  { value: "consultation", label: "Consulta" },
  { value: "training_plan", label: "Plano de Treino" },
  { value: "nutrition_plan", label: "Plano Nutricional" },
  { value: "injury_recovery", label: "Recuperação de Lesão" },
  { value: "performance_analysis", label: "Análise de Performance" },
  { value: "general_coaching", label: "Coaching Geral" },
];

export function AppointmentModal({ professional, open, onOpenChange }: AppointmentModalProps) {
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [selectedTime, setSelectedTime] = useState<string>("");
  const [serviceType, setServiceType] = useState<string>("consultation");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const availableTimes = selectedDate
    ? (professional.availability_schedule?.[format(selectedDate, "EEEE", { locale: ptBR }).toLowerCase()] || [])
    : [];

  const handleBookAppointment = async () => {
    if (!selectedDate || !selectedTime) {
      toast({
        title: "Dados incompletos",
        description: "Selecione uma data e horário",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Usuário não autenticado");

      const { error } = await supabase.from("appointments").insert({
        client_user_id: user.id,
        professional_id: professional.id,
        appointment_date: format(selectedDate, "yyyy-MM-dd"),
        appointment_time: selectedTime,
        service_type: serviceType as any,
        notes,
        total_amount: professional.hourly_rate,
        status: "pending" as any,
        payment_status: "pending" as any,
      });

      if (error) throw error;

      toast({
        title: "Consulta agendada!",
        description: "Você receberá uma confirmação em breve",
      });

      onOpenChange(false);
    } catch (error: any) {
      toast({
        title: "Erro ao agendar",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">Agendar Consulta</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Date Selection */}
          <div className="space-y-3">
            <Label className="flex items-center gap-2">
              <CalendarIcon className="w-4 h-4" />
              Selecione a Data
            </Label>
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={setSelectedDate}
              disabled={(date) => date < new Date() || date.getDay() === 0}
              className="rounded-xl border border-border/40 bg-card/30"
              locale={ptBR}
            />
          </div>

          {/* Time Selection */}
          {selectedDate && (
            <div className="space-y-3">
              <Label className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Horário Disponível
              </Label>
              {availableTimes.length > 0 ? (
                <div className="grid grid-cols-4 gap-2">
                  {availableTimes.map((time: string) => (
                    <Button
                      key={time}
                      variant={selectedTime === time ? "default" : "outline"}
                      className={selectedTime === time ? "bg-accent text-accent-ink" : ""}
                      onClick={() => setSelectedTime(time)}
                    >
                      {time}
                    </Button>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">
                  Sem horários disponíveis nesta data
                </p>
              )}
            </div>
          )}

          {/* Service Type */}
          <div className="space-y-3">
            <Label>Tipo de Serviço</Label>
            <Select value={serviceType} onValueChange={setServiceType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {serviceTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Notes */}
          <div className="space-y-3">
            <Label>Observações (opcional)</Label>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Ex: Tenho dores no joelho, preciso de atenção especial..."
              className="min-h-[100px]"
            />
          </div>

          {/* Summary */}
          <div className="rounded-xl bg-accent/10 border border-accent/20 p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Valor da Consulta</span>
              <span className="text-xl font-bold text-accent flex items-center gap-1">
                <DollarSign className="w-5 h-5" />
                R$ {professional.hourly_rate.toFixed(2)}
              </span>
            </div>
            {selectedDate && selectedTime && (
              <div className="text-sm text-muted-foreground">
                {format(selectedDate, "dd 'de' MMMM 'de' yyyy", { locale: ptBR })} às {selectedTime}
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <Button
              variant="outline"
              className="flex-1"
              onClick={() => onOpenChange(false)}
              disabled={loading}
            >
              Cancelar
            </Button>
            <Button
              className="flex-1 bg-gradient-to-r from-accent to-accent-2 text-accent-ink"
              onClick={handleBookAppointment}
              disabled={!selectedDate || !selectedTime || loading}
            >
              {loading ? "Agendando..." : "Confirmar Agendamento"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
