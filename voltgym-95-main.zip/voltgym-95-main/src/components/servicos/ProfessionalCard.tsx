import { Star, Award, Clock, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface ProfessionalCardProps {
  professional: {
    id: string;
    specialty: string;
    bio: string;
    certifications: string[];
    experience_years: number;
    hourly_rate: number;
    rating: number;
    total_reviews: number;
    profile_image_url: string | null;
  };
  onBook: (professional: any) => void;
}

const specialtyLabels: Record<string, string> = {
  personal_trainer: "Personal Trainer",
  nutritionist: "Nutricionista",
  physiotherapist: "Fisioterapeuta",
  sports_psychologist: "Psicólogo Esportivo",
  general_coach: "Coach Geral",
};

export function ProfessionalCard({ professional, onBook }: ProfessionalCardProps) {
  return (
    <Card className="group overflow-hidden bg-card/50 backdrop-blur-sm border-border/60 hover:border-accent/40 hover:shadow-glow transition-all duration-300">
      <div className="relative h-48 overflow-hidden bg-gradient-to-br from-accent/10 to-primary/10">
        {professional.profile_image_url ? (
          <img
            src={professional.profile_image_url}
            alt="Profissional"
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Award className="w-16 h-16 text-muted-foreground/20" />
          </div>
        )}
        <div className="absolute top-3 right-3">
          <Badge className="bg-accent/90 text-accent-ink border-0">
            {specialtyLabels[professional.specialty] || professional.specialty}
          </Badge>
        </div>
      </div>

      <div className="p-6 space-y-4">
        {/* Rating */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star
                key={star}
                className={`w-4 h-4 ${
                  star <= Math.round(professional.rating)
                    ? "fill-accent text-accent"
                    : "text-muted-foreground/30"
                }`}
              />
            ))}
          </div>
          <span className="text-sm text-muted-foreground">
            {professional.rating.toFixed(1)} ({professional.total_reviews} avaliações)
          </span>
        </div>

        {/* Bio */}
        <p className="text-sm text-muted-foreground line-clamp-3 min-h-[3.6rem]">
          {professional.bio || "Profissional certificado e experiente."}
        </p>

        {/* Stats */}
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Clock className="w-4 h-4" />
            <span>{professional.experience_years} anos</span>
          </div>
          <div className="flex items-center gap-1.5 text-accent font-semibold">
            <DollarSign className="w-4 h-4" />
            <span>R$ {professional.hourly_rate.toFixed(0)}/h</span>
          </div>
        </div>

        {/* Certifications */}
        {professional.certifications && professional.certifications.length > 0 && (
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Award className="w-3.5 h-3.5" />
            <span className="truncate">{professional.certifications[0]}</span>
          </div>
        )}

        {/* CTA Button */}
        <Button
          className="w-full bg-gradient-to-r from-accent to-accent-2 text-accent-ink hover:shadow-glow transition-all"
          onClick={() => onBook(professional)}
        >
          Agendar Consulta
        </Button>
      </div>
    </Card>
  );
}
