import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { MessageCircle, Trash2, Plus } from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface Conversation {
  id: string;
  title: string;
  updated_at: string;
  created_at: string;
}

interface ConversationManagerProps {
  onSelectConversation: (id: string) => void;
  selectedConversationId?: string;
  onNewConversation?: () => void;
  onClose?: () => void;
}

export function ConversationManager({
  onSelectConversation,
  selectedConversationId,
  onNewConversation
}: ConversationManagerProps) {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadConversations();
  }, []);

  const loadConversations = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('ai_conversations')
        .select('*')
        .eq('user_id', user.id)
        .order('updated_at', { ascending: false });

      if (error) throw error;
      setConversations(data || []);
    } catch (error) {
      console.error('Error loading conversations:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await supabase.from('ai_messages').delete().eq('conversation_id', id);
      await supabase.from('ai_conversations').delete().eq('id', id);
      
      setConversations(prev => prev.filter(c => c.id !== id));
      toast.success('Conversa excluída');
    } catch (error) {
      toast.error('Erro ao excluir conversa');
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
  };

  if (loading) {
    return (
      <div className="p-4 text-center text-muted-foreground">
        Carregando conversas...
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-2 p-2">
      {onNewConversation && (
        <Button
          variant="outline"
          onClick={onNewConversation}
          className="w-full justify-start gap-2 mb-2"
        >
          <Plus className="w-4 h-4" />
          Nova Conversa
        </Button>
      )}

      {conversations.length === 0 ? (
        <div className="p-4 text-center text-muted-foreground text-sm">
          Nenhuma conversa ainda
        </div>
      ) : (
        conversations.map((conv) => (
          <div
            key={conv.id}
            onClick={() => onSelectConversation(conv.id)}
            className={cn(
              "flex items-center justify-between p-3 rounded-lg cursor-pointer transition-all",
              "hover:bg-accent/50 border border-transparent",
              selectedConversationId === conv.id && "bg-accent border-primary/30"
            )}
          >
            <div className="flex items-center gap-3 flex-1 min-w-0">
              <MessageCircle className="w-4 h-4 text-muted-foreground flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{conv.title || 'Nova Conversa'}</p>
                <p className="text-xs text-muted-foreground">{formatDate(conv.updated_at)}</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-muted-foreground hover:text-destructive"
              onClick={(e) => handleDelete(conv.id, e)}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        ))
      )}
    </div>
  );
}
