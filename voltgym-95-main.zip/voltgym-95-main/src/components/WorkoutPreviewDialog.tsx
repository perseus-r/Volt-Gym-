import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { motion } from 'framer-motion';
import { Dumbbell, Zap, Save, X, CheckCircle2 } from 'lucide-react';

interface Exercise {
  exercise_id: string;
  exercise_name: string;
  target_sets: number;
  target_reps_min: number;
  target_reps_max?: number;
  target_weight?: number;
  target_rest_sec?: number;
  notes?: string;
}

interface WorkoutDay {
  name: string;
  exercises: Exercise[];
}

interface WorkoutPreviewProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  workoutData: {
    name: string;
    split?: string;
    goal?: string;
    days: WorkoutDay[];
  } | null;
  onConfirm: () => void;
  onCancel: () => void;
}

export function WorkoutPreviewDialog({ 
  open, 
  onOpenChange, 
  workoutData, 
  onConfirm, 
  onCancel 
}: WorkoutPreviewProps) {
  if (!workoutData) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden liquid-glass border-accent/20">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-txt">
            <Dumbbell className="w-5 h-5 text-accent" />
            Preview do Treino
          </DialogTitle>
          <DialogDescription className="text-txt-2">
            Revise o treino criado pela IA antes de salvar
          </DialogDescription>
        </DialogHeader>

        <div className="overflow-y-auto max-h-[calc(90vh-200px)] space-y-4 pr-2">
          {/* Header do Treino */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 rounded-xl bg-gradient-to-br from-accent/10 to-accent-2/10 border border-accent/20"
          >
            <h3 className="text-xl font-bold text-txt mb-2">{workoutData.name}</h3>
            <div className="flex gap-3 flex-wrap">
              {workoutData.split && (
                <span className="px-3 py-1 rounded-full bg-accent/20 text-accent text-sm border border-accent/30">
                  {workoutData.split}
                </span>
              )}
              {workoutData.goal && (
                <span className="px-3 py-1 rounded-full bg-accent-2/20 text-accent-2 text-sm border border-accent-2/30">
                  Objetivo: {workoutData.goal}
                </span>
              )}
              <span className="px-3 py-1 rounded-full bg-purple-500/20 text-purple-400 text-sm border border-purple-500/30">
                {workoutData.days.length} dias
              </span>
            </div>
          </motion.div>

          {/* Dias do Treino */}
          {workoutData.days.map((day, dayIndex) => (
            <motion.div
              key={dayIndex}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: dayIndex * 0.1 }}
            >
              <Card className="p-4 bg-bg/50 border-border">
                <div className="flex items-center gap-2 mb-3">
                  <Zap className="w-4 h-4 text-accent" />
                  <h4 className="font-bold text-txt">{day.name}</h4>
                  <span className="text-txt-2 text-sm">
                    ({day.exercises.length} exercícios)
                  </span>
                </div>

                <div className="space-y-2">
                  {day.exercises.map((exercise, exIndex) => (
                    <div
                      key={exIndex}
                      className="flex items-start justify-between p-3 rounded-lg bg-bg-2/50 border border-border/50 hover:border-accent/30 transition-colors"
                    >
                      <div className="flex-1">
                        <p className="font-medium text-txt">{exercise.exercise_name}</p>
                        <div className="flex gap-3 mt-1 flex-wrap">
                          <span className="text-xs text-txt-2">
                            {exercise.target_sets} séries
                          </span>
                          <span className="text-xs text-txt-2">
                            {exercise.target_reps_min}
                            {exercise.target_reps_max && exercise.target_reps_max !== exercise.target_reps_min 
                              ? `-${exercise.target_reps_max}` 
                              : ''} reps
                          </span>
                          {exercise.target_weight && (
                            <span className="text-xs text-accent">
                              {exercise.target_weight}kg
                            </span>
                          )}
                          {exercise.target_rest_sec && (
                            <span className="text-xs text-txt-2">
                              {exercise.target_rest_sec}s descanso
                            </span>
                          )}
                        </div>
                        {exercise.notes && (
                          <p className="text-xs text-txt-2 mt-1 italic">{exercise.notes}</p>
                        )}
                      </div>
                      <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0 mt-1" />
                    </div>
                  ))}
                </div>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Footer com Botões */}
        <div className="flex gap-3 pt-4 border-t border-border">
          <Button
            variant="outline"
            className="flex-1 border-border hover:bg-bg-2"
            onClick={onCancel}
          >
            <X className="w-4 h-4 mr-2" />
            Cancelar
          </Button>
          <Button
            className="flex-1 bg-gradient-to-r from-accent to-accent-2 hover:opacity-90 text-white"
            onClick={onConfirm}
          >
            <Save className="w-4 h-4 mr-2" />
            Salvar Treino
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
