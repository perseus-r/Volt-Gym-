import { Navigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useUserRole } from '@/hooks/useUserRole';
import { isAdminEmail } from '@/lib/admin';
import { Shield, Loader2 } from 'lucide-react';

interface AdminRouteProps {
  children: React.ReactNode;
}

export function AdminRoute({ children }: AdminRouteProps) {
  const { user, loading: authLoading } = useAuth();
  const { isAdmin: isAdminByRole, loading: roleLoading } = useUserRole();
  
  // Verificação híbrida: role no banco OU email na lista
  const isAdminByEmail = isAdminEmail(user?.email);
  const isAdmin = isAdminByRole || isAdminByEmail;
  
  // Ainda carregando autenticação ou role
  if (authLoading || roleLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-accent" />
          <span className="text-muted-foreground">Verificando permissões...</span>
        </div>
      </div>
    );
  }
  
  // Não autenticado
  if (!user) {
    return <Navigate to="/auth" replace />;
  }
  
  // Não é admin
  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4 p-6">
          <Shield className="h-16 w-16 text-destructive mx-auto" />
          <h1 className="text-2xl font-bold text-foreground">Acesso Negado</h1>
          <p className="text-muted-foreground max-w-md">
            Você não tem permissão para acessar esta área. 
            Apenas administradores podem visualizar este conteúdo.
          </p>
          <Link 
            to="/dashboard" 
            className="inline-block mt-4 px-6 py-2 bg-accent text-accent-foreground rounded-lg hover:bg-accent/90 transition-colors"
          >
            Voltar ao Dashboard
          </Link>
        </div>
      </div>
    );
  }
  
  // É admin - renderizar conteúdo
  return <>{children}</>;
}
