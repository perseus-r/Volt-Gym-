import React, { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { X, Download, Share2, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import html2canvas from 'html2canvas';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface WorkoutData {
  name: string;
  focus: string;
  duration_minutes: number;
  total_volume: number;
  exercises: Array<{ name: string; sets: number; reps: number | string; weight?: number }>;
  completed_at: string;
}

interface StravaStyleShareCardProps {
  workout: WorkoutData;
  onClose: () => void;
}

type StickerStyle = 'volt' | 'fire' | 'neon' | 'gold' | 'ocean' | 'dark' | 'minimal';
type StickerSize = 'small' | 'medium' | 'large';
type LayoutType = 'compact' | 'balanced' | 'full';
type StatsLayout = 'inline' | 'grid-3' | 'grid-2x2';
type HeaderLayout = 'inline' | 'stacked';

interface SizeConfig {
  name: string;
  width: string;
  height: string;
  aspectRatio: string;
  layout: LayoutType;
  showExerciseList: boolean;
  showDate: boolean;
  statsLayout: StatsLayout;
  headerLayout: HeaderLayout;
  padding: string;
  logoSize: string;
  zapSize: string;
  brandSize: string;
  titleSize: string;
  subtitleSize: string;
  statsValueSize: string;
  statsLabelSize: string;
  badgeSize: string;
  watermarkSize: string;
  gap: string;
}

// Distinct size configurations with unique layouts
const sizeConfigs: Record<StickerSize, SizeConfig> = {
  // P (Pequeno) - Square compact sticker
  small: {
    name: 'P',
    width: '200px',
    height: '200px',
    aspectRatio: '1/1',
    layout: 'compact',
    showExerciseList: false,
    showDate: false,
    statsLayout: 'inline',
    headerLayout: 'inline',
    padding: '14px',
    logoSize: 'w-6 h-6',
    zapSize: 'w-3.5 h-3.5',
    brandSize: 'text-[8px]',
    titleSize: 'text-sm',
    subtitleSize: 'text-[8px]',
    statsValueSize: 'text-[11px]',
    statsLabelSize: 'text-[6px]',
    badgeSize: 'text-[7px]',
    watermarkSize: 'text-[7px]',
    gap: 'gap-1.5',
  },
  // M (Médio) - Balanced 4:5 post format
  medium: {
    name: 'M',
    width: '280px',
    height: '350px',
    aspectRatio: '4/5',
    layout: 'balanced',
    showExerciseList: false,
    showDate: false,
    statsLayout: 'grid-3',
    headerLayout: 'stacked',
    padding: '22px',
    logoSize: 'w-12 h-12',
    zapSize: 'w-7 h-7',
    brandSize: 'text-[10px]',
    titleSize: 'text-xl',
    subtitleSize: 'text-[10px]',
    statsValueSize: 'text-xl',
    statsLabelSize: 'text-[8px]',
    badgeSize: 'text-[9px]',
    watermarkSize: 'text-[9px]',
    gap: 'gap-3',
  },
  // G (Grande) - Full vertical story 9:16
  large: {
    name: 'G',
    width: '320px',
    height: '568px',
    aspectRatio: '9/16',
    layout: 'full',
    showExerciseList: true,
    showDate: true,
    statsLayout: 'grid-2x2',
    headerLayout: 'stacked',
    padding: '28px',
    logoSize: 'w-16 h-16',
    zapSize: 'w-9 h-9',
    brandSize: 'text-xs',
    titleSize: 'text-2xl',
    subtitleSize: 'text-xs',
    statsValueSize: 'text-2xl',
    statsLabelSize: 'text-[9px]',
    badgeSize: 'text-[10px]',
    watermarkSize: 'text-[10px]',
    gap: 'gap-4',
  },
};

// Premium style configurations inspired by Strava/Nike Run Club
const styleConfigs = {
  volt: {
    name: 'Volt',
    cardBg: 'linear-gradient(165deg, #0a0a0f 0%, #0d1117 50%, #111827 100%)',
    accent: '#3b82f6',
    accentGlow: 'rgba(59, 130, 246, 0.6)',
    textPrimary: '#ffffff',
    textSecondary: 'rgba(255,255,255,0.7)',
    statsBg: 'rgba(59, 130, 246, 0.12)',
    statsBorder: 'rgba(59, 130, 246, 0.3)',
    badgeBg: 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)',
    glowIntensity: 0.5,
  },
  fire: {
    name: 'Fire',
    cardBg: 'linear-gradient(165deg, #0f0a08 0%, #1a0f0a 50%, #261510 100%)',
    accent: '#f97316',
    accentGlow: 'rgba(249, 115, 22, 0.6)',
    textPrimary: '#ffffff',
    textSecondary: 'rgba(255,255,255,0.7)',
    statsBg: 'rgba(249, 115, 22, 0.12)',
    statsBorder: 'rgba(249, 115, 22, 0.3)',
    badgeBg: 'linear-gradient(135deg, #f97316 0%, #ea580c 100%)',
    glowIntensity: 0.6,
  },
  neon: {
    name: 'Neon',
    cardBg: 'linear-gradient(165deg, #0a0a12 0%, #0f0a18 50%, #150d20 100%)',
    accent: '#d946ef',
    accentGlow: 'rgba(217, 70, 239, 0.6)',
    textPrimary: '#ffffff',
    textSecondary: 'rgba(255,255,255,0.7)',
    statsBg: 'rgba(217, 70, 239, 0.12)',
    statsBorder: 'rgba(217, 70, 239, 0.3)',
    badgeBg: 'linear-gradient(135deg, #d946ef 0%, #a855f7 100%)',
    glowIntensity: 0.7,
  },
  gold: {
    name: 'Gold',
    cardBg: 'linear-gradient(165deg, #0a0908 0%, #151210 50%, #1f1a15 100%)',
    accent: '#fbbf24',
    accentGlow: 'rgba(251, 191, 36, 0.5)',
    textPrimary: '#fef3c7',
    textSecondary: 'rgba(254, 243, 199, 0.7)',
    statsBg: 'rgba(251, 191, 36, 0.1)',
    statsBorder: 'rgba(251, 191, 36, 0.25)',
    badgeBg: 'linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%)',
    glowIntensity: 0.5,
  },
  ocean: {
    name: 'Ocean',
    cardBg: 'linear-gradient(165deg, #051014 0%, #0a1a20 50%, #0f2530 100%)',
    accent: '#06b6d4',
    accentGlow: 'rgba(6, 182, 212, 0.5)',
    textPrimary: '#ffffff',
    textSecondary: 'rgba(255,255,255,0.7)',
    statsBg: 'rgba(6, 182, 212, 0.12)',
    statsBorder: 'rgba(6, 182, 212, 0.3)',
    badgeBg: 'linear-gradient(135deg, #06b6d4 0%, #0891b2 100%)',
    glowIntensity: 0.5,
  },
  dark: {
    name: 'Dark',
    cardBg: 'linear-gradient(165deg, #09090b 0%, #0f0f12 50%, #18181b 100%)',
    accent: '#71717a',
    accentGlow: 'rgba(113, 113, 122, 0.3)',
    textPrimary: '#ffffff',
    textSecondary: 'rgba(255,255,255,0.6)',
    statsBg: 'rgba(255, 255, 255, 0.06)',
    statsBorder: 'rgba(255, 255, 255, 0.12)',
    badgeBg: 'linear-gradient(135deg, #3f3f46 0%, #27272a 100%)',
    glowIntensity: 0.2,
  },
  minimal: {
    name: 'Light',
    cardBg: 'linear-gradient(165deg, #ffffff 0%, #f8fafc 50%, #f1f5f9 100%)',
    accent: '#0f172a',
    accentGlow: 'rgba(15, 23, 42, 0.15)',
    textPrimary: '#0f172a',
    textSecondary: 'rgba(15, 23, 42, 0.6)',
    statsBg: 'rgba(15, 23, 42, 0.05)',
    statsBorder: 'rgba(15, 23, 42, 0.1)',
    badgeBg: 'linear-gradient(135deg, #1e293b 0%, #0f172a 100%)',
    glowIntensity: 0,
  },
};

export function StravaStyleShareCard({ workout, onClose }: StravaStyleShareCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [saving, setSaving] = useState(false);
  const [selectedStyle, setSelectedStyle] = useState<StickerStyle>('volt');
  const [selectedSize, setSelectedSize] = useState<StickerSize>('medium');
  const [showGradientBg, setShowGradientBg] = useState(true);

  const style = styleConfigs[selectedStyle];
  const size = sizeConfigs[selectedSize];

  const formatVolume = (vol: number) => {
    if (vol >= 10000) return `${(vol / 1000).toFixed(0)}k`;
    if (vol >= 1000) return `${(vol / 1000).toFixed(1)}k`;
    return vol.toString();
  };

  const exerciseCount = workout.exercises?.length || 0;
  const topExercises = workout.exercises?.slice(0, 3) || [];
  const workoutDate = workout.completed_at 
    ? format(new Date(workout.completed_at), "d 'de' MMM", { locale: ptBR })
    : '';

  const downloadImage = async () => {
    if (!cardRef.current || saving) return;
    setSaving(true);
    toast.loading('Gerando sticker...');

    try {
      const canvas = await html2canvas(cardRef.current, {
        backgroundColor: null,
        scale: 3,
        logging: false,
        useCORS: true,
      });

      canvas.toBlob((blob) => {
        if (blob) {
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          link.download = `volt-workout-${Date.now()}.png`;
          link.click();
          URL.revokeObjectURL(url);
          toast.dismiss();
          toast.success('Sticker salvo!');
        }
      }, 'image/png');
    } catch (e) {
      console.error(e);
      toast.dismiss();
      toast.error('Erro ao gerar sticker');
    } finally {
      setSaving(false);
    }
  };

  const tryNativeShare = async () => {
    if (!cardRef.current) return;
    setSaving(true);
    toast.loading('Preparando...');

    try {
      const canvas = await html2canvas(cardRef.current, {
        backgroundColor: null,
        scale: 3,
        logging: false,
        useCORS: true,
      });

      const blob = await new Promise<Blob>((resolve) => {
        canvas.toBlob((b) => resolve(b!), 'image/png');
      });

      const file = new File([blob], `volt-workout-${Date.now()}.png`, { type: 'image/png' });

      toast.dismiss();

      if (navigator.share && navigator.canShare?.({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: 'VOLT Workout',
          text: `${workout.name} 💪⚡`,
        });
      } else {
        await downloadImage();
      }
    } catch (e) {
      console.error(e);
      toast.dismiss();
      if ((e as Error).name !== 'AbortError') {
        await downloadImage();
      }
    } finally {
      setSaving(false);
    }
  };

  // ========== CONDITIONAL RENDER FUNCTIONS ==========

  // Header: inline (small) vs stacked (medium/large)
  const renderHeader = () => {
    if (size.headerLayout === 'inline') {
      // Compact inline header for small size
      return (
        <div className="flex items-center gap-2 mb-2">
          <div 
            className={cn("rounded-full bg-white flex items-center justify-center", size.logoSize)}
            style={{
              boxShadow: style.glowIntensity > 0 
                ? `0 2px 10px rgba(0,0,0,0.2), 0 0 15px ${style.accentGlow}`
                : '0 2px 8px rgba(0,0,0,0.15)',
            }}
          >
            <Zap className={cn("text-black fill-black", size.zapSize)} />
          </div>
          <span 
            className={cn("font-bold tracking-[0.2em] uppercase", size.brandSize)}
            style={{ color: style.textPrimary }}
          >
            VOLTGYM
          </span>
        </div>
      );
    }

    // Stacked header for medium/large
    return (
      <>
        <div 
          className={cn("rounded-full bg-white flex items-center justify-center mb-2", size.logoSize)}
          style={{
            boxShadow: style.glowIntensity > 0 
              ? `0 4px 20px rgba(0,0,0,0.25), 0 0 30px ${style.accentGlow}`
              : '0 4px 15px rgba(0,0,0,0.2)',
          }}
        >
          <Zap className={cn("text-black fill-black", size.zapSize)} />
        </div>
        <div 
          className={cn("font-bold tracking-[0.3em] uppercase opacity-60 mb-3", size.brandSize)}
          style={{ color: style.textPrimary }}
        >
          VOLTGYM
        </div>
        {/* Decorative line */}
        <div 
          className="h-0.5 rounded-full mb-3"
          style={{ 
            width: size.layout === 'full' ? '48px' : '32px',
            background: `linear-gradient(90deg, transparent, ${style.accent}, transparent)`,
          }}
        />
      </>
    );
  };

  // Stats: inline (small), grid-3 (medium), grid-2x2 (large)
  const renderStats = () => {
    if (size.statsLayout === 'inline') {
      // Single line compact stats for small
      return (
        <div 
          className="flex items-center justify-center gap-2 py-2 px-3 rounded-lg mb-2"
          style={{
            background: style.statsBg,
            border: `1px solid ${style.statsBorder}`,
          }}
        >
          <div className="flex items-baseline gap-1">
            <span className={cn("font-black", size.statsValueSize)} style={{ color: style.textPrimary }}>
              {workout.duration_minutes}
            </span>
            <span className={cn("uppercase opacity-70", size.statsLabelSize)} style={{ color: style.textSecondary }}>
              min
            </span>
          </div>
          <span className="text-white/30">|</span>
          <div className="flex items-baseline gap-1">
            <span className={cn("font-black", size.statsValueSize)} style={{ color: style.textPrimary }}>
              {formatVolume(workout.total_volume)}
            </span>
            <span className={cn("uppercase opacity-70", size.statsLabelSize)} style={{ color: style.textSecondary }}>
              vol
            </span>
          </div>
          <span className="text-white/30">|</span>
          <div className="flex items-baseline gap-1">
            <span className={cn("font-black", size.statsValueSize)} style={{ color: style.textPrimary }}>
              {exerciseCount}
            </span>
            <span className={cn("uppercase opacity-70", size.statsLabelSize)} style={{ color: style.textSecondary }}>
              ex
            </span>
          </div>
        </div>
      );
    }

    if (size.statsLayout === 'grid-2x2') {
      // 2x2 grid with date for large
      return (
        <div 
          className="grid grid-cols-2 gap-2 w-full mb-4 px-2"
        >
          {[
            { value: workout.duration_minutes, label: 'min' },
            { value: formatVolume(workout.total_volume), label: 'volume' },
            { value: exerciseCount, label: 'exercícios' },
            { value: workoutDate, label: 'data', isDate: true },
          ].map((stat, i) => (
            <div 
              key={i}
              className="flex flex-col items-center justify-center py-3 px-2 rounded-xl"
              style={{
                background: style.statsBg,
                border: `1px solid ${style.statsBorder}`,
              }}
            >
              <span 
                className={cn("font-black tabular-nums leading-none", stat.isDate ? 'text-base' : size.statsValueSize)}
                style={{ color: style.textPrimary }}
              >
                {stat.value}
              </span>
              <span 
                className={cn("uppercase tracking-wide mt-1", size.statsLabelSize)}
                style={{ color: style.textSecondary }}
              >
                {stat.label}
              </span>
            </div>
          ))}
        </div>
      );
    }

    // grid-3: 3 columns for medium
    return (
      <div 
        className="w-full rounded-xl p-3 mb-3"
        style={{
          background: style.statsBg,
          border: `1px solid ${style.statsBorder}`,
        }}
      >
        <div className="flex items-center justify-between">
          {[
            { value: workout.duration_minutes, label: 'min' },
            { value: formatVolume(workout.total_volume), label: 'vol' },
            { value: exerciseCount, label: 'exer' },
          ].map((stat, i) => (
            <React.Fragment key={i}>
              {i > 0 && (
                <div 
                  className="w-px h-8 mx-1"
                  style={{ background: style.statsBorder }}
                />
              )}
              <div className="flex-1 text-center">
                <div 
                  className={cn("font-black tabular-nums leading-none", size.statsValueSize)}
                  style={{ color: style.textPrimary }}
                >
                  {stat.value}
                </div>
                <div 
                  className={cn("font-semibold uppercase tracking-[0.1em] mt-1", size.statsLabelSize)}
                  style={{ color: style.textSecondary }}
                >
                  {stat.label}
                </div>
              </div>
            </React.Fragment>
          ))}
        </div>
      </div>
    );
  };

  // Exercise list (only for large)
  const renderExerciseList = () => {
    if (!size.showExerciseList || topExercises.length === 0) return null;

    return (
      <div 
        className="w-full rounded-xl p-3 mb-4"
        style={{
          background: style.statsBg,
          border: `1px solid ${style.statsBorder}`,
        }}
      >
        <p 
          className="text-[9px] font-bold uppercase tracking-[0.15em] mb-2 opacity-60"
          style={{ color: style.textPrimary }}
        >
          Exercícios
        </p>
        <div className="space-y-1.5">
          {topExercises.map((ex, i) => (
            <div 
              key={i}
              className="flex items-center gap-2"
            >
              <div 
                className="w-1 h-1 rounded-full"
                style={{ background: style.accent }}
              />
              <span 
                className="text-[11px] font-medium truncate"
                style={{ color: style.textSecondary }}
              >
                {ex.name}
              </span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  // Badge rendering
  const renderBadge = () => {
    const isCompact = size.layout === 'compact';
    
    return (
      <div 
        className={cn(
          "inline-flex items-center gap-1 rounded-full mb-2",
          isCompact ? "px-2 py-0.5" : "px-3 py-1"
        )}
        style={{
          background: style.statsBg,
          border: `1px solid ${style.statsBorder}`,
        }}
      >
        <span className={isCompact ? "text-[10px]" : "text-xs"}>🔥</span>
        <span 
          className={cn("font-bold uppercase tracking-[0.08em]", size.badgeSize)}
          style={{ color: style.textPrimary }}
        >
          Completo
        </span>
        <span className={isCompact ? "text-[10px]" : "text-xs"}>💪</span>
      </div>
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/95 backdrop-blur-md p-4 overflow-y-auto"
    >
      {/* Close button */}
      <button
        onClick={onClose}
        className="absolute top-4 right-4 p-2.5 rounded-full bg-white/10 hover:bg-white/20 transition-all z-10"
      >
        <X className="w-5 h-5 text-white" />
      </button>

      {/* Style Selector */}
      <div className="mb-4 w-full max-w-md">
        <p className="text-white/40 text-[10px] font-semibold uppercase tracking-[0.2em] text-center mb-3">
          Estilo
        </p>
        <div className="flex justify-center gap-1.5 flex-wrap px-2">
          {(Object.keys(styleConfigs) as StickerStyle[]).map((key) => (
            <motion.button
              key={key}
              onClick={() => setSelectedStyle(key)}
              whileTap={{ scale: 0.95 }}
              className={cn(
                "px-3 py-1.5 rounded-full text-[11px] font-semibold transition-all",
                selectedStyle === key 
                  ? "bg-white text-black" 
                  : "bg-white/10 text-white/70 hover:bg-white/20"
              )}
            >
              {styleConfigs[key].name}
            </motion.button>
          ))}
        </div>
      </div>

      {/* Size + Background - Same Line */}
      <div className="mb-4 flex items-center justify-center gap-4">
        {/* Size Selector */}
        <div className="flex items-center gap-2">
          <p className="text-white/40 text-[10px] font-semibold uppercase tracking-[0.15em]">
            Tamanho
          </p>
          <div className="flex gap-1.5">
            {(Object.keys(sizeConfigs) as StickerSize[]).map((key) => (
              <motion.button
                key={key}
                onClick={() => setSelectedSize(key)}
                whileTap={{ scale: 0.95 }}
                className={cn(
                  "w-8 h-8 rounded-full text-xs font-bold transition-all",
                  selectedSize === key 
                    ? "bg-white text-black" 
                    : "bg-white/10 text-white/70 hover:bg-white/20"
                )}
              >
                {sizeConfigs[key].name}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Separator */}
        <div className="w-px h-6 bg-white/10" />

        {/* Background toggle */}
        <div className="flex items-center gap-2">
          <p className="text-white/40 text-[10px] font-semibold uppercase tracking-[0.15em]">
            Fundo
          </p>
          <div className="flex gap-1">
            <button
              onClick={() => setShowGradientBg(true)}
              className={cn(
                "text-[10px] font-medium transition-all px-2.5 py-1 rounded-full",
                showGradientBg ? "bg-white/20 text-white" : "text-white/40 hover:text-white/60"
              )}
            >
              Com
            </button>
            <button
              onClick={() => setShowGradientBg(false)}
              className={cn(
                "text-[10px] font-medium transition-all px-2.5 py-1 rounded-full",
                !showGradientBg ? "bg-white/20 text-white" : "text-white/40 hover:text-white/60"
              )}
            >
              Sem
            </button>
          </div>
        </div>
      </div>

      {/* Preview container */}
      <div 
        className="relative rounded-3xl overflow-hidden"
        style={{
          backgroundImage: !showGradientBg 
            ? 'repeating-conic-gradient(#505050 0% 25%, #404040 0% 50%)'
            : 'none',
          backgroundSize: '12px 12px',
          boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
        }}
      >
        {/* === THE STICKER CARD === */}
        <motion.div
          ref={cardRef}
          key={`${selectedStyle}-${selectedSize}-${showGradientBg}`}
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative overflow-hidden flex flex-col"
          style={{ 
            width: size.width,
            height: size.height,
            background: showGradientBg ? style.cardBg : 'transparent',
            padding: size.padding,
          }}
        >
          {/* Ambient glow effects */}
          {showGradientBg && style.glowIntensity > 0 && (
            <>
              <div 
                className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full blur-[80px] pointer-events-none"
                style={{ 
                  width: size.layout === 'compact' ? '150px' : size.layout === 'balanced' ? '220px' : '280px',
                  height: size.layout === 'compact' ? '150px' : size.layout === 'balanced' ? '220px' : '280px',
                  background: style.accent,
                  opacity: style.glowIntensity * 0.4,
                }}
              />
              <div 
                className="absolute bottom-0 right-0 translate-x-1/4 translate-y-1/4 rounded-full blur-[60px] pointer-events-none"
                style={{ 
                  width: size.layout === 'compact' ? '100px' : size.layout === 'balanced' ? '160px' : '200px',
                  height: size.layout === 'compact' ? '100px' : size.layout === 'balanced' ? '160px' : '200px',
                  background: style.accent,
                  opacity: style.glowIntensity * 0.25,
                }}
              />
            </>
          )}

          {/* Content - Flex layout */}
          <div className="relative z-10 flex flex-col items-center flex-1 justify-between">
            {/* Top section: Header + Title */}
            <div className="flex flex-col items-center">
              {renderHeader()}

              {/* Workout Title */}
              <h1 
                className={cn(
                  "font-black uppercase text-center leading-tight tracking-tight",
                  size.titleSize,
                  size.layout === 'compact' ? 'mb-0.5' : 'mb-1'
                )}
                style={{ 
                  color: style.textPrimary,
                  maxWidth: size.layout === 'compact' ? '170px' : size.layout === 'balanced' ? '240px' : '280px',
                  textShadow: style.glowIntensity > 0 
                    ? `0 2px 20px ${style.accentGlow}`
                    : 'none',
                }}
              >
                {workout.name}
              </h1>

              {/* Focus subtitle - only show if different from name */}
              {workout.focus && workout.focus.toLowerCase().trim() !== workout.name.toLowerCase().trim() && (
                <p 
                  className={cn(
                    "font-semibold uppercase tracking-[0.15em]",
                    size.subtitleSize,
                    size.layout === 'compact' ? 'mb-2' : 'mb-3'
                  )}
                  style={{ color: style.textSecondary }}
                >
                  {workout.focus}
                </p>
              )}
            </div>

            {/* Middle section: Stats + Exercises */}
            <div className="flex flex-col items-center w-full">
              {renderStats()}
              {renderExerciseList()}
            </div>

            {/* Bottom section: Badge + Watermark */}
            <div className="flex flex-col items-center">
              {renderBadge()}

              {/* Watermark */}
              <div 
                className="flex items-center gap-1"
                style={{ color: style.textSecondary }}
              >
                <span className={size.layout === 'compact' ? 'text-[9px]' : 'text-[11px]'}>⚡</span>
                <span className={cn("font-semibold tracking-wide", size.watermarkSize)}>
                  @voltgym.app
                </span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Info text */}
      <p className="text-white/30 text-[10px] text-center mt-4 mb-4 flex items-center gap-2 uppercase tracking-wider">
        {showGradientBg ? 'Pronto para postar' : 'Fundo transparente • Ideal para stories'}
      </p>

      {/* Action buttons */}
      <div className="flex gap-3 w-full max-w-xs">
        <Button
          onClick={downloadImage}
          disabled={saving}
          variant="outline"
          className="flex-1 h-12 bg-white/5 border-white/20 text-white hover:bg-white/10 rounded-xl font-semibold"
        >
          <Download className="w-4 h-4 mr-2" />
          Salvar
        </Button>
        <Button
          onClick={tryNativeShare}
          disabled={saving}
          className="flex-1 h-12 rounded-xl font-semibold text-white"
          style={{
            background: style.badgeBg,
            boxShadow: `0 4px 20px ${style.accentGlow}`,
          }}
        >
          <Share2 className="w-4 h-4 mr-2" />
          Compartilhar
        </Button>
      </div>

      {/* Instagram tip */}
      <p className="text-white/30 text-[10px] text-center mt-4 max-w-xs">
        Marque <span className="font-semibold text-white/50">@voltgym.app</span> no Instagram
      </p>
    </motion.div>
  );
}
