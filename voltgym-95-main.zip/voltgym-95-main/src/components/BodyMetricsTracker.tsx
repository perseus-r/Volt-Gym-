import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Scale, Camera, TrendingUp, Image as ImageIcon } from "lucide-react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

interface BodyMetric {
  id: string;
  date: string;
  weight: number;
  body_fat_pct?: number;
  measurements?: {
    chest?: number;
    waist?: number;
    hips?: number;
    arms?: number;
    legs?: number;
  };
  notes?: string;
}

export function BodyMetricsTracker() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [metrics, setMetrics] = useState<BodyMetric[]>([]);
  const [weight, setWeight] = useState("");
  const [bodyFat, setBodyFat] = useState("");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user) return;
    loadMetrics();
  }, [user]);

  const loadMetrics = async () => {
    try {
      const { data, error } = await supabase
        .from('body_metrics')
        .select('*')
        .eq('user_id', user!.id)
        .order('date', { ascending: false })
        .limit(30);

      if (error) throw error;
      setMetrics((data || []) as BodyMetric[]);
    } catch (error) {
      console.error('Error loading metrics:', error);
    }
  };

  const handleSave = async () => {
    if (!weight) {
      toast({
        title: "Erro",
        description: "Por favor, insira seu peso.",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const today = new Date().toISOString().split('T')[0];
      const { error } = await supabase
        .from('body_metrics')
        .insert({
          user_id: user!.id,
          date: today,
          weight: parseFloat(weight),
          body_fat_pct: bodyFat ? parseFloat(bodyFat) : null,
          notes
        });

      if (error) throw error;

      toast({
        title: "✅ Medições Salvas",
        description: "Suas métricas foram registradas com sucesso.",
      });

      setWeight("");
      setBodyFat("");
      setNotes("");
      await loadMetrics();
    } catch (error) {
      console.error('Error saving metrics:', error);
      toast({
        title: "Erro",
        description: "Não foi possível salvar. Tente novamente.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Preparar dados para o gráfico (últimos 30 dias)
  const chartData = metrics
    .slice(0, 30)
    .reverse()
    .map(m => ({
      date: new Date(m.date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }),
      weight: m.weight,
      bodyFat: m.body_fat_pct || 0
    }));

  // Calcular média móvel de 7 dias
  const calculateMovingAverage = (data: typeof chartData, window: number) => {
    return data.map((item, index) => {
      if (index < window - 1) return { ...item, avg: null };
      const slice = data.slice(index - window + 1, index + 1);
      const avg = slice.reduce((sum, d) => sum + d.weight, 0) / window;
      return { ...item, avg: Number(avg.toFixed(1)) };
    });
  };

  const dataWithAvg = calculateMovingAverage(chartData, 7);

  const latestMetric = metrics[0];
  const previousMetric = metrics[1];
  const weightChange = latestMetric && previousMetric 
    ? latestMetric.weight - previousMetric.weight 
    : 0;

  return (
    <div className="space-y-4">
      {/* Current Stats */}
      {latestMetric && (
        <Card className="p-6 bg-gradient-to-br from-accent/10 to-accent-2/10 border-accent/20">
          <div className="flex items-start justify-between">
            <div>
              <div className="text-sm text-muted-foreground mb-1">Peso Atual</div>
              <div className="text-4xl font-bold text-foreground mb-2">
                {latestMetric.weight}<span className="text-lg">kg</span>
              </div>
              {weightChange !== 0 && (
                <div className={`flex items-center gap-1 text-sm ${
                  weightChange > 0 ? 'text-accent' : 'text-green-500'
                }`}>
                  <TrendingUp className={`h-4 w-4 ${weightChange < 0 ? 'rotate-180' : ''}`} />
                  {Math.abs(weightChange).toFixed(1)}kg desde última medição
                </div>
              )}
            </div>
            {latestMetric.body_fat_pct && (
              <div className="text-right">
                <div className="text-sm text-muted-foreground mb-1">% Gordura</div>
                <div className="text-2xl font-bold text-accent">
                  {latestMetric.body_fat_pct}%
                </div>
              </div>
            )}
          </div>
        </Card>
      )}

      {/* Weight Trend Chart */}
      {chartData.length > 1 && (
        <Card className="p-6 bg-surface/50 border-border">
          <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-accent" />
            Evolução de Peso (30 dias)
          </h3>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={dataWithAvg}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey="date" 
                stroke="hsl(var(--muted-foreground))"
                style={{ fontSize: '12px' }}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                style={{ fontSize: '12px' }}
                domain={['dataMin - 2', 'dataMax + 2']}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'hsl(var(--surface))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="weight" 
                stroke="hsl(var(--accent))" 
                strokeWidth={2}
                dot={{ fill: 'hsl(var(--accent))' }}
              />
              <Line 
                type="monotone" 
                dataKey="avg" 
                stroke="hsl(var(--accent-2))" 
                strokeWidth={2}
                strokeDasharray="5 5"
                dot={false}
                name="Média 7d"
              />
            </LineChart>
          </ResponsiveContainer>
          <div className="mt-2 text-xs text-muted-foreground text-center">
            Linha tracejada = média móvel de 7 dias
          </div>
        </Card>
      )}

      {/* Add New Measurement */}
      <Card className="p-6 bg-surface/50 border-border">
        <h3 className="text-lg font-semibold text-foreground mb-4 flex items-center gap-2">
          <Scale className="h-5 w-5 text-accent" />
          Adicionar Medição
        </h3>
        
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="weight">Peso (kg) *</Label>
              <Input
                id="weight"
                type="number"
                step="0.1"
                placeholder="70.5"
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="bodyFat">% Gordura (opcional)</Label>
              <Input
                id="bodyFat"
                type="number"
                step="0.1"
                placeholder="15.0"
                value={bodyFat}
                onChange={(e) => setBodyFat(e.target.value)}
              />
            </div>
          </div>

          <div>
            <Label htmlFor="notes">Observações (opcional)</Label>
            <Textarea
              id="notes"
              placeholder="Como você está se sentindo? Alguma mudança notável?"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
            />
          </div>

          <Button 
            onClick={handleSave} 
            disabled={loading}
            className="w-full bg-gradient-to-r from-accent to-accent-2"
          >
            {loading ? "Salvando..." : "Salvar Medição"}
          </Button>
        </div>
      </Card>

      {/* Recent Measurements */}
      {metrics.length > 0 && (
        <Card className="p-6 bg-surface/50 border-border">
          <h3 className="text-lg font-semibold text-foreground mb-4">
            Histórico Recente
          </h3>
          <div className="space-y-2">
            {metrics.slice(0, 5).map((metric) => (
              <div
                key={metric.id}
                className="flex items-center justify-between p-3 rounded-lg bg-background/50 border border-border/50"
              >
                <div>
                  <div className="text-sm font-medium text-foreground">
                    {new Date(metric.date).toLocaleDateString('pt-BR', { 
                      day: '2-digit', 
                      month: 'long',
                      year: 'numeric'
                    })}
                  </div>
                  {metric.notes && (
                    <div className="text-xs text-muted-foreground mt-1">
                      {metric.notes}
                    </div>
                  )}
                </div>
                <div className="text-right">
                  <div className="text-lg font-bold text-foreground">
                    {metric.weight}kg
                  </div>
                  {metric.body_fat_pct && (
                    <div className="text-xs text-muted-foreground">
                      {metric.body_fat_pct}% gordura
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}