import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { 
  User, Dumbbell, Target, Settings, Apple, 
  ChevronLeft, ChevronRight, Check, Loader2 
} from 'lucide-react';

interface OnboardingData {
  // Step 1: Physical Data
  age: number | null;
  sexo: string;
  height: number | null;
  weight: number | null;
  
  // Step 2: Training Experience
  experience_level: string;
  tempo_treino_meses: number;
  lesoes_historico: string[];
  limitacoes: string;
  
  // Step 3: Goals
  objetivo_principal: string;
  goal: string;
  frequencia_treino: number;
  
  // Step 4: Preferences
  workout_location: string;
  equipamentos_disponiveis: string[];
  exercicios_evitados: string[];
  preferencias_treino: string;
  
  // Step 5: Nutrition (Optional)
  restricoes_alimentares: string[];
  alergias: string[];
  objetivo_calorico: number | null;
  estilo_alimentar: string;
}

const INITIAL_DATA: OnboardingData = {
  age: null,
  sexo: '',
  height: null,
  weight: null,
  experience_level: '',
  tempo_treino_meses: 0,
  lesoes_historico: [],
  limitacoes: '',
  objetivo_principal: '',
  goal: '',
  frequencia_treino: 4,
  workout_location: '',
  equipamentos_disponiveis: [],
  exercicios_evitados: [],
  preferencias_treino: '',
  restricoes_alimentares: [],
  alergias: [],
  objetivo_calorico: null,
  estilo_alimentar: '',
};

const EXPERIENCE_LEVELS = [
  { value: 'iniciante', label: 'Iniciante', desc: 'Menos de 6 meses de treino' },
  { value: 'intermediario', label: 'Intermediário', desc: '6 meses a 2 anos' },
  { value: 'avancado', label: 'Avançado', desc: 'Mais de 2 anos consistentes' },
];

const GOALS = [
  { value: 'massa', label: 'Ganho de Massa', icon: '💪' },
  { value: 'forca', label: 'Força', icon: '🏋️' },
  { value: 'emagrecimento', label: 'Emagrecimento', icon: '🔥' },
  { value: 'performance', label: 'Performance', icon: '⚡' },
  { value: 'saude', label: 'Saúde Geral', icon: '❤️' },
];

const LOCATIONS = [
  { value: 'academia', label: 'Academia' },
  { value: 'casa', label: 'Casa' },
  { value: 'ar_livre', label: 'Ar Livre' },
  { value: 'hibrido', label: 'Híbrido' },
];

const EQUIPMENTS = [
  'Barra e anilhas', 'Halteres', 'Máquinas', 'Cabos', 
  'Kettlebell', 'Elásticos', 'TRX', 'Barra fixa'
];

const COMMON_INJURIES = [
  'Ombro', 'Joelho', 'Lombar', 'Cervical', 
  'Cotovelo', 'Punho', 'Tornozelo', 'Quadril'
];

const DIETARY_RESTRICTIONS = [
  'Vegetariano', 'Vegano', 'Sem glúten', 'Sem lactose', 
  'Low carb', 'Cetogênica', 'Jejum intermitente'
];

const CompleteOnboardingWizard: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [currentStep, setCurrentStep] = useState(0);
  const [data, setData] = useState<OnboardingData>(INITIAL_DATA);
  const [loading, setLoading] = useState(false);

  const totalSteps = 5;
  const progress = ((currentStep + 1) / totalSteps) * 100;

  useEffect(() => {
    // Load existing profile data
    const loadProfile = async () => {
      if (!user?.id) return;
      
      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', user.id)
        .single();
      
      if (profile) {
        setData(prev => ({
          ...prev,
          age: profile.age,
          sexo: profile.sexo || '',
          height: profile.height,
          weight: profile.weight,
          experience_level: profile.experience_level || '',
          tempo_treino_meses: profile.tempo_treino_meses || 0,
          lesoes_historico: profile.lesoes_historico || [],
          limitacoes: (profile.limitacoes || []).join(', '),
          objetivo_principal: profile.objetivo_principal || '',
          goal: profile.goal || '',
          frequencia_treino: profile.frequencia_treino || 4,
          workout_location: profile.workout_location || '',
          equipamentos_disponiveis: profile.equipamentos_disponiveis || [],
          exercicios_evitados: profile.exercicios_evitados || [],
          preferencias_treino: profile.preferencias_treino || '',
          restricoes_alimentares: profile.restricoes_alimentares || [],
          alergias: profile.alergias || [],
          objetivo_calorico: profile.objetivo_calorico,
          estilo_alimentar: profile.estilo_alimentar || '',
        }));
      }
    };
    
    loadProfile();
  }, [user?.id]);

  const updateData = (field: keyof OnboardingData, value: any) => {
    setData(prev => ({ ...prev, [field]: value }));
  };

  const toggleArrayItem = (field: keyof OnboardingData, item: string) => {
    const currentArray = data[field] as string[];
    const newArray = currentArray.includes(item)
      ? currentArray.filter(i => i !== item)
      : [...currentArray, item];
    updateData(field, newArray);
  };

  const handleNext = () => {
    if (currentStep < totalSteps - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      handleComplete();
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleComplete = async () => {
    if (!user?.id) {
      toast.error('Usuário não autenticado');
      return;
    }

    setLoading(true);
    try {
      const profileData = {
        age: data.age,
        sexo: data.sexo,
        height: data.height,
        weight: data.weight,
        experience_level: data.experience_level,
        tempo_treino_meses: data.tempo_treino_meses,
        lesoes_historico: data.lesoes_historico,
        limitacoes: data.limitacoes.split(',').map(s => s.trim()).filter(Boolean),
        objetivo_principal: data.objetivo_principal,
        goal: data.goal || data.objetivo_principal,
        frequencia_treino: data.frequencia_treino,
        workout_location: data.workout_location,
        equipamentos_disponiveis: data.equipamentos_disponiveis,
        exercicios_evitados: data.exercicios_evitados,
        preferencias_treino: data.preferencias_treino,
        restricoes_alimentares: data.restricoes_alimentares,
        alergias: data.alergias,
        objetivo_calorico: data.objetivo_calorico,
        estilo_alimentar: data.estilo_alimentar,
        onboarding_completed: true,
        onboarding_step: totalSteps,
        updated_at: new Date().toISOString(),
      };

      const { error } = await supabase
        .from('profiles')
        .update(profileData)
        .eq('user_id', user.id);

      if (error) throw error;

      toast.success('Perfil completo! Vamos treinar! 💪');
      navigate('/dashboard');
    } catch (error) {
      console.error('Error saving profile:', error);
      toast.error('Erro ao salvar perfil');
    } finally {
      setLoading(false);
    }
  };

  const isStepValid = (): boolean => {
    switch (currentStep) {
      case 0: // Physical Data
        return !!(data.age && data.sexo && data.height && data.weight);
      case 1: // Training Experience
        return !!data.experience_level;
      case 2: // Goals
        return !!(data.objetivo_principal && data.frequencia_treino);
      case 3: // Preferences
        return !!data.workout_location;
      case 4: // Nutrition (optional)
        return true;
      default:
        return false;
    }
  };

  const renderStepIcon = (step: number) => {
    const icons = [User, Dumbbell, Target, Settings, Apple];
    const Icon = icons[step];
    return <Icon className="w-5 h-5" />;
  };

  const renderStep = () => {
    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Idade</Label>
                <Input
                  type="number"
                  value={data.age || ''}
                  onChange={e => updateData('age', parseInt(e.target.value) || null)}
                  placeholder="25"
                />
              </div>
              <div className="space-y-2">
                <Label>Sexo</Label>
                <div className="flex gap-2">
                  {['M', 'F'].map(sex => (
                    <Button
                      key={sex}
                      type="button"
                      variant={data.sexo === sex ? 'default' : 'outline'}
                      onClick={() => updateData('sexo', sex)}
                      className="flex-1"
                    >
                      {sex === 'M' ? 'Masculino' : 'Feminino'}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Altura (cm)</Label>
                <Input
                  type="number"
                  value={data.height || ''}
                  onChange={e => updateData('height', parseInt(e.target.value) || null)}
                  placeholder="175"
                />
              </div>
              <div className="space-y-2">
                <Label>Peso (kg)</Label>
                <Input
                  type="number"
                  value={data.weight || ''}
                  onChange={e => updateData('weight', parseFloat(e.target.value) || null)}
                  placeholder="70"
                />
              </div>
            </div>
          </div>
        );

      case 1:
        return (
          <div className="space-y-6">
            <div className="space-y-3">
              <Label>Nível de Experiência</Label>
              <div className="grid gap-3">
                {EXPERIENCE_LEVELS.map(level => (
                  <Button
                    key={level.value}
                    type="button"
                    variant={data.experience_level === level.value ? 'default' : 'outline'}
                    onClick={() => updateData('experience_level', level.value)}
                    className="h-auto py-3 justify-start"
                  >
                    <div className="text-left">
                      <div className="font-medium">{level.label}</div>
                      <div className="text-xs opacity-70">{level.desc}</div>
                    </div>
                  </Button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Tempo de treino (meses)</Label>
              <Input
                type="number"
                value={data.tempo_treino_meses || ''}
                onChange={e => updateData('tempo_treino_meses', parseInt(e.target.value) || 0)}
                placeholder="12"
              />
            </div>

            <div className="space-y-3">
              <Label>Histórico de lesões (se houver)</Label>
              <div className="flex flex-wrap gap-2">
                {COMMON_INJURIES.map(injury => (
                  <Button
                    key={injury}
                    type="button"
                    variant={data.lesoes_historico.includes(injury) ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => toggleArrayItem('lesoes_historico', injury)}
                  >
                    {injury}
                  </Button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Outras limitações</Label>
              <Textarea
                value={data.limitacoes}
                onChange={e => updateData('limitacoes', e.target.value)}
                placeholder="Descreva outras limitações que devemos considerar..."
                rows={2}
              />
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="space-y-3">
              <Label>Objetivo Principal</Label>
              <div className="grid gap-3">
                {GOALS.map(goal => (
                  <Button
                    key={goal.value}
                    type="button"
                    variant={data.objetivo_principal === goal.value ? 'default' : 'outline'}
                    onClick={() => updateData('objetivo_principal', goal.value)}
                    className="h-auto py-3 justify-start"
                  >
                    <span className="mr-3 text-xl">{goal.icon}</span>
                    <span className="font-medium">{goal.label}</span>
                  </Button>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <Label>Frequência semanal: {data.frequencia_treino}x</Label>
              <div className="flex gap-2">
                {[2, 3, 4, 5, 6].map(freq => (
                  <Button
                    key={freq}
                    type="button"
                    variant={data.frequencia_treino === freq ? 'default' : 'outline'}
                    onClick={() => updateData('frequencia_treino', freq)}
                    className="flex-1"
                  >
                    {freq}x
                  </Button>
                ))}
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="space-y-3">
              <Label>Local de Treino</Label>
              <div className="grid grid-cols-2 gap-3">
                {LOCATIONS.map(loc => (
                  <Button
                    key={loc.value}
                    type="button"
                    variant={data.workout_location === loc.value ? 'default' : 'outline'}
                    onClick={() => updateData('workout_location', loc.value)}
                  >
                    {loc.label}
                  </Button>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <Label>Equipamentos Disponíveis</Label>
              <div className="flex flex-wrap gap-2">
                {EQUIPMENTS.map(equip => (
                  <Button
                    key={equip}
                    type="button"
                    variant={data.equipamentos_disponiveis.includes(equip) ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => toggleArrayItem('equipamentos_disponiveis', equip)}
                  >
                    {equip}
                  </Button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Preferências de treino</Label>
              <Textarea
                value={data.preferencias_treino}
                onChange={e => updateData('preferencias_treino', e.target.value)}
                placeholder="Prefere treinos curtos e intensos, gosta de cardio, prefere exercícios compostos..."
                rows={2}
              />
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <p className="text-sm text-muted-foreground">
              Essas informações são opcionais e serão usadas para recomendações nutricionais futuras.
            </p>

            <div className="space-y-3">
              <Label>Restrições Alimentares</Label>
              <div className="flex flex-wrap gap-2">
                {DIETARY_RESTRICTIONS.map(restriction => (
                  <Button
                    key={restriction}
                    type="button"
                    variant={data.restricoes_alimentares.includes(restriction) ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => toggleArrayItem('restricoes_alimentares', restriction)}
                  >
                    {restriction}
                  </Button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label>Alergias (separadas por vírgula)</Label>
              <Input
                value={data.alergias.join(', ')}
                onChange={e => updateData('alergias', e.target.value.split(',').map(s => s.trim()).filter(Boolean))}
                placeholder="Amendoim, frutos do mar..."
              />
            </div>

            <div className="space-y-2">
              <Label>Objetivo calórico diário (opcional)</Label>
              <Input
                type="number"
                value={data.objetivo_calorico || ''}
                onChange={e => updateData('objetivo_calorico', parseInt(e.target.value) || null)}
                placeholder="2500"
              />
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  const stepTitles = [
    'Dados Físicos',
    'Experiência de Treino',
    'Objetivos',
    'Preferências',
    'Nutrição (Opcional)',
  ];

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 rounded-full bg-primary/10 text-primary">
              {renderStepIcon(currentStep)}
            </div>
            <div>
              <CardTitle className="text-lg">{stepTitles[currentStep]}</CardTitle>
              <CardDescription>Passo {currentStep + 1} de {totalSteps}</CardDescription>
            </div>
          </div>
          <Progress value={progress} className="h-2" />
        </CardHeader>

        <CardContent className="space-y-6">
          {renderStep()}

          <div className="flex gap-3 pt-4">
            {currentStep > 0 && (
              <Button
                type="button"
                variant="outline"
                onClick={handleBack}
                className="flex-1"
              >
                <ChevronLeft className="w-4 h-4 mr-1" />
                Voltar
              </Button>
            )}
            
            <Button
              type="button"
              onClick={handleNext}
              disabled={!isStepValid() || loading}
              className="flex-1"
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : currentStep === totalSteps - 1 ? (
                <>
                  <Check className="w-4 h-4 mr-1" />
                  Concluir
                </>
              ) : (
                <>
                  Próximo
                  <ChevronRight className="w-4 h-4 ml-1" />
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CompleteOnboardingWizard;
