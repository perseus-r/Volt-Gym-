import * as React from 'react';
import * as SheetPrimitive from '@radix-ui/react-dialog';
import { cva, type VariantProps } from 'class-variance-authority';
import { motion, useMotionValue, useTransform, PanInfo } from 'framer-motion';
import { X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { haptic } from '@/utils/haptics';

const PremiumSheet = SheetPrimitive.Root;
const PremiumSheetTrigger = SheetPrimitive.Trigger;
const PremiumSheetClose = SheetPrimitive.Close;
const PremiumSheetPortal = SheetPrimitive.Portal;

const PremiumSheetOverlay = React.forwardRef<
  React.ElementRef<typeof SheetPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof SheetPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <SheetPrimitive.Overlay
    className={cn(
      'fixed inset-0 z-50 bg-black/80 backdrop-blur-sm',
      'data-[state=open]:animate-in data-[state=closed]:animate-out',
      'data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0',
      className
    )}
    {...props}
    ref={ref}
  />
));
PremiumSheetOverlay.displayName = SheetPrimitive.Overlay.displayName;

const sheetVariants = cva(
  'fixed z-50 gap-4 bg-surface/95 backdrop-blur-xl border border-line/20 shadow-2xl transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out',
  {
    variants: {
      side: {
        top: 'inset-x-0 top-0 border-b rounded-b-3xl data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top',
        bottom:
          'inset-x-0 bottom-0 border-t rounded-t-3xl data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom',
        left: 'inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm',
        right:
          'inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm',
      },
    },
    defaultVariants: {
      side: 'bottom',
    },
  }
);

interface PremiumSheetContentProps
  extends React.ComponentPropsWithoutRef<typeof SheetPrimitive.Content>,
    VariantProps<typeof sheetVariants> {
  snapPoints?: number[]; // Percentage values: [25, 50, 90]
  defaultSnap?: number; // Index of snapPoints
  onSnapChange?: (snap: number) => void;
}

const PremiumSheetContent = React.forwardRef<
  React.ElementRef<typeof SheetPrimitive.Content>,
  PremiumSheetContentProps
>(
  (
    {
      side = 'bottom',
      className,
      children,
      snapPoints = [25, 50, 90],
      defaultSnap = 1,
      onSnapChange,
      ...props
    },
    ref
  ) => {
    const [currentSnap, setCurrentSnap] = React.useState(defaultSnap);
    const [isDragging, setIsDragging] = React.useState(false);
    const y = useMotionValue(0);
    const containerRef = React.useRef<HTMLDivElement>(null);

    // Calculate snap positions in pixels
    const getSnapPosition = (snapPercent: number) => {
      if (!containerRef.current) return 0;
      const viewportHeight = window.innerHeight;
      return viewportHeight * (1 - snapPercent / 100);
    };

    const handleDragStart = () => {
      setIsDragging(true);
      haptic.soft();
    };

    const handleDrag = (event: any, info: PanInfo) => {
      // Only allow dragging down on bottom sheet
      if (side === 'bottom' && info.offset.y > 0) {
        y.set(info.offset.y);

        // Haptic feedback when crossing snap points
        const dragPercent = (info.offset.y / window.innerHeight) * 100;
        snapPoints.forEach((snap, index) => {
          if (
            Math.abs(dragPercent - (100 - snap)) < 2 &&
            index !== currentSnap
          ) {
            haptic.light();
          }
        });
      }
    };

    const handleDragEnd = (event: any, info: PanInfo) => {
      setIsDragging(false);

      if (side !== 'bottom') {
        y.set(0);
        return;
      }

      const dragDistance = info.offset.y;
      const dragPercent = (dragDistance / window.innerHeight) * 100;

      // Close if dragged down significantly
      if (dragPercent > 30) {
        haptic.medium();
        props.onPointerDownOutside?.(event);
        return;
      }

      // Find nearest snap point
      let nearestSnap = currentSnap;
      let minDistance = Infinity;

      snapPoints.forEach((snap, index) => {
        const snapDistance = Math.abs(100 - snap - dragPercent);
        if (snapDistance < minDistance) {
          minDistance = snapDistance;
          nearestSnap = index;
        }
      });

      if (nearestSnap !== currentSnap) {
        setCurrentSnap(nearestSnap);
        onSnapChange?.(nearestSnap);
        haptic.light();
      }

      // Snap back
      y.set(0);
    };

    // Dynamic height based on snap point
    const sheetHeight = snapPoints[currentSnap];

    return (
      <PremiumSheetPortal>
        <PremiumSheetOverlay />
        <SheetPrimitive.Content
          ref={ref}
          className={cn(sheetVariants({ side }), className)}
          style={
            side === 'bottom'
              ? { height: `${sheetHeight}vh` }
              : undefined
          }
          {...props}
        >
          <motion.div
            ref={containerRef}
            drag={side === 'bottom' ? 'y' : false}
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={0.1}
            onDragStart={handleDragStart}
            onDrag={handleDrag}
            onDragEnd={handleDragEnd}
            style={{ y }}
            className="h-full flex flex-col"
          >
            {/* Drag Indicator */}
            {side === 'bottom' && (
              <div className="flex justify-center py-3 cursor-grab active:cursor-grabbing">
                <motion.div
                  className="w-12 h-1.5 rounded-full bg-line/40"
                  animate={{
                    width: isDragging ? 60 : 48,
                    backgroundColor: isDragging
                      ? 'hsl(var(--accent))'
                      : 'hsl(var(--line) / 0.4)',
                  }}
                  transition={{ duration: 0.2 }}
                />
              </div>
            )}

            {/* Close Button for non-bottom sheets */}
            {side !== 'bottom' && (
              <SheetPrimitive.Close className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary">
                <X className="h-4 w-4" />
                <span className="sr-only">Close</span>
              </SheetPrimitive.Close>
            )}

            {/* Content */}
            <div className="flex-1 overflow-auto px-6 pb-6">{children}</div>
          </motion.div>
        </SheetPrimitive.Content>
      </PremiumSheetPortal>
    );
  }
);
PremiumSheetContent.displayName = SheetPrimitive.Content.displayName;

const PremiumSheetHeader = ({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn(
      'flex flex-col space-y-2 text-center sm:text-left mb-4',
      className
    )}
    {...props}
  />
);
PremiumSheetHeader.displayName = 'PremiumSheetHeader';

const PremiumSheetFooter = ({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn(
      'flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2 mt-4',
      className
    )}
    {...props}
  />
);
PremiumSheetFooter.displayName = 'PremiumSheetFooter';

const PremiumSheetTitle = React.forwardRef<
  React.ElementRef<typeof SheetPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof SheetPrimitive.Title>
>(({ className, ...props }, ref) => (
  <SheetPrimitive.Title
    ref={ref}
    className={cn('text-xl font-bold text-txt', className)}
    {...props}
  />
));
PremiumSheetTitle.displayName = SheetPrimitive.Title.displayName;

const PremiumSheetDescription = React.forwardRef<
  React.ElementRef<typeof SheetPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof SheetPrimitive.Description>
>(({ className, ...props }, ref) => (
  <SheetPrimitive.Description
    ref={ref}
    className={cn('text-sm text-txt-2', className)}
    {...props}
  />
));
PremiumSheetDescription.displayName = SheetPrimitive.Description.displayName;

export {
  PremiumSheet,
  PremiumSheetPortal,
  PremiumSheetOverlay,
  PremiumSheetTrigger,
  PremiumSheetClose,
  PremiumSheetContent,
  PremiumSheetHeader,
  PremiumSheetFooter,
  PremiumSheetTitle,
  PremiumSheetDescription,
};
