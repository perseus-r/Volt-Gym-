import * as React from "react";
import { motion, HTMLMotionProps } from "framer-motion";
import { cn } from "@/lib/utils";
import { usePageTheme } from "@/hooks/usePageTheme";

/**
 * PremiumGlassCard - iOS 18 style glassmorphism with dynamic effects
 * Features:
 * - Multi-layer frosted glass effect
 * - Dynamic scroll-based reflections
 * - Animated gradient borders (shimmer)
 * - Contextual glow based on page theme
 * - Multiple intensity levels
 */

export interface PremiumGlassCardProps extends Omit<HTMLMotionProps<"div">, "ref"> {
  /** Glass intensity: subtle, medium, intense */
  intensity?: "subtle" | "medium" | "intense";
  /** Enable animated gradient border */
  shimmerBorder?: boolean;
  /** Enable contextual glow effect */
  glow?: boolean;
  /** Glow color override (uses theme accent by default) */
  glowColor?: string;
  /** Enable hover lift effect */
  hoverLift?: boolean;
  /** Enable tap scale effect */
  tapScale?: boolean;
  /** Card padding size */
  padding?: "none" | "sm" | "md" | "lg" | "xl";
  /** Border radius size */
  radius?: "sm" | "md" | "lg" | "xl" | "2xl" | "3xl";
  /** Enable reflection overlay */
  reflection?: boolean;
  /** Loading state with skeleton */
  loading?: boolean;
  children?: React.ReactNode;
}

const intensityStyles = {
  subtle: "bg-card/40 backdrop-blur-md border-white/5",
  medium: "bg-card/60 backdrop-blur-xl border-white/10",
  intense: "bg-card/80 backdrop-blur-2xl border-white/15",
};

const paddingStyles = {
  none: "",
  sm: "p-3",
  md: "p-4",
  lg: "p-6",
  xl: "p-8",
};

const radiusStyles = {
  sm: "rounded-lg",
  md: "rounded-xl",
  lg: "rounded-2xl",
  xl: "rounded-3xl",
  "2xl": "rounded-[2rem]",
  "3xl": "rounded-[2.5rem]",
};

export const PremiumGlassCard = React.forwardRef<HTMLDivElement, PremiumGlassCardProps>(
  (
    {
      className,
      intensity = "medium",
      shimmerBorder = false,
      glow = false,
      glowColor,
      hoverLift = true,
      tapScale = true,
      padding = "md",
      radius = "xl",
      reflection = false,
      loading = false,
      children,
      ...props
    },
    ref
  ) => {
    const { primaryColor } = usePageTheme();
    const effectiveGlowColor = glowColor || primaryColor || "hsl(var(--accent))";

    // Animation variants
    const cardVariants = {
      initial: { 
        y: 0, 
        scale: 1,
        boxShadow: glow 
          ? `0 0 0 rgba(${effectiveGlowColor}, 0)` 
          : "0 4px 24px rgba(0, 0, 0, 0.1)"
      },
      hover: hoverLift ? { 
        y: -4, 
        scale: 1.01,
        boxShadow: glow 
          ? `0 8px 40px ${effectiveGlowColor}40, 0 0 60px ${effectiveGlowColor}20` 
          : "0 12px 40px rgba(0, 0, 0, 0.15)"
      } : {},
      tap: tapScale ? { 
        scale: 0.98,
        y: 0
      } : {},
    };

    if (loading) {
      return (
        <div
          className={cn(
            "relative overflow-hidden",
            intensityStyles[intensity],
            paddingStyles[padding],
            radiusStyles[radius],
            "border animate-pulse",
            className
          )}
        >
          <div className="space-y-4">
            <div className="h-4 bg-white/10 rounded-lg w-3/4" />
            <div className="h-4 bg-white/10 rounded-lg w-1/2" />
            <div className="h-20 bg-white/5 rounded-xl" />
          </div>
          {/* Shimmer overlay */}
          <div className="absolute inset-0 -translate-x-full animate-[shimmer_2s_infinite] bg-gradient-to-r from-transparent via-white/5 to-transparent" />
        </div>
      );
    }

    return (
      <motion.div
        ref={ref}
        variants={cardVariants}
        initial="initial"
        whileHover="hover"
        whileTap="tap"
        transition={{ 
          type: "spring", 
          stiffness: 400, 
          damping: 25,
          mass: 0.8
        }}
        className={cn(
          "relative overflow-hidden",
          intensityStyles[intensity],
          paddingStyles[padding],
          radiusStyles[radius],
          "border transition-colors duration-300",
          className
        )}
        style={{
          boxShadow: glow 
            ? `0 4px 30px ${effectiveGlowColor}15, inset 0 1px 0 rgba(255,255,255,0.05)` 
            : "0 4px 24px rgba(0, 0, 0, 0.1), inset 0 1px 0 rgba(255,255,255,0.05)"
        }}
        {...props}
      >
        {/* Shimmer border effect */}
        {shimmerBorder && (
          <div className="absolute inset-0 rounded-[inherit] overflow-hidden pointer-events-none">
            <div 
              className="absolute inset-[-200%] animate-[spin_8s_linear_infinite]"
              style={{
                background: `conic-gradient(from 0deg, transparent, ${effectiveGlowColor}40, transparent 40%)`
              }}
            />
            <div className={cn(
              "absolute inset-[1px] rounded-[inherit]",
              intensityStyles[intensity]
            )} />
          </div>
        )}

        {/* Reflection overlay */}
        {reflection && (
          <div 
            className="absolute inset-0 pointer-events-none opacity-30"
            style={{
              background: "linear-gradient(135deg, rgba(255,255,255,0.1) 0%, transparent 50%, transparent 100%)"
            }}
          />
        )}

        {/* Glow effect */}
        {glow && (
          <div 
            className="absolute -inset-1 rounded-[inherit] opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none blur-xl"
            style={{
              background: `radial-gradient(ellipse at center, ${effectiveGlowColor}30, transparent 70%)`
            }}
          />
        )}

        {/* Content */}
        <div className="relative z-10">
          {children}
        </div>
      </motion.div>
    );
  }
);

PremiumGlassCard.displayName = "PremiumGlassCard";

// Preset variants
export const GlassCardSubtle = React.forwardRef<HTMLDivElement, Omit<PremiumGlassCardProps, "intensity">>(
  (props, ref) => <PremiumGlassCard ref={ref} intensity="subtle" {...props} />
);

export const GlassCardIntense = React.forwardRef<HTMLDivElement, Omit<PremiumGlassCardProps, "intensity">>(
  (props, ref) => <PremiumGlassCard ref={ref} intensity="intense" shimmerBorder glow {...props} />
);

export const GlassCardInteractive = React.forwardRef<HTMLDivElement, Omit<PremiumGlassCardProps, "hoverLift" | "tapScale">>(
  (props, ref) => <PremiumGlassCard ref={ref} hoverLift tapScale glow {...props} />
);

// Header component for cards
export const GlassCardHeader = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn("flex flex-col space-y-1.5", className)}
      {...props}
    />
  )
);
GlassCardHeader.displayName = "GlassCardHeader";

// Title component
export const GlassCardTitle = React.forwardRef<HTMLHeadingElement, React.HTMLAttributes<HTMLHeadingElement>>(
  ({ className, ...props }, ref) => (
    <h3
      ref={ref}
      className={cn("text-lg font-semibold text-txt tracking-tight", className)}
      {...props}
    />
  )
);
GlassCardTitle.displayName = "GlassCardTitle";

// Description component
export const GlassCardDescription = React.forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLParagraphElement>>(
  ({ className, ...props }, ref) => (
    <p
      ref={ref}
      className={cn("text-sm text-txt-2", className)}
      {...props}
    />
  )
);
GlassCardDescription.displayName = "GlassCardDescription";

// Content component
export const GlassCardContent = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={cn("pt-0", className)} {...props} />
  )
);
GlassCardContent.displayName = "GlassCardContent";

// Footer component
export const GlassCardFooter = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn("flex items-center pt-4", className)}
      {...props}
    />
  )
);
GlassCardFooter.displayName = "GlassCardFooter";

export default PremiumGlassCard;
