import * as React from 'react';
import { Slot } from '@radix-ui/react-slot';
import { cva, type VariantProps } from 'class-variance-authority';
import { motion, HTMLMotionProps } from 'framer-motion';
import { Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { haptic } from '@/utils/haptics';

const premiumButtonVariants = cva(
  'inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-custom text-sm font-semibold transition-all duration-200 ease-smooth focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-40 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 touch-manipulation select-none relative overflow-hidden',
  {
    variants: {
      variant: {
        default:
          'bg-gradient-to-r from-accent via-accent-bright to-accent text-black font-bold border border-accent/30 shadow-[0_0_40px_rgba(55,160,244,0.4)] hover:shadow-[0_0_60px_rgba(55,160,244,0.6)] hover:scale-[1.02] active:scale-[0.98]',
        destructive:
          'bg-gradient-to-br from-error to-error/80 text-white shadow-lg shadow-error/30 hover:shadow-error/50 border border-error/30',
        outline:
          'border-2 border-line/50 bg-black/50 backdrop-blur-md text-txt hover:bg-black/80 hover:border-accent/40 hover:text-accent shadow-sm',
        secondary:
          'bg-black text-accent border-2 border-accent/40 hover:bg-accent/10 hover:border-accent/60 shadow-md',
        ghost: 'bg-transparent text-txt-2 border border-line/20 hover:bg-white/5 hover:text-txt hover:border-line/30 backdrop-blur-sm',
        link: 'text-accent underline-offset-4 hover:underline hover:text-electric-glow transition-colors duration-150',
        hero: 'bg-gradient-lightning text-accent-ink shadow-[0_0_50px_hsl(var(--electric-blue)/0.6)] hover:shadow-[0_0_70px_hsl(var(--electric-blue)/0.8)] border border-accent/30 font-bold tracking-wide',
        glass:
          'bg-surface/20 backdrop-blur-xl border border-white/10 text-white hover:bg-surface/30 hover:border-white/20 shadow-glass',
        success:
          'bg-gradient-to-br from-accent to-accent-2 text-accent-ink shadow-lg shadow-accent/30 hover:shadow-accent/50 border border-accent/30 font-semibold',
        premium:
          'bg-gradient-chrome text-bg shadow-[0_8px_32px_rgba(255,255,255,0.15)] hover:shadow-[0_12px_48px_rgba(255,255,255,0.25)] border border-white/20 font-bold',
        revolut:
          'btn-revolut-glow bg-gradient-primary text-accent-ink shadow-glow backdrop-blur-sm border-2 border-accent/30 font-bold',
        revolutIntense:
          'btn-revolut-glow-intense bg-gradient-lightning text-accent-ink shadow-[0_0_50px_hsl(var(--electric-blue)/0.6)] border-2 border-accent/40 font-bold tracking-wide',
        revolutPremium:
          'btn-revolut-glow-premium text-txt shadow-[0_8px_32px_rgba(0,0,0,0.3)] border border-white/10 font-bold',
      },
      size: {
        default: 'h-12 px-6 py-2.5 text-sm min-h-[48px]',
        sm: 'h-10 rounded-lg px-4 text-xs min-h-[40px]',
        lg: 'h-14 rounded-2xl px-8 text-base min-h-[56px]',
        xl: 'h-16 rounded-2xl px-10 text-lg min-h-[64px]',
        icon: 'h-12 w-12 rounded-xl min-h-[48px] min-w-[48px]',
      },
      hapticFeedback: {
        none: '',
        light: '',
        medium: '',
        heavy: '',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'default',
      hapticFeedback: 'light',
    },
  }
);

export interface PremiumButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof premiumButtonVariants> {
  asChild?: boolean;
  loading?: boolean;
  success?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  ripple?: boolean;
}

const PremiumButton = React.forwardRef<HTMLButtonElement, PremiumButtonProps>(
  (
    {
      className,
      variant,
      size,
      asChild = false,
      loading = false,
      success = false,
      leftIcon,
      rightIcon,
      ripple = true,
      hapticFeedback = 'light',
      children,
      onClick,
      disabled,
      ...props
    },
    ref
  ) => {
    const [ripples, setRipples] = React.useState<
      Array<{ x: number; y: number; id: number }>
    >([]);

    const Comp = asChild ? Slot : motion.button;

    const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
      if (disabled || loading) return;

      // Haptic feedback
      if (hapticFeedback !== 'none') {
        switch (hapticFeedback) {
          case 'light':
            haptic.light();
            break;
          case 'medium':
            haptic.medium();
            break;
          case 'heavy':
            haptic.heavy();
            break;
        }
      }

      // Ripple effect
      if (ripple) {
        const button = e.currentTarget;
        const rect = button.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const id = Date.now();

        setRipples((prev) => [...prev, { x, y, id }]);

        setTimeout(() => {
          setRipples((prev) => prev.filter((r) => r.id !== id));
        }, 600);
      }

      onClick?.(e);
    };

    if (asChild) {
      return (
        <Slot
          className={cn(premiumButtonVariants({ variant, size, className }))}
          ref={ref}
          onClick={handleClick}
          {...props}
        >
          {children}
        </Slot>
      );
    }

    const motionProps = {
      whileHover: !disabled && !loading ? { scale: 1.02 } : undefined,
      whileTap: !disabled && !loading ? { scale: 0.98 } : undefined,
      transition: { duration: 0.15, ease: [0.4, 0, 0.2, 1] } as const,
    };

    return (
      <motion.button
        className={cn(premiumButtonVariants({ variant, size, className }))}
        ref={ref}
        onClick={handleClick}
        disabled={disabled || loading}
        {...motionProps}
        type={props.type}
        aria-label={props['aria-label']}
        style={props.style}
      >
        {/* Loading Spinner */}
        {loading && (
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0 }}
          >
            <Loader2 className="w-4 h-4 animate-spin" />
          </motion.div>
        )}

        {/* Success Checkmark */}
        {success && !loading && (
          <motion.svg
            className="w-4 h-4"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <motion.path d="M20 6L9 17l-5-5" />
          </motion.svg>
        )}

        {/* Left Icon */}
        {leftIcon && !loading && !success && (
          <span className="flex-shrink-0">{leftIcon}</span>
        )}

        {/* Button Content */}
        {!loading && <span>{children}</span>}

        {/* Right Icon */}
        {rightIcon && !loading && !success && (
          <span className="flex-shrink-0">{rightIcon}</span>
        )}

        {/* Ripple Effect */}
        {ripple && ripples.map((ripple) => (
          <motion.span
            key={ripple.id}
            className="absolute rounded-full bg-white/30 pointer-events-none"
            style={{
              left: ripple.x,
              top: ripple.y,
              width: 0,
              height: 0,
            }}
            initial={{ width: 0, height: 0, opacity: 0.5 }}
            animate={{ width: 300, height: 300, opacity: 0 }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
          />
        ))}

        {/* Shimmer effect for primary variants */}
        {(variant === 'default' ||
          variant === 'hero' ||
          variant === 'revolut') &&
          !disabled &&
          !loading && (
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent"
              initial={{ x: '-100%' }}
              animate={{ x: '100%' }}
              transition={{
                duration: 2,
                repeat: Infinity,
                repeatDelay: 1,
                ease: 'linear',
              }}
            />
          )}
      </motion.button>
    );
  }
);

PremiumButton.displayName = 'PremiumButton';

export { PremiumButton, premiumButtonVariants };
