import * as React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import { Check, AlertCircle, Eye, EyeOff } from 'lucide-react';
import { haptic } from '@/utils/haptics';

export interface PremiumInputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  success?: boolean;
  helperText?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  maxLength?: number;
  showCharCount?: boolean;
  variant?: 'default' | 'glass' | 'premium';
}

const PremiumInput = React.forwardRef<HTMLInputElement, PremiumInputProps>(
  (
    {
      className,
      type,
      label,
      error,
      success,
      helperText,
      leftIcon,
      rightIcon,
      maxLength,
      showCharCount = false,
      variant = 'default',
      disabled,
      ...props
    },
    ref
  ) => {
    const [isFocused, setIsFocused] = React.useState(false);
    const [showPassword, setShowPassword] = React.useState(false);
    const [charCount, setCharCount] = React.useState(0);
    const inputRef = React.useRef<HTMLInputElement>(null);

    React.useImperativeHandle(ref, () => inputRef.current!);

    const handleFocus = () => {
      setIsFocused(true);
      haptic.soft();
    };

    const handleBlur = () => {
      setIsFocused(false);
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      setCharCount(e.target.value.length);
      props.onChange?.(e);
    };

    const togglePasswordVisibility = () => {
      setShowPassword(!showPassword);
      haptic.light();
    };

    const variantStyles = {
      default: 'bg-surface/80 border-line/30 focus:border-accent/50',
      glass: 'bg-surface/20 backdrop-blur-xl border-white/10 focus:border-accent/40',
      premium: 'bg-gradient-to-r from-surface/60 to-surface/40 border-accent/20 focus:border-accent/60',
    };

    const hasError = !!error;
    const hasSuccess = success && !hasError;

    return (
      <div className="w-full">
        {/* Label with float animation */}
        {label && (
          <motion.label
            className={cn(
              'block text-sm font-medium mb-2 transition-colors duration-200',
              isFocused || props.value ? 'text-txt' : 'text-txt-2',
              hasError && 'text-error',
              hasSuccess && 'text-success'
            )}
            initial={false}
            animate={{
              y: isFocused ? -2 : 0,
            }}
            transition={{ duration: 0.2 }}
          >
            {label}
            {props.required && <span className="text-error ml-1">*</span>}
          </motion.label>
        )}

        {/* Input Container */}
        <div className="relative">
          {/* Left Icon */}
          {leftIcon && (
            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-txt-3 pointer-events-none">
              {leftIcon}
            </div>
          )}

          {/* Input Field */}
          <motion.div
            className="relative"
            initial={false}
            animate={{
              scale: isFocused ? 1.01 : 1,
            }}
            transition={{ duration: 0.2 }}
          >
            <input
              ref={inputRef}
              type={type === 'password' && showPassword ? 'text' : type}
              className={cn(
                'flex h-12 w-full rounded-custom px-4 py-3 text-sm transition-all duration-200',
                'border-2 backdrop-blur-sm',
                'focus:outline-none focus:ring-0',
                'disabled:cursor-not-allowed disabled:opacity-50',
                'placeholder:text-txt-3',
                variantStyles[variant],
                leftIcon && 'pl-10',
                (rightIcon || type === 'password' || hasError || hasSuccess) && 'pr-10',
                hasError && 'border-error/50 focus:border-error',
                hasSuccess && 'border-success/50 focus:border-success',
                className
              )}
              onFocus={handleFocus}
              onBlur={handleBlur}
              onChange={handleChange}
              maxLength={maxLength}
              disabled={disabled}
              {...props}
            />

            {/* Focus glow effect */}
            <AnimatePresence>
              {isFocused && !disabled && (
                <motion.div
                  className={cn(
                    'absolute inset-0 rounded-custom pointer-events-none',
                    hasError && 'shadow-[0_0_20px_hsl(var(--error)/0.3)]',
                    hasSuccess && 'shadow-[0_0_20px_hsl(var(--success)/0.3)]',
                    !hasError && !hasSuccess && 'shadow-[0_0_20px_hsl(var(--accent)/0.2)]'
                  )}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.2 }}
                />
              )}
            </AnimatePresence>
          </motion.div>

          {/* Right Icons/Indicators */}
          <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
            {/* Password Toggle */}
            {type === 'password' && (
              <motion.button
                type="button"
                onClick={togglePasswordVisibility}
                className="text-txt-3 hover:text-txt transition-colors"
                whileTap={{ scale: 0.95 }}
              >
                {showPassword ? (
                  <EyeOff className="w-4 h-4" />
                ) : (
                  <Eye className="w-4 h-4" />
                )}
              </motion.button>
            )}

            {/* Success Icon */}
            {hasSuccess && (
              <motion.div
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: 'spring', stiffness: 300, damping: 20 }}
              >
                <Check className="w-4 h-4 text-success" />
              </motion.div>
            )}

            {/* Error Icon with shake */}
            {hasError && (
              <motion.div
                initial={{ scale: 0, x: 0 }}
                animate={{
                  scale: 1,
                  x: [0, -4, 4, -4, 4, 0],
                }}
                transition={{
                  scale: { duration: 0.2 },
                  x: { duration: 0.4, delay: 0.1 },
                }}
              >
                <AlertCircle className="w-4 h-4 text-error" />
              </motion.div>
            )}

            {/* Custom Right Icon */}
            {rightIcon && !hasError && !hasSuccess && (
              <div className="text-txt-3">{rightIcon}</div>
            )}
          </div>
        </div>

        {/* Character Count Progress Ring */}
        {showCharCount && maxLength && (
          <div className="mt-2 flex items-center justify-end gap-2">
            <span
              className={cn(
                'text-xs transition-colors',
                charCount >= maxLength ? 'text-error' : 'text-txt-3'
              )}
            >
              {charCount}/{maxLength}
            </span>
            <svg className="w-5 h-5 -rotate-90" viewBox="0 0 20 20">
              <circle
                cx="10"
                cy="10"
                r="8"
                fill="none"
                stroke="hsl(var(--line))"
                strokeWidth="2"
              />
              <motion.circle
                cx="10"
                cy="10"
                r="8"
                fill="none"
                stroke={charCount >= maxLength ? 'hsl(var(--error))' : 'hsl(var(--accent))'}
                strokeWidth="2"
                strokeLinecap="round"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: charCount / maxLength }}
                transition={{ duration: 0.3 }}
                style={{
                  strokeDasharray: '50.27',
                  strokeDashoffset: 0,
                }}
              />
            </svg>
          </div>
        )}

        {/* Helper Text / Error Message */}
        <AnimatePresence mode="wait">
          {(error || helperText) && (
            <motion.p
              className={cn(
                'mt-2 text-xs',
                hasError ? 'text-error' : 'text-txt-3'
              )}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {error || helperText}
            </motion.p>
          )}
        </AnimatePresence>
      </div>
    );
  }
);

PremiumInput.displayName = 'PremiumInput';

export { PremiumInput };
