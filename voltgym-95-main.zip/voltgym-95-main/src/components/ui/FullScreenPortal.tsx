import { ReactNode, useEffect } from 'react';
import { createPortal } from 'react-dom';

interface FullScreenPortalProps {
  children: ReactNode;
  className?: string;
}

/**
 * Portal that renders children directly to document.body
 * This bypasses any parent transforms (like PageEntranceAnimation)
 * which can break position:fixed on iOS
 * 
 * NOTE: This component is ONLY a visual wrapper. It does NOT control
 * FloatingNavButton visibility - that is managed centrally by route.
 */
export function FullScreenPortal({ children, className = '' }: FullScreenPortalProps) {
  // Prevent body scroll while portal is open
  useEffect(() => {
    const originalOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    
    return () => {
      document.body.style.overflow = originalOverflow;
    };
  }, []);

  return createPortal(
    <div 
      className={`fixed inset-0 z-[100] bg-background ${className}`}
      style={{
        // Force new stacking context
        isolation: 'isolate',
      }}
    >
      {children}
    </div>,
    document.body
  );
}
