import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { Search, X } from 'lucide-react';

interface IPhoneInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  variant?: 'default' | 'search' | 'chat';
  icon?: React.ReactNode;
  onClear?: () => void;
  showClear?: boolean;
}

export const IPhoneInput = React.forwardRef<HTMLInputElement, IPhoneInputProps>(
  ({ className, variant = 'default', icon, onClear, showClear, value, ...props }, ref) => {
    const hasValue = value && String(value).length > 0;

    return (
      <div className="relative">
        {/* Icon */}
        {icon && (
          <div className="absolute left-4 top-1/2 -translate-y-1/2 text-txt-3">
            {icon}
          </div>
        )}
        
        {/* Search Icon for search variant */}
        {variant === 'search' && !icon && (
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-txt-3" />
        )}

        <input
          ref={ref}
          value={value}
          className={cn(
            // Base - optimized for performance
            'w-full',
            'bg-gradient-to-br from-white/[0.08] to-white/[0.03]',
            'border border-white/10',
            'text-txt placeholder:text-txt-3',
            'transition-colors duration-200', // Simplified transition
            'focus:outline-none focus:border-accent/40 focus:ring-2 focus:ring-accent/20',
            'focus:bg-white/[0.1]',
            
            // Variants
            variant === 'default' && 'px-4 py-3 rounded-2xl',
            variant === 'search' && 'pl-11 pr-10 py-3 rounded-2xl',
            variant === 'chat' && 'px-4 py-3 rounded-3xl',
            
            // Icon padding
            icon && 'pl-11',
            
            className
          )}
          {...props}
        />

        {/* Clear button */}
        {showClear && hasValue && onClear && (
          <button
            onClick={onClear}
            className="absolute right-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
          >
            <X className="w-3 h-3 text-txt-2" />
          </button>
        )}
      </div>
    );
  }
);

IPhoneInput.displayName = 'IPhoneInput';

// Chat Input - iOS Messages style
export function IPhoneChatInput({
  value,
  onChange,
  onSend,
  placeholder = 'Mensagem...',
  className,
  disabled,
}: {
  value: string;
  onChange: (value: string) => void;
  onSend: () => void;
  placeholder?: string;
  className?: string;
  disabled?: boolean;
}) {
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey && value.trim()) {
      e.preventDefault();
      onSend();
    }
  };

  return (
    <div className={cn(
      'flex items-center gap-2 p-2',
      'bg-surface/80 backdrop-blur-md', // Reduced blur
      'border-t border-white/10',
      className
    )}>
      <div className="flex-1 relative">
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          disabled={disabled}
          className={cn(
            'w-full px-4 py-3',
            'bg-gradient-to-br from-white/[0.08] to-white/[0.03]',
            'border border-white/15',
            'rounded-3xl',
            'text-txt placeholder:text-txt-3',
            'focus:outline-none focus:border-accent/40',
            'transition-colors duration-200',
            disabled && 'opacity-50 cursor-not-allowed'
          )}
        />
      </div>
      
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={onSend}
        disabled={disabled || !value.trim()}
        className={cn(
          'w-10 h-10 rounded-full',
          'flex items-center justify-center',
          'transition-all duration-200',
          value.trim() ? [
            'bg-gradient-to-br from-accent to-accent-2',
            'text-accent-ink',
            'shadow-lg shadow-accent/30'
          ] : [
            'bg-white/10',
            'text-txt-3'
          ],
          (disabled || !value.trim()) && 'opacity-50 cursor-not-allowed'
        )}
      >
        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" />
        </svg>
      </motion.button>
    </div>
  );
}

// Segmented Control - iOS style
export function IPhoneSegmentedControl({
  segments,
  value,
  onChange,
  className,
}: {
  segments: { value: string; label: string }[];
  value: string;
  onChange: (value: string) => void;
  className?: string;
}) {
  return (
    <div className={cn(
      'flex p-1 rounded-xl',
      'bg-white/[0.06]',
      'border border-white/10',
      className
    )}>
      {segments.map((segment) => (
        <button
          key={segment.value}
          onClick={() => onChange(segment.value)}
          className={cn(
            'flex-1 px-4 py-2 rounded-lg',
            'text-sm font-medium',
            'transition-all duration-200',
            value === segment.value ? [
              'bg-white/[0.12]',
              'text-txt',
              'shadow-sm'
            ] : [
              'text-txt-2',
              'hover:text-txt'
            ]
          )}
        >
          {segment.label}
        </button>
      ))}
    </div>
  );
}
