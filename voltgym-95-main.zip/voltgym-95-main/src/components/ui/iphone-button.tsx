import React from 'react';
import { motion, HTMLMotionProps } from 'framer-motion';
import { cn } from '@/lib/utils';
import { Loader2 } from 'lucide-react';

interface IPhoneButtonProps extends Omit<HTMLMotionProps<'button'>, 'children'> {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'ghost' | 'destructive' | 'premium' | 'glass';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  loading?: boolean;
  icon?: React.ComponentType<{ className?: string }>;
  iconPosition?: 'left' | 'right';
  fullWidth?: boolean;
}

const sizeStyles = {
  sm: 'px-4 py-2 text-sm rounded-xl gap-1.5',
  md: 'px-5 py-3 text-base rounded-2xl gap-2',
  lg: 'px-6 py-4 text-lg rounded-2xl gap-2.5',
  xl: 'px-8 py-5 text-xl rounded-3xl gap-3',
};

const variantStyles = {
  primary: cn(
    'bg-gradient-to-br from-primary to-primary/80',
    'text-primary-foreground font-semibold',
    'shadow-lg shadow-primary/30',
    'border border-primary/50'
  ),
  secondary: cn(
    'bg-gradient-to-br from-white/[0.12] to-white/[0.05]',
    'text-foreground font-medium',
    'border border-white/15',
    'shadow-lg shadow-black/20'
  ),
  ghost: cn(
    'bg-transparent',
    'text-muted-foreground font-medium',
    'hover:bg-white/[0.08]',
    'border border-transparent'
  ),
  destructive: cn(
    'bg-gradient-to-br from-red-500/90 to-red-600/90',
    'text-white font-semibold',
    'shadow-lg shadow-red-500/30',
    'border border-red-500/50'
  ),
  premium: cn(
    'bg-gradient-to-br from-amber-500 via-orange-500 to-red-500',
    'text-white font-bold',
    'shadow-lg shadow-orange-500/40',
    'border border-amber-400/50'
  ),
  glass: cn(
    'bg-white/[0.08]',
    'text-foreground font-medium',
    'border border-white/10',
    'hover:bg-white/[0.12]'
  ),
};

export function IPhoneButton({
  children,
  className,
  variant = 'primary',
  size = 'md',
  loading = false,
  icon: IconComponent,
  iconPosition = 'left',
  fullWidth = false,
  disabled,
  ...props
}: IPhoneButtonProps) {
  const isDisabled = disabled || loading;

  return (
    <motion.button
      whileHover={!isDisabled ? { scale: 1.01, y: -1 } : undefined}
      whileTap={!isDisabled ? { scale: 0.98 } : undefined}
      transition={{
        type: 'spring',
        stiffness: 600, // Increased for faster response
        damping: 35,
      }}
      disabled={isDisabled}
      className={cn(
        // Base
        'relative inline-flex items-center justify-center',
        'font-medium',
        'transition-colors duration-200', // Simplified transition
        'focus:outline-none focus-visible:ring-2 focus-visible:ring-accent/50',
        'overflow-hidden',
        
        // Size
        sizeStyles[size],
        
        // Variant
        variantStyles[variant],
        
        // Full width
        fullWidth && 'w-full',
        
        // Disabled
        isDisabled && 'opacity-50 cursor-not-allowed',
        
        className
      )}
      {...props}
    >
      {/* Shine effect */}
      <div className="absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/20 to-transparent pointer-events-none" />
      
      {/* Content */}
      <span className="relative z-10 flex items-center gap-2">
        {loading ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : (
          IconComponent && iconPosition === 'left' && <IconComponent className="w-5 h-5" />
        )}
        
        {children}
        
        {!loading && IconComponent && iconPosition === 'right' && <IconComponent className="w-5 h-5" />}
      </span>
    </motion.button>
  );
}

// Floating Action Button - iOS style
export function IPhoneFAB({
  children,
  className,
  variant = 'primary',
  size = 'lg',
  ...props
}: IPhoneButtonProps) {
  return (
    <motion.button
      whileHover={{ scale: 1.08, y: -2 }}
      whileTap={{ scale: 0.92 }}
      transition={{
        type: 'spring',
        stiffness: 500,
        damping: 25,
      }}
      className={cn(
        'fixed bottom-24 right-4 z-40',
        'w-14 h-14 rounded-full',
        'flex items-center justify-center',
        'shadow-2xl',
        variant === 'primary' && [
          'bg-gradient-to-br from-accent to-accent-2',
          'shadow-accent/40',
          'text-accent-ink'
        ],
        variant === 'secondary' && [
          'bg-surface/90 backdrop-blur-md',
          'border border-white/20',
          'text-txt'
        ],
        className
      )}
      {...props}
    >
      {/* Shine */}
      <div className="absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/25 to-transparent rounded-t-full pointer-events-none" />
      
      <span className="relative z-10">
        {children}
      </span>
    </motion.button>
  );
}

// Pill Button - iOS style segmented control
export function IPhonePillButton({
  children,
  active = false,
  onClick,
  className,
}: {
  children: React.ReactNode;
  active?: boolean;
  onClick?: () => void;
  className?: string;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'px-4 py-2 rounded-full text-sm font-medium',
        'transition-all duration-200',
        'active:scale-95',
        active ? [
          'bg-accent text-accent-ink',
          'shadow-lg shadow-accent/30'
        ] : [
          'bg-white/[0.08] text-txt-2',
          'hover:bg-white/[0.12]'
        ],
        className
      )}
    >
      {children}
    </button>
  );
}
