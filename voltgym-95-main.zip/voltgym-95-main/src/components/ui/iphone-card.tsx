import React from 'react';
import { motion, HTMLMotionProps } from 'framer-motion';
import { cn } from '@/lib/utils';

interface IPhoneCardProps extends Omit<HTMLMotionProps<'div'>, 'children'> {
  children: React.ReactNode;
  variant?: 'default' | 'widget' | 'button' | 'subtle' | 'premium' | 'glass';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  glow?: boolean;
  gradient?: string;
  interactive?: boolean;
  hoverable?: boolean;
  static?: boolean; // New prop for performance optimization
}

const sizeStyles = {
  sm: 'p-3 rounded-[16px]',
  md: 'p-4 rounded-[20px]',
  lg: 'p-5 rounded-[24px]',
  xl: 'p-6 rounded-[28px]',
};

const variantStyles = {
  default: 'bg-gradient-to-br from-white/[0.08] to-white/[0.02] border-white/10',
  widget: 'bg-gradient-to-br from-white/[0.12] to-white/[0.04] border-white/15',
  button: 'bg-gradient-to-br from-white/[0.15] to-white/[0.05] border-white/20',
  subtle: 'bg-gradient-to-br from-white/[0.05] to-transparent border-white/5',
  premium: 'bg-gradient-to-br from-accent/15 to-accent/5 border-accent/25',
  glass: 'bg-white/[0.05] border-white/10',
};

export function IPhoneCard({
  children,
  className,
  variant = 'default',
  size = 'md',
  glow = false,
  gradient,
  interactive = true,
  hoverable = true,
  static: isStatic = false,
  ...props
}: IPhoneCardProps) {
  const shouldAnimate = interactive && hoverable && !isStatic;
  
  // Static version - no animations, better performance
  if (isStatic) {
    return (
      <div
        className={cn(
          // Base glassmorphism iOS 17
          'relative overflow-hidden',
          'backdrop-blur-md', // Reduced from backdrop-blur-2xl
          'border',
          'shadow-[0_8px_32px_rgba(0,0,0,0.4)]',
          
          // Size & variant
          sizeStyles[size],
          variantStyles[variant],
          
          // Gradient override
          gradient && `bg-gradient-to-br ${gradient}`,
          
          // Glow effect
          glow && 'shadow-accent/20',
          
          // Interactive states
          interactive && 'cursor-pointer active:scale-[0.98]',
          
          // Transitions
          'transition-all duration-200 ease-out',
          
          className
        )}
      >
        {/* Shine effect on top */}
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/30 to-transparent" />
        
        {/* Content */}
        <div className="relative z-10">
          {children}
        </div>
      </div>
    );
  }
  
  // Animated version
  return (
    <motion.div
      whileHover={shouldAnimate ? { scale: 1.02, y: -2 } : undefined}
      whileTap={shouldAnimate ? { scale: 0.98 } : undefined}
      transition={{
        type: 'spring',
        stiffness: 400,
        damping: 25,
      }}
      className={cn(
        // Base glassmorphism iOS 17
        'relative overflow-hidden',
        'backdrop-blur-xl', // Reduced from backdrop-blur-2xl
        'border',
        'shadow-[0_8px_32px_rgba(0,0,0,0.4)]',
        
        // Size & variant
        sizeStyles[size],
        variantStyles[variant],
        
        // Gradient override
        gradient && `bg-gradient-to-br ${gradient}`,
        
        // Glow effect
        glow && 'shadow-accent/20',
        
        // Interactive states
        interactive && 'cursor-pointer active:scale-[0.98]',
        
        // Transitions
        'transition-all duration-300 ease-out',
        
        className
      )}
      {...props}
    >
      {/* Shine effect on top */}
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/30 to-transparent" />
      
      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>
    </motion.div>
  );
}

// Widget Card - Square iOS widget style
export function IPhoneWidgetCard({
  children,
  className,
  color = 'blue',
  ...props
}: IPhoneCardProps & { color?: 'blue' | 'purple' | 'orange' | 'green' | 'red' | 'cyan' }) {
  const colorStyles = {
    blue: 'from-blue-500/20 to-cyan-500/10 border-blue-500/25 shadow-blue-500/20',
    purple: 'from-purple-500/20 to-pink-500/10 border-purple-500/25 shadow-purple-500/20',
    orange: 'from-orange-500/20 to-amber-500/10 border-orange-500/25 shadow-orange-500/20',
    green: 'from-green-500/20 to-emerald-500/10 border-green-500/25 shadow-green-500/20',
    red: 'from-red-500/20 to-rose-500/10 border-red-500/25 shadow-red-500/20',
    cyan: 'from-cyan-500/20 to-blue-500/10 border-cyan-500/25 shadow-cyan-500/20',
  };

  return (
    <IPhoneCard
      variant="widget"
      size="lg"
      glow
      className={cn(
        'bg-gradient-to-br',
        colorStyles[color],
        'shadow-lg',
        className
      )}
      {...props}
    >
      {children}
    </IPhoneCard>
  );
}

// App Icon Button - iOS App Store style
export function IPhoneAppIcon({
  children,
  className,
  gradient,
  label,
  badge,
  onClick,
}: { 
  children: React.ReactNode;
  className?: string;
  gradient?: string;
  label?: string;
  badge?: number | string;
  onClick?: () => void;
}) {
  return (
    <motion.button
      onClick={onClick}
      whileHover={{ scale: 1.08, y: -2 }}
      whileTap={{ scale: 0.92 }}
      transition={{
        type: 'spring',
        stiffness: 500,
        damping: 25,
      }}
      className={cn(
        'flex flex-col items-center gap-2 p-1',
        'focus:outline-none focus-visible:ring-2 focus-visible:ring-accent/50',
        className
      )}
    >
      {/* Icon container */}
      <div className={cn(
        'relative w-16 h-16 rounded-[18px]',
        'bg-gradient-to-br',
        gradient || 'from-accent to-accent-2',
        'flex items-center justify-center',
        'shadow-lg shadow-current/30',
        'overflow-hidden'
      )}>
        {/* Shine overlay */}
        <div className="absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/25 to-transparent rounded-t-[18px]" />
        
        {/* Icon */}
        <div className="relative z-10 text-white">
          {children}
        </div>
        
        {/* Badge */}
        {badge && (
          <div className="absolute -top-1 -right-1 min-w-5 h-5 px-1.5 rounded-full bg-red-500 flex items-center justify-center">
            <span className="text-[10px] font-bold text-white">{badge}</span>
          </div>
        )}
      </div>
      
      {/* Label */}
      {label && (
        <span className="text-[11px] font-medium text-txt-2 text-center leading-tight max-w-16 truncate">
          {label}
        </span>
      )}
    </motion.button>
  );
}

// Section Header - iOS style
export function IPhoneSectionHeader({ 
  title, 
  action,
  className 
}: { 
  title: string; 
  action?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn('flex items-center justify-between mb-3', className)}>
      <h3 className="text-xs font-semibold uppercase tracking-wider text-txt-3">
        {title}
      </h3>
      {action}
    </div>
  );
}

// List Item - iOS Settings style
export function IPhoneListItem({
  icon,
  title,
  subtitle,
  trailing,
  onClick,
  destructive = false,
  className,
}: {
  icon?: React.ReactNode;
  title: string;
  subtitle?: string;
  trailing?: React.ReactNode;
  onClick?: () => void;
  destructive?: boolean;
  className?: string;
}) {
  return (
    <motion.button
      onClick={onClick}
      whileTap={{ scale: 0.98, backgroundColor: 'rgba(255,255,255,0.05)' }}
      className={cn(
        'w-full flex items-center gap-3 p-4',
        'border-b border-white/5 last:border-b-0',
        'transition-colors duration-150',
        'hover:bg-white/[0.03]',
        onClick && 'cursor-pointer',
        className
      )}
    >
      {icon && (
        <div className={cn(
          'w-8 h-8 rounded-lg flex items-center justify-center',
          destructive ? 'bg-red-500/15 text-red-500' : 'bg-accent/15 text-accent'
        )}>
          {icon}
        </div>
      )}
      
      <div className="flex-1 text-left">
        <div className={cn(
          'font-medium',
          destructive ? 'text-red-500' : 'text-txt'
        )}>
          {title}
        </div>
        {subtitle && (
          <div className="text-sm text-txt-3">{subtitle}</div>
        )}
      </div>
      
      {trailing}
    </motion.button>
  );
}
