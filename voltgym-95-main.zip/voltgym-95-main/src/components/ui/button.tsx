import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-custom text-sm font-semibold transition-all duration-200 ease-smooth focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-40 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.97] touch-manipulation select-none",
  {
    variants: {
      variant: {
        default: "bg-gradient-primary text-accent-ink shadow-glow hover:shadow-[0_0_40px_hsl(var(--electric-blue)/0.5)] hover:scale-[1.02] active:scale-[0.98] backdrop-blur-sm border border-accent/20 font-bold",
        destructive: "bg-gradient-to-br from-error to-error/80 text-white shadow-lg shadow-error/30 hover:shadow-error/50 hover:scale-[1.02] active:scale-[0.98] border border-error/30",
        outline: "border-2 border-line/50 bg-surface/30 backdrop-blur-md text-txt hover:bg-surface/60 hover:border-accent/40 hover:text-accent hover:scale-[1.01] active:scale-[0.99] shadow-sm",
        secondary: "bg-surface/80 backdrop-blur-sm text-txt border border-line/30 hover:bg-surface hover:border-line/50 hover:scale-[1.01] active:scale-[0.99] shadow-md",
        ghost: "text-txt-2 hover:bg-surface/50 hover:text-txt hover:scale-[1.02] active:scale-[0.98] backdrop-blur-sm",
        link: "text-accent underline-offset-4 hover:underline hover:text-electric-glow transition-colors duration-150",
        hero: "bg-gradient-lightning text-accent-ink shadow-[0_0_50px_hsl(var(--electric-blue)/0.6)] hover:shadow-[0_0_70px_hsl(var(--electric-blue)/0.8)] hover:scale-[1.03] active:scale-[0.99] border border-accent/30 font-bold tracking-wide",
        glass: "bg-surface/20 backdrop-blur-xl border border-white/10 text-white hover:bg-surface/30 hover:border-white/20 hover:scale-[1.02] active:scale-[0.98] shadow-glass",
        success: "bg-gradient-to-br from-accent to-accent-2 text-accent-ink shadow-lg shadow-accent/30 hover:shadow-accent/50 hover:scale-[1.02] active:scale-[0.98] border border-accent/30 font-semibold",
        premium: "bg-gradient-chrome text-bg shadow-[0_8px_32px_rgba(255,255,255,0.15)] hover:shadow-[0_12px_48px_rgba(255,255,255,0.25)] hover:scale-[1.03] active:scale-[0.98] border border-white/20 font-bold",
        revolut: "btn-revolut-glow bg-gradient-primary text-accent-ink shadow-glow hover:scale-[1.02] active:scale-[0.98] backdrop-blur-sm border-2 border-accent/30 font-bold",
        revolutIntense: "btn-revolut-glow-intense bg-gradient-lightning text-accent-ink shadow-[0_0_50px_hsl(var(--electric-blue)/0.6)] hover:scale-[1.03] active:scale-[0.98] border-2 border-accent/40 font-bold tracking-wide",
        revolutPremium: "btn-revolut-glow-premium text-txt shadow-[0_8px_32px_rgba(0,0,0,0.3)] hover:scale-[1.02] active:scale-[0.98] border border-white/10 font-bold",
      },
      size: {
        default: "h-11 px-5 py-2.5 text-sm",
        sm: "h-9 rounded-lg px-3.5 text-xs",
        lg: "h-14 rounded-2xl px-8 text-base",
        icon: "h-11 w-11 rounded-xl",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />;
  },
);
Button.displayName = "Button";

export { Button, buttonVariants };
