import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Edit, 
  Trash2, 
  Youtube, 
  Star, 
  Target,
  Eye,
  Play
} from "lucide-react";

interface ExercisePreviewCardProps {
  exercise: {
    id: string;
    name: string;
    category_id: string | null;
    primary_muscles: string[] | null;
    difficulty_level: number | null;
    equipment: string | null;
    youtube_url: string | null;
    youtube_video_id: string | null;
    thumbnail_url: string | null;
    view_count: number | null;
  };
  categories: Array<{ id: string; name: string }>;
  onEdit: () => void;
  onDelete: () => void;
}

export const ExercisePreviewCard = ({ 
  exercise, 
  categories, 
  onEdit, 
  onDelete 
}: ExercisePreviewCardProps) => {
  const category = categories.find(c => c.id === exercise.category_id);
  const difficultyStars = exercise.difficulty_level || 3;

  return (
    <Card className="glass-card overflow-hidden hover:shadow-lg transition-all group">
      {/* Thumbnail/Video */}
      <div className="relative h-40 bg-gradient-to-br from-accent/20 to-accent/5 overflow-hidden">
        {exercise.thumbnail_url ? (
          <img 
            src={exercise.thumbnail_url} 
            alt={exercise.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Target className="w-16 h-16 text-accent/30" />
          </div>
        )}
        
        {/* Video Badge */}
        {exercise.youtube_url && (
          <div className="absolute top-3 right-3">
            <Badge className="bg-error/90 text-white border-0 backdrop-blur-sm">
              <Youtube className="w-3 h-3 mr-1" />
              Vídeo
            </Badge>
          </div>
        )}

        {/* Category Badge */}
        {category && (
          <div className="absolute top-3 left-3">
            <Badge variant="outline" className="bg-bg/80 backdrop-blur-sm">
              {category.name}
            </Badge>
          </div>
        )}

        {/* Play Button Overlay */}
        {exercise.youtube_url && (
          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
            <a 
              href={exercise.youtube_url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-4 bg-white/90 rounded-full hover:bg-white transition-colors"
            >
              <Play className="w-6 h-6 text-accent fill-accent" />
            </a>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-4 space-y-3">
        {/* Title */}
        <h3 className="font-bold text-txt line-clamp-2 min-h-[3rem]">
          {exercise.name}
        </h3>

        {/* Difficulty */}
        <div className="flex items-center gap-1">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              className={`w-3.5 h-3.5 ${
                i < difficultyStars
                  ? "fill-accent text-accent"
                  : "text-txt-3"
              }`}
            />
          ))}
        </div>

        {/* Muscles */}
        {exercise.primary_muscles && exercise.primary_muscles.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {exercise.primary_muscles.slice(0, 3).map((muscle) => (
              <Badge 
                key={muscle} 
                variant="outline" 
                className="text-xs bg-accent/10 text-accent border-accent/30"
              >
                {muscle}
              </Badge>
            ))}
            {exercise.primary_muscles.length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{exercise.primary_muscles.length - 3}
              </Badge>
            )}
          </div>
        )}

        {/* Equipment */}
        {exercise.equipment && (
          <p className="text-xs text-txt-2">
            📦 {exercise.equipment}
          </p>
        )}

        {/* Stats */}
        <div className="flex items-center gap-4 text-xs text-txt-3 pt-2 border-t border-border">
          <div className="flex items-center gap-1">
            <Eye className="w-3 h-3" />
            {exercise.view_count || 0} views
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-2 pt-2">
          <Button
            onClick={onEdit}
            variant="outline"
            size="sm"
            className="flex-1"
          >
            <Edit className="w-3 h-3 mr-1" />
            Editar
          </Button>
          <Button
            onClick={onDelete}
            variant="outline"
            size="sm"
            className="text-error hover:text-error hover:bg-error/10"
          >
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      </div>
    </Card>
  );
};
