import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Shield, User, Eye } from 'lucide-react';
import { toast } from 'sonner';

interface RoleManagerProps {
  userId: string;
  currentRole: 'user' | 'moderator' | 'admin';
  onRoleChanged: () => void;
}

export function RoleManager({ userId, currentRole, onRoleChanged }: RoleManagerProps) {
  const [newRole, setNewRole] = useState(currentRole);
  const [loading, setLoading] = useState(false);

  const updateRole = async () => {
    setLoading(true);
    try {
      const { error } = await supabase.functions.invoke('admin-manage-role', {
        body: { targetUserId: userId, newRole }
      });

      if (error) throw error;

      toast.success(`Role atualizado para ${newRole}`);
      onRoleChanged();
    } catch (error) {
      console.error('Error updating role:', error);
      toast.error('Erro ao atualizar role');
    } finally {
      setLoading(false);
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'admin': return <Shield className="w-4 h-4 text-red-400" />;
      case 'moderator': return <Eye className="w-4 h-4 text-yellow-400" />;
      default: return <User className="w-4 h-4 text-gray-400" />;
    }
  };

  return (
    <div className="flex items-center gap-2">
      {getRoleIcon(currentRole)}
      <Select value={newRole} onValueChange={(value: string) => setNewRole(value as 'user' | 'moderator' | 'admin')}>
        <SelectTrigger className="w-32 glass-input">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="user">User</SelectItem>
          <SelectItem value="moderator">Moderator</SelectItem>
          <SelectItem value="admin">Admin</SelectItem>
        </SelectContent>
      </Select>
      {newRole !== currentRole && (
        <Button size="sm" onClick={updateRole} disabled={loading}>
          Atualizar
        </Button>
      )}
    </div>
  );
}
