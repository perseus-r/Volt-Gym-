import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Pencil, Check, X, Loader2 } from 'lucide-react';
import { AthletePlanAdmin } from '@/hooks/useAdminPlans';

interface AthletePlansTableProps {
  plans: AthletePlanAdmin[];
  saving: boolean;
  onUpdate: (id: string, updates: Partial<AthletePlanAdmin>) => Promise<void>;
}

export function AthletePlansTable({ plans, saving, onUpdate }: AthletePlansTableProps) {
  const [editingPlan, setEditingPlan] = useState<AthletePlanAdmin | null>(null);
  const [formData, setFormData] = useState<Partial<AthletePlanAdmin>>({});

  const handleEdit = (plan: AthletePlanAdmin) => {
    setEditingPlan(plan);
    setFormData({
      plan_name: plan.plan_name,
      monthly_price_brl: plan.monthly_price_brl,
      annual_price_brl: plan.annual_price_brl,
      trial_days: plan.trial_days,
      stripe_price_id_monthly: plan.stripe_price_id_monthly,
      stripe_price_id_annual: plan.stripe_price_id_annual,
      max_workouts: plan.max_workouts,
      max_ai_queries: plan.max_ai_queries,
      has_nutrition: plan.has_nutrition,
      has_advanced_metrics: plan.has_advanced_metrics,
      has_verification: plan.has_verification,
      is_active: plan.is_active
    });
  };

  const handleSave = async () => {
    if (!editingPlan) return;
    await onUpdate(editingPlan.id, formData);
    setEditingPlan(null);
  };

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'free': return 'text-gray-400';
      case 'pro': return 'text-accent';
      case 'premium': return 'text-purple-400';
      default: return 'text-white';
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white">Planos de Atletas</h3>
      
      <div className="grid gap-4">
        {plans.map((plan) => (
          <Card key={plan.id} className={`p-4 border ${plan.is_active ? 'border-line/50' : 'border-red-500/30 opacity-60'}`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div>
                  <h4 className={`font-bold ${getTierColor(plan.plan_tier)}`}>
                    {plan.plan_name}
                  </h4>
                  <p className="text-sm text-txt-2">{plan.plan_tier}</p>
                </div>
                
                <div className="flex items-center gap-6 text-sm">
                  <div>
                    <span className="text-txt-3">Preço:</span>
                    <span className="ml-2 font-mono text-white">R$ {plan.monthly_price_brl}</span>
                  </div>
                  <div>
                    <span className="text-txt-3">Trial:</span>
                    <span className="ml-2 text-white">{plan.trial_days} dias</span>
                  </div>
                  <div>
                    <span className="text-txt-3">Treinos:</span>
                    <span className="ml-2 text-white">{plan.max_workouts === -1 ? '∞' : plan.max_workouts}</span>
                  </div>
                  <div>
                    <span className="text-txt-3">IA:</span>
                    <span className="ml-2 text-white">{plan.max_ai_queries === -1 ? '∞' : plan.max_ai_queries}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {plan.has_nutrition && <span className="px-2 py-0.5 bg-green-500/20 text-green-400 text-xs rounded">Nutrição</span>}
                    {plan.has_verification && <span className="px-2 py-0.5 bg-purple-500/20 text-purple-400 text-xs rounded">Verificado</span>}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {plan.stripe_price_id_monthly ? (
                  <span className="text-xs text-green-400">Stripe ✓</span>
                ) : (
                  <span className="text-xs text-yellow-400">Sem Stripe</span>
                )}
                
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="ghost" size="sm" onClick={() => handleEdit(plan)}>
                      <Pencil className="w-4 h-4" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-lg">
                    <DialogHeader>
                      <DialogTitle>Editar Plano: {plan.plan_name}</DialogTitle>
                    </DialogHeader>
                    
                    <div className="grid gap-4 py-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Nome</Label>
                          <Input
                            value={formData.plan_name || ''}
                            onChange={(e) => setFormData({ ...formData, plan_name: e.target.value })}
                          />
                        </div>
                        <div>
                          <Label>Preço Mensal (R$)</Label>
                          <Input
                            type="number"
                            value={formData.monthly_price_brl || 0}
                            onChange={(e) => setFormData({ ...formData, monthly_price_brl: Number(e.target.value) })}
                          />
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Preço Anual (R$)</Label>
                          <Input
                            type="number"
                            value={formData.annual_price_brl || ''}
                            onChange={(e) => setFormData({ ...formData, annual_price_brl: e.target.value ? Number(e.target.value) : null })}
                          />
                        </div>
                        <div>
                          <Label>Dias de Trial</Label>
                          <Input
                            type="number"
                            value={formData.trial_days || 0}
                            onChange={(e) => setFormData({ ...formData, trial_days: Number(e.target.value) })}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Max Treinos (-1 = ilimitado)</Label>
                          <Input
                            type="number"
                            value={formData.max_workouts || 0}
                            onChange={(e) => setFormData({ ...formData, max_workouts: Number(e.target.value) })}
                          />
                        </div>
                        <div>
                          <Label>Max Consultas IA (-1 = ilimitado)</Label>
                          <Input
                            type="number"
                            value={formData.max_ai_queries || 0}
                            onChange={(e) => setFormData({ ...formData, max_ai_queries: Number(e.target.value) })}
                          />
                        </div>
                      </div>
                      
                      <div>
                        <Label>Stripe Price ID (Mensal)</Label>
                        <Input
                          value={formData.stripe_price_id_monthly || ''}
                          onChange={(e) => setFormData({ ...formData, stripe_price_id_monthly: e.target.value || null })}
                          placeholder="price_xxxxxxxxx"
                        />
                      </div>
                      
                      <div>
                        <Label>Stripe Price ID (Anual)</Label>
                        <Input
                          value={formData.stripe_price_id_annual || ''}
                          onChange={(e) => setFormData({ ...formData, stripe_price_id_annual: e.target.value || null })}
                          placeholder="price_xxxxxxxxx"
                        />
                      </div>
                      
                      <div className="flex items-center gap-6">
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={formData.has_nutrition}
                            onCheckedChange={(v) => setFormData({ ...formData, has_nutrition: v })}
                          />
                          <Label>Nutrição</Label>
                        </div>
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={formData.has_advanced_metrics}
                            onCheckedChange={(v) => setFormData({ ...formData, has_advanced_metrics: v })}
                          />
                          <Label>Métricas Avançadas</Label>
                        </div>
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={formData.has_verification}
                            onCheckedChange={(v) => setFormData({ ...formData, has_verification: v })}
                          />
                          <Label>Selo Verificado</Label>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Switch
                          checked={formData.is_active}
                          onCheckedChange={(v) => setFormData({ ...formData, is_active: v })}
                        />
                        <Label>Plano Ativo</Label>
                      </div>
                    </div>
                    
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" onClick={() => setEditingPlan(null)}>
                        <X className="w-4 h-4 mr-2" />
                        Cancelar
                      </Button>
                      <Button onClick={handleSave} disabled={saving}>
                        {saving ? (
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        ) : (
                          <Check className="w-4 h-4 mr-2" />
                        )}
                        Salvar
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
