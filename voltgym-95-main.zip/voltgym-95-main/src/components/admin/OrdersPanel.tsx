import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { Package, Eye, Loader2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface Order {
  id: string;
  user_id: string;
  status: string;
  items: any;
  total_brl: number;
  payment_method: string;
  shipping_address: any;
  tracking_code: string | null;
  notes: string | null;
  created_at: string;
  profiles?: {
    display_name: string;
  };
}

const statusColors: Record<string, string> = {
  pending: "bg-yellow-500",
  confirmed: "bg-blue-500",
  shipped: "bg-purple-500",
  delivered: "bg-green-500",
  cancelled: "bg-red-500"
};

const statusLabels: Record<string, string> = {
  pending: "Pendente",
  confirmed: "Confirmado",
  shipped: "Enviado",
  delivered: "Entregue",
  cancelled: "Cancelado"
};

export function OrdersPanel() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const loadOrders = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Carregar perfis dos usuários separadamente
      const ordersWithProfiles = await Promise.all(
        (data || []).map(async (order) => {
          const { data: profile } = await supabase
            .from('profiles')
            .select('display_name')
            .eq('user_id', order.user_id)
            .single();
          
          return {
            ...order,
            profiles: profile || { display_name: 'Cliente' }
          };
        })
      );

      setOrders(ordersWithProfiles as Order[]);
    } catch (error) {
      console.error('Error loading orders:', error);
      toast({
        title: "Erro ao carregar pedidos",
        description: "Tente novamente mais tarde",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadOrders();
  }, []);

  const updateOrderStatus = async (orderId: string, status: string) => {
    try {
      const { error } = await supabase
        .from('orders')
        .update({ status, updated_at: new Date().toISOString() })
        .eq('id', orderId);

      if (error) throw error;

      toast({
        title: "Status atualizado",
        description: `Pedido marcado como ${statusLabels[status]}`
      });

      loadOrders();
    } catch (error) {
      console.error('Error updating order:', error);
      toast({
        title: "Erro ao atualizar",
        description: "Tente novamente",
        variant: "destructive"
      });
    }
  };

  const updateTrackingCode = async (orderId: string, trackingCode: string) => {
    try {
      const { error } = await supabase
        .from('orders')
        .update({ tracking_code: trackingCode, updated_at: new Date().toISOString() })
        .eq('id', orderId);

      if (error) throw error;

      toast({
        title: "Código de rastreio salvo",
        description: "O código foi atualizado com sucesso"
      });

      loadOrders();
    } catch (error) {
      console.error('Error updating tracking:', error);
      toast({
        title: "Erro ao salvar",
        description: "Tente novamente",
        variant: "destructive"
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="w-5 h-5" />
            Gerenciar Pedidos ({orders.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data</TableHead>
                <TableHead>Cliente</TableHead>
                <TableHead>Itens</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {orders.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-muted-foreground">
                    Nenhum pedido encontrado
                  </TableCell>
                </TableRow>
              ) : (
                orders.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell className="text-sm">
                      {new Date(order.created_at).toLocaleDateString('pt-BR')}
                    </TableCell>
                    <TableCell className="font-medium">
                      {order.profiles?.display_name || 'Cliente'}
                    </TableCell>
                    <TableCell>{order.items?.length || 0} itens</TableCell>
                    <TableCell className="font-semibold">
                      R$ {order.total_brl?.toFixed(2) || '0.00'}
                    </TableCell>
                    <TableCell>
                      <Select
                        value={order.status}
                        onValueChange={(value) => updateOrderStatus(order.id, value)}
                      >
                        <SelectTrigger className="w-36">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pending">
                            <Badge className={statusColors.pending}>Pendente</Badge>
                          </SelectItem>
                          <SelectItem value="confirmed">
                            <Badge className={statusColors.confirmed}>Confirmado</Badge>
                          </SelectItem>
                          <SelectItem value="shipped">
                            <Badge className={statusColors.shipped}>Enviado</Badge>
                          </SelectItem>
                          <SelectItem value="delivered">
                            <Badge className={statusColors.delivered}>Entregue</Badge>
                          </SelectItem>
                          <SelectItem value="cancelled">
                            <Badge className={statusColors.cancelled}>Cancelado</Badge>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setSelectedOrder(order)}
                      >
                        <Eye className="w-4 h-4 mr-2" />
                        Ver
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Modal de Detalhes do Pedido */}
      <Dialog open={!!selectedOrder} onOpenChange={() => setSelectedOrder(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Detalhes do Pedido #{selectedOrder?.id.slice(0, 8)}</DialogTitle>
          </DialogHeader>

          {selectedOrder && (
            <div className="space-y-6">
              {/* Informações do Cliente */}
              <div className="space-y-2">
                <h3 className="font-semibold">Cliente</h3>
                <div className="bg-muted/50 p-4 rounded-lg">
                  <p><strong>Nome:</strong> {selectedOrder.shipping_address?.name || 'N/A'}</p>
                  <p><strong>Telefone:</strong> {selectedOrder.shipping_address?.phone || 'N/A'}</p>
                </div>
              </div>

              {/* Endereço de Entrega */}
              <div className="space-y-2">
                <h3 className="font-semibold">Endereço de Entrega</h3>
                <div className="bg-muted/50 p-4 rounded-lg">
                  <p>{selectedOrder.shipping_address?.street}, {selectedOrder.shipping_address?.number}</p>
                  {selectedOrder.shipping_address?.complement && (
                    <p>{selectedOrder.shipping_address.complement}</p>
                  )}
                  <p>{selectedOrder.shipping_address?.neighborhood} - {selectedOrder.shipping_address?.city}/{selectedOrder.shipping_address?.state}</p>
                  <p>CEP: {selectedOrder.shipping_address?.zip}</p>
                </div>
              </div>

              {/* Itens do Pedido */}
              <div className="space-y-2">
                <h3 className="font-semibold">Itens do Pedido</h3>
                <div className="bg-muted/50 p-4 rounded-lg space-y-2">
                  {selectedOrder.items?.map((item: any, idx: number) => (
                    <div key={idx} className="flex justify-between">
                      <span>{item.quantity}x {item.product.name}</span>
                      <span className="font-medium">R$ {(item.product.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                  <div className="border-t pt-2 flex justify-between font-bold">
                    <span>TOTAL</span>
                    <span className="text-primary">R$ {selectedOrder.total_brl?.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* Observações */}
              {selectedOrder.notes && (
                <div className="space-y-2">
                  <h3 className="font-semibold">Observações</h3>
                  <div className="bg-muted/50 p-4 rounded-lg">
                    <p>{selectedOrder.notes}</p>
                  </div>
                </div>
              )}

              {/* Código de Rastreio */}
              <div className="space-y-2">
                <h3 className="font-semibold">Código de Rastreio</h3>
                <div className="flex gap-2">
                  <Input
                    defaultValue={selectedOrder.tracking_code || ''}
                    placeholder="Digite o código de rastreio"
                    onBlur={(e) => {
                      if (e.target.value !== selectedOrder.tracking_code) {
                        updateTrackingCode(selectedOrder.id, e.target.value);
                      }
                    }}
                  />
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
