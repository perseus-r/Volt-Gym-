import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Search, Filter, Dumbbell } from "lucide-react";
import { ExerciseForm } from "./ExerciseForm";
import { ExercisePreviewCard } from "./ExercisePreviewCard";
import { toast } from "sonner";

interface Exercise {
  id: string;
  name: string;
  category_id: string | null;
  primary_muscles: string[] | null;
  secondary_muscles: string[] | null;
  difficulty_level: number | null;
  equipment: string | null;
  instructions: string[] | null;
  form_tips: string[] | null;
  youtube_url: string | null;
  youtube_video_id: string | null;
  thumbnail_url: string | null;
  is_short: boolean | null;
  view_count: number | null;
  created_at: string | null;
}

interface Category {
  id: string;
  name: string;
}

export const ExerciseManagerPanel = () => {
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [filteredExercises, setFilteredExercises] = useState<Exercise[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [editingExercise, setEditingExercise] = useState<Exercise | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [difficultyFilter, setDifficultyFilter] = useState<string>("all");

  const fetchExercises = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from("exercises")
        .select("*")
        .order("name", { ascending: true });

      if (error) throw error;
      setExercises(data || []);
      setFilteredExercises(data || []);
    } catch (error) {
      console.error("Error fetching exercises:", error);
      toast.error("Erro ao carregar exercícios");
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from("exercise_categories")
        .select("*")
        .order("name", { ascending: true });

      if (error) throw error;
      setCategories(data || []);
    } catch (error) {
      console.error("Error fetching categories:", error);
    }
  };

  useEffect(() => {
    fetchExercises();
    fetchCategories();
  }, []);

  useEffect(() => {
    let filtered = exercises;

    if (searchTerm) {
      filtered = filtered.filter((ex) =>
        ex.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (categoryFilter !== "all") {
      filtered = filtered.filter((ex) => ex.category_id === categoryFilter);
    }

    if (difficultyFilter !== "all") {
      const level = parseInt(difficultyFilter);
      filtered = filtered.filter((ex) => ex.difficulty_level === level);
    }

    setFilteredExercises(filtered);
  }, [searchTerm, categoryFilter, difficultyFilter, exercises]);

  const handleSaveExercise = async (exerciseData: any) => {
    try {
      if (editingExercise) {
        const { error } = await supabase
          .from("exercises")
          .update(exerciseData)
          .eq("id", editingExercise.id);

        if (error) throw error;
        toast.success("Exercício atualizado com sucesso!");
      } else {
        const { error } = await supabase
          .from("exercises")
          .insert(exerciseData);

        if (error) throw error;
        toast.success("Exercício criado com sucesso!");
      }

      setIsCreating(false);
      setEditingExercise(null);
      fetchExercises();
    } catch (error) {
      console.error("Error saving exercise:", error);
      toast.error("Erro ao salvar exercício");
    }
  };

  const handleDeleteExercise = async (id: string) => {
    if (!confirm("Tem certeza que deseja deletar este exercício?")) return;

    try {
      const { error } = await supabase
        .from("exercises")
        .delete()
        .eq("id", id);

      if (error) throw error;
      toast.success("Exercício deletado com sucesso!");
      fetchExercises();
    } catch (error) {
      console.error("Error deleting exercise:", error);
      toast.error("Erro ao deletar exercício");
    }
  };

  if (isCreating || editingExercise) {
    return (
      <ExerciseForm
        exercise={editingExercise}
        categories={categories}
        onSave={handleSaveExercise}
        onCancel={() => {
          setIsCreating(false);
          setEditingExercise(null);
        }}
      />
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-accent/10 rounded-lg">
            <Dumbbell className="w-6 h-6 text-accent" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-txt">
              Gerenciar Exercícios
            </h2>
            <p className="text-sm text-txt-2">
              {exercises.length} exercício(s) cadastrado(s)
            </p>
          </div>
        </div>
        <Button
          onClick={() => setIsCreating(true)}
          className="bg-accent text-accent-ink hover:bg-accent/90"
        >
          <Plus className="w-4 h-4 mr-2" />
          Criar Novo Exercício
        </Button>
      </div>

      {/* Filters */}
      <Card className="glass-card p-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-txt-3" />
            <Input
              placeholder="Buscar por nome..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Todas as categorias" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas as categorias</SelectItem>
              {categories.map((cat) => (
                <SelectItem key={cat.id} value={cat.id}>
                  {cat.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={difficultyFilter} onValueChange={setDifficultyFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Todas as dificuldades" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas as dificuldades</SelectItem>
              <SelectItem value="1">⭐ Muito Fácil</SelectItem>
              <SelectItem value="2">⭐⭐ Fácil</SelectItem>
              <SelectItem value="3">⭐⭐⭐ Intermediário</SelectItem>
              <SelectItem value="4">⭐⭐⭐⭐ Difícil</SelectItem>
              <SelectItem value="5">⭐⭐⭐⭐⭐ Muito Difícil</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Exercise Grid */}
      {loading ? (
        <div className="text-center py-12">
          <p className="text-txt-2">Carregando exercícios...</p>
        </div>
      ) : filteredExercises.length === 0 ? (
        <Card className="glass-card p-12 text-center">
          <Dumbbell className="w-16 h-16 text-txt-3 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-txt mb-2">
            Nenhum exercício encontrado
          </h3>
          <p className="text-txt-2 mb-6">
            {searchTerm || categoryFilter !== "all" || difficultyFilter !== "all"
              ? "Tente ajustar os filtros"
              : "Comece criando seu primeiro exercício"}
          </p>
          {!searchTerm && categoryFilter === "all" && difficultyFilter === "all" && (
            <Button
              onClick={() => setIsCreating(true)}
              className="bg-accent text-accent-ink"
            >
              <Plus className="w-4 h-4 mr-2" />
              Criar Primeiro Exercício
            </Button>
          )}
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredExercises.map((exercise) => (
            <ExercisePreviewCard
              key={exercise.id}
              exercise={exercise}
              categories={categories}
              onEdit={() => setEditingExercise(exercise)}
              onDelete={() => handleDeleteExercise(exercise.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
};
