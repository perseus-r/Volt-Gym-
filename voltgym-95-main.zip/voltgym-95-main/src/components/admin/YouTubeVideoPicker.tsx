import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Search, Youtube, Loader2, AlertCircle } from 'lucide-react';
import { YouTubeService, YouTubeVideo } from '@/services/YouTubeService';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface YouTubeVideoPickerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (video: { videoId: string; title: string; thumb: string }) => void;
}

export const YouTubeVideoPicker = ({ isOpen, onClose, onSelect }: YouTubeVideoPickerProps) => {
  const [videos, setVideos] = useState<YouTubeVideo[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      fetchVideos();
    }
  }, [isOpen]);

  const fetchVideos = async (query?: string) => {
    setLoading(true);
    setError(null);
    
    try {
      const result = await YouTubeService.fetchChannelVideos({
        q: query,
        maxResults: 20
      });
      setVideos(result);
    } catch (err: any) {
      const errorMsg = err.message || 'Erro ao buscar vídeos';
      setError(errorMsg);
      toast.error(errorMsg);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    if (searchTerm.trim()) {
      fetchVideos(searchTerm.trim());
    } else {
      fetchVideos();
    }
  };

  const handleSelectVideo = (video: YouTubeVideo) => {
    onSelect({
      videoId: video.id,
      title: video.title,
      thumb: video.thumb
    });
    onClose();
    toast.success(`Vídeo "${video.title}" selecionado!`);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] bg-bg border-line">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-txt">
            <Youtube className="w-6 h-6 text-accent" />
            Escolher Vídeo do Meu Canal
          </DialogTitle>
        </DialogHeader>

        <div className="flex gap-2 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-txt-3" />
            <Input
              placeholder="Buscar no meu canal..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              className="pl-10"
            />
          </div>
          <Button onClick={handleSearch} disabled={loading}>
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Buscar'}
          </Button>
        </div>

        {error && (
          <div className="bg-error/10 border border-error/30 rounded-lg p-4 mb-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-error flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold text-error mb-1">Erro de Configuração</p>
                <p className="text-sm text-txt-2">{error}</p>
                {error.includes('Configure') && (
                  <p className="text-sm text-txt-3 mt-2">
                    Adicione as variáveis <code className="bg-bg-2 px-2 py-0.5 rounded">VITE_YT_API_KEY</code> e{' '}
                    <code className="bg-bg-2 px-2 py-0.5 rounded">VITE_YT_CHANNEL_ID</code> no arquivo <code>.env</code>
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        <ScrollArea className="h-[500px] pr-4">
          {loading && videos.length === 0 ? (
            <div className="flex items-center justify-center h-40">
              <Loader2 className="w-8 h-8 animate-spin text-accent" />
            </div>
          ) : videos.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 text-txt-2">
              <Youtube className="w-12 h-12 mb-3 opacity-30" />
              <p>Nenhum vídeo encontrado</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {videos.map((video) => (
                <div
                  key={video.id}
                  className="glass-card p-4 hover:border-accent/50 transition-all cursor-pointer group"
                  onClick={() => handleSelectVideo(video)}
                >
                  <div className="relative mb-3 rounded-lg overflow-hidden aspect-video">
                    <img
                      src={video.thumb}
                      alt={video.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <Youtube className="w-12 h-12 text-white" />
                    </div>
                  </div>

                  <h4 className="text-sm font-semibold text-txt mb-2 line-clamp-2 min-h-[2.5rem]">
                    {video.title}
                  </h4>

                  <p className="text-xs text-txt-3 mb-3">
                    {format(new Date(video.publishedAt), "dd 'de' MMMM, yyyy", { locale: ptBR })}
                  </p>

                  <Button
                    className="w-full bg-accent text-accent-ink hover:bg-accent/90"
                    size="sm"
                  >
                    Selecionar Vídeo
                  </Button>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};
