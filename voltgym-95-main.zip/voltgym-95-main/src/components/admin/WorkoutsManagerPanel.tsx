import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Dumbbell, Target, Trophy, TrendingUp } from "lucide-react";
import { WorkoutBuilderWizard } from "@/components/workout/WorkoutBuilderWizard";
import { WorkoutAdminCard } from "./WorkoutAdminCard";
import { toast } from "sonner";

interface WorkoutTemplate {
  id: string;
  name: string;
  description: string | null;
  focus: string;
  difficulty_level: number | null;
  estimated_duration: number | null;
  target_muscle_groups: string[] | null;
  is_public: boolean | null;
  created_at: string | null;
  created_by: string | null;
}

export const WorkoutsManagerPanel = () => {
  const [workouts, setWorkouts] = useState<WorkoutTemplate[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchWorkouts = async () => {
    try {
      const { data, error } = await supabase
        .from('workout_templates')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setWorkouts(data || []);
    } catch (error) {
      console.error('Error fetching workouts:', error);
      toast.error('Erro ao carregar treinos');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWorkouts();
  }, []);

  const handleSaveWorkout = async (workoutData: any) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      // Primeiro criar o template
      const { data: template, error: templateError } = await supabase
        .from('workout_templates')
        .insert({
          name: workoutData.name,
          description: workoutData.description || null,
          focus: workoutData.type || 'full',
          difficulty_level: workoutData.difficulty === 'iniciante' ? 1 : workoutData.difficulty === 'avancado' ? 3 : 2,
          estimated_duration: workoutData.exercises.length * 4,
          target_muscle_groups: [workoutData.type || 'full'],
          created_by: user?.id,
          is_public: true,
          video_url: workoutData.video_url || null,
          tags: workoutData.tags || [],
          source: workoutData.source || 'Admin - Treino Manual',
          metadata: workoutData.metadata || {}
        })
        .select()
        .single();

      if (templateError) throw templateError;

      // Depois criar os exercícios do template na tabela template_exercises
      if (template && workoutData.exercises.length > 0) {
        const exercisesToInsert = workoutData.exercises.map((ex: any, idx: number) => ({
          template_id: template.id,
          exercise_id: ex.id,
          sets: ex.sets || 3,
          reps_min: typeof ex.reps === 'string' ? parseInt(ex.reps.split('-')[0]) : ex.reps,
          reps_max: typeof ex.reps === 'string' ? parseInt(ex.reps.split('-')[1] || ex.reps.split('-')[0]) : ex.reps,
          rest_seconds: ex.rest || 60,
          notes: ex.notes || null,
          order_index: idx + 1
        }));

        const { error: exercisesError } = await supabase
          .from('template_exercises')
          .insert(exercisesToInsert);

        if (exercisesError) throw exercisesError;
      }

      toast.success('Treino criado com sucesso!');
      setIsCreating(false);
      fetchWorkouts();
    } catch (error) {
      console.error('Error creating workout:', error);
      toast.error('Erro ao criar treino');
    }
  };

  const handleTogglePublic = async (id: string, isPublic: boolean | null) => {
    try {
      const { error } = await supabase
        .from('workout_templates')
        .update({ is_public: !isPublic })
        .eq('id', id);

      if (error) throw error;
      toast.success(isPublic ? 'Treino tornado privado' : 'Treino tornado público');
      fetchWorkouts();
    } catch (error) {
      console.error('Error toggling workout:', error);
      toast.error('Erro ao atualizar treino');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Tem certeza que deseja excluir este treino?')) return;
    
    try {
      const { error } = await supabase
        .from('workout_templates')
        .delete()
        .eq('id', id);

      if (error) throw error;
      toast.success('Treino excluído');
      fetchWorkouts();
    } catch (error) {
      console.error('Error deleting workout:', error);
      toast.error('Erro ao excluir treino');
    }
  };

  const stats = {
    total: workouts.length,
    public: workouts.filter(w => w.is_public).length,
    private: workouts.filter(w => !w.is_public).length,
    avgDuration: workouts.length > 0 
      ? Math.round(workouts.reduce((acc, w) => acc + (w.estimated_duration || 0), 0) / workouts.length)
      : 0
  };

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Header - Mobile Optimized */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl md:text-2xl font-bold text-txt">Gerenciar Treinos</h2>
          <p className="text-xs md:text-sm text-txt-2">Crie e edite treinos para a biblioteca</p>
        </div>
        <Button 
          onClick={() => setIsCreating(true)} 
          className="w-full sm:w-auto"
        >
          <Plus className="w-4 h-4 mr-2" />
          Criar Novo Treino
        </Button>
      </div>

      {/* Stats - Mobile Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 md:gap-4">
        <Card className="glass-card p-3 md:p-4">
          <div className="flex items-center gap-2">
            <Dumbbell className="w-5 h-5 md:w-6 md:h-6 text-accent flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-xs text-txt-2 truncate">Total</p>
              <p className="text-lg md:text-xl font-bold text-txt">{stats.total}</p>
            </div>
          </div>
        </Card>
        <Card className="glass-card p-3 md:p-4">
          <div className="flex items-center gap-2">
            <Target className="w-5 h-5 md:w-6 md:h-6 text-success flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-xs text-txt-2 truncate">Públicos</p>
              <p className="text-lg md:text-xl font-bold text-txt">{stats.public}</p>
            </div>
          </div>
        </Card>
        <Card className="glass-card p-3 md:p-4">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 md:w-6 md:h-6 text-warning flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-xs text-txt-2 truncate">Privados</p>
              <p className="text-lg md:text-xl font-bold text-txt">{stats.private}</p>
            </div>
          </div>
        </Card>
        <Card className="glass-card p-3 md:p-4">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 md:w-6 md:h-6 text-txt-3 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-xs text-txt-2 truncate">Duração Média</p>
              <p className="text-lg md:text-xl font-bold text-txt">{stats.avgDuration}min</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Lista de Treinos - Responsive Grid */}
      {loading ? (
        <div className="text-center py-12">
          <p className="text-txt-2">Carregando treinos...</p>
        </div>
      ) : workouts.length === 0 ? (
        <Card className="glass-card p-8 md:p-12 text-center">
          <Dumbbell className="w-12 h-12 md:w-16 md:h-16 text-txt-3 mx-auto mb-4" />
          <h3 className="text-lg md:text-xl font-bold text-txt mb-2">Nenhum treino criado ainda</h3>
          <p className="text-sm md:text-base text-txt-2 mb-6">Crie seu primeiro treino clicando no botão acima</p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 md:gap-6">
          {workouts.map(workout => (
            <WorkoutAdminCard
              key={workout.id}
              workout={workout}
              onTogglePublic={handleTogglePublic}
              onDelete={handleDelete}
            />
          ))}
        </div>
      )}

      {/* Wizard de Criação */}
      <WorkoutBuilderWizard
        isOpen={isCreating}
        onClose={() => setIsCreating(false)}
        onSave={handleSaveWorkout}
      />
    </div>
  );
};