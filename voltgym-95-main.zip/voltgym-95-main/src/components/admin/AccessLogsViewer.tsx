import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Calendar, Monitor, MapPin, Clock } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

interface AccessLog {
  id: string;
  user_id: string;
  ip_address: string | null;
  user_agent: string | null;
  device_info: any;
  location: string | null;
  login_at: string;
  session_duration_minutes: number | null;
  created_at: string;
  user_email?: string;
  user_name?: string;
}

export function AccessLogsViewer() {
  const [logs, setLogs] = useState<AccessLog[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<AccessLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [periodFilter, setPeriodFilter] = useState("all");

  useEffect(() => {
    loadLogs();
  }, []);

  useEffect(() => {
    filterLogs();
  }, [logs, searchTerm, periodFilter]);

  const loadLogs = async () => {
    setLoading(true);
    try {
      const { data: logsData, error } = await supabase
        .from('user_access_logs')
        .select('*')
        .order('login_at', { ascending: false })
        .limit(500);

      if (error) throw error;

      // Enriquecer com dados dos usuários
      const userIds = [...new Set(logsData?.map(log => log.user_id) || [])];
      const { data: users } = await supabase
        .from('profiles')
        .select('user_id, display_name')
        .in('user_id', userIds);

      const authUsersResult = await supabase.auth.admin.listUsers();
      const authUsersList = authUsersResult.data?.users || [];

      const enrichedLogs: AccessLog[] = logsData?.map(log => {
        const profile = users?.find(u => u.user_id === log.user_id);
        const authUser = authUsersList.find(u => u.id === log.user_id);
        
        return {
          ...log,
          ip_address: log.ip_address as string | null,
          user_agent: log.user_agent as string | null,
          user_name: profile?.display_name || 'Desconhecido',
          user_email: authUser?.email || 'N/A'
        };
      }) || [];

      setLogs(enrichedLogs);
    } catch (error) {
      console.error('Erro ao carregar logs:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterLogs = () => {
    let filtered = logs;

    // Filtro de período
    if (periodFilter !== 'all') {
      const now = new Date();
      const periodDays = periodFilter === '7d' ? 7 : periodFilter === '30d' ? 30 : 1;
      const cutoffDate = new Date(now.getTime() - periodDays * 24 * 60 * 60 * 1000);
      
      filtered = filtered.filter(log => new Date(log.login_at) >= cutoffDate);
    }

    // Filtro de busca
    if (searchTerm) {
      filtered = filtered.filter(log => 
        log.user_email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.user_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.ip_address?.includes(searchTerm)
      );
    }

    setFilteredLogs(filtered);
  };

  const getDeviceIcon = (userAgent: string) => {
    if (!userAgent) return "💻";
    if (userAgent.includes('Mobile') || userAgent.includes('Android') || userAgent.includes('iPhone')) {
      return "📱";
    }
    if (userAgent.includes('Tablet') || userAgent.includes('iPad')) {
      return "📱";
    }
    return "💻";
  };

  const getDeviceName = (userAgent: string) => {
    if (!userAgent) return "Desconhecido";
    if (userAgent.includes('iPhone')) return "iPhone";
    if (userAgent.includes('Android')) return "Android";
    if (userAgent.includes('Windows')) return "Windows";
    if (userAgent.includes('Mac')) return "Mac";
    if (userAgent.includes('Linux')) return "Linux";
    return "Outro";
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Logs de Acesso</CardTitle>
          <CardDescription>Carregando histórico de acessos...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Logs de Acesso
            </CardTitle>
            <CardDescription>
              Histórico completo de acessos ao VoltGym ({filteredLogs.length} registros)
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Filtros */}
        <div className="flex gap-4">
          <Input
            placeholder="Buscar por usuário, email ou IP..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="max-w-sm"
          />
          <Select value={periodFilter} onValueChange={setPeriodFilter}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="1d">Últimas 24h</SelectItem>
              <SelectItem value="7d">Últimos 7 dias</SelectItem>
              <SelectItem value="30d">Últimos 30 dias</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Tabela */}
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data/Hora</TableHead>
                <TableHead>Usuário</TableHead>
                <TableHead>IP</TableHead>
                <TableHead>Dispositivo</TableHead>
                <TableHead>Localização</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredLogs.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                    Nenhum acesso encontrado
                  </TableCell>
                </TableRow>
              ) : (
                filteredLogs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-muted-foreground" />
                        <div className="text-sm">
                          <div className="font-medium">
                            {format(new Date(log.login_at), "dd/MM/yyyy")}
                          </div>
                          <div className="text-muted-foreground">
                            {format(new Date(log.login_at), "HH:mm:ss")}
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div className="font-medium">{log.user_name}</div>
                        <div className="text-muted-foreground">{log.user_email}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="font-mono text-xs">
                        {log.ip_address || 'N/A'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{getDeviceIcon(log.user_agent)}</span>
                        <span className="text-sm">{getDeviceName(log.user_agent)}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {log.location ? (
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">{log.location}</span>
                        </div>
                      ) : (
                        <span className="text-muted-foreground text-sm">N/A</span>
                      )}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
