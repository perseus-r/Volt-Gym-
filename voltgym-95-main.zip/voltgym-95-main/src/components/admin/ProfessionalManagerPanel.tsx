import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { UserPlus, Edit, Star, Eye, Calendar, DollarSign } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

interface Professional {
  id: string;
  user_id: string;
  specialty: string;
  bio: string;
  hourly_rate: number;
  experience_years: number;
  certifications: string[];
  availability_schedule: any;
  profile_image_url: string | null;
  rating: number;
  total_reviews: number;
  is_active: boolean;
  created_at: string;
}

const specialtyLabels = {
  personal_trainer: 'Personal Trainer',
  nutritionist: 'Nutricionista',
  physiotherapist: 'Fisioterapeuta',
  sports_psychologist: 'Psicólogo Esportivo',
  general_coach: 'Coach Geral',
};

export function ProfessionalManagerPanel() {
  const [professionals, setProfessionals] = useState<Professional[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProfessional, setEditingProfessional] = useState<Professional | null>(null);
  
  // Form state
  const [formData, setFormData] = useState({
    user_id: '',
    specialty: 'personal_trainer',
    bio: '',
    hourly_rate: 150,
    experience_years: 0,
    certifications: '',
    availability_schedule: '{}',
    profile_image_url: '',
  });

  useEffect(() => {
    fetchProfessionals();
  }, []);

  const fetchProfessionals = async () => {
    try {
      const { data, error } = await supabase
        .from('professionals')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProfessionals(data || []);
    } catch (error: any) {
      toast.error('Erro ao carregar profissionais');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const certArray = formData.certifications.split(',').map(c => c.trim()).filter(Boolean);
      
      const professionalData = {
        user_id: formData.user_id,
        specialty: formData.specialty as 'personal_trainer' | 'nutritionist' | 'physiotherapist' | 'sports_psychologist' | 'general_coach',
        bio: formData.bio,
        hourly_rate: formData.hourly_rate,
        experience_years: formData.experience_years,
        certifications: certArray,
        availability_schedule: JSON.parse(formData.availability_schedule || '{}'),
        profile_image_url: formData.profile_image_url || null,
        is_active: true,
      };

      if (editingProfessional) {
        const { error } = await supabase
          .from('professionals')
          .update(professionalData)
          .eq('id', editingProfessional.id);

        if (error) throw error;
        toast.success('Profissional atualizado com sucesso!');
      } else {
        const { error } = await supabase
          .from('professionals')
          .insert([professionalData]);

        if (error) throw error;
        toast.success('Profissional cadastrado com sucesso!');
      }

      setIsDialogOpen(false);
      resetForm();
      fetchProfessionals();
    } catch (error: any) {
      toast.error(error.message || 'Erro ao salvar profissional');
      console.error(error);
    }
  };

  const toggleActive = async (id: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('professionals')
        .update({ is_active: !currentStatus })
        .eq('id', id);

      if (error) throw error;
      toast.success(`Profissional ${!currentStatus ? 'ativado' : 'desativado'}`);
      fetchProfessionals();
    } catch (error) {
      toast.error('Erro ao atualizar status');
    }
  };

  const resetForm = () => {
    setFormData({
      user_id: '',
      specialty: 'personal_trainer',
      bio: '',
      hourly_rate: 150,
      experience_years: 0,
      certifications: '',
      availability_schedule: '{}',
      profile_image_url: '',
    });
    setEditingProfessional(null);
  };

  const openEditDialog = (professional: Professional) => {
    setEditingProfessional(professional);
    setFormData({
      user_id: professional.user_id,
      specialty: professional.specialty,
      bio: professional.bio,
      hourly_rate: professional.hourly_rate,
      experience_years: professional.experience_years,
      certifications: professional.certifications.join(', '),
      availability_schedule: JSON.stringify(professional.availability_schedule, null, 2),
      profile_image_url: professional.profile_image_url || '',
    });
    setIsDialogOpen(true);
  };

  if (loading) {
    return <div className="text-center py-8">Carregando profissionais...</div>;
  }

  return (
    <Card className="bg-surface/50 border-line/20">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-xl text-txt">Gerenciar Profissionais</CardTitle>
            <CardDescription className="text-txt-3">
              Cadastre e gerencie profissionais para consultorias
            </CardDescription>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={resetForm} className="gap-2">
                <UserPlus className="w-4 h-4" />
                Novo Profissional
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-surface border-line/20">
              <DialogHeader>
                <DialogTitle className="text-txt">
                  {editingProfessional ? 'Editar Profissional' : 'Cadastrar Profissional'}
                </DialogTitle>
                <DialogDescription className="text-txt-3">
                  Preencha os dados do profissional
                </DialogDescription>
              </DialogHeader>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="user_id">User ID</Label>
                    <Input
                      id="user_id"
                      value={formData.user_id}
                      onChange={(e) => setFormData({ ...formData, user_id: e.target.value })}
                      placeholder="UUID do usuário"
                      required
                      className="bg-bg/50 border-line/30"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="specialty">Especialidade</Label>
                    <Select value={formData.specialty} onValueChange={(v) => setFormData({ ...formData, specialty: v })}>
                      <SelectTrigger className="bg-bg/50 border-line/30">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-surface border-line/20">
                        {Object.entries(specialtyLabels).map(([key, label]) => (
                          <SelectItem key={key} value={key}>{label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bio">Bio</Label>
                  <Textarea
                    id="bio"
                    value={formData.bio}
                    onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                    placeholder="Descrição do profissional..."
                    rows={4}
                    required
                    className="bg-bg/50 border-line/30"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="hourly_rate">Valor/Hora (R$)</Label>
                    <Input
                      id="hourly_rate"
                      type="number"
                      value={formData.hourly_rate}
                      onChange={(e) => setFormData({ ...formData, hourly_rate: Number(e.target.value) })}
                      required
                      className="bg-bg/50 border-line/30"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="experience_years">Anos de Experiência</Label>
                    <Input
                      id="experience_years"
                      type="number"
                      value={formData.experience_years}
                      onChange={(e) => setFormData({ ...formData, experience_years: Number(e.target.value) })}
                      required
                      className="bg-bg/50 border-line/30"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="certifications">Certificações (separadas por vírgula)</Label>
                  <Input
                    id="certifications"
                    value={formData.certifications}
                    onChange={(e) => setFormData({ ...formData, certifications: e.target.value })}
                    placeholder="CREF, CrossFit Level 1, etc"
                    className="bg-bg/50 border-line/30"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="profile_image_url">URL da Imagem de Perfil</Label>
                  <Input
                    id="profile_image_url"
                    value={formData.profile_image_url}
                    onChange={(e) => setFormData({ ...formData, profile_image_url: e.target.value })}
                    placeholder="https://..."
                    className="bg-bg/50 border-line/30"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="availability_schedule">Horários Disponíveis (JSON)</Label>
                  <Textarea
                    id="availability_schedule"
                    value={formData.availability_schedule}
                    onChange={(e) => setFormData({ ...formData, availability_schedule: e.target.value })}
                    placeholder='{"segunda": ["08:00", "09:00"], "terca": ["14:00"]}'
                    rows={4}
                    className="bg-bg/50 border-line/30 font-mono text-xs"
                  />
                </div>

                <div className="flex gap-2 justify-end pt-4">
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button type="submit">
                    {editingProfessional ? 'Atualizar' : 'Cadastrar'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>

      <CardContent>
        <Table>
          <TableHeader>
            <TableRow className="border-line/20">
              <TableHead>Profissional</TableHead>
              <TableHead>Especialidade</TableHead>
              <TableHead>Experiência</TableHead>
              <TableHead>Valor/Hora</TableHead>
              <TableHead>Avaliação</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {professionals.map((prof) => (
              <TableRow key={prof.id} className="border-line/10">
                <TableCell>
                  <div className="flex items-center gap-3">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src={prof.profile_image_url || undefined} />
                      <AvatarFallback className="bg-accent/20 text-accent">
                        {specialtyLabels[prof.specialty as keyof typeof specialtyLabels]?.[0] || 'P'}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium text-txt">{prof.user_id.slice(0, 8)}...</div>
                      <div className="text-xs text-txt-3">{prof.bio.slice(0, 40)}...</div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="text-xs">
                    {specialtyLabels[prof.specialty as keyof typeof specialtyLabels]}
                  </Badge>
                </TableCell>
                <TableCell className="text-txt-2">{prof.experience_years} anos</TableCell>
                <TableCell className="text-txt-2">R$ {prof.hourly_rate}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                    <span className="text-txt-2">{prof.rating.toFixed(1)}</span>
                    <span className="text-xs text-txt-3">({prof.total_reviews})</span>
                  </div>
                </TableCell>
                <TableCell>
                  <Switch
                    checked={prof.is_active}
                    onCheckedChange={() => toggleActive(prof.id, prof.is_active)}
                  />
                </TableCell>
                <TableCell className="text-right">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => openEditDialog(prof)}
                    className="gap-2"
                  >
                    <Edit className="w-4 h-4" />
                    Editar
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

        {professionals.length === 0 && (
          <div className="text-center py-12 text-txt-3">
            Nenhum profissional cadastrado ainda.
          </div>
        )}
      </CardContent>
    </Card>
  );
}