import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { supabase } from "@/integrations/supabase/client";
import { 
  Save, 
  X, 
  Plus, 
  Trash2, 
  Video, 
  Youtube,
  Upload,
  Dumbbell,
  Target,
  Star,
  Loader2
} from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { getYouTubeId } from "@/utils/youtube";
import { YouTubeVideoPicker } from "./YouTubeVideoPicker";
import YouTubePlayer from "@/components/YouTubePlayer";
import { useVideoUpload } from "@/hooks/useVideoUpload";

interface ExerciseFormProps {
  exercise: any;
  categories: Array<{ id: string; name: string }>;
  onSave: (data: any) => void;
  onCancel: () => void;
}

export const ExerciseForm = ({ exercise, categories, onSave, onCancel }: ExerciseFormProps) => {
  const [formData, setFormData] = useState({
    name: exercise?.name || "",
    category_id: exercise?.category_id || "",
    primary_muscles: exercise?.primary_muscles || [],
    secondary_muscles: exercise?.secondary_muscles || [],
    difficulty_level: exercise?.difficulty_level || 3,
    equipment: exercise?.equipment || "",
    instructions: exercise?.instructions || [],
    form_tips: exercise?.form_tips || [],
    youtube_url: exercise?.youtube_url || "",
    demo_video_url: exercise?.demo_video_url || "",
  });

  const [muscleInput, setMuscleInput] = useState("");
  const [instructionInput, setInstructionInput] = useState("");
  const [tipInput, setTipInput] = useState("");
  const [availableMuscles, setAvailableMuscles] = useState<string[]>([]);
  const [urlPreview, setUrlPreview] = useState<{ valid: boolean; platform?: string }>({ valid: false });
  const [isVideoPickerOpen, setIsVideoPickerOpen] = useState(false);
  const [videoSourceType, setVideoSourceType] = useState<'youtube' | 'upload'>(
    exercise?.demo_video_url ? 'upload' : 'youtube'
  );
  const [selectedVideo, setSelectedVideo] = useState<{
    videoId: string;
    title: string;
    thumb: string;
  } | null>(
    exercise?.youtube_url
      ? {
          videoId: getYouTubeId(exercise.youtube_url) || '',
          title: exercise.name || 'Vídeo selecionado',
          thumb: `https://i.ytimg.com/vi/${getYouTubeId(exercise.youtube_url)}/hqdefault.jpg`
        }
      : null
  );
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { uploadVideo, uploading, progress, converting, conversionProgress } = useVideoUpload();

  useEffect(() => {
    fetchMuscles();
  }, []);

  useEffect(() => {
    if (!formData.youtube_url) {
      setUrlPreview({ valid: false });
      return;
    }

    const videoId = getYouTubeId(formData.youtube_url);
    if (videoId) {
      setUrlPreview({ valid: true, platform: 'YouTube' });
    } else {
      setUrlPreview({ valid: false });
    }
  }, [formData.youtube_url]);

  const fetchMuscles = async () => {
    try {
      const { data, error } = await supabase
        .from("muscles")
        .select("name")
        .order("name");

      if (error) throw error;
      setAvailableMuscles(data?.map(m => m.name) || []);
    } catch (error) {
      console.error("Error fetching muscles:", error);
    }
  };

  const addMuscle = (type: 'primary' | 'secondary') => {
    if (!muscleInput.trim()) return;
    
    const muscle = muscleInput.trim();
    const field = type === 'primary' ? 'primary_muscles' : 'secondary_muscles';
    
    if (formData[field].includes(muscle)) {
      toast.error("Músculo já adicionado");
      return;
    }

    setFormData({
      ...formData,
      [field]: [...formData[field], muscle]
    });
    setMuscleInput("");
  };

  const removeMuscle = (type: 'primary' | 'secondary', muscle: string) => {
    const field = type === 'primary' ? 'primary_muscles' : 'secondary_muscles';
    setFormData({
      ...formData,
      [field]: formData[field].filter(m => m !== muscle)
    });
  };

  const addInstruction = () => {
    if (!instructionInput.trim()) return;
    setFormData({
      ...formData,
      instructions: [...formData.instructions, instructionInput.trim()]
    });
    setInstructionInput("");
  };

  const removeInstruction = (index: number) => {
    setFormData({
      ...formData,
      instructions: formData.instructions.filter((_, i) => i !== index)
    });
  };

  const addTip = () => {
    if (!tipInput.trim()) return;
    setFormData({
      ...formData,
      form_tips: [...formData.form_tips, tipInput.trim()]
    });
    setTipInput("");
  };

  const removeTip = (index: number) => {
    setFormData({
      ...formData,
      form_tips: formData.form_tips.filter((_, i) => i !== index)
    });
  };

  const handleVideoSelect = (video: { videoId: string; title: string; thumb: string }) => {
    setSelectedVideo(video);
    setFormData({
      ...formData,
      youtube_url: `https://www.youtube.com/watch?v=${video.videoId}`,
      demo_video_url: "" // Clear uploaded video when selecting YouTube
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const url = await uploadVideo(file);
      setFormData({
        ...formData,
        demo_video_url: url,
        youtube_url: "" // Clear YouTube when uploading local
      });
      setSelectedVideo(null);
    } catch (error) {
      // Error is already handled in the hook with toast
    }
    
    // Reset input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleRemoveUploadedVideo = () => {
    setFormData({
      ...formData,
      demo_video_url: ""
    });
  };

  const handleSubmit = () => {
    if (!formData.name.trim()) {
      toast.error("Nome do exercício é obrigatório");
      return;
    }

    if (!formData.category_id) {
      toast.error("Categoria é obrigatória");
      return;
    }

    if (formData.primary_muscles.length === 0) {
      toast.error("Adicione ao menos um músculo primário");
      return;
    }

    if (formData.youtube_url && !urlPreview.valid) {
      toast.error("URL do vídeo inválida");
      return;
    }

    // Extract youtube_video_id from URL before saving
    const videoId = formData.youtube_url ? getYouTubeId(formData.youtube_url) : null;
    
    onSave({
      ...formData,
      youtube_video_id: videoId,
    });
  };

  const difficultyLabels = ["Muito Fácil", "Fácil", "Intermediário", "Difícil", "Muito Difícil"];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-accent/10 rounded-lg">
            <Dumbbell className="w-6 h-6 text-accent" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-txt">
              {exercise ? "Editar Exercício" : "Criar Novo Exercício"}
            </h2>
            <p className="text-sm text-txt-2">
              Preencha todos os campos para adicionar à biblioteca
            </p>
          </div>
        </div>
      </div>

      {/* Form */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Coluna Esquerda */}
        <div className="space-y-6">
          {/* Nome */}
          <Card className="glass-card p-6 space-y-4">
            <Label className="text-base font-semibold text-txt">
              Nome do Exercício *
            </Label>
            <Input
              placeholder="Ex: Supino Reto com Barra"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
          </Card>

          {/* Categoria */}
          <Card className="glass-card p-6 space-y-4">
            <Label className="text-base font-semibold text-txt">
              Categoria *
            </Label>
            <Select value={formData.category_id} onValueChange={(val) => setFormData({ ...formData, category_id: val })}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione uma categoria" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat.id} value={cat.id}>
                    {cat.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Card>

          {/* Equipamento */}
          <Card className="glass-card p-6 space-y-4">
            <Label className="text-base font-semibold text-txt">
              Equipamento
            </Label>
            <Input
              placeholder="Ex: Barra, Halteres, Peso Corporal"
              value={formData.equipment}
              onChange={(e) => setFormData({ ...formData, equipment: e.target.value })}
            />
          </Card>

          {/* Dificuldade */}
          <Card className="glass-card p-6 space-y-4">
            <div className="flex items-center justify-between mb-2">
              <Label className="text-base font-semibold text-txt">
                Nível de Dificuldade
              </Label>
              <div className="flex items-center gap-2">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${
                      i < formData.difficulty_level
                        ? "fill-accent text-accent"
                        : "text-txt-3"
                    }`}
                  />
                ))}
              </div>
            </div>
            <Slider
              value={[formData.difficulty_level]}
              onValueChange={(val) => setFormData({ ...formData, difficulty_level: val[0] })}
              min={1}
              max={5}
              step={1}
              className="py-4"
            />
            <p className="text-sm text-center text-txt-2 font-medium">
              {difficultyLabels[formData.difficulty_level - 1]}
            </p>
          </Card>
        </div>

        {/* Coluna Direita */}
        <div className="space-y-6">
          {/* Músculos Primários */}
          <Card className="glass-card p-6 space-y-4">
            <div className="flex items-center gap-2">
              <Target className="w-5 h-5 text-accent" />
              <Label className="text-base font-semibold text-txt">
                Músculos Primários *
              </Label>
            </div>
            
            <div className="flex gap-2">
              <Input
                placeholder="Digite ou selecione"
                value={muscleInput}
                onChange={(e) => setMuscleInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addMuscle('primary'))}
                list="muscles-list"
              />
              <datalist id="muscles-list">
                {availableMuscles.map(m => (
                  <option key={m} value={m} />
                ))}
              </datalist>
              <Button onClick={() => addMuscle('primary')} variant="outline" size="icon">
                <Plus className="w-4 h-4" />
              </Button>
            </div>

            {formData.primary_muscles.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {formData.primary_muscles.map((muscle) => (
                  <Badge key={muscle} className="bg-accent/20 text-accent border-accent/30">
                    {muscle}
                    <button onClick={() => removeMuscle('primary', muscle)} className="ml-2">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </Card>

          {/* Músculos Secundários */}
          <Card className="glass-card p-6 space-y-4">
            <Label className="text-base font-semibold text-txt">
              Músculos Secundários
            </Label>
            
            <div className="flex gap-2">
              <Input
                placeholder="Digite ou selecione"
                value={muscleInput}
                onChange={(e) => setMuscleInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addMuscle('secondary'))}
                list="muscles-list"
              />
              <Button onClick={() => addMuscle('secondary')} variant="outline" size="icon">
                <Plus className="w-4 h-4" />
              </Button>
            </div>

            {formData.secondary_muscles.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {formData.secondary_muscles.map((muscle) => (
                  <Badge key={muscle} variant="outline" className="bg-bg-2 border-border">
                    {muscle}
                    <button onClick={() => removeMuscle('secondary', muscle)} className="ml-2">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </Card>

          {/* Vídeo Demonstrativo */}
          <Card className="glass-card p-6 space-y-4">
            <div className="flex items-center gap-2">
              <Video className="w-5 h-5 text-accent" />
              <Label className="text-base font-semibold text-txt">
                Vídeo Demonstrativo
              </Label>
            </div>
            
            {/* Toggle entre YouTube e Upload */}
            <div className="flex gap-2">
              <Button
                type="button"
                variant={videoSourceType === 'youtube' ? 'default' : 'outline'}
                onClick={() => setVideoSourceType('youtube')}
                className={`flex-1 ${videoSourceType === 'youtube' ? 'bg-accent text-accent-ink' : ''}`}
                size="sm"
              >
                <Youtube className="w-4 h-4 mr-2" />
                YouTube
              </Button>
              <Button
                type="button"
                variant={videoSourceType === 'upload' ? 'default' : 'outline'}
                onClick={() => setVideoSourceType('upload')}
                className={`flex-1 ${videoSourceType === 'upload' ? 'bg-accent text-accent-ink' : ''}`}
                size="sm"
              >
                <Upload className="w-4 h-4 mr-2" />
                Upload Local
              </Button>
            </div>

            {/* YouTube Section */}
            {videoSourceType === 'youtube' && (
              <>
                <p className="text-sm text-txt-2">
                  Escolha um vídeo do seu canal do YouTube
                </p>

                {selectedVideo && (
                  <div className="space-y-2">
                    <Label className="text-xs text-txt-3">Vídeo Selecionado</Label>
                    <Input
                      value={selectedVideo.videoId}
                      readOnly
                      className="font-mono text-sm bg-bg-2"
                    />
                  </div>
                )}

                <Button
                  type="button"
                  onClick={() => setIsVideoPickerOpen(true)}
                  variant="outline"
                  className="w-full"
                >
                  <Youtube className="w-4 h-4 mr-2" />
                  {selectedVideo ? 'Trocar Vídeo' : 'Escolher Vídeo do YouTube'}
                </Button>

                {selectedVideo && formData.youtube_url && (
                  <div className="space-y-2">
                    <Label className="text-xs text-txt-3">Preview</Label>
                    <YouTubePlayer
                      url={formData.youtube_url}
                      title={selectedVideo.title}
                      className="w-full"
                    />
                  </div>
                )}
              </>
            )}

            {/* Upload Section */}
            {videoSourceType === 'upload' && (
              <>
                <p className="text-sm text-txt-2">
                  Faça upload de um vídeo local (MP4, WebM ou MOV)
                </p>

                {/* Hidden file input */}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".mp4,.webm,.mov,video/mp4,video/webm,video/quicktime"
                  onChange={handleFileUpload}
                  className="hidden"
                />

                {/* Upload area */}
                {!formData.demo_video_url && !uploading && !converting && (
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="border-2 border-dashed border-border rounded-lg p-8 text-center cursor-pointer hover:border-accent/50 hover:bg-accent/5 transition-colors"
                  >
                    <Upload className="w-10 h-10 mx-auto mb-3 text-txt-3" />
                    <p className="text-sm font-medium text-txt">
                      Clique para selecionar um vídeo
                    </p>
                    <p className="text-xs text-txt-3 mt-1">
                      MP4, WebM ou MOV (máx. 50MB)
                    </p>
                    <p className="text-xs text-info mt-2">
                      💡 Arquivos MOV serão convertidos automaticamente para MP4
                    </p>
                  </div>
                )}

                {/* Converting progress */}
                {converting && (
                  <div className="space-y-3 p-4 bg-bg-2 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin text-accent" />
                      <span className="text-sm text-txt">Convertendo MOV → MP4...</span>
                    </div>
                    <Progress value={conversionProgress} className="h-2" />
                    <p className="text-xs text-txt-3">{conversionProgress}% concluído</p>
                  </div>
                )}

                {/* Uploading progress */}
                {uploading && !converting && (
                  <div className="space-y-3 p-4 bg-bg-2 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin text-accent" />
                      <span className="text-sm text-txt">Enviando vídeo...</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                    <p className="text-xs text-txt-3">{progress}% concluído</p>
                  </div>
                )}

                {/* Uploaded video preview */}
                {formData.demo_video_url && !uploading && !converting && (
                  <div className="space-y-3">
                    <Label className="text-xs text-txt-3">Preview do Vídeo</Label>
                    <div className="relative rounded-lg overflow-hidden bg-bg-2">
                      <video
                        src={formData.demo_video_url}
                        controls
                        className="w-full max-h-[200px] object-contain"
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => fileInputRef.current?.click()}
                        className="flex-1"
                        size="sm"
                      >
                        <Upload className="w-4 h-4 mr-2" />
                        Trocar Vídeo
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={handleRemoveUploadedVideo}
                        size="sm"
                        className="text-error border-error/30 hover:bg-error/10"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </>
            )}
          </Card>
        </div>
      </div>

      {/* Instruções */}
      <Card className="glass-card p-6 space-y-4">
        <Label className="text-base font-semibold text-txt">
          Instruções de Execução
        </Label>
        
        <div className="flex gap-2">
          <Textarea
            placeholder="Digite um passo da execução..."
            value={instructionInput}
            onChange={(e) => setInstructionInput(e.target.value)}
            rows={2}
          />
          <Button onClick={addInstruction} variant="outline" size="icon" className="flex-shrink-0">
            <Plus className="w-4 h-4" />
          </Button>
        </div>

        {formData.instructions.length > 0 && (
          <div className="space-y-2">
            {formData.instructions.map((instruction, index) => (
              <div key={index} className="flex items-start gap-3 p-3 bg-bg-2 rounded-lg">
                <span className="text-sm font-semibold text-accent mt-0.5">{index + 1}.</span>
                <p className="flex-1 text-sm text-txt">{instruction}</p>
                <Button
                  onClick={() => removeInstruction(index)}
                  variant="ghost"
                  size="icon"
                  className="flex-shrink-0 h-8 w-8"
                >
                  <Trash2 className="w-4 h-4 text-error" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Dicas de Forma */}
      <Card className="glass-card p-6 space-y-4">
        <Label className="text-base font-semibold text-txt">
          Dicas de Forma e Execução
        </Label>
        
        <div className="flex gap-2">
          <Input
            placeholder="Digite uma dica..."
            value={tipInput}
            onChange={(e) => setTipInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTip())}
          />
          <Button onClick={addTip} variant="outline" size="icon">
            <Plus className="w-4 h-4" />
          </Button>
        </div>

        {formData.form_tips.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {formData.form_tips.map((tip, index) => (
              <Badge key={index} variant="outline" className="py-2 px-3">
                💡 {tip}
                <button onClick={() => removeTip(index)} className="ml-2">
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
          </div>
        )}
      </Card>

      {/* Actions */}
      <div className="flex gap-3 pt-6">
        <Button onClick={onCancel} variant="outline" className="flex-1">
          <X className="w-4 h-4 mr-2" />
          Cancelar
        </Button>
        <Button onClick={handleSubmit} className="flex-1 bg-accent text-accent-ink hover:bg-accent/90">
          <Save className="w-4 h-4 mr-2" />
          Salvar Exercício
        </Button>
      </div>

      {/* Modal de Seleção de Vídeo */}
      <YouTubeVideoPicker
        isOpen={isVideoPickerOpen}
        onClose={() => setIsVideoPickerOpen(false)}
        onSelect={handleVideoSelect}
      />
    </div>
  );
};
