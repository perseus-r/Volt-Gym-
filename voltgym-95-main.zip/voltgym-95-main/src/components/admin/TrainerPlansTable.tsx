import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Pencil, Check, X, Loader2, Users } from 'lucide-react';
import { TrainerPlanAdmin } from '@/hooks/useAdminPlans';

interface TrainerPlansTableProps {
  plans: TrainerPlanAdmin[];
  saving: boolean;
  onUpdate: (id: string, updates: Partial<TrainerPlanAdmin>) => Promise<void>;
}

export function TrainerPlansTable({ plans, saving, onUpdate }: TrainerPlansTableProps) {
  const [editingPlan, setEditingPlan] = useState<TrainerPlanAdmin | null>(null);
  const [formData, setFormData] = useState<Partial<TrainerPlanAdmin>>({});

  const handleEdit = (plan: TrainerPlanAdmin) => {
    setEditingPlan(plan);
    setFormData({
      plan_name: plan.plan_name,
      monthly_price_brl: plan.monthly_price_brl,
      annual_price_brl: plan.annual_price_brl,
      stripe_price_id_monthly: plan.stripe_price_id_monthly,
      stripe_price_id_annual: plan.stripe_price_id_annual,
      max_athletes: plan.max_athletes,
      max_ai_queries_per_month: plan.max_ai_queries_per_month,
      is_public: plan.is_public
    });
  };

  const handleSave = async () => {
    if (!editingPlan) return;
    await onUpdate(editingPlan.id, formData);
    setEditingPlan(null);
  };

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'starter': return 'text-blue-400';
      case 'professional': return 'text-accent';
      case 'enterprise': return 'text-purple-400';
      default: return 'text-white';
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white">Planos de Personal Trainers</h3>
      
      <div className="grid gap-4">
        {plans.map((plan) => (
          <Card key={plan.id} className={`p-4 border ${plan.is_public ? 'border-line/50' : 'border-yellow-500/30 opacity-60'}`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div>
                  <h4 className={`font-bold ${getTierColor(plan.plan_tier)}`}>
                    {plan.plan_name}
                  </h4>
                  <p className="text-sm text-txt-2">{plan.plan_tier}</p>
                </div>
                
                <div className="flex items-center gap-6 text-sm">
                  <div>
                    <span className="text-txt-3">Preço:</span>
                    <span className="ml-2 font-mono text-white">R$ {plan.monthly_price_brl}</span>
                  </div>
                  <div>
                    <span className="text-txt-3">Trial:</span>
                    <span className="ml-2 text-white">7 dias</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Users className="w-4 h-4 text-txt-3" />
                    <span className="text-txt-3">Max:</span>
                    <span className="ml-1 text-white">{plan.max_athletes}</span>
                  </div>
                  <div>
                    <span className="text-txt-3">IA:</span>
                    <span className="ml-2 text-white">{plan.max_ai_queries_per_month === -1 ? '∞' : plan.max_ai_queries_per_month}</span>
                  </div>
                  <div className="text-xs text-txt-3">
                    ≈ R$ {(plan.monthly_price_brl / plan.max_athletes).toFixed(0)}/atleta
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {plan.stripe_price_id_monthly ? (
                  <span className="text-xs text-green-400">Stripe ✓</span>
                ) : (
                  <span className="text-xs text-yellow-400">Sem Stripe</span>
                )}
                
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="ghost" size="sm" onClick={() => handleEdit(plan)}>
                      <Pencil className="w-4 h-4" />
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-lg">
                    <DialogHeader>
                      <DialogTitle>Editar Plano: {plan.plan_name}</DialogTitle>
                    </DialogHeader>
                    
                    <div className="grid gap-4 py-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Nome</Label>
                          <Input
                            value={formData.plan_name || ''}
                            onChange={(e) => setFormData({ ...formData, plan_name: e.target.value })}
                          />
                        </div>
                        <div>
                          <Label>Preço Mensal (R$)</Label>
                          <Input
                            type="number"
                            value={formData.monthly_price_brl || 0}
                            onChange={(e) => setFormData({ ...formData, monthly_price_brl: Number(e.target.value) })}
                          />
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Preço Anual (R$)</Label>
                          <Input
                            type="number"
                            value={formData.annual_price_brl || ''}
                            onChange={(e) => setFormData({ ...formData, annual_price_brl: e.target.value ? Number(e.target.value) : null })}
                          />
                        </div>
                        <div>
                          <Label>Máximo de Atletas</Label>
                          <Input
                            type="number"
                            value={formData.max_athletes || 0}
                            onChange={(e) => setFormData({ ...formData, max_athletes: Number(e.target.value) })}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Max Consultas IA (-1 = ilimitado)</Label>
                          <Input
                            type="number"
                            value={formData.max_ai_queries_per_month || 0}
                            onChange={(e) => setFormData({ ...formData, max_ai_queries_per_month: Number(e.target.value) })}
                          />
                        </div>
                        <div>
                          <Label>&nbsp;</Label>
                          <div className="text-sm text-txt-3 pt-2">
                            Trial: 7 dias (padrão)
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <Label>Stripe Price ID (Mensal)</Label>
                        <Input
                          value={formData.stripe_price_id_monthly || ''}
                          onChange={(e) => setFormData({ ...formData, stripe_price_id_monthly: e.target.value || null })}
                          placeholder="price_xxxxxxxxx"
                        />
                      </div>
                      
                      <div>
                        <Label>Stripe Price ID (Anual)</Label>
                        <Input
                          value={formData.stripe_price_id_annual || ''}
                          onChange={(e) => setFormData({ ...formData, stripe_price_id_annual: e.target.value || null })}
                          placeholder="price_xxxxxxxxx"
                        />
                      </div>

                      <div className="flex items-center gap-2">
                        <Switch
                          checked={formData.is_public}
                          onCheckedChange={(v) => setFormData({ ...formData, is_public: v })}
                        />
                        <Label>Plano Público (visível na página de preços)</Label>
                      </div>
                    </div>
                    
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" onClick={() => setEditingPlan(null)}>
                        <X className="w-4 h-4 mr-2" />
                        Cancelar
                      </Button>
                      <Button onClick={handleSave} disabled={saving}>
                        {saving ? (
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        ) : (
                          <Check className="w-4 h-4 mr-2" />
                        )}
                        Salvar
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
