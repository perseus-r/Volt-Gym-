import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Search, Video, VideoOff, TrendingUp, Eye, Youtube, Upload } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { ExerciseVideoManager } from './ExerciseVideoManager';
import { WorkoutVideoPlayer } from '@/components/workout/WorkoutVideoPlayer';
interface Exercise {
  id: string;
  name: string;
  primary_muscles: string[];
  youtube_url?: string | null;
  youtube_video_id?: string | null;
  demo_video_url?: string | null;
  video_duration_seconds?: number | null;
  view_count?: number;
  is_short?: boolean;
  thumbnail_url?: string | null;
  category?: string;
}

export const ExerciseVideosPanel: React.FC = () => {
  const navigate = useNavigate();
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [filteredExercises, setFilteredExercises] = useState<Exercise[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'with-video' | 'without-video'>('all');
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null);

  const fetchExercises = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('exercises')
        .select('*')
        .order('name');

      if (error) throw error;

      setExercises(data || []);
      filterExercises(data || [], searchTerm, filterStatus);
    } catch (error) {
      console.error('Error fetching exercises:', error);
      toast.error('Erro ao carregar exercícios');
    } finally {
      setLoading(false);
    }
  };

  const filterExercises = (
    exerciseList: Exercise[],
    search: string,
    status: typeof filterStatus
  ) => {
    let filtered = exerciseList;

    // Filter by search term
    if (search) {
      filtered = filtered.filter(ex =>
        ex.name.toLowerCase().includes(search.toLowerCase()) ||
        ex.primary_muscles?.some(m => m.toLowerCase().includes(search.toLowerCase()))
      );
    }

    // Filter by video status
    if (status === 'with-video') {
      filtered = filtered.filter(ex => ex.youtube_video_id || ex.demo_video_url);
    } else if (status === 'without-video') {
      filtered = filtered.filter(ex => !ex.youtube_video_id && !ex.demo_video_url);
    }

    setFilteredExercises(filtered);
  };

  useEffect(() => {
    fetchExercises();
  }, []);

  useEffect(() => {
    filterExercises(exercises, searchTerm, filterStatus);
  }, [searchTerm, filterStatus, exercises]);

  const stats = {
    total: exercises.length,
    withVideo: exercises.filter(ex => ex.youtube_video_id || ex.demo_video_url).length,
    withoutVideo: exercises.filter(ex => !ex.youtube_video_id && !ex.demo_video_url).length,
    totalViews: exercises.reduce((sum, ex) => sum + (ex.view_count || 0), 0)
  };

  const handleIncrementViews = async (exerciseId: string) => {
    try {
      const { error } = await supabase.rpc('increment_exercise_views', {
        exercise_id_param: exerciseId
      });

      if (error) throw error;
      
      await fetchExercises();
    } catch (error) {
      console.error('Error incrementing views:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-12">
        <div className="text-txt-2">Carregando exercícios...</div>
      </div>
    );
  }

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Stats - Mobile Optimized */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 md:gap-4">
        <Card className="p-3 md:p-4">
          <div className="flex flex-col gap-1">
            <div className="flex items-center justify-between mb-1">
              <p className="text-xs text-txt-2 truncate">Total</p>
              <Video className="w-5 h-5 md:w-6 md:h-6 text-accent flex-shrink-0" />
            </div>
            <p className="text-lg md:text-2xl font-bold text-txt">{stats.total}</p>
          </div>
        </Card>

        <Card className="p-3 md:p-4">
          <div className="flex flex-col gap-1">
            <div className="flex items-center justify-between mb-1">
              <p className="text-xs text-txt-2 truncate">Com Vídeo</p>
              <Youtube className="w-5 h-5 md:w-6 md:h-6 text-success flex-shrink-0" />
            </div>
            <p className="text-lg md:text-2xl font-bold text-success">{stats.withVideo}</p>
          </div>
        </Card>

        <Card className="p-3 md:p-4">
          <div className="flex flex-col gap-1">
            <div className="flex items-center justify-between mb-1">
              <p className="text-xs text-txt-2 truncate">Sem Vídeo</p>
              <VideoOff className="w-5 h-5 md:w-6 md:h-6 text-warning flex-shrink-0" />
            </div>
            <p className="text-lg md:text-2xl font-bold text-warning">{stats.withoutVideo}</p>
          </div>
        </Card>

        <Card className="p-3 md:p-4">
          <div className="flex flex-col gap-1">
            <div className="flex items-center justify-between mb-1">
              <p className="text-xs text-txt-2 truncate">Views</p>
              <Eye className="w-5 h-5 md:w-6 md:h-6 text-accent flex-shrink-0" />
            </div>
            <p className="text-lg md:text-2xl font-bold text-accent">{stats.totalViews.toLocaleString()}</p>
          </div>
        </Card>
      </div>

      {/* Filters - Mobile Optimized */}
      <Card className="p-4 md:p-6">
        <div className="flex flex-col gap-3 md:gap-4">
          {/* Bulk Upload Button */}
          <div className="flex justify-end">
            <Button
              onClick={() => navigate('/admin/bulk-upload')}
              className="bg-accent hover:bg-accent/80"
              size="sm"
            >
              <Upload className="w-4 h-4 mr-2" />
              Upload em Massa
            </Button>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3 md:gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-txt-3" />
            <Input
              type="text"
              placeholder="Buscar exercício..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 text-sm"
            />
          </div>

          <div className="flex flex-wrap gap-2">
            <Button
              variant={filterStatus === 'all' ? 'default' : 'outline'}
              onClick={() => setFilterStatus('all')}
              size="sm"
              className="flex-1 sm:flex-none min-w-[85px] text-xs md:text-sm"
            >
              Todos ({stats.total})
            </Button>
            <Button
              variant={filterStatus === 'with-video' ? 'default' : 'outline'}
              onClick={() => setFilterStatus('with-video')}
              size="sm"
              className="flex-1 sm:flex-none min-w-[85px] text-xs md:text-sm"
            >
              Com ({stats.withVideo})
            </Button>
            <Button
              variant={filterStatus === 'without-video' ? 'default' : 'outline'}
              onClick={() => setFilterStatus('without-video')}
              size="sm"
              className="flex-1 sm:flex-none min-w-[85px] text-xs md:text-sm"
            >
              Sem ({stats.withoutVideo})
            </Button>
          </div>
          </div>
        </div>
      </Card>

      {/* Exercise List - Responsive Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4 md:gap-6">
        {filteredExercises.length === 0 ? (
          <Card className="col-span-2 p-12 text-center">
            <VideoOff className="w-16 h-16 text-txt-3 mx-auto mb-4" />
            <p className="text-txt-2">Nenhum exercício encontrado</p>
          </Card>
        ) : (
          filteredExercises.map((exercise) => (
            <Card key={exercise.id} className="p-6">
              <div className="space-y-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold text-txt mb-2">{exercise.name}</h3>
                    <div className="flex flex-wrap gap-2 mb-2">
                      {exercise.primary_muscles?.map((muscle, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {muscle}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  {(exercise.youtube_video_id || exercise.demo_video_url) ? (
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                      <Video className="w-3 h-3 mr-1" />
                      Com vídeo
                    </Badge>
                  ) : (
                    <Badge className="bg-orange-500/20 text-orange-400 border-orange-500/30">
                      <VideoOff className="w-3 h-3 mr-1" />
                      Sem vídeo
                    </Badge>
                  )}
                </div>

                {(exercise.youtube_url || exercise.demo_video_url) && (
                  <WorkoutVideoPlayer
                    videoUrl={exercise.demo_video_url || exercise.youtube_url!}
                    className="w-full"
                    controls
                    clickToPlay
                  />
                )}

                <Button
                  onClick={() => setSelectedExercise(exercise)}
                  variant="outline"
                  className="w-full"
                >
                  {(exercise.youtube_video_id || exercise.demo_video_url) ? 'Editar Vídeo' : 'Adicionar Vídeo'}
                </Button>
              </div>
            </Card>
          ))
        )}
      </div>

      {/* Edit Modal - Mobile Bottom Sheet */}
      {selectedExercise && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
          <div className="bg-background glass-card rounded-t-xl sm:rounded-xl w-full sm:max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-background border-b border-line/30 p-4 md:p-6 flex items-center justify-between">
              <h2 className="text-lg md:text-xl font-bold text-txt">Gerenciar Vídeo</h2>
              <Button variant="ghost" size="sm" onClick={() => setSelectedExercise(null)}>
                ✕
              </Button>
            </div>
            
            <div className="p-4 md:p-6">
              <ExerciseVideoManager
                exerciseId={selectedExercise.id}
                exerciseName={selectedExercise.name}
                currentYoutubeUrl={selectedExercise.youtube_url}
                currentVideoId={selectedExercise.youtube_video_id}
                currentDemoVideoUrl={selectedExercise.demo_video_url}
                currentViewCount={selectedExercise.view_count}
                onUpdate={() => {
                  fetchExercises();
                  setSelectedExercise(null);
                }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
