import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Upload, X, Video, Image as ImageIcon } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface MediaFile {
  url: string;
  type: 'image' | 'video';
  preview: string;
}

interface ProductMediaUploadProps {
  existingMedia?: string[];
  onMediaChange: (urls: string[]) => void;
}

export function ProductMediaUpload({ 
  existingMedia = [], 
  onMediaChange 
}: ProductMediaUploadProps) {
  const [uploading, setUploading] = useState(false);
  const [mediaFiles, setMediaFiles] = useState<MediaFile[]>(
    existingMedia.map(url => ({
      url,
      type: url.includes('.mp4') || url.includes('.webm') ? 'video' : 'image',
      preview: url
    }))
  );

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    
    if (files.length === 0) return;

    // Validar tamanho (50MB max)
    const invalidFiles = files.filter(f => f.size > 50 * 1024 * 1024);
    if (invalidFiles.length > 0) {
      toast({
        title: "Arquivo muito grande",
        description: "O tamanho máximo é 50MB por arquivo",
        variant: "destructive"
      });
      return;
    }
    
    setUploading(true);
    const uploadedUrls: string[] = [];
    const newMediaFiles: MediaFile[] = [];

    try {
      for (const file of files) {
        const fileExt = file.name.split('.').pop();
        const fileName = `${Math.random()}.${fileExt}`;
        const filePath = `${fileName}`;

        const { error, data } = await supabase.storage
          .from('product-media')
          .upload(filePath, file, {
            cacheControl: '3600',
            upsert: false
          });

        if (error) {
          console.error('Upload error:', error);
          toast({
            title: "Erro no upload",
            description: error.message,
            variant: "destructive"
          });
          continue;
        }

        if (data) {
          const { data: { publicUrl } } = supabase.storage
            .from('product-media')
            .getPublicUrl(filePath);
          
          uploadedUrls.push(publicUrl);
          
          newMediaFiles.push({
            url: publicUrl,
            type: file.type.startsWith('video') ? 'video' : 'image',
            preview: publicUrl
          });
        }
      }

      const allMediaFiles = [...mediaFiles, ...newMediaFiles];
      setMediaFiles(allMediaFiles);
      onMediaChange(allMediaFiles.map(m => m.url));

      toast({
        title: "Upload concluído",
        description: `${uploadedUrls.length} arquivo(s) enviado(s) com sucesso`
      });
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: "Erro no upload",
        description: "Ocorreu um erro ao fazer upload dos arquivos",
        variant: "destructive"
      });
    } finally {
      setUploading(false);
    }
  };

  const removeMedia = async (url: string) => {
    try {
      // Extrair o path do URL para deletar do storage
      const path = url.split('/product-media/')[1];
      if (path) {
        await supabase.storage.from('product-media').remove([path]);
      }

      const updatedFiles = mediaFiles.filter(m => m.url !== url);
      setMediaFiles(updatedFiles);
      onMediaChange(updatedFiles.map(m => m.url));

      toast({
        title: "Mídia removida",
        description: "Arquivo removido com sucesso"
      });
    } catch (error) {
      console.error('Error removing media:', error);
      toast({
        title: "Erro ao remover",
        description: "Não foi possível remover o arquivo",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <label className="block mb-2 text-sm font-medium">
          Imagens e Vídeos do Produto
        </label>
        <Button 
          type="button" 
          variant="outline" 
          disabled={uploading}
          className="w-full"
          onClick={() => document.getElementById('media-upload')?.click()}
        >
          <Upload className="w-4 h-4 mr-2" />
          {uploading ? 'Enviando...' : 'Upload de Imagens/Vídeos'}
        </Button>
        <input
          id="media-upload"
          type="file"
          multiple
          accept="image/jpeg,image/png,image/webp,video/mp4,video/webm"
          onChange={handleFileUpload}
          className="hidden"
        />
        <p className="text-xs text-muted-foreground mt-1">
          Formatos aceitos: JPG, PNG, WEBP, MP4, WEBM (máx 50MB por arquivo)
        </p>
      </div>

      {mediaFiles.length > 0 && (
        <div className="grid grid-cols-3 gap-2">
          {mediaFiles.map((media, idx) => (
            <div key={idx} className="relative group">
              {media.type === 'video' ? (
                <div className="relative">
                  <video 
                    src={media.url} 
                    className="w-full h-24 object-cover rounded border"
                    controls={false}
                  />
                  <div className="absolute inset-0 flex items-center justify-center bg-black/20 rounded">
                    <Video className="w-6 h-6 text-white" />
                  </div>
                </div>
              ) : (
                <img 
                  src={media.url} 
                  className="w-full h-24 object-cover rounded border"
                  alt="Product media"
                />
              )}
              <button
                type="button"
                onClick={() => removeMedia(media.url)}
                className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground p-1 rounded-full opacity-0 group-hover:opacity-100 transition shadow-lg"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
