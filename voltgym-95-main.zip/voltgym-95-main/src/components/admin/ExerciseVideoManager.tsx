import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Youtube, Check, AlertCircle, Eye, Upload, Trash2, Video, CheckCircle2, XCircle, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import YouTubePlayer from '@/components/YouTubePlayer';
import { WorkoutVideoPlayer } from '@/components/workout/WorkoutVideoPlayer';
import { useVideoUpload } from '@/hooks/useVideoUpload';
import { getYouTubeId } from '@/utils/youtube';

interface ExerciseVideoManagerProps {
  exerciseId: string;
  exerciseName: string;
  currentYoutubeUrl?: string | null;
  currentVideoId?: string | null;
  currentDemoVideoUrl?: string | null;
  currentViewCount?: number;
  onUpdate?: () => void;
}

interface VideoFileStatus {
  checking: boolean;
  accessible: boolean | null;
  contentType: string | null;
  errorMessage: string | null;
}

export const ExerciseVideoManager: React.FC<ExerciseVideoManagerProps> = ({
  exerciseId,
  exerciseName,
  currentYoutubeUrl,
  currentVideoId,
  currentDemoVideoUrl,
  currentViewCount = 0,
  onUpdate
}) => {
  const [videoType, setVideoType] = useState<'youtube' | 'upload'>('youtube');
  const [youtubeUrl, setYoutubeUrl] = useState(currentYoutubeUrl || '');
  const [isValidating, setIsValidating] = useState(false);
  const [isValid, setIsValid] = useState(false);
  const [extractedId, setExtractedId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [uploadedVideoUrl, setUploadedVideoUrl] = useState<string | null>(currentDemoVideoUrl || null);
  const [fileStatus, setFileStatus] = useState<VideoFileStatus>({
    checking: false,
    accessible: null,
    contentType: null,
    errorMessage: null
  });
  const { uploadVideo, deleteVideo, uploading, progress } = useVideoUpload();

  // Verificar status do arquivo de vídeo
  useEffect(() => {
    const videoUrl = uploadedVideoUrl || currentDemoVideoUrl;
    if (!videoUrl) {
      setFileStatus({ checking: false, accessible: null, contentType: null, errorMessage: null });
      return;
    }

    const checkVideoFile = async () => {
      setFileStatus(prev => ({ ...prev, checking: true }));
      try {
        const response = await fetch(videoUrl, { method: 'HEAD', cache: 'no-cache' });
        const contentType = response.headers.get('content-type') || '';
        
        if (!response.ok) {
          setFileStatus({
            checking: false,
            accessible: false,
            contentType: null,
            errorMessage: response.status === 404 
              ? 'Arquivo não encontrado (404)' 
              : `Erro HTTP ${response.status}`
          });
        } else {
          setFileStatus({
            checking: false,
            accessible: true,
            contentType,
            errorMessage: null
          });
        }
      } catch (error) {
        // CORS pode bloquear HEAD - assume acessível
        setFileStatus({
          checking: false,
          accessible: null,
          contentType: null,
          errorMessage: 'Não foi possível verificar (CORS)'
        });
      }
    };

    checkVideoFile();
  }, [uploadedVideoUrl, currentDemoVideoUrl]);

  // Validar URL do YouTube usando utility
  const validateYoutubeUrl = (url: string) => {
    if (!url) {
      setIsValid(false);
      setExtractedId(null);
      return;
    }

    setIsValidating(true);
    const videoId = getYouTubeId(url);

    if (videoId) {
      setIsValid(true);
      setExtractedId(videoId);
    } else {
      setIsValid(false);
      setExtractedId(null);
    }

    setIsValidating(false);
  };

  const handleUrlChange = (url: string) => {
    setYoutubeUrl(url);
    validateYoutubeUrl(url);
    
    // Se colar link do YouTube no modo upload, avisar e trocar
    if (videoType === 'upload' && url && (url.includes('youtube.com') || url.includes('youtu.be'))) {
      toast.info('Link do YouTube detectado! Mudando para modo YouTube...', { duration: 3000 });
      setVideoType('youtube');
    }
  };

  const handleSave = async () => {
    if (!isValid || !extractedId) {
      toast.error('URL do YouTube inválida');
      return;
    }

    setIsSaving(true);

    try {
      // Salvar YouTube e limpar demo_video_url
      const { error } = await supabase
        .from('exercises')
        .update({
          youtube_url: youtubeUrl,
          demo_video_url: null,
          updated_at: new Date().toISOString()
        })
        .eq('id', exerciseId);

      if (error) throw error;

      toast.success('Vídeo do YouTube adicionado com sucesso!');
      onUpdate?.();
    } catch (error) {
      console.error('Error saving YouTube URL:', error);
      toast.error('Erro ao salvar vídeo');
    } finally {
      setIsSaving(false);
    }
  };

  const handleRemove = async () => {
    setIsSaving(true);

    try {
      const { error } = await supabase
        .from('exercises')
        .update({
          youtube_url: null,
          youtube_video_id: null,
          video_duration_seconds: null,
          updated_at: new Date().toISOString()
        })
        .eq('id', exerciseId);

      if (error) throw error;

      setYoutubeUrl('');
      setIsValid(false);
      setExtractedId(null);
      toast.success('Vídeo removido');
      onUpdate?.();
    } catch (error) {
      console.error('Error removing YouTube URL:', error);
      toast.error('Erro ao remover vídeo');
    } finally {
      setIsSaving(false);
    }
  };

  const handleFileUpload = async (file: File) => {
    // Validação adicional no cliente
    const validExtensions = ['.mp4', '.webm'];
    const fileExt = '.' + file.name.split('.').pop()?.toLowerCase();
    
    if (!validExtensions.includes(fileExt)) {
      toast.error(`Formato ${fileExt.toUpperCase()} não suportado. Use MP4 ou WebM.`);
      return;
    }

    if (file.size > 50 * 1024 * 1024) {
      toast.error('Arquivo muito grande. Máximo 50MB.');
      return;
    }

    try {
      const publicUrl = await uploadVideo(file);
      setUploadedVideoUrl(publicUrl);
      
      // Salvar demo_video_url e limpar YouTube
      const { error } = await supabase
        .from('exercises')
        .update({
          demo_video_url: publicUrl,
          youtube_url: null,
          youtube_video_id: null,
          updated_at: new Date().toISOString()
        })
        .eq('id', exerciseId);

      if (error) throw error;
      toast.success('Vídeo enviado e salvo com sucesso!');
      onUpdate?.();
    } catch (error: any) {
      console.error('Upload error:', error);
      toast.error(error?.message || 'Erro ao fazer upload do vídeo');
    }
  };

  const handleRemoveDirectVideo = async () => {
    if (!uploadedVideoUrl) return;
    
    setIsSaving(true);
    try {
      await deleteVideo(uploadedVideoUrl);
      
      const { error } = await supabase
        .from('exercises')
        .update({
          demo_video_url: null,
          updated_at: new Date().toISOString()
        })
        .eq('id', exerciseId);

      if (error) throw error;

      setUploadedVideoUrl(null);
      toast.success('Vídeo removido');
      onUpdate?.();
    } catch (error) {
      console.error('Error removing video:', error);
      toast.error('Erro ao remover vídeo');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Card className="p-6">
      <div className="space-y-4">
        <div className="flex items-center gap-2 mb-4">
          <Video className="w-5 h-5 text-accent" />
          <h3 className="font-semibold text-txt">Vídeo de Preview - {exerciseName}</h3>
        </div>

        {/* Toggle entre YouTube e Upload */}
        <div className="flex gap-2 mb-4">
          <Button
            variant={videoType === 'youtube' ? 'default' : 'outline'}
            onClick={() => setVideoType('youtube')}
            size="sm"
          >
            <Youtube className="w-4 h-4 mr-2" />
            YouTube
          </Button>
          <Button
            variant={videoType === 'upload' ? 'default' : 'outline'}
            onClick={() => setVideoType('upload')}
            size="sm"
          >
            <Upload className="w-4 h-4 mr-2" />
            Upload Direto
          </Button>
        </div>

        {videoType === 'youtube' ? (
          <div className="space-y-4">
            {/* URL Input */}
            <div className="space-y-2">
              <Label htmlFor="youtube-url">URL do YouTube</Label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Input
                    id="youtube-url"
                    type="text"
                    placeholder="https://youtube.com/watch?v=... ou https://youtu.be/..."
                    value={youtubeUrl}
                    onChange={(e) => handleUrlChange(e.target.value)}
                    className={isValid ? 'border-green-500' : ''}
                  />
                  {isValid && (
                    <Check className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-green-500" />
                  )}
                  {youtubeUrl && !isValid && !isValidating && (
                    <AlertCircle className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-red-500" />
                  )}
                </div>
              </div>
              
              {isValid && extractedId && (
                <p className="text-sm text-green-600">
                  ✓ ID extraído: <code className="bg-green-100 px-2 py-1 rounded">{extractedId}</code>
                </p>
              )}
            </div>

            {/* Preview */}
            {youtubeUrl && isValid && (
              <div className="space-y-2">
                <Label>Preview</Label>
                <YouTubePlayer
                  url={youtubeUrl}
                  title={exerciseName}
                  className="max-w-md"
                />
              </div>
            )}

            {/* Stats */}
            {currentVideoId && (
              <div className="flex items-center gap-4 text-sm text-txt-2">
                <div className="flex items-center gap-2">
                  <Eye className="w-4 h-4" />
                  <span>{currentViewCount} visualizações no app</span>
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="flex gap-2 pt-2">
              <Button
                onClick={handleSave}
                disabled={!isValid || isSaving}
                className="flex-1"
              >
                {isSaving ? 'Salvando...' : currentVideoId ? 'Atualizar Vídeo' : 'Adicionar Vídeo'}
              </Button>
              
              {currentVideoId && (
                <Button
                  onClick={handleRemove}
                  disabled={isSaving}
                  variant="outline"
                >
                  Remover
                </Button>
              )}
            </div>

            {/* Tips */}
            <div className="bg-accent/10 border border-accent/30 rounded-lg p-4 text-sm">
              <p className="font-semibold text-accent mb-2">💡 Dicas:</p>
              <ul className="space-y-1 text-txt-2">
                <li>• Cole o link completo do YouTube</li>
                <li>• Funciona com: youtube.com/watch, youtu.be, youtube.com/shorts</li>
                <li>• O thumbnail é gerado automaticamente</li>
                <li>• Shorts são detectados automaticamente</li>
              </ul>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="video-upload">Upload de Vídeo (MP4 ou WebM - máx 50MB)</Label>
              <div className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${uploading ? 'border-accent/50 bg-accent/5' : 'border-line/40 hover:border-accent/50'}`}>
                <input
                  id="video-upload"
                  type="file"
                  accept=".mp4,.webm,video/mp4,video/webm"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleFileUpload(file);
                    e.target.value = ''; // Reset input
                  }}
                  disabled={uploading}
                  className="hidden"
                />
                <label
                  htmlFor="video-upload"
                  className={`flex flex-col items-center gap-3 ${uploading ? 'cursor-wait' : 'cursor-pointer'}`}
                >
                  <Upload className={`w-12 h-12 ${uploading ? 'text-accent animate-pulse' : 'text-accent'}`} />
                  <div>
                    <p className="font-medium text-txt">
                      {uploading ? 'Enviando vídeo...' : 'Clique para fazer upload'}
                    </p>
                    <p className="text-sm text-txt-2">
                      {uploading ? 'Aguarde o upload completar' : 'Apenas MP4 ou WebM (máx 50MB)'}
                    </p>
                  </div>
                </label>
              </div>
            </div>

            {uploading && (
              <div className="space-y-2">
                <div className="w-full bg-surface rounded-full h-2 overflow-hidden">
                  <div 
                    className="bg-accent h-2 rounded-full transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <p className="text-sm text-txt-2 text-center">{progress}% enviado...</p>
              </div>
            )}

            {(uploadedVideoUrl || currentDemoVideoUrl) && (
              <div className="space-y-3">
                <Label>Preview do Vídeo</Label>
                <WorkoutVideoPlayer
                  videoUrl={uploadedVideoUrl || currentDemoVideoUrl || ''}
                  controls={true}
                  className="max-w-md"
                />
                
                {/* Status do arquivo */}
                <div className="flex items-center gap-2 text-sm bg-surface/50 rounded-lg p-3">
                  {fileStatus.checking ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                      <span className="text-muted-foreground">Verificando arquivo...</span>
                    </>
                  ) : fileStatus.accessible === true ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-green-500" />
                      <span className="text-green-600">Acessível</span>
                      {fileStatus.contentType && (
                        <span className="text-muted-foreground">• {fileStatus.contentType}</span>
                      )}
                    </>
                  ) : fileStatus.accessible === false ? (
                    <>
                      <XCircle className="w-4 h-4 text-destructive" />
                      <span className="text-destructive">{fileStatus.errorMessage}</span>
                    </>
                  ) : fileStatus.errorMessage ? (
                    <>
                      <AlertCircle className="w-4 h-4 text-amber-500" />
                      <span className="text-amber-600">{fileStatus.errorMessage}</span>
                    </>
                  ) : null}
                </div>
              </div>
            )}

            {(uploadedVideoUrl || currentDemoVideoUrl) && (
              <Button
                onClick={handleRemoveDirectVideo}
                disabled={isSaving}
                variant="outline"
                className="w-full"
              >
                <Trash2 className="w-4 h-4 mr-2" />
                Remover Vídeo
              </Button>
            )}

            <div className="bg-accent/10 border border-accent/30 rounded-lg p-4 text-sm">
              <p className="font-semibold text-accent mb-2">💡 Formatos Suportados:</p>
              <ul className="space-y-1 text-txt-2">
                <li>• <strong>MP4</strong> - Recomendado (H.264/AAC) para máxima compatibilidade</li>
                <li>• <strong>WebM</strong> - Boa compatibilidade em navegadores modernos</li>
                <li>• Tamanho máximo: 50MB</li>
              </ul>
              <p className="mt-2 text-xs text-destructive/80">
                ⚠️ MOV não é suportado (incompatível com Android/Chrome)
              </p>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
};
