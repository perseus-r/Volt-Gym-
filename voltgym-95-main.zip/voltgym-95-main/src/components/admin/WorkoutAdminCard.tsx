import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { WorkoutVideoPlayer } from "@/components/workout/WorkoutVideoPlayer";
import { 
  MoreVertical, 
  Eye, 
  EyeOff, 
  Star, 
  Trash2, 
  Clock, 
  Dumbbell,
  Target,
  ExternalLink
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface WorkoutAdminCardProps {
  workout: {
    id: string;
    name: string;
    description: string | null;
    focus: string;
    difficulty_level: number | null;
    estimated_duration: number | null;
    target_muscle_groups: string[] | null;
    is_public: boolean | null;
    video_url?: string | null;
    tags?: string[] | null;
    source?: string | null;
  };
  onTogglePublic: (id: string, isPublic: boolean | null) => void;
  onDelete: (id: string) => void;
}

const difficultyColors: Record<number, string> = {
  1: 'bg-success/20 text-success border-success/30',
  2: 'bg-warning/20 text-warning border-warning/30',
  3: 'bg-error/20 text-error border-error/30',
};

const difficultyLabels: Record<number, string> = {
  1: 'Iniciante',
  2: 'Intermediário',
  3: 'Avançado',
};

const focusLabels: Record<string, string> = {
  push: 'Push',
  pull: 'Pull',
  legs: 'Legs',
  upper: 'Upper Body',
  lower: 'Lower Body',
  full: 'Full Body',
};

export const WorkoutAdminCard = ({
  workout,
  onTogglePublic,
  onDelete,
}: WorkoutAdminCardProps) => {
  return (
    <Card className={`glass-card p-4 md:p-6 transition-all ${
      workout.is_public ? '' : 'opacity-60'
    }`}>
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1 min-w-0">
          <h3 className="text-base md:text-lg font-bold text-txt mb-1 truncate">
            {workout.name}
          </h3>
          <p className="text-xs md:text-sm text-txt-2 line-clamp-2 mb-3">
            {workout.description || 'Sem descrição'}
          </p>
        </div>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="flex-shrink-0 ml-2">
              <MoreVertical className="w-4 h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="glass-card border-line/30">
            <DropdownMenuItem onClick={() => onTogglePublic(workout.id, workout.is_public)}>
              {workout.is_public ? (
                <>
                  <EyeOff className="w-4 h-4 mr-2" />
                  Tornar Privado
                </>
              ) : (
                <>
                  <Eye className="w-4 h-4 mr-2" />
                  Tornar Público
                </>
              )}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem 
              onClick={() => onDelete(workout.id)}
              className="text-error focus:text-error"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Excluir
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Badges */}
      <div className="flex flex-wrap gap-2 mb-4">
        {workout.difficulty_level && (
          <Badge 
            variant="outline" 
            className={difficultyColors[workout.difficulty_level] || 'bg-surface/50 text-txt-2 border-line/30'}
          >
            {difficultyLabels[workout.difficulty_level] || `Nível ${workout.difficulty_level}`}
          </Badge>
        )}
        <Badge variant="outline" className="bg-surface/50 text-txt-2 border-line/30">
          {focusLabels[workout.focus] || workout.focus}
        </Badge>
        {workout.target_muscle_groups && workout.target_muscle_groups.length > 0 && (
          <Badge variant="outline" className="bg-accent/20 text-accent border-accent/30">
            {workout.target_muscle_groups.join(', ')}
          </Badge>
        )}
        {workout.is_public && (
          <Badge variant="outline" className="bg-success/20 text-success border-success/30">
            <Eye className="w-3 h-3 mr-1" />
            Público
          </Badge>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3">
        <div className="flex items-center gap-2 text-txt-2">
          <Target className="w-4 h-4 flex-shrink-0" />
          <span className="text-xs md:text-sm truncate">{workout.focus}</span>
        </div>
        <div className="flex items-center gap-2 text-txt-2">
          <Clock className="w-4 h-4 flex-shrink-0" />
          <span className="text-xs md:text-sm truncate">~{workout.estimated_duration || 0}min</span>
        </div>
      </div>

      {/* Video Player */}
      {workout.video_url && (
        <div className="mt-4 pt-4 border-t border-line/30">
          <p className="text-xs text-txt-3 mb-2">Preview do Treino:</p>
          <WorkoutVideoPlayer 
            videoUrl={workout.video_url}
            className="rounded-lg"
            controls
          />
        </div>
      )}

      {/* Tags */}
      {workout.tags && workout.tags.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1">
          {workout.tags.slice(0, 3).map(tag => (
            <Badge key={tag} variant="outline" className="text-xs bg-accent/5 text-accent border-accent/20">
              #{tag}
            </Badge>
          ))}
          {workout.tags.length > 3 && (
            <Badge variant="outline" className="text-xs bg-surface/50 text-txt-3 border-line/20">
              +{workout.tags.length - 3}
            </Badge>
          )}
        </div>
      )}

      {/* Status */}
      {!workout.is_public && (
        <div className="mt-4 pt-4 border-t border-line/30">
          <p className="text-xs text-txt-3 text-center">
            Este treino está privado e não aparece para os usuários
          </p>
        </div>
      )}
    </Card>
  );
};