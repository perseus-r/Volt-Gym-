import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { Users, Activity, TrendingUp, Calendar } from 'lucide-react';
import { LineChart, Line, PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Skeleton } from '@/components/ui/skeleton';
import { Package } from 'lucide-react';

interface AnalyticsStats {
  totalUsers: number;
  activeUsers7d: number;
  activeUsers30d: number;
  avgSessionDuration: number;
  newUsersToday: number;
}

interface ActivityDataPoint {
  date: string;
  logins: number;
  newUsers: number;
}

interface PlanDistribution {
  name: string;
  value: number;
}

const AdminAnalyticsDashboard = () => {
  const [stats, setStats] = useState<AnalyticsStats | null>(null);
  const [activityData, setActivityData] = useState<ActivityDataPoint[]>([]);
  const [planData, setPlanData] = useState<PlanDistribution[]>([]);
  const [productStats, setProductStats] = useState({
    total: 0,
    active: 0,
    featured: 0,
    lowStock: 0,
    totalValue: 0
  });
  const [loading, setLoading] = useState(true);

  const loadStats = async () => {
    try {
      setLoading(true);

      // Total users
      const { count: totalUsers } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true });

      // Active users
      const { data: analytics } = await supabase
        .from('user_analytics')
        .select('logins_last_7_days, logins_last_30_days, avg_session_duration_minutes');

      const activeUsers7d = analytics?.filter(a => (a.logins_last_7_days || 0) > 0).length || 0;
      const activeUsers30d = analytics?.filter(a => (a.logins_last_30_days || 0) > 0).length || 0;
      const avgDuration = analytics?.reduce((acc, a) => acc + (a.avg_session_duration_minutes || 0), 0) / (analytics?.length || 1);

      // New users today
      const today = new Date().toISOString().split('T')[0];
      const { count: newUsersToday } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true })
        .gte('created_at', today);

      setStats({
        totalUsers: totalUsers || 0,
        activeUsers7d,
        activeUsers30d,
        avgSessionDuration: Math.round(avgDuration || 0),
        newUsersToday: newUsersToday || 0
      });

      // Load activity data (last 30 days)
      await loadActivityData();
      await loadPlanDistribution();
    } catch (error) {
      console.error('Error loading analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadActivityData = async () => {
    try {
      // Get profiles created in last 30 days grouped by date
      const { data: profiles } = await supabase
        .from('profiles')
        .select('created_at')
        .gte('created_at', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString())
        .order('created_at', { ascending: true });

      // Group by date
      const dateMap = new Map<string, { newUsers: number, logins: number }>();
      
      profiles?.forEach(p => {
        const date = new Date(p.created_at).toISOString().split('T')[0];
        const current = dateMap.get(date) || { newUsers: 0, logins: 0 };
        dateMap.set(date, { ...current, newUsers: current.newUsers + 1 });
      });

      const chartData: ActivityDataPoint[] = Array.from(dateMap.entries())
        .map(([date, data]) => ({
          date: new Date(date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }),
          logins: data.logins,
          newUsers: data.newUsers
        }))
        .slice(-14); // Last 14 days

      setActivityData(chartData);
    } catch (error) {
      console.error('Error loading activity data:', error);
    }
  };

  const loadPlanDistribution = async () => {
    try {
      const { data: subscriptions } = await supabase
        .from('subscriptions')
        .select('plan_id, status');

      const { count: totalProfiles } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true });

      const activeSubscriptions = subscriptions?.filter(s => s.status === 'active') || [];
      const proCount = activeSubscriptions.filter(s => s.plan_id?.includes('pro') && !s.plan_id?.includes('premium')).length;
      const premiumCount = activeSubscriptions.filter(s => s.plan_id?.includes('premium')).length;
      const freeCount = (totalProfiles || 0) - proCount - premiumCount;

      setPlanData([
        { name: 'Free', value: freeCount },
        { name: 'Pro', value: proCount },
        { name: 'Premium', value: premiumCount }
      ]);
    } catch (error) {
      console.error('Error loading plan distribution:', error);
    }
  };

  useEffect(() => {
    loadStats();
    loadProductStats();
  }, []);

  const loadProductStats = async () => {
    try {
      const { data: products } = await supabase
        .from('products')
        .select('*');

      if (products) {
        const stats = {
          total: products.length,
          active: products.filter(p => p.is_active).length,
          featured: products.filter(p => p.featured).length,
          lowStock: products.filter(p => p.stock_quantity < 10).length,
          totalValue: products.reduce((sum, p) => sum + (p.price * p.stock_quantity), 0)
        };
        setProductStats(stats);
      }
    } catch (error) {
      console.error('Erro ao carregar stats de produtos:', error);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          {[...Array(5)].map((_, i) => (
            <Card key={i} className="glass-card p-4">
              <Skeleton className="h-20 w-full" />
            </Card>
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="glass-card p-6">
            <Skeleton className="h-64 w-full" />
          </Card>
          <Card className="glass-card p-6">
            <Skeleton className="h-64 w-full" />
          </Card>
        </div>
      </div>
    );
  }

  const COLORS = ['hsl(var(--muted))', 'hsl(var(--accent))', 'hsl(var(--purple-400))'];

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card className="glass-card p-4">
          <div className="flex items-center gap-3">
            <Users className="w-8 h-8 text-accent" />
            <div>
              <p className="text-text-2 text-sm">Total Usuários</p>
              <p className="text-2xl font-bold text-white">{stats?.totalUsers || 0}</p>
            </div>
          </div>
        </Card>

        <Card className="glass-card p-4">
          <div className="flex items-center gap-3">
            <Activity className="w-8 h-8 text-green-400" />
            <div>
              <p className="text-text-2 text-sm">Ativos (7d)</p>
              <p className="text-2xl font-bold text-white">{stats?.activeUsers7d || 0}</p>
            </div>
          </div>
        </Card>

        <Card className="glass-card p-4">
          <div className="flex items-center gap-3">
            <Activity className="w-8 h-8 text-blue-400" />
            <div>
              <p className="text-text-2 text-sm">Ativos (30d)</p>
              <p className="text-2xl font-bold text-white">{stats?.activeUsers30d || 0}</p>
            </div>
          </div>
        </Card>

        <Card className="glass-card p-4">
          <div className="flex items-center gap-3">
            <TrendingUp className="w-8 h-8 text-accent" />
            <div>
              <p className="text-text-2 text-sm">Sessão Média</p>
              <p className="text-2xl font-bold text-white">{stats?.avgSessionDuration || 0}min</p>
            </div>
          </div>
        </Card>

        <Card className="glass-card p-4">
          <div className="flex items-center gap-3">
            <Calendar className="w-8 h-8 text-purple-400" />
            <div>
              <p className="text-text-2 text-sm">Novos Hoje</p>
              <p className="text-2xl font-bold text-white">{stats?.newUsersToday || 0}</p>
            </div>
          </div>
        </Card>

        <Card className="glass-card p-4">
          <div className="flex items-center gap-3">
            <Package className="w-8 h-8 text-orange-400" />
            <div>
              <p className="text-text-2 text-sm">Produtos na Loja</p>
              <p className="text-2xl font-bold text-white">{productStats.total}</p>
              <p className="text-xs text-text-2">{productStats.active} ativos</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Activity Chart */}
        <Card className="glass-card p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Novos Usuários (14 dias)</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={activityData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="date" stroke="hsl(var(--text-2))" />
              <YAxis stroke="hsl(var(--text-2))" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--card))', 
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px'
                }}
              />
              <Bar dataKey="newUsers" fill="hsl(var(--accent))" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Plan Distribution */}
        <Card className="glass-card p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Distribuição de Planos</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={planData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) => `${name}: ${value}`}
                outerRadius={80}
                fill="hsl(var(--accent))"
                dataKey="value"
              >
                {planData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--card))', 
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '8px'
                }}
              />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>
    </div>
  );
};

export default AdminAnalyticsDashboard;
