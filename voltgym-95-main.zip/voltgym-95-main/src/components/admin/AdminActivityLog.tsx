import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Search, Eye, Shield, UserCog, FileText } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface AdminAction {
  id: string;
  admin_id: string;
  action_type: string;
  target_user_id: string | null;
  details: any;
  created_at: string;
  ip_address?: string;
  user_agent?: string;
  admin_email?: string;
  target_user_email?: string;
}

const AdminActivityLog = () => {
  const [actions, setActions] = useState<AdminAction[]>([]);
  const [filteredActions, setFilteredActions] = useState<AdminAction[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [actionTypeFilter, setActionTypeFilter] = useState('all');
  const [selectedAction, setSelectedAction] = useState<AdminAction | null>(null);
  const [page, setPage] = useState(1);
  const itemsPerPage = 25;

  const loadActions = async () => {
    try {
      setLoading(true);

      // Buscar ações admin
      const { data: actionsData } = await supabase
        .from('admin_actions')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(500);

      if (!actionsData) {
        setLoading(false);
        return;
      }

      // Buscar emails dos admins e usuários alvo
      const adminIds = [...new Set(actionsData.map(a => a.admin_id))];
      const targetUserIds = [...new Set(actionsData.filter(a => a.target_user_id).map(a => a.target_user_id))];

      const { data: adminUsers } = await supabase.functions.invoke('admin-get-users', {
        body: { userIds: adminIds }
      });

      const { data: targetUsers } = await supabase.functions.invoke('admin-get-users', {
        body: { userIds: targetUserIds }
      });

      // Merge emails
      const enrichedActions: AdminAction[] = actionsData.map(action => ({
        ...action,
        ip_address: action.ip_address as string | undefined,
        user_agent: action.user_agent as string | undefined,
        admin_email: adminUsers?.find((u: any) => u.id === action.admin_id)?.email || 'N/A',
        target_user_email: targetUsers?.find((u: any) => u.id === action.target_user_id)?.email || 'N/A'
      }));

      setActions(enrichedActions);
      setFilteredActions(enrichedActions);
    } catch (error) {
      console.error('Error loading admin actions:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadActions();
  }, []);

  useEffect(() => {
    let filtered = actions;

    if (searchTerm) {
      filtered = filtered.filter(action =>
        action.admin_email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        action.target_user_email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        action.action_type?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (actionTypeFilter !== 'all') {
      filtered = filtered.filter(action => action.action_type === actionTypeFilter);
    }

    setFilteredActions(filtered);
    setPage(1);
  }, [actions, searchTerm, actionTypeFilter]);

  const getActionIcon = (type: string) => {
    switch (type) {
      case 'grant_role': return <UserCog className="w-4 h-4 text-blue-400" />;
      case 'update_plan': return <Shield className="w-4 h-4 text-accent" />;
      default: return <FileText className="w-4 h-4 text-text-2" />;
    }
  };

  const getActionLabel = (type: string) => {
    switch (type) {
      case 'grant_role': return 'Alterou Role';
      case 'update_plan': return 'Alterou Plano';
      default: return type;
    }
  };

  const paginatedActions = filteredActions.slice((page - 1) * itemsPerPage, page * itemsPerPage);
  const totalPages = Math.ceil(filteredActions.length / itemsPerPage);

  return (
    <div className="space-y-6">
      {/* Filters */}
      <Card className="glass-card p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-2" />
            <Input
              placeholder="Buscar por admin, usuário ou ação..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 glass-input"
            />
          </div>

          <Select value={actionTypeFilter} onValueChange={setActionTypeFilter}>
            <SelectTrigger className="glass-input">
              <SelectValue placeholder="Filtrar por tipo de ação" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas as ações</SelectItem>
              <SelectItem value="grant_role">Alteração de Role</SelectItem>
              <SelectItem value="update_plan">Alteração de Plano</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Actions Table */}
      <Card className="glass-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left p-4 text-text-2 font-medium">Data</th>
                <th className="text-left p-4 text-text-2 font-medium">Admin</th>
                <th className="text-left p-4 text-text-2 font-medium">Ação</th>
                <th className="text-left p-4 text-text-2 font-medium">Usuário Alvo</th>
                <th className="text-left p-4 text-text-2 font-medium">Detalhes</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={5} className="text-center p-8 text-text-2">
                    Carregando histórico...
                  </td>
                </tr>
              ) : paginatedActions.length === 0 ? (
                <tr>
                  <td colSpan={5} className="text-center p-8 text-text-2">
                    Nenhuma ação encontrada
                  </td>
                </tr>
              ) : (
                paginatedActions.map((action) => (
                  <tr key={action.id} className="border-b border-white/5 hover:bg-white/5">
                    <td className="p-4">
                      <span className="text-text-2 text-sm">
                        {format(new Date(action.created_at), "dd/MM/yyyy HH:mm", { locale: ptBR })}
                      </span>
                    </td>
                    <td className="p-4">
                      <span className="text-white text-sm">{action.admin_email}</span>
                    </td>
                    <td className="p-4">
                      <Badge variant="outline" className="flex items-center gap-2 w-fit">
                        {getActionIcon(action.action_type)}
                        {getActionLabel(action.action_type)}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <span className="text-text-2 text-sm">{action.target_user_email || 'N/A'}</span>
                    </td>
                    <td className="p-4">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setSelectedAction(action)}
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        Ver Detalhes
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between p-4 border-t border-white/10">
            <p className="text-text-2 text-sm">
              Mostrando {((page - 1) * itemsPerPage) + 1} - {Math.min(page * itemsPerPage, filteredActions.length)} de {filteredActions.length}
            </p>
            <div className="flex gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1}
              >
                Anterior
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
              >
                Próximo
              </Button>
            </div>
          </div>
        )}
      </Card>

      {/* Details Modal */}
      <Dialog open={!!selectedAction} onOpenChange={() => setSelectedAction(null)}>
        <DialogContent className="glass-card max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-white">Detalhes da Ação</DialogTitle>
            <DialogDescription className="text-text-2">
              Informações completas sobre a ação administrativa
            </DialogDescription>
          </DialogHeader>
          
          {selectedAction && (
            <div className="space-y-4">
              <div>
                <p className="text-text-2 text-sm">Data/Hora</p>
                <p className="text-white font-medium">
                  {format(new Date(selectedAction.created_at), "dd/MM/yyyy 'às' HH:mm:ss", { locale: ptBR })}
                </p>
              </div>

              <div>
                <p className="text-text-2 text-sm">Admin Responsável</p>
                <p className="text-white font-medium">{selectedAction.admin_email}</p>
              </div>

              {selectedAction.target_user_email && (
                <div>
                  <p className="text-text-2 text-sm">Usuário Afetado</p>
                  <p className="text-white font-medium">{selectedAction.target_user_email}</p>
                </div>
              )}

              <div>
                <p className="text-text-2 text-sm">Tipo de Ação</p>
                <Badge variant="outline" className="mt-1">
                  {getActionLabel(selectedAction.action_type)}
                </Badge>
              </div>

              {selectedAction.ip_address && (
                <div>
                  <p className="text-text-2 text-sm">IP Address</p>
                  <p className="text-white font-mono text-sm">{selectedAction.ip_address}</p>
                </div>
              )}

              <div>
                <p className="text-text-2 text-sm mb-2">Detalhes Completos (JSON)</p>
                <pre className="bg-black/40 p-4 rounded-lg text-xs text-text-2 overflow-auto max-h-64">
                  {JSON.stringify(selectedAction.details, null, 2)}
                </pre>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminActivityLog;
