import { useMemo } from 'react';
import { UserWorkoutData } from '@/hooks/useUserWorkouts';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { AlertTriangle, CheckCircle, TrendingUp } from 'lucide-react';
import { VoltCard } from '@/components/VoltCard';

interface MuscleBalanceAnalysisProps {
  workouts: UserWorkoutData[];
}

export function MuscleBalanceAnalysis({ workouts }: MuscleBalanceAnalysisProps) {
  const muscleDistribution = useMemo(() => {
    const distribution: Record<string, number> = {
      'Peito': 0,
      'Costas': 0,
      'Ombros': 0,
      'Pernas': 0,
      'Bíceps': 0,
      'Tríceps': 0,
      'Core': 0,
    };

    workouts.forEach(workout => {
      const focus = workout.focus.toLowerCase();
      
      if (focus.includes('peito') || focus.includes('chest')) distribution['Peito']++;
      if (focus.includes('costas') || focus.includes('back')) distribution['Costas']++;
      if (focus.includes('ombro') || focus.includes('shoulder')) distribution['Ombros']++;
      if (focus.includes('perna') || focus.includes('leg') || focus.includes('inferior')) distribution['Pernas']++;
      if (focus.includes('bíceps') || focus.includes('bicep')) distribution['Bíceps']++;
      if (focus.includes('tríceps') || focus.includes('tricep')) distribution['Tríceps']++;
      if (focus.includes('core') || focus.includes('abdominal')) distribution['Core']++;
    });

    return Object.entries(distribution)
      .filter(([_, count]) => count > 0)
      .map(([name, value]) => ({ name, value }));
  }, [workouts]);

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d', '#ffc658'];

  const balanceScore = useMemo(() => {
    if (muscleDistribution.length === 0) return 0;
    
    const total = muscleDistribution.reduce((sum, item) => sum + item.value, 0);
    const avg = total / muscleDistribution.length;
    const variance = muscleDistribution.reduce((sum, item) => 
      sum + Math.pow(item.value - avg, 2), 0
    ) / muscleDistribution.length;
    
    const maxVariance = Math.pow(avg, 2);
    const score = Math.max(0, 100 - (variance / maxVariance) * 100);
    
    return Math.round(score);
  }, [muscleDistribution]);

  const neglectedMuscles = useMemo(() => {
    if (muscleDistribution.length === 0) return [];
    
    const total = muscleDistribution.reduce((sum, item) => sum + item.value, 0);
    const threshold = total / muscleDistribution.length * 0.5;
    
    return muscleDistribution.filter(item => item.value < threshold);
  }, [muscleDistribution]);

  return (
    <div className="space-y-6">
      {/* Balance Score */}
      <VoltCard className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-txt">Score de Balanceamento</h3>
          <div className="flex items-center gap-2">
            {balanceScore >= 70 ? (
              <CheckCircle className="w-5 h-5 text-green-500" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-yellow-500" />
            )}
            <span className="text-2xl font-bold text-accent">{balanceScore}%</span>
          </div>
        </div>
        <div className="w-full bg-surface/50 rounded-full h-3">
          <div 
            className="h-3 rounded-full bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 transition-all"
            style={{ width: `${balanceScore}%` }}
          />
        </div>
        <p className="text-sm text-txt-3 mt-2">
          {balanceScore >= 70 
            ? '✓ Seu treino está bem balanceado!' 
            : 'Alguns grupos musculares precisam de mais atenção'
          }
        </p>
      </VoltCard>

      {/* Distribution Chart */}
      {muscleDistribution.length > 0 && (
        <VoltCard className="p-6">
          <h3 className="text-lg font-semibold text-txt mb-4">Distribuição por Grupo Muscular</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={muscleDistribution}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {muscleDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </VoltCard>
      )}

      {/* Neglected Muscles Warning */}
      {neglectedMuscles.length > 0 && (
        <VoltCard className="p-6 border-yellow-500/50">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-yellow-500 mt-0.5" />
            <div>
              <h4 className="font-semibold text-txt mb-2">Músculos Negligenciados</h4>
              <p className="text-sm text-txt-2 mb-3">
                Estes grupos musculares estão sendo treinados com menos frequência:
              </p>
              <ul className="space-y-1">
                {neglectedMuscles.map(muscle => (
                  <li key={muscle.name} className="text-sm text-txt-3">
                    • {muscle.name} ({muscle.value} treinos)
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </VoltCard>
      )}
    </div>
  );
}