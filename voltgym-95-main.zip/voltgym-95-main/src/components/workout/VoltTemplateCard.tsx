import React from 'react';
import { cn } from '@/lib/utils';
import { Clock, Dumbbell } from 'lucide-react';
import { VoltBadge } from '@/components/VoltBadge';
import { motion } from 'framer-motion';

interface VoltTemplateCardProps {
  name: string;
  exerciseCount: number;
  category?: string;
  difficulty?: 'beginner' | 'intermediate' | 'advanced';
  estimatedDuration?: number;
  onClick?: () => void;
  className?: string;
}

const DIFFICULTY_LABELS: Record<string, string> = {
  beginner: 'Iniciante',
  intermediate: 'Intermediário',
  advanced: 'Avançado',
};

const DIFFICULTY_LEVELS: Record<string, number> = {
  beginner: 1,
  intermediate: 2,
  advanced: 3,
};

export const VoltTemplateCard: React.FC<VoltTemplateCardProps> = ({
  name,
  exerciseCount,
  category,
  difficulty = 'intermediate',
  estimatedDuration,
  onClick,
  className,
}) => {
  const duration = estimatedDuration || Math.round(exerciseCount * 5);
  const level = DIFFICULTY_LEVELS[difficulty] || 2;

  return (
    <motion.div
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={cn(
        'relative overflow-hidden rounded-2xl cursor-pointer',
        'bg-zinc-950/90 border border-white/[0.08]',
        'p-5 transition-all duration-200',
        'hover:border-white/15 hover:bg-zinc-900/90',
        'active:bg-zinc-900',
        className
      )}
    >
      {/* VOLT Badge */}
      <div className="absolute top-4 left-4">
        <VoltBadge size="sm" showGlow />
      </div>

      {/* Content */}
      <div className="pt-10">
        {/* Category subtitle */}
        {category && (
          <p className="text-xs text-white/40 uppercase tracking-wider mb-1.5">
            {category}
          </p>
        )}

        {/* Title */}
        <h3 className="text-xl font-bold text-white tracking-tight mb-4 leading-tight">
          {name}
        </h3>

        {/* Stats Row */}
        <div className="flex items-center gap-3">
          {/* Duration chip */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/[0.06] border border-white/[0.04]">
            <Clock className="w-3.5 h-3.5 text-white/50" />
            <span className="text-xs font-medium text-white/70">{duration}min</span>
          </div>

          {/* Exercise count chip */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/[0.06] border border-white/[0.04]">
            <Dumbbell className="w-3.5 h-3.5 text-white/50" />
            <span className="text-xs font-medium text-white/70">{exerciseCount} exercícios</span>
          </div>

          {/* Difficulty chip */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/[0.06] border border-white/[0.04]">
            <div className="flex gap-0.5">
              {[1, 2, 3].map((i) => (
                <div
                  key={i}
                  className={cn(
                    'w-1 h-2.5 rounded-sm transition-colors',
                    i <= level ? 'bg-white/70' : 'bg-white/20'
                  )}
                />
              ))}
            </div>
            <span className="text-xs font-medium text-white/70">
              {DIFFICULTY_LABELS[difficulty] || 'Intermediário'}
            </span>
          </div>
        </div>
      </div>

    </motion.div>
  );
};

export default VoltTemplateCard;
