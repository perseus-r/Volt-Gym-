import { motion } from 'framer-motion';
import { Plus, Check, Dumbbell, Play } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ExerciseCardProps {
  name: string;
  group: string;
  isSelected: boolean;
  onToggle: () => void;
  index: number;
  thumbnailUrl?: string;
}

export function ExerciseCard({ name, group, isSelected, onToggle, index, thumbnailUrl }: ExerciseCardProps) {
  return (
    <motion.button
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05, duration: 0.3 }}
      onClick={onToggle}
      className={cn(
        "relative w-full rounded-xl text-left transition-all duration-300",
        "border-2 backdrop-blur-md overflow-hidden group",
        isSelected
          ? "border-primary bg-primary/10 shadow-[0_0_20px_rgba(var(--primary),0.3)]"
          : "border-border/30 bg-secondary/30 hover:border-primary/50 hover:bg-secondary/50"
      )}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
    >
      {/* Thumbnail */}
      {thumbnailUrl && (
        <div className="relative w-full h-24 overflow-hidden">
          <img 
            src={thumbnailUrl} 
            alt={name}
            className="w-full h-full object-cover"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
          <div className="absolute bottom-2 left-2 bg-background/60 backdrop-blur-sm rounded-full p-1.5">
            <Play className="w-3 h-3 text-primary" />
          </div>
        </div>
      )}

      {/* Content */}
      <div className={cn("relative z-10 flex items-center justify-between p-4", !thumbnailUrl && "py-4")}>
        <div className="flex items-center gap-3">
          {!thumbnailUrl && (
            <div className={cn(
              "w-10 h-10 rounded-lg flex items-center justify-center transition-colors",
              isSelected ? "bg-primary/20" : "bg-primary/10"
            )}>
              <Dumbbell className={cn(
                "w-5 h-5 transition-colors",
                isSelected ? "text-primary" : "text-primary/60"
              )} />
            </div>
          )}
          
          <div>
            <h4 className={cn(
              "font-semibold transition-colors line-clamp-1",
              isSelected ? "text-primary" : "text-foreground"
            )}>
              {name}
            </h4>
            <p className="text-sm text-muted-foreground">{group}</p>
          </div>
        </div>
        
        {/* Toggle Icon */}
        <motion.div
          animate={{ 
            scale: isSelected ? [1, 1.2, 1] : 1,
            rotate: isSelected ? [0, 10, 0] : 0
          }}
          transition={{ duration: 0.3 }}
          className={cn(
            "w-8 h-8 rounded-full flex items-center justify-center transition-colors flex-shrink-0",
            isSelected
              ? "bg-primary text-primary-foreground"
              : "bg-secondary border-2 border-border text-muted-foreground group-hover:border-primary/50"
          )}
        >
          {isSelected ? (
            <Check className="w-4 h-4" />
          ) : (
            <Plus className="w-4 h-4" />
          )}
        </motion.div>
      </div>
    </motion.button>
  );
}
