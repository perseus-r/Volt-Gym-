import { motion } from 'framer-motion';
import { Dumbbell, Sparkles, Search, Filter } from 'lucide-react';
import { VoltButton } from '@/components/VoltButton';

interface WorkoutEmptyStateProps {
  type: 'search' | 'filter' | 'initial';
  searchQuery?: string;
  onClearSearch?: () => void;
  onCreateWorkout?: () => void;
}

export function WorkoutEmptyState({
  type,
  searchQuery,
  onClearSearch,
  onCreateWorkout
}: WorkoutEmptyStateProps) {
  const config = {
    search: {
      icon: Search,
      title: 'Nenhum treino encontrado',
      description: searchQuery ? `Não encontramos treinos com "${searchQuery}"` : 'Tente ajustar sua busca',
      actionLabel: 'Limpar busca',
      onAction: onClearSearch
    },
    filter: {
      icon: Filter,
      title: 'Nenhum treino nesta categoria',
      description: 'Tente selecionar outro filtro ou criar um novo treino',
      actionLabel: 'Ver todos',
      onAction: onClearSearch
    },
    initial: {
      icon: Sparkles,
      title: 'Comece sua jornada',
      description: 'Crie seu primeiro treino personalizado ou use um template rápido',
      actionLabel: 'Criar treino',
      onAction: onCreateWorkout
    }
  }[type];

  const Icon = config.icon;
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="flex flex-col items-center justify-center py-16 px-6"
    >
      {/* Animated Icon */}
      <motion.div
        animate={{ 
          rotate: [0, -10, 10, -10, 0],
          scale: [1, 1.1, 1]
        }}
        transition={{ 
          duration: 2,
          repeat: Infinity,
          repeatDelay: 3
        }}
        className="relative mb-6"
      >
        {/* Glow Effect */}
        <div className="absolute inset-0 bg-accent/20 blur-3xl rounded-full" />
        
        {/* Icon Container */}
        <div className="relative w-24 h-24 rounded-3xl bg-gradient-to-br from-accent/20 to-accent-2/20 border-2 border-accent/30 flex items-center justify-center">
          <Icon className="w-12 h-12 text-accent" />
          
          {/* Floating Sparkles */}
          <motion.div
            animate={{ 
              x: [0, 10, 0],
              y: [0, -10, 0],
              opacity: [0, 1, 0]
            }}
            transition={{ 
              duration: 2,
              repeat: Infinity,
              delay: 0.5
            }}
            className="absolute -top-2 -right-2"
          >
            <Sparkles className="w-5 h-5 text-accent" />
          </motion.div>
        </div>
      </motion.div>

      {/* Text */}
      <h3 className="text-2xl font-bold text-txt mb-2">
        {config.title}
      </h3>
      <p className="text-txt-2 text-center max-w-md mb-8">
        {config.description}
      </p>

      {/* Action Button */}
      {config.onAction && (
        <VoltButton
          variant="primary"
          size="lg"
          onClick={config.onAction}
          className="shadow-[0_10px_40px_rgba(0,191,255,0.3)]"
        >
          <Sparkles className="w-5 h-5 mr-2" />
          {config.actionLabel}
        </VoltButton>
      )}

      {/* Decorative Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-accent/20 rounded-full"
            animate={{
              x: [0, Math.random() * 200 - 100],
              y: [0, Math.random() * 200 - 100],
              opacity: [0, 0.5, 0],
              scale: [0, 1, 0]
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
            style={{
              left: `${20 + Math.random() * 60}%`,
              top: `${20 + Math.random() * 60}%`,
            }}
          />
        ))}
      </div>
    </motion.div>
  );
}
