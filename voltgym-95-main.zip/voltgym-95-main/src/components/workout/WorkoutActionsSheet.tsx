import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Play, Star, Share2, CalendarPlus, Trash2, Pencil } from 'lucide-react';
import { UserWorkoutData } from '@/hooks/useUserWorkouts';
import { Separator } from '@/components/ui/separator';

interface WorkoutActionsSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  workout: UserWorkoutData;
  isFavorite: boolean;
  onStart: () => void;
  onToggleFavorite: () => void;
  onShare: () => void;
  onAddToRoutine: () => void;
  onRename?: () => void;
  onDelete: () => void;
}

export function WorkoutActionsSheet({
  open,
  onOpenChange,
  workout,
  isFavorite,
  onStart,
  onToggleFavorite,
  onShare,
  onAddToRoutine,
  onRename,
  onDelete,
}: WorkoutActionsSheetProps) {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="h-auto rounded-t-3xl">
        <SheetHeader>
          <SheetTitle className="text-left">{workout.name}</SheetTitle>
        </SheetHeader>

        <div className="space-y-2 py-4">
          {/* Ação Primária */}
          <Button
            onClick={onStart}
            className="w-full justify-start h-14 text-lg"
            variant="default"
          >
            <Play className="w-5 h-5 mr-3" />
            Iniciar Treino
          </Button>

          <Separator className="my-2" />

          {/* Ações Secundárias */}
          <Button
            onClick={onToggleFavorite}
            className="w-full justify-start h-12"
            variant="ghost"
          >
            <Star className={`w-5 h-5 mr-3 ${isFavorite ? 'fill-yellow-500 text-yellow-500' : ''}`} />
            {isFavorite ? 'Remover dos Favoritos' : 'Adicionar aos Favoritos'}
          </Button>

          {onRename && (
            <Button
              onClick={onRename}
              className="w-full justify-start h-12"
              variant="ghost"
            >
              <Pencil className="w-5 h-5 mr-3" />
              Renomear
            </Button>
          )}

          <Button
            onClick={onShare}
            className="w-full justify-start h-12"
            variant="ghost"
          >
            <Share2 className="w-5 h-5 mr-3" />
            Compartilhar
          </Button>

          <Button
            onClick={onAddToRoutine}
            className="w-full justify-start h-12"
            variant="ghost"
          >
            <CalendarPlus className="w-5 h-5 mr-3" />
            Adicionar à Rotina
          </Button>

          <Separator className="my-2" />

          {/* Ação Destrutiva */}
          <Button
            onClick={onDelete}
            className="w-full justify-start h-12 text-error hover:text-error hover:bg-error/10"
            variant="ghost"
          >
            <Trash2 className="w-5 h-5 mr-3" />
            Excluir
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
