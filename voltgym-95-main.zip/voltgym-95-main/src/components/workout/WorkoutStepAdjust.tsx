import { VoltCard } from '@/components/VoltCard';
import { VoltButton } from '@/components/VoltButton';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Stagger, Item } from '@/components/animations/Stagger';
import { WorkoutExercise } from '@/types/workout.unified';
import { ArrowLeftRight } from 'lucide-react';

interface WorkoutStepAdjustProps {
  selectedExercises: WorkoutExercise[];
  setSelectedExercises: (exercises: WorkoutExercise[]) => void;
  onNext: () => void;
  onPrev: () => void;
}

export function WorkoutStepAdjust({
  selectedExercises,
  setSelectedExercises,
  onNext,
  onPrev,
}: WorkoutStepAdjustProps) {
  const updateExercise = (id: string, field: keyof WorkoutExercise, value: any) => {
    setSelectedExercises(
      selectedExercises.map((ex) =>
        ex.id === id ? { ...ex, [field]: value } : ex
      )
    );
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h3 className="text-xl font-bold text-txt">Ajuste Fino dos Exercícios</h3>
        <p className="text-txt-2 mt-1">Configure séries, reps, carga e descanso</p>
      </div>

      <Stagger className="space-y-4">
        {selectedExercises.map((exercise, index) => (
          <Item key={exercise.id}>
            <VoltCard className="p-4">
              <div className="space-y-4">
                {/* Exercise Header */}
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-r from-accent to-accent-2 flex items-center justify-center text-accent-ink font-bold">
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-txt">{exercise.name}</h4>
                    <p className="text-xs text-txt-3">{exercise.group}</p>
                  </div>
                </div>

                {/* Inputs Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div>
                    <Label className="text-xs text-txt-3">Séries</Label>
                    <Input
                      type="number"
                      value={exercise.sets}
                      onChange={(e) =>
                        updateExercise(exercise.id, 'sets', parseInt(e.target.value) || 1)
                      }
                      min="1"
                      max="10"
                      className="mt-1"
                    />
                  </div>
                  
                  <div>
                    <Label className="text-xs text-txt-3">Reps</Label>
                    <Input
                      value={exercise.reps}
                      onChange={(e) => updateExercise(exercise.id, 'reps', e.target.value)}
                      placeholder="8-12"
                      className="mt-1"
                    />
                  </div>
                  
                  <div>
                    <Label className="text-xs text-txt-3">Carga (kg)</Label>
                    <Input
                      type="number"
                      value={exercise.weight}
                      onChange={(e) =>
                        updateExercise(exercise.id, 'weight', parseFloat(e.target.value) || 0)
                      }
                      min="0"
                      step="2.5"
                      className="mt-1"
                    />
                  </div>
                  
                  <div>
                    <Label className="text-xs text-txt-3">Descanso (s)</Label>
                    <Input
                      type="number"
                      value={exercise.rest}
                      onChange={(e) =>
                        updateExercise(exercise.id, 'rest', parseInt(e.target.value) || 30)
                      }
                      min="30"
                      max="300"
                      step="15"
                      className="mt-1"
                    />
                  </div>
                </div>

                {/* Unilateral Toggle */}
                <div className="flex items-center justify-between p-3 rounded-lg bg-card/50 border border-border/50">
                  <div className="flex items-center gap-2">
                    <ArrowLeftRight className="w-4 h-4 text-accent" />
                    <div>
                      <Label className="text-sm text-txt cursor-pointer">Exercício Unilateral</Label>
                      <p className="text-xs text-txt-3">Executa cada lado separadamente</p>
                    </div>
                  </div>
                  <Switch
                    checked={exercise.isUnilateral || false}
                    onCheckedChange={(checked) => updateExercise(exercise.id, 'isUnilateral', checked)}
                  />
                </div>

                {/* Notes */}
                <div>
                  <Label className="text-xs text-txt-3">Notas (opcional)</Label>
                  <Textarea
                    value={exercise.notes}
                    onChange={(e) => updateExercise(exercise.id, 'notes', e.target.value)}
                    placeholder="Ex: Drop set no final, atenção na forma..."
                    className="mt-1 resize-none"
                    rows={2}
                  />
                </div>
              </div>
            </VoltCard>
          </Item>
        ))}
      </Stagger>

      {/* Navigation */}
      <div className="flex items-center justify-between pt-4">
        <VoltButton variant="ghost" onClick={onPrev}>
          ← Voltar
        </VoltButton>
        
        <VoltButton onClick={onNext}>
          Próximo: Confirmar →
        </VoltButton>
      </div>
    </div>
  );
}
