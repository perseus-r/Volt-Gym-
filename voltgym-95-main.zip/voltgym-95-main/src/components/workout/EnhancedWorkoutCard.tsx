import { useState } from 'react';
import { motion } from 'framer-motion';
import { Clock, Target, Star, ChevronDown, Play, Trash2, MoreVertical, AlertCircle, Dumbbell } from 'lucide-react';
import { HoverCard } from '@/components/interactions/HoverCard';
import { WorkoutCardActions } from './WorkoutCardActions';
import { UserWorkoutData } from '@/hooks/useUserWorkouts';
import { SwipeableCard } from '@/components/SwipeableCard';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { useIsMobile } from '@/hooks/use-mobile';
import { cn } from '@/lib/utils';

interface EnhancedWorkoutCardProps {
  workout: UserWorkoutData;
  isFavorite?: boolean;
  onStart: () => void;
  onRename?: () => void;
  onDuplicate?: () => void;
  onToggleFavorite?: () => void;
  onShare?: () => void;
  onDelete?: () => void;
  onMoreActions?: () => void;
  className?: string;
}

export function EnhancedWorkoutCard({
  workout,
  isFavorite = false,
  onStart,
  onRename,
  onDuplicate,
  onToggleFavorite,
  onShare,
  onDelete,
  onMoreActions,
  className,
}: EnhancedWorkoutCardProps) {
  const isMobile = useIsMobile();
  const [showExercises, setShowExercises] = useState(false);

  const formatDate = (dateString?: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', { 
      day: '2-digit', 
      month: 'short',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Get workout color based on focus
  const getWorkoutColor = () => {
    const focus = workout.focus?.toLowerCase() || '';
    if (focus.includes('peito') || focus.includes('chest')) return 'blue';
    if (focus.includes('costas') || focus.includes('back')) return 'cyan';
    if (focus.includes('perna') || focus.includes('leg')) return 'orange';
    if (focus.includes('ombro') || focus.includes('shoulder')) return 'purple';
    if (focus.includes('braço') || focus.includes('arm')) return 'green';
    if (focus.includes('full') || focus.includes('corpo')) return 'red';
    return 'blue';
  };

  const colorStyles = {
    blue: 'from-blue-500/20 to-cyan-500/10 border-blue-500/25 shadow-blue-500/15',
    cyan: 'from-cyan-500/20 to-teal-500/10 border-cyan-500/25 shadow-cyan-500/15',
    orange: 'from-orange-500/20 to-amber-500/10 border-orange-500/25 shadow-orange-500/15',
    purple: 'from-purple-500/20 to-pink-500/10 border-purple-500/25 shadow-purple-500/15',
    green: 'from-green-500/20 to-emerald-500/10 border-green-500/25 shadow-green-500/15',
    red: 'from-red-500/20 to-rose-500/10 border-red-500/25 shadow-red-500/15',
  };

  const iconColors = {
    blue: 'from-blue-500 to-cyan-500 shadow-blue-500/40',
    cyan: 'from-cyan-500 to-teal-500 shadow-cyan-500/40',
    orange: 'from-orange-500 to-amber-500 shadow-orange-500/40',
    purple: 'from-purple-500 to-pink-500 shadow-purple-500/40',
    green: 'from-green-500 to-emerald-500 shadow-green-500/40',
    red: 'from-red-500 to-rose-500 shadow-red-500/40',
  };

  const color = getWorkoutColor();

  const cardContent = (
    <div className={cn(
      // iOS Widget glassmorphism - COMPACT
      "relative overflow-hidden",
      "bg-gradient-to-br",
      colorStyles[color],
      "backdrop-blur-2xl",
      "rounded-xl",
      "border",
      "shadow-lg",
      "p-3",
      className
    )}>
      {/* Shine effect on top */}
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/30 to-transparent" />
      
      {/* Favorite Badge */}
      {isFavorite && (
        <motion.div 
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="absolute top-4 right-4 z-10"
        >
          <div className="w-8 h-8 rounded-full bg-amber-500/20 backdrop-blur-xl flex items-center justify-center border border-amber-500/30">
            <Star className="w-4 h-4 fill-amber-500 text-amber-500" />
          </div>
        </motion.div>
      )}

      {/* Header with Icon - COMPACT */}
      <div className="flex items-start gap-3 mb-3">
        {/* Workout Icon - iOS App style - COMPACT */}
        <div className={cn(
          "w-10 h-10 rounded-xl",
          "bg-gradient-to-br",
          iconColors[color],
          "flex items-center justify-center",
          "shadow-lg",
          "flex-shrink-0"
        )}>
          <div className="absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/25 to-transparent rounded-t-xl" />
          <Dumbbell className="w-5 h-5 text-white relative z-10" strokeWidth={1.8} />
        </div>
        
        <div className="flex-1 min-w-0">
          <span className="text-[10px] font-semibold text-accent uppercase tracking-wider">
            {workout.focus}
          </span>
          
          <h3 className="text-sm font-bold text-txt mt-0.5 truncate pr-6">
            {workout.name}
          </h3>

          {workout.completed_at && (
            <p className="text-[10px] text-txt-3 mt-0.5">
              Último: {formatDate(workout.completed_at)}
            </p>
          )}
        </div>

        {/* More Actions Button */}
        {isMobile && onMoreActions && (
          <button
            type="button"
            aria-label="Mais opções"
            onClick={onMoreActions}
            className="p-2 -mr-2 -mt-1 rounded-xl text-txt-3 hover:text-txt hover:bg-white/10 active:scale-95 transition-all"
          >
            <MoreVertical className="w-5 h-5" />
          </button>
        )}
        
        {!isMobile && (
          <WorkoutCardActions
            workoutId={workout.id}
            isFavorite={isFavorite}
            onStart={onStart}
            onRename={onRename}
            onDuplicate={onDuplicate}
            onToggleFavorite={onToggleFavorite}
            onShare={onShare}
            onDelete={onDelete}
          />
        )}
      </div>

      {/* Stats Pills - COMPACT */}
      <div className="flex items-center gap-1.5 mb-3 flex-wrap">
        <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-white/[0.08] backdrop-blur-xl border border-white/10">
          <Target className="w-3 h-3 text-txt-2" />
          <span className="text-[10px] font-medium text-txt-2">{workout.exercises.length} exercícios</span>
        </div>
        <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-white/[0.08] backdrop-blur-xl border border-white/10">
          <Clock className="w-3 h-3 text-txt-2" />
          <span className="text-[10px] font-medium text-txt-2">~45min</span>
        </div>
      </div>

      {/* Warning for zero volume */}
      {(workout as any).total_volume === 0 && workout.completed_at && (
        <div className="mb-4 px-3 py-2 bg-amber-500/10 border border-amber-500/20 rounded-xl text-xs text-amber-400 flex items-center gap-2 backdrop-blur-xl">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <span>Volume não registrado</span>
        </div>
      )}

      {/* Exercises Preview - Collapsible */}
      {isMobile ? (
        <Collapsible open={showExercises} onOpenChange={setShowExercises}>
          <CollapsibleTrigger className="flex items-center justify-between w-full text-sm text-txt-3 mb-2 py-2 px-3 rounded-xl bg-white/[0.05] hover:bg-white/[0.08] transition-colors">
            <span>Ver {workout.exercises.length} exercícios</span>
            <ChevronDown className={cn(
              "w-4 h-4 transition-transform duration-200",
              showExercises && "rotate-180"
            )} />
          </CollapsibleTrigger>
          
          <CollapsibleContent className="space-y-2 mt-2">
            {workout.exercises.map((ex, idx) => (
              <motion.div 
                key={idx} 
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.05 }}
                className="flex items-center justify-between text-sm px-3 py-2 rounded-xl bg-white/[0.04]"
              >
                <span className="text-txt-2 truncate">{ex.name}</span>
                <span className="text-txt-3 text-xs ml-2 flex-shrink-0 font-medium">
                  {ex.sets || 3}x{ex.reps}
                </span>
              </motion.div>
            ))}
          </CollapsibleContent>
        </Collapsible>
      ) : (
        <div className="space-y-1.5">
          {workout.exercises.slice(0, 3).map((ex, idx) => (
            <div key={idx} className="flex items-center justify-between text-sm">
              <span className="text-txt-2 truncate">{ex.name}</span>
              <span className="text-txt-3 text-xs ml-2 flex-shrink-0">
                {ex.sets || 3}x{ex.reps}
              </span>
            </div>
          ))}
          {workout.exercises.length > 3 && (
            <p className="text-xs text-txt-3 mt-1">
              +{workout.exercises.length - 3} exercícios
            </p>
          )}
        </div>
      )}

      {/* Start Button - iOS Premium Style - COMPACT */}
      {isMobile && (
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.97 }}
          onClick={onStart}
          className={cn(
            "w-full mt-3 py-2.5 rounded-xl",
            "bg-gradient-to-br from-accent to-accent-2",
            "text-accent-ink font-semibold text-sm",
            "flex items-center justify-center gap-2",
            "shadow-lg shadow-accent/30",
            "border border-white/20",
            "relative overflow-hidden"
          )}
        >
          {/* Shine */}
          <div className="absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/20 to-transparent" />
          <Play className="w-4 h-4 relative z-10" fill="currentColor" />
          <span className="relative z-10">Iniciar</span>
        </motion.button>
      )}
    </div>
  );

  if (isMobile) {
    return (
      <SwipeableCard
        rightAction={onMoreActions ? {
          icon: <MoreVertical className="w-5 h-5 text-white" />,
          label: 'Mais opções',
          color: 'bg-accent',
          onAction: onMoreActions
        } : undefined}
        leftAction={onDelete ? {
          icon: <Trash2 className="w-5 h-5 text-white" />,
          label: 'Deletar',
          color: 'bg-red-500',
          onAction: onDelete
        } : undefined}
      >
        {cardContent}
      </SwipeableCard>
    );
  }

  return (
    <HoverCard depth={1} className="p-0">
      {cardContent}
    </HoverCard>
  );
}
