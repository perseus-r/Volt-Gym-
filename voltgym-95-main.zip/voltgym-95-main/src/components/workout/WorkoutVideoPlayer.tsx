import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import { AlertCircle, ExternalLink, Copy, RefreshCw } from 'lucide-react';
import { getYouTubeId, toEmbedUrl, getThumbnailUrl } from '@/utils/youtube';
import { VideoLoadingOverlay, PlayButton, VideoControls } from '@/components/video';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface WorkoutVideoPlayerProps {
  videoUrl: string;
  thumbnail?: string;
  className?: string;
  autoplay?: boolean;
  controls?: boolean;
  clickToPlay?: boolean;
}

interface VideoStatus {
  accessible: boolean;
  statusCode?: number;
  contentType?: string;
  errorMessage?: string;
}

function detectVideoType(url: string): 'youtube' | 'vimeo' | 'direct' {
  if (!url) return 'direct';
  if (url.includes('youtube.com') || url.includes('youtu.be')) return 'youtube';
  if (url.includes('vimeo.com')) return 'vimeo';
  return 'direct';
}

function extractVimeoId(url: string): string {
  const match = url.match(/vimeo\.com\/(\d+)/);
  return match ? match[1] : '';
}

export function WorkoutVideoPlayer({ 
  videoUrl, 
  thumbnail, 
  className, 
  autoplay = false, 
  controls = true,
  clickToPlay = true 
}: WorkoutVideoPlayerProps) {
  const [hasError, setHasError] = useState(false);
  const [videoError, setVideoError] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [videoStatus, setVideoStatus] = useState<VideoStatus | null>(null);
  const [isCheckingUrl, setIsCheckingUrl] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const videoType = detectVideoType(videoUrl);

  // Verificar se o arquivo de vídeo está acessível
  useEffect(() => {
    if (videoType !== 'direct' || !videoUrl) return;

    const checkVideoUrl = async () => {
      setIsCheckingUrl(true);
      try {
        const response = await fetch(videoUrl, { 
          method: 'HEAD',
          cache: 'no-cache'
        });
        
        const contentType = response.headers.get('content-type') || '';
        const isVideo = contentType.startsWith('video/');
        
        if (!response.ok) {
          const errorMessages: Record<number, string> = {
            404: 'Arquivo não encontrado (404)',
            403: 'Sem permissão de acesso (403)',
            500: 'Erro no servidor (500)',
          };
          setVideoStatus({
            accessible: false,
            statusCode: response.status,
            errorMessage: errorMessages[response.status] || `Erro HTTP ${response.status}`
          });
          setVideoError(errorMessages[response.status] || `Erro HTTP ${response.status}`);
          setHasError(true);
        } else if (!isVideo && contentType !== '') {
          setVideoStatus({
            accessible: false,
            contentType,
            errorMessage: `Tipo inesperado: ${contentType}`
          });
          setVideoError(`Arquivo não é um vídeo válido (${contentType})`);
          setHasError(true);
        } else {
          setVideoStatus({
            accessible: true,
            statusCode: response.status,
            contentType
          });
        }
      } catch (error) {
        // Erro de CORS ou rede - tentar carregar o vídeo direto
        console.log('HEAD request failed (CORS?), will try loading video directly');
        setVideoStatus({
          accessible: true, // Assume true, o player vai mostrar erro se falhar
          errorMessage: 'Verificação não suportada (CORS)'
        });
      } finally {
        setIsCheckingUrl(false);
      }
    };

    checkVideoUrl();
  }, [videoUrl, videoType]);

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(videoUrl);
    toast.success('Link copiado!');
  };

  const handleOpenInNewTab = () => {
    window.open(videoUrl, '_blank');
  };

  const handleRetry = () => {
    setHasError(false);
    setVideoError(null);
    setVideoStatus(null);
    // Force re-render by updating key
    if (videoRef.current) {
      videoRef.current.load();
    }
  };

  const getVideoMimeType = (url: string): string | undefined => {
    const ext = url.split('.').pop()?.split('?')[0]?.toLowerCase();
    const mimeTypes: Record<string, string> = {
      'mp4': 'video/mp4',
      'webm': 'video/webm',
      'mov': 'video/quicktime',
      'm4v': 'video/x-m4v',
      'ogg': 'video/ogg'
    };
    return ext ? mimeTypes[ext] : undefined;
  };

  // YouTube Player
  if (videoType === 'youtube') {
    const videoId = getYouTubeId(videoUrl);
    
    if (!videoId) {
      return (
        <div className={cn("w-full aspect-video rounded-2xl bg-muted/30 flex items-center justify-center", className)}>
          <p className="text-muted-foreground text-sm">URL do YouTube inválida</p>
        </div>
      );
    }

    // Click-to-play: show thumbnail until user clicks
    if (clickToPlay && !isPlaying) {
      const thumbnailUrl = getThumbnailUrl(videoId, 'hq');

      return (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className={cn(
            "relative w-full aspect-video rounded-2xl overflow-hidden cursor-pointer group bg-muted/30",
            className
          )}
          onClick={() => setIsPlaying(true)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === 'Enter' && setIsPlaying(true)}
          aria-label="Reproduzir vídeo"
        >
          <img
            src={thumbnailUrl}
            alt="Vídeo"
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
          
          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent transition-opacity duration-300 group-hover:opacity-80" />
          
          {/* Play button */}
          <div className="absolute inset-0 flex items-center justify-center">
            <PlayButton size="lg" />
          </div>

          {/* Bottom info */}
          <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
            <span className="text-xs text-white/80 bg-black/40 px-2 py-1 rounded backdrop-blur-sm">
              YouTube
            </span>
          </div>
        </motion.div>
      );
    }

    // Playing: render iframe
    const embedUrl = toEmbedUrl(videoId, { 
      nocookie: false, 
      autoplay: clickToPlay || autoplay 
    });
    
    return (
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className={cn("relative w-full aspect-video rounded-2xl overflow-hidden bg-muted/30", className)}
      >
        <iframe
          className="w-full h-full"
          src={embedUrl}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
        />
      </motion.div>
    );
  }

  // Vimeo Player
  if (videoType === 'vimeo') {
    const videoId = extractVimeoId(videoUrl);
    if (!videoId) {
      return (
        <div className={cn("w-full aspect-video rounded-2xl bg-muted/30 flex items-center justify-center", className)}>
          <p className="text-muted-foreground text-sm">URL do Vimeo inválida</p>
        </div>
      );
    }
    
    return (
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className={cn("relative w-full aspect-video rounded-2xl overflow-hidden bg-muted/30", className)}
      >
        <VideoLoadingOverlay isLoading={isLoading} />
        <iframe
          className="w-full h-full"
          src={`https://player.vimeo.com/video/${videoId}?autoplay=${autoplay ? 1 : 0}&playsinline=1`}
          allow="autoplay; fullscreen; picture-in-picture"
          allowFullScreen
          referrerPolicy="strict-origin-when-cross-origin"
          onLoad={() => setIsLoading(false)}
        />
      </motion.div>
    );
  }

  // HTML5 Video with custom controls
  const mimeType = getVideoMimeType(videoUrl);

  const handlePlayPause = () => {
    const video = videoRef.current;
    if (!video) return;

    if (video.paused) {
      video.play();
      setIsVideoPlaying(true);
    } else {
      video.pause();
      setIsVideoPlaying(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className={cn("relative w-full aspect-video rounded-2xl overflow-hidden bg-muted/30", className)}
    >
      {/* Loading overlay */}
      <VideoLoadingOverlay isLoading={isLoading || isCheckingUrl} />

      {/* Error state with detailed diagnostics */}
      <AnimatePresence>
        {(videoError || hasError) && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-muted/95 flex flex-col items-center justify-center p-4 z-20"
          >
            <AlertCircle className="w-10 h-10 text-destructive mb-3" />
            <p className="text-destructive text-sm text-center font-medium mb-1">
              {videoError || 'Erro ao carregar vídeo'}
            </p>
            {videoStatus?.contentType && (
              <p className="text-muted-foreground text-xs mb-3">
                Tipo: {videoStatus.contentType}
              </p>
            )}
            
            {/* Action buttons */}
            <div className="flex flex-wrap gap-2 mt-2 justify-center">
              <Button
                variant="outline"
                size="sm"
                onClick={handleRetry}
                className="text-xs"
              >
                <RefreshCw className="w-3 h-3 mr-1" />
                Tentar novamente
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleOpenInNewTab}
                className="text-xs"
              >
                <ExternalLink className="w-3 h-3 mr-1" />
                Abrir em nova aba
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleCopyUrl}
                className="text-xs"
              >
                <Copy className="w-3 h-3 mr-1" />
                Copiar link
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Video element */}
      <video
        ref={videoRef}
        key={videoUrl}
        className="w-full h-full object-cover"
        controls={false}
        autoPlay={autoplay}
        playsInline
        muted={autoplay}
        poster={thumbnail}
        preload="metadata"
        onError={(e) => {
          const video = e.currentTarget;
          const errorCode = video.error?.code;
          const errorMessages: Record<number, string> = {
            1: 'Carregamento abortado',
            2: 'Erro de rede - verifique sua conexão',
            3: 'Erro ao decodificar (codec incompatível)',
            4: 'Formato não suportado pelo navegador'
          };
          setVideoError(errorMessages[errorCode || 0] || 'Erro ao carregar vídeo');
          setHasError(true);
          setIsLoading(false);
        }}
        onLoadStart={() => setIsLoading(true)}
        onCanPlay={() => setIsLoading(false)}
        onPlay={() => setIsVideoPlaying(true)}
        onPause={() => setIsVideoPlaying(false)}
      >
        {mimeType ? (
          <source src={videoUrl} type={mimeType} />
        ) : (
          <source src={videoUrl} />
        )}
      </video>

      {/* Custom controls */}
      {controls && !hasError && (
        <VideoControls
          videoRef={videoRef}
          isPlaying={isVideoPlaying}
          onPlayPause={handlePlayPause}
        />
      )}
    </motion.div>
  );
}
