import { VoltCard } from '@/components/VoltCard';
import { VoltButton } from '@/components/VoltButton';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Dumbbell, Clock, Target, Save, Zap, Link as LinkIcon, ExternalLink } from 'lucide-react';
import { WorkoutExercise } from '@/types/workout.unified';

interface WorkoutStepConfirmProps {
  workoutInfo: { name: string; type: string; goal: string };
  selectedExercises: WorkoutExercise[];
  metadata?: {
    videoUrl: string;
    tags: string[];
    source: string;
    additionalNotes: string;
  };
  onSave: (startNow?: boolean) => void;
  onPrev: () => void;
}

export function WorkoutStepConfirm({
  workoutInfo,
  selectedExercises,
  metadata,
  onSave,
  onPrev,
}: WorkoutStepConfirmProps) {
  const estimatedDuration = selectedExercises.reduce(
    (total, ex) => total + ex.sets * ((ex.rest || 90) / 60) + 2,
    0
  );

  const totalVolume = selectedExercises.reduce(
    (total, ex) => total + (ex.weight || 0) * ex.sets * (typeof ex.reps === 'number' ? ex.reps : parseInt(String(ex.reps)) || 10),
    0
  );

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-2xl font-bold text-txt mb-2">Treino Pronto! 🔥</h3>
        <p className="text-txt-2">Revise e confirme seu treino personalizado</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <VoltCard className="p-4 text-center" glow>
          <Dumbbell className="w-6 h-6 text-accent mx-auto mb-2" />
          <div className="text-2xl font-bold text-txt">{selectedExercises.length}</div>
          <div className="text-xs text-txt-3">Exercícios</div>
        </VoltCard>
        
        <VoltCard className="p-4 text-center" glow>
          <Clock className="w-6 h-6 text-accent mx-auto mb-2" />
          <div className="text-2xl font-bold text-txt">{Math.round(estimatedDuration)}min</div>
          <div className="text-xs text-txt-3">Duração Est.</div>
        </VoltCard>
        
        <VoltCard className="p-4 text-center" glow>
          <Target className="w-6 h-6 text-accent mx-auto mb-2" />
          <div className="text-2xl font-bold text-txt">{Math.round(totalVolume)}kg</div>
          <div className="text-xs text-txt-3">Volume Total</div>
        </VoltCard>
        
        <VoltCard className="p-4 text-center" glow>
          <Zap className="w-6 h-6 text-accent mx-auto mb-2" />
          <div className="text-2xl font-bold text-txt">{workoutInfo.goal}</div>
          <div className="text-xs text-txt-3">Objetivo</div>
        </VoltCard>
      </div>

      {/* Workout Details */}
      <VoltCard className="p-6">
        <div className="space-y-4">
          <div>
            <h4 className="text-lg font-bold text-txt">{workoutInfo.name}</h4>
            <p className="text-sm text-txt-2">{workoutInfo.type} - {workoutInfo.goal}</p>
          </div>

          <Separator />

          {/* Exercise List */}
          <div className="space-y-3">
            {selectedExercises.map((exercise, index) => (
              <div key={exercise.id} className="flex items-start gap-3 p-3 rounded-lg bg-secondary/50">
                <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center text-primary-foreground font-bold text-sm flex-shrink-0">
                  {index + 1}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <h5 className="font-semibold text-foreground">{exercise.name}</h5>
                      <div className="flex items-center gap-2 mt-1 flex-wrap">
                        <Badge variant="outline" className="text-xs">
                          {exercise.sets} séries
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {exercise.reps} reps
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {exercise.weight || 0}kg
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {exercise.rest || 90}s descanso
                        </Badge>
                      </div>
                    </div>
                  </div>
                  
                  {exercise.notes && (
                    <p className="text-xs text-muted-foreground mt-2 italic">"{exercise.notes}"</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </VoltCard>

      {/* Metadata Preview */}
      {metadata && (metadata.videoUrl || metadata.tags.length > 0 || metadata.source) && (
        <VoltCard className="p-6">
          <h4 className="font-semibold text-txt mb-3 flex items-center gap-2">
            <LinkIcon className="w-4 h-4 text-accent" />
            Recursos e Tags
          </h4>
          
          {metadata.videoUrl && (
            <div className="mb-3 p-3 bg-accent/10 rounded-lg">
              <p className="text-xs text-txt-3 mb-1">Link de vídeo:</p>
              <a 
                href={metadata.videoUrl} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-sm text-accent hover:underline flex items-center gap-1 truncate"
              >
                <ExternalLink className="w-3 h-3 flex-shrink-0" />
                {metadata.videoUrl}
              </a>
            </div>
          )}
          
          {metadata.tags.length > 0 && (
            <div className="mb-3">
              <p className="text-xs text-txt-3 mb-2">Tags:</p>
              <div className="flex flex-wrap gap-2">
                {metadata.tags.map(tag => (
                  <Badge key={tag} variant="outline" className="bg-accent/10 text-accent">
                    #{tag}
                  </Badge>
                ))}
              </div>
            </div>
          )}
          
          {metadata.source && (
            <div>
              <p className="text-xs text-txt-3 mb-1">Fonte:</p>
              <p className="text-sm text-txt">{metadata.source}</p>
            </div>
          )}
        </VoltCard>
      )}

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-3 pt-4">
        <VoltButton variant="ghost" onClick={onPrev} className="flex-1">
          ← Voltar
        </VoltButton>
        
        <VoltButton
          onClick={() => onSave(false)}
          className="flex-1 bg-gradient-to-r from-accent to-accent-2"
        >
          <Save className="w-4 h-4 mr-2" />
          Salvar Template
        </VoltButton>
        
        <VoltButton
          onClick={() => onSave(true)}
          className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500"
        >
          <Zap className="w-4 h-4 mr-2" />
          Iniciar Agora!
        </VoltButton>
      </div>
    </div>
  );
}
