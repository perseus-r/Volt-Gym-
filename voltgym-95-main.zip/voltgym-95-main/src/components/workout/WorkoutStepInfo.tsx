import { VoltCard } from '@/components/VoltCard';
import { VoltButton } from '@/components/VoltButton';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dumbbell, Target, TrendingUp, Zap, Flame, Activity } from 'lucide-react';

interface WorkoutStepInfoProps {
  workoutInfo: { name: string; type: string; goal: string };
  setWorkoutInfo: (info: any) => void;
  onNext: () => void;
}

export function WorkoutStepInfo({ workoutInfo, setWorkoutInfo, onNext }: WorkoutStepInfoProps) {
  const workoutTypes = [
    { id: 'push', name: 'Push', icon: Dumbbell, color: 'from-red-500 to-pink-500' },
    { id: 'pull', name: 'Pull', icon: Target, color: 'from-blue-500 to-cyan-500' },
    { id: 'legs', name: 'Legs', icon: TrendingUp, color: 'from-purple-500 to-pink-500' },
    { id: 'upper', name: 'Upper Body', icon: Zap, color: 'from-orange-500 to-red-500' },
    { id: 'lower', name: 'Lower Body', icon: Flame, color: 'from-green-500 to-emerald-500' },
    { id: 'full', name: 'Full Body', icon: Activity, color: 'from-indigo-500 to-purple-500' },
  ];

  const goals = [
    { id: 'hipertrofia', name: 'Hipertrofia', desc: '8-12 reps, volume alto' },
    { id: 'forca', name: 'Força', desc: '3-6 reps, carga alta' },
    { id: 'resistencia', name: 'Resistência', desc: '12-20 reps, descanso curto' },
  ];

  const isValid = workoutInfo.name.trim() && workoutInfo.type && workoutInfo.goal;

  return (
    <div className="space-y-8">
      {/* Nome do Treino */}
      <div className="space-y-3">
        <Label className="text-lg font-semibold text-txt">Nome do Treino</Label>
        <Input
          placeholder="Ex: Push Destruidor, Pull Power..."
          value={workoutInfo.name}
          onChange={(e) => setWorkoutInfo({ ...workoutInfo, name: e.target.value })}
          className="text-lg p-6 bg-surface/50 border-line/50"
        />
      </div>

      {/* Tipo de Treino */}
      <div className="space-y-3">
        <Label className="text-lg font-semibold text-txt">Tipo de Treino</Label>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {workoutTypes.map((type) => {
            const Icon = type.icon;
            return (
              <VoltCard
                key={type.id}
                onClick={() => setWorkoutInfo({ ...workoutInfo, type: type.name })}
                className={`p-4 cursor-pointer transition-all ${
                  workoutInfo.type === type.name
                    ? 'ring-2 ring-accent shadow-accent/30'
                    : 'hover:border-accent/50'
                }`}
              >
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${type.color} flex items-center justify-center mb-3`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold text-txt">{type.name}</h3>
              </VoltCard>
            );
          })}
        </div>
      </div>

      {/* Objetivo */}
      <div className="space-y-3">
        <Label className="text-lg font-semibold text-txt">Objetivo</Label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {goals.map((goal) => (
            <VoltCard
              key={goal.id}
              onClick={() => setWorkoutInfo({ ...workoutInfo, goal: goal.name })}
              className={`p-4 cursor-pointer transition-all ${
                workoutInfo.goal === goal.name
                  ? 'ring-2 ring-accent shadow-accent/30'
                  : 'hover:border-accent/50'
              }`}
            >
              <h3 className="font-semibold text-txt mb-1">{goal.name}</h3>
              <p className="text-sm text-txt-2">{goal.desc}</p>
            </VoltCard>
          ))}
        </div>
      </div>

      {/* Botão Próximo */}
      <div className="flex justify-end pt-4">
        <VoltButton
          onClick={onNext}
          disabled={!isValid}
          className="min-w-[200px]"
        >
          Próximo: Exercícios →
        </VoltButton>
      </div>
    </div>
  );
}
