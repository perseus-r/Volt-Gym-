import { motion } from 'framer-motion';
import { Sparkles, Play, Clock, Target } from 'lucide-react';
import { UserWorkoutData } from '@/hooks/useUserWorkouts';
import { HoverCard } from '@/components/interactions/HoverCard';
import { RippleButton } from '@/components/interactions/RippleButton';

interface NextWorkoutSuggestionProps {
  suggestedWorkout: UserWorkoutData;
  onStart: () => void;
}

export function NextWorkoutSuggestion({ suggestedWorkout, onStart }: NextWorkoutSuggestionProps) {
  return (
    <HoverCard depth={2} glow className="p-6 border-accent/30">
      <div className="flex items-start gap-4">
        {/* Icon */}
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-accent to-accent/50 flex items-center justify-center flex-shrink-0">
          <Sparkles className="w-7 h-7 text-accent-ink" />
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold text-accent uppercase tracking-wider">
              Próximo Treino Sugerido
            </span>
          </div>
          
          <h3 className="text-xl font-bold text-txt mb-2">
            {suggestedWorkout.name}
          </h3>

          <div className="flex items-center gap-4 text-txt-3 mb-4">
            <div className="flex items-center gap-1.5">
              <Target className="w-4 h-4" />
              <span className="text-sm">{suggestedWorkout.focus}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Clock className="w-4 h-4" />
              <span className="text-sm">{suggestedWorkout.exercises.length} exercícios</span>
            </div>
          </div>

          <RippleButton
            variant="primary"
            onClick={onStart}
            className="w-full sm:w-auto"
          >
            <Play className="w-4 h-4 mr-2" />
            Iniciar Agora
          </RippleButton>
        </div>
      </div>
    </HoverCard>
  );
}