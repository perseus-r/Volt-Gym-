import React from 'react';
import { motion } from 'framer-motion';
import { 
  Dumbbell, Zap, Heart, Activity, Flame, HeartPulse, 
  Clock, MoreVertical, Sparkles, Play
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

interface WorkoutTemplateCardPremiumProps {
  name: string;
  description?: string;
  category: string;
  difficulty: 'iniciante' | 'intermediario' | 'avancado' | string;
  exerciseCount: number;
  duration?: number;
  timesUsed?: number;
  rating?: number;
  completionRate?: number;
  isAiGenerated?: boolean;
  onClick?: () => void;
  onAction?: () => void;
  actionIcon?: React.ReactNode;
  className?: string;
}

// Category icons only - no colorful gradients
const CATEGORY_ICONS: Record<string, React.ElementType> = {
  hipertrofia: Dumbbell,
  forca: Zap,
  resistencia: Heart,
  funcional: Activity,
  emagrecimento: Flame,
  reabilitacao: HeartPulse,
};

const DIFFICULTY_CONFIG = {
  iniciante: { level: 1, label: 'Iniciante' },
  intermediario: { level: 2, label: 'Intermediário' },
  avancado: { level: 3, label: 'Avançado' },
};

const CATEGORY_LABELS: Record<string, string> = {
  hipertrofia: 'Hipertrofia',
  forca: 'Força',
  resistencia: 'Resistência',
  funcional: 'Funcional',
  emagrecimento: 'Emagrecimento',
  reabilitacao: 'Reabilitação',
};

export function WorkoutTemplateCardPremium({
  name,
  description,
  category,
  difficulty,
  exerciseCount,
  duration,
  timesUsed = 0,
  isAiGenerated = false,
  onClick,
  onAction,
  actionIcon,
  className,
}: WorkoutTemplateCardPremiumProps) {
  const CategoryIcon = CATEGORY_ICONS[category] || Dumbbell;
  const difficultyConfig = DIFFICULTY_CONFIG[difficulty as keyof typeof DIFFICULTY_CONFIG] || DIFFICULTY_CONFIG.intermediario;

  return (
    <motion.div
      whileHover={{ y: -2 }}
      whileTap={{ scale: 0.99 }}
      transition={{ duration: 0.15, ease: 'easeOut' }}
      onClick={onClick}
      className={cn(
        'relative overflow-hidden rounded-xl cursor-pointer',
        'bg-zinc-900/80 backdrop-blur-sm border border-white/[0.06]',
        'hover:border-white/10 hover:bg-zinc-900/90 transition-all duration-200',
        className
      )}
    >
      <div className="p-5 space-y-4">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            {isAiGenerated ? (
              <Sparkles className="w-4 h-4 text-white/40" />
            ) : (
              <CategoryIcon className="w-4 h-4 text-white/40" />
            )}
            <span className="text-xs text-white/50 uppercase tracking-wider font-medium">
              {CATEGORY_LABELS[category] || category}
            </span>
            {isAiGenerated && (
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-white/5 text-white/40 font-medium">
                IA
              </span>
            )}
          </div>
          
          {onAction && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onAction();
              }}
              className="p-1.5 -mr-1.5 rounded-md hover:bg-white/5 transition-colors"
            >
              {actionIcon || <MoreVertical className="w-4 h-4 text-white/30" />}
            </button>
          )}
        </div>

        {/* Title */}
        <h3 className="text-base font-semibold text-white line-clamp-1">
          {name}
        </h3>

        {/* Description */}
        {description && (
          <p className="text-sm text-white/50 line-clamp-2 leading-relaxed">
            {description}
          </p>
        )}

        {/* Difficulty - bar style */}
        <div className="flex items-center gap-2">
          <div className="flex gap-0.5">
            {[1, 2, 3].map((bar) => (
              <div
                key={bar}
                className={cn(
                  'w-1 h-3 rounded-sm transition-all',
                  bar <= difficultyConfig.level
                    ? 'bg-white/70'
                    : 'bg-white/10'
                )}
              />
            ))}
          </div>
          <span className="text-xs text-white/40">
            {difficultyConfig.label}
          </span>
        </div>

        {/* Stats */}
        <div className="flex items-center gap-4 pt-3 border-t border-white/[0.06]">
          <div className="flex items-center gap-1.5 text-sm text-white/50">
            <span className="font-medium text-white/70">{exerciseCount}</span>
            <span>exercícios</span>
          </div>
          {duration && (
            <div className="flex items-center gap-1.5 text-sm text-white/50">
              <span className="font-medium text-white/70">{duration}</span>
              <span>min</span>
            </div>
          )}
          {timesUsed > 0 && (
            <div className="flex items-center gap-1.5 text-sm text-white/50 ml-auto">
              <span className="font-medium text-white/70">{timesUsed}x</span>
              <span>usado</span>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

// Mobile-optimized version with action button
export function WorkoutTemplateCardMobile({
  name,
  description,
  category,
  difficulty,
  exerciseCount,
  duration,
  muscleGroups = [],
  onStart,
  className,
}: {
  name: string;
  description?: string;
  category?: string;
  difficulty: number | string;
  exerciseCount: number;
  duration?: number;
  muscleGroups?: string[];
  onStart: () => void;
  className?: string;
}) {
  // Map numeric difficulty to string
  const difficultyKey = typeof difficulty === 'number'
    ? difficulty <= 2 ? 'iniciante' : difficulty <= 3 ? 'intermediario' : 'avancado'
    : difficulty;
  
  const categoryKey = category?.toLowerCase().replace(/\s/g, '') || 'funcional';
  const CategoryIcon = CATEGORY_ICONS[categoryKey] || Dumbbell;
  const difficultyConfig = DIFFICULTY_CONFIG[difficultyKey as keyof typeof DIFFICULTY_CONFIG] || DIFFICULTY_CONFIG.intermediario;

  return (
    <motion.div
      whileTap={{ scale: 0.99 }}
      className={cn(
        'relative overflow-hidden rounded-xl',
        'bg-zinc-900/80 backdrop-blur-sm border border-white/[0.06]',
        'active:border-white/10 transition-all duration-150',
        className
      )}
    >
      <div className="p-4 space-y-3">
        {/* Header */}
        <div className="flex items-start gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <CategoryIcon className="w-3.5 h-3.5 text-white/40" />
              <span className="text-[10px] text-white/40 uppercase tracking-wider font-medium">
                {category || 'Treino'}
              </span>
            </div>
            <h3 className="font-semibold text-white line-clamp-1">{name}</h3>
          </div>

          {/* Difficulty bars */}
          <div className="flex gap-0.5 flex-shrink-0 pt-1">
            {[1, 2, 3].map((bar) => (
              <div
                key={bar}
                className={cn(
                  'w-1 h-2.5 rounded-sm',
                  bar <= difficultyConfig.level
                    ? 'bg-white/60'
                    : 'bg-white/10'
                )}
              />
            ))}
          </div>
        </div>

        {/* Description */}
        {description && (
          <p className="text-xs text-white/45 line-clamp-2 leading-relaxed">{description}</p>
        )}

        {/* Muscle groups */}
        {muscleGroups.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {muscleGroups.slice(0, 3).map((muscle, idx) => (
              <span
                key={idx}
                className="px-2 py-0.5 rounded bg-white/[0.04] text-[10px] font-medium text-white/45"
              >
                {muscle}
              </span>
            ))}
            {muscleGroups.length > 3 && (
              <span className="px-2 py-0.5 rounded bg-white/[0.02] text-[10px] text-white/30">
                +{muscleGroups.length - 3}
              </span>
            )}
          </div>
        )}

        {/* Stats row */}
        <div className="flex items-center gap-4 text-xs text-white/40">
          <span className="flex items-center gap-1.5">
            <Dumbbell className="w-3 h-3" />
            {exerciseCount} exercícios
          </span>
          {duration && (
            <span className="flex items-center gap-1.5">
              <Clock className="w-3 h-3" />
              {duration} min
            </span>
          )}
          <span className="ml-auto text-white/35">{difficultyConfig.label}</span>
        </div>

        {/* Action button - neutral style */}
        <Button 
          variant="outline"
          className={cn(
            'w-full font-medium',
            'bg-white/[0.03] border-white/10 text-white/80',
            'hover:bg-white/[0.06] hover:border-white/15 hover:text-white',
            'transition-all duration-150'
          )}
          onClick={(e) => {
            e.stopPropagation();
            onStart();
          }}
        >
          <Play className="w-3.5 h-3.5 mr-2" />
          Iniciar Treino
        </Button>
      </div>
    </motion.div>
  );
}
