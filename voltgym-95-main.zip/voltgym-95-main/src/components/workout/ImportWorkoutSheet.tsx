import React, { useState } from 'react';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetTrigger,
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from 'sonner';
import { Upload, FileText, Check, AlertCircle, Loader2 } from 'lucide-react';

interface ParsedExercise {
  name: string;
  sets: number;
  reps: string;
  weight?: number;
  notes?: string;
}

interface ImportWorkoutSheetProps {
  onImport: (exercises: ParsedExercise[], workoutName: string) => void;
  trigger?: React.ReactNode;
}

const ImportWorkoutSheet: React.FC<ImportWorkoutSheetProps> = ({ onImport, trigger }) => {
  const [open, setOpen] = useState(false);
  const [rawText, setRawText] = useState('');
  const [workoutName, setWorkoutName] = useState('');
  const [parsedExercises, setParsedExercises] = useState<ParsedExercise[]>([]);
  const [parseErrors, setParseErrors] = useState<string[]>([]);
  const [isParsing, setIsParsing] = useState(false);

  const parseWorkoutText = (text: string): { exercises: ParsedExercise[]; errors: string[] } => {
    const exercises: ParsedExercise[] = [];
    const errors: string[] = [];
    const lines = text.split('\n').filter(line => line.trim());

    for (const line of lines) {
      const trimmed = line.trim();
      
      // Skip empty lines and headers
      if (!trimmed || trimmed.startsWith('#') || trimmed.startsWith('--')) continue;

      // Try different parsing patterns
      let parsed: ParsedExercise | null = null;

      // Pattern 1: "Nome do exercício - 3x12 @60kg"
      const pattern1 = trimmed.match(/^(.+?)\s*[-–]\s*(\d+)\s*[xX]\s*([\d\-]+)(?:\s*[@]?\s*(\d+(?:\.\d+)?)\s*kg)?(.*)$/);
      if (pattern1) {
        const [, name, sets, reps, weight, notes] = pattern1;
        parsed = {
          name: name.trim(),
          sets: parseInt(sets),
          reps: reps,
          weight: weight ? parseFloat(weight) : undefined,
          notes: notes?.trim().replace(/^\|?\s*/, '') || undefined,
        };
      }

      // Pattern 2: "Supino Reto: 4 séries x 10 reps - 80kg"
      if (!parsed) {
        const pattern2 = trimmed.match(/^(.+?)\s*:\s*(\d+)\s*(?:séries?|sets?)?\s*[xX×]\s*([\d\-]+)\s*(?:reps?)?(?:\s*[-–]\s*(\d+(?:\.\d+)?)\s*kg)?(.*)$/i);
        if (pattern2) {
          const [, name, sets, reps, weight, notes] = pattern2;
          parsed = {
            name: name.trim(),
            sets: parseInt(sets),
            reps: reps,
            weight: weight ? parseFloat(weight) : undefined,
            notes: notes?.trim() || undefined,
          };
        }
      }

      // Pattern 3: Simple "Nome 3x12"
      if (!parsed) {
        const pattern3 = trimmed.match(/^(.+?)\s+(\d+)\s*[xX]\s*([\d\-]+)\s*(?:[@]?\s*(\d+(?:\.\d+)?)\s*kg)?$/);
        if (pattern3) {
          const [, name, sets, reps, weight] = pattern3;
          parsed = {
            name: name.trim(),
            sets: parseInt(sets),
            reps: reps,
            weight: weight ? parseFloat(weight) : undefined,
          };
        }
      }

      // Pattern 4: Just exercise name (assume 3x10)
      if (!parsed && trimmed.length > 3 && !trimmed.match(/^\d/)) {
        parsed = {
          name: trimmed,
          sets: 3,
          reps: '10',
          notes: 'Ajuste séries e reps',
        };
      }

      if (parsed) {
        exercises.push(parsed);
      } else if (trimmed.length > 2) {
        errors.push(`Não entendi: "${trimmed.slice(0, 50)}..."`);
      }
    }

    return { exercises, errors };
  };

  const handleParse = () => {
    setIsParsing(true);
    
    setTimeout(() => {
      const { exercises, errors } = parseWorkoutText(rawText);
      setParsedExercises(exercises);
      setParseErrors(errors);
      setIsParsing(false);

      if (exercises.length > 0) {
        toast.success(`${exercises.length} exercícios encontrados!`);
      } else {
        toast.error('Nenhum exercício encontrado. Verifique o formato.');
      }
    }, 300);
  };

  const handleConfirmImport = () => {
    if (parsedExercises.length === 0) {
      toast.error('Nenhum exercício para importar');
      return;
    }

    const name = workoutName.trim() || `Treino Importado ${new Date().toLocaleDateString('pt-BR')}`;
    onImport(parsedExercises, name);
    
    // Reset state
    setRawText('');
    setWorkoutName('');
    setParsedExercises([]);
    setParseErrors([]);
    setOpen(false);
    
    toast.success(`${parsedExercises.length} exercícios importados com sucesso!`);
  };

  const exampleText = `Supino Reto - 4x10 @80kg
Supino Inclinado - 3x12 @60kg
Crucifixo - 3x15 @12kg
Tríceps Corda - 4x12 @30kg
Tríceps Francês - 3x10 @20kg`;

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        {trigger || (
          <Button variant="outline" className="gap-2">
            <Upload className="w-4 h-4" />
            Importar Treino
          </Button>
        )}
      </SheetTrigger>
      
      <SheetContent side="bottom" className="h-[90vh] overflow-y-auto">
        <SheetHeader className="mb-4">
          <SheetTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Importar Treino Externo
          </SheetTitle>
          <SheetDescription>
            Cole seu treino abaixo. Aceitamos vários formatos!
          </SheetDescription>
        </SheetHeader>

        <div className="space-y-6">
          {/* Workout Name */}
          <div className="space-y-2">
            <Label>Nome do Treino (opcional)</Label>
            <Input
              value={workoutName}
              onChange={e => setWorkoutName(e.target.value)}
              placeholder="Ex: Peito e Tríceps"
            />
          </div>

          {/* Raw Text Input */}
          <div className="space-y-2">
            <Label>Cole seu treino aqui</Label>
            <Textarea
              value={rawText}
              onChange={e => setRawText(e.target.value)}
              placeholder={exampleText}
              rows={8}
              className="font-mono text-sm"
            />
            <p className="text-xs text-muted-foreground">
              Formatos aceitos: "Exercício - 3x10 @60kg" ou "Exercício: 3 séries x 10 reps"
            </p>
          </div>

          {/* Parse Button */}
          <Button 
            onClick={handleParse} 
            disabled={!rawText.trim() || isParsing}
            className="w-full"
          >
            {isParsing ? (
              <Loader2 className="w-4 h-4 animate-spin mr-2" />
            ) : (
              <FileText className="w-4 h-4 mr-2" />
            )}
            Analisar Treino
          </Button>

          {/* Parse Errors */}
          {parseErrors.length > 0 && (
            <Card className="border-yellow-500/50 bg-yellow-500/10">
              <CardContent className="pt-4">
                <div className="flex items-start gap-2 text-yellow-600">
                  <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                  <div className="text-sm">
                    <p className="font-medium">Algumas linhas não foram reconhecidas:</p>
                    <ul className="mt-1 space-y-1">
                      {parseErrors.slice(0, 3).map((err, i) => (
                        <li key={i} className="text-xs opacity-80">{err}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Parsed Preview */}
          {parsedExercises.length > 0 && (
            <div className="space-y-3">
              <Label className="flex items-center gap-2">
                <Check className="w-4 h-4 text-green-500" />
                {parsedExercises.length} exercícios encontrados
              </Label>
              
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {parsedExercises.map((exercise, index) => (
                  <Card key={index} className="bg-muted/50">
                    <CardContent className="py-3 px-4">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">{exercise.name}</span>
                        <span className="text-sm text-muted-foreground">
                          {exercise.sets}x{exercise.reps}
                          {exercise.weight && ` @${exercise.weight}kg`}
                        </span>
                      </div>
                      {exercise.notes && (
                        <p className="text-xs text-muted-foreground mt-1">{exercise.notes}</p>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>

              <Button 
                onClick={handleConfirmImport}
                className="w-full"
                variant="default"
              >
                <Check className="w-4 h-4 mr-2" />
                Confirmar Importação
              </Button>
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default ImportWorkoutSheet;
