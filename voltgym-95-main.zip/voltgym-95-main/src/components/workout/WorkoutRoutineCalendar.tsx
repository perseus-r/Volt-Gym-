import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, Flame, Dumbbell, Clock, TrendingUp } from 'lucide-react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, addMonths, subMonths, parseISO, isToday } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';

interface WorkoutSession {
  id: string;
  name: string;
  focus?: string;
  completed_at?: string;
  created_at?: string;
  total_volume?: number;
  duration_minutes?: number;
  exercises?: any[];
}

interface WorkoutRoutineCalendarProps {
  workouts: WorkoutSession[];
  onDayClick?: (date: Date, workouts: WorkoutSession[]) => void;
}

export function WorkoutRoutineCalendar({ workouts, onDayClick }: WorkoutRoutineCalendarProps) {
  const [selectedMonth, setSelectedMonth] = useState(new Date());
  const [selectedDay, setSelectedDay] = useState<{ date: Date; workouts: WorkoutSession[] } | null>(null);

  // Organize workouts by date
  const workoutsByDate = useMemo(() => {
    const map = new Map<string, WorkoutSession[]>();
    
    workouts.forEach(workout => {
      let date: Date | null = null;
      
      if (workout.completed_at) {
        date = parseISO(workout.completed_at);
      } else if (workout.created_at) {
        date = parseISO(workout.created_at);
      }
      
      if (date) {
        const dateKey = format(date, 'yyyy-MM-dd');
        const existing = map.get(dateKey) || [];
        map.set(dateKey, [...existing, workout]);
      }
    });
    
    return map;
  }, [workouts]);

  // Calculate intensity for coloring
  const getIntensityForDate = (date: Date): number => {
    const dateKey = format(date, 'yyyy-MM-dd');
    const dayWorkouts = workoutsByDate.get(dateKey) || [];
    
    if (dayWorkouts.length === 0) return 0;
    if (dayWorkouts.length === 1) return 1;
    if (dayWorkouts.length === 2) return 2;
    return 3; // 3+ workouts
  };

  const getIntensityColor = (intensity: number): string => {
    switch (intensity) {
      case 0: return 'bg-surface/30';
      case 1: return 'bg-accent/20';
      case 2: return 'bg-accent/40';
      case 3: return 'bg-accent/60';
      default: return 'bg-surface/30';
    }
  };

  const monthDays = eachDayOfInterval({
    start: startOfMonth(selectedMonth),
    end: endOfMonth(selectedMonth)
  });

  // Calculate padding days for grid alignment
  const firstDayOfMonth = startOfMonth(selectedMonth);
  const startDayOfWeek = firstDayOfMonth.getDay(); // 0 = Sunday

  const handleDayClick = (day: Date) => {
    const dateKey = format(day, 'yyyy-MM-dd');
    const dayWorkouts = workoutsByDate.get(dateKey) || [];
    setSelectedDay({ date: day, workouts: dayWorkouts });
    onDayClick?.(day, dayWorkouts);
  };

  // Stats for the month
  const monthStats = useMemo(() => {
    let totalWorkouts = 0;
    let totalVolume = 0;
    let totalDuration = 0;
    let trainingDays = 0;

    monthDays.forEach(day => {
      const dateKey = format(day, 'yyyy-MM-dd');
      const dayWorkouts = workoutsByDate.get(dateKey) || [];
      if (dayWorkouts.length > 0) {
        trainingDays++;
        totalWorkouts += dayWorkouts.length;
        dayWorkouts.forEach(w => {
          totalVolume += w.total_volume || 0;
          totalDuration += w.duration_minutes || 0;
        });
      }
    });

    return { totalWorkouts, totalVolume, totalDuration, trainingDays };
  }, [monthDays, workoutsByDate]);

  return (
    <div className="space-y-4">
      {/* Month Navigation */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-txt capitalize">
          {format(selectedMonth, 'MMMM yyyy', { locale: ptBR })}
        </h3>
        <div className="flex gap-2">
          <button
            onClick={() => setSelectedMonth(subMonths(selectedMonth, 1))}
            className="p-2 rounded-lg bg-surface/50 hover:bg-surface transition-colors"
          >
            <ChevronLeft className="w-4 h-4 text-txt" />
          </button>
          <button
            onClick={() => setSelectedMonth(addMonths(selectedMonth, 1))}
            className="p-2 rounded-lg bg-surface/50 hover:bg-surface transition-colors"
          >
            <ChevronRight className="w-4 h-4 text-txt" />
          </button>
        </div>
      </div>

      {/* Calendar Grid */}
      <div className="grid grid-cols-7 gap-1.5">
        {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map(day => (
          <div key={day} className="text-center text-xs font-medium text-txt-3 py-2">
            {day}
          </div>
        ))}
        
        {/* Empty cells for alignment */}
        {Array.from({ length: startDayOfWeek }).map((_, i) => (
          <div key={`empty-${i}`} className="aspect-square" />
        ))}
        
        {monthDays.map(day => {
          const dateKey = format(day, 'yyyy-MM-dd');
          const dayWorkouts = workoutsByDate.get(dateKey) || [];
          const intensity = getIntensityForDate(day);
          const hasWorkout = dayWorkouts.length > 0;
          const isTodayDate = isToday(day);

          return (
            <motion.button
              key={dateKey}
              onClick={() => handleDayClick(day)}
              className={`
                relative aspect-square rounded-lg p-1 text-sm transition-all flex flex-col items-center justify-center
                ${getIntensityColor(intensity)}
                ${isTodayDate ? 'ring-2 ring-accent' : 'border border-border/30'}
                hover:scale-105
              `}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <div className={`font-medium ${isTodayDate ? 'text-accent' : 'text-txt'}`}>
                {format(day, 'd')}
              </div>
              {hasWorkout && (
                <div className="absolute bottom-1 left-1/2 -translate-x-1/2 flex gap-0.5">
                  {dayWorkouts.slice(0, 3).map((_, i) => (
                    <div key={i} className="w-1 h-1 rounded-full bg-accent" />
                  ))}
                </div>
              )}
            </motion.button>
          );
        })}
      </div>

      {/* Month Stats */}
      <Card className="p-4 bg-surface/30">
        <div className="grid grid-cols-4 gap-4 text-center">
          <div>
            <div className="text-xl font-bold text-accent">{monthStats.trainingDays}</div>
            <div className="text-xs text-txt-3">Dias de treino</div>
          </div>
          <div>
            <div className="text-xl font-bold text-txt">{monthStats.totalWorkouts}</div>
            <div className="text-xs text-txt-3">Treinos</div>
          </div>
          <div>
            <div className="text-xl font-bold text-txt">
              {monthStats.totalVolume > 1000 
                ? `${(monthStats.totalVolume / 1000).toFixed(1)}t`
                : `${Math.round(monthStats.totalVolume)}kg`
              }
            </div>
            <div className="text-xs text-txt-3">Volume</div>
          </div>
          <div>
            <div className="text-xl font-bold text-txt">
              {monthStats.totalDuration > 60 
                ? `${Math.round(monthStats.totalDuration / 60)}h`
                : `${monthStats.totalDuration}min`
              }
            </div>
            <div className="text-xs text-txt-3">Tempo</div>
          </div>
        </div>
      </Card>

      {/* Legend */}
      <div className="flex items-center justify-center gap-4 text-xs text-txt-3">
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 rounded bg-surface/30 border border-border/30" />
          <span>Sem treino</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 rounded bg-accent/20" />
          <span>1 treino</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 rounded bg-accent/40" />
          <span>2 treinos</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 rounded bg-accent/60" />
          <span>3+ treinos</span>
        </div>
      </div>

      {/* Day Details Sheet */}
      <Sheet open={!!selectedDay} onOpenChange={() => setSelectedDay(null)}>
        <SheetContent side="bottom" className="max-h-[60vh]">
          {selectedDay && (
            <>
              <SheetHeader>
                <SheetTitle className="text-left">
                  {format(selectedDay.date, "EEEE, dd 'de' MMMM", { locale: ptBR })}
                </SheetTitle>
              </SheetHeader>
              <div className="mt-4 space-y-3">
                {selectedDay.workouts.length > 0 ? (
                  selectedDay.workouts.map((workout) => (
                    <Card key={workout.id} className="p-4 bg-surface/50">
                      <div className="flex items-center gap-3">
                        <div className="p-2 rounded-lg bg-accent/20">
                          <Dumbbell className="w-5 h-5 text-accent" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-txt">{workout.name}</h4>
                          <p className="text-sm text-txt-2">{workout.focus || 'Treino'}</p>
                        </div>
                        <Badge variant="outline" className="bg-green-500/20 text-green-400 border-green-500/30">
                          Concluído
                        </Badge>
                      </div>
                      <div className="mt-3 flex items-center gap-4 text-sm text-txt-3">
                        {workout.total_volume && workout.total_volume > 0 && (
                          <span className="flex items-center gap-1">
                            <TrendingUp className="w-4 h-4" />
                            {workout.total_volume > 1000 
                              ? `${(workout.total_volume / 1000).toFixed(1)}t`
                              : `${Math.round(workout.total_volume)}kg`
                            }
                          </span>
                        )}
                        {workout.duration_minutes && workout.duration_minutes > 0 && (
                          <span className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {workout.duration_minutes}min
                          </span>
                        )}
                        {workout.exercises && (
                          <span className="flex items-center gap-1">
                            <Flame className="w-4 h-4" />
                            {workout.exercises.length} exercícios
                          </span>
                        )}
                      </div>
                    </Card>
                  ))
                ) : (
                  <div className="text-center py-8 text-txt-3">
                    <Dumbbell className="w-12 h-12 mx-auto mb-3 opacity-30" />
                    <p>Nenhum treino neste dia</p>
                  </div>
                )}
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
}
