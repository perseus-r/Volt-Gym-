import { motion } from 'framer-motion';
import { Dumbbell, Clock, Target, Zap } from 'lucide-react';

interface WorkoutPreviewBarProps {
  exercisesCount: number;
  estimatedDuration: number;
}

export function WorkoutPreviewBar({ 
  exercisesCount, 
  estimatedDuration
}: WorkoutPreviewBarProps) {
  if (exercisesCount === 0) return null;
  
  const estimatedCalories = Math.round(estimatedDuration * 8);
  
  return (
    <motion.div
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className="sticky bottom-0 left-0 right-0 p-4 bg-surface/95 backdrop-blur-xl border-t border-line/50 shadow-[0_-10px_40px_rgba(0,0,0,0.3)]"
    >
      <div className="flex items-center justify-between max-w-5xl mx-auto gap-4">
        {/* Stats Grid */}
        <div className="flex items-center gap-3 md:gap-6 flex-wrap">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center">
              <Dumbbell className="w-5 h-5 text-accent" />
            </div>
            <div>
              <p className="text-xs text-txt-3">Exercícios</p>
              <p className="font-bold text-txt">{exercisesCount}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
              <Clock className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <p className="text-xs text-txt-3">Duração</p>
              <p className="font-bold text-txt">~{estimatedDuration}min</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-orange-500/20 flex items-center justify-center">
              <Zap className="w-5 h-5 text-orange-400" />
            </div>
            <div>
              <p className="text-xs text-txt-3">Calorias</p>
              <p className="font-bold text-txt">~{estimatedCalories}</p>
            </div>
          </div>
        </div>

        {/* Visual Indicator */}
        <div className="hidden md:flex items-center gap-2 px-4 py-2 rounded-lg bg-accent/10 border border-accent/30">
          <motion.div
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-2 h-2 rounded-full bg-accent"
          />
          <span className="text-sm text-accent font-medium">Preview</span>
        </div>
      </div>
    </motion.div>
  );
}
