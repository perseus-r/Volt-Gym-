import { useState, useMemo } from 'react';
import { Calendar } from '@/components/ui/calendar';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, Flame } from 'lucide-react';
import { UserWorkoutData } from '@/hooks/useUserWorkouts';
import { format, isSameDay, startOfMonth, endOfMonth, eachDayOfInterval, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface WorkoutCalendarViewProps {
  workouts: UserWorkoutData[];
  onDayClick?: (date: Date, workouts: UserWorkoutData[]) => void;
}

export function WorkoutCalendarView({ workouts, onDayClick }: WorkoutCalendarViewProps) {
  const [selectedMonth, setSelectedMonth] = useState(new Date());

  // Organize workouts by date (convert UTC to local timezone)
  const workoutsByDate = useMemo(() => {
    const map = new Map<string, UserWorkoutData[]>();
    
    workouts.forEach(workout => {
      let date: Date | null = null;
      
      if (workout.completed_at) {
        // Parse ISO string - this automatically handles timezone conversion to local
        date = parseISO(workout.completed_at);
      } else if (workout.created_at) {
        date = parseISO(workout.created_at);
      }
      
      if (date) {
        // Format in local timezone
        const dateKey = format(date, 'yyyy-MM-dd');
        const existing = map.get(dateKey) || [];
        map.set(dateKey, [...existing, workout]);
      }
    });
    
    return map;
  }, [workouts]);

  // Calculate intensity heatmap
  const getIntensityForDate = (date: Date): number => {
    const dateKey = format(date, 'yyyy-MM-dd');
    const dayWorkouts = workoutsByDate.get(dateKey) || [];
    
    if (dayWorkouts.length === 0) return 0;
    
    const avgRpe = dayWorkouts.reduce((sum, w) => {
      const exerciseRpes = w.exercises.map(ex => ex.rpe || 7);
      const avgExRpe = exerciseRpes.reduce((a, b) => a + b, 0) / exerciseRpes.length;
      return sum + avgExRpe;
    }, 0) / dayWorkouts.length;
    
    if (avgRpe < 6) return 1; // Light
    if (avgRpe < 8) return 2; // Medium
    return 3; // Hard
  };

  const getIntensityColor = (intensity: number): string => {
    switch (intensity) {
      case 0: return 'bg-surface/50';
      case 1: return 'bg-green-500/30';
      case 2: return 'bg-yellow-500/30';
      case 3: return 'bg-red-500/30';
      default: return 'bg-surface/50';
    }
  };

  const monthDays = eachDayOfInterval({
    start: startOfMonth(selectedMonth),
    end: endOfMonth(selectedMonth)
  });

  return (
    <div className="space-y-4">
      {/* Month Navigation */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-txt">
          {format(selectedMonth, 'MMMM yyyy', { locale: ptBR })}
        </h3>
        <div className="flex gap-2">
          <button
            onClick={() => setSelectedMonth(new Date(selectedMonth.getFullYear(), selectedMonth.getMonth() - 1))}
            className="p-2 rounded-lg bg-surface/50 hover:bg-surface transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={() => setSelectedMonth(new Date(selectedMonth.getFullYear(), selectedMonth.getMonth() + 1))}
            className="p-2 rounded-lg bg-surface/50 hover:bg-surface transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Calendar Grid */}
      <div className="grid grid-cols-7 gap-2">
        {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map(day => (
          <div key={day} className="text-center text-xs font-medium text-txt-3 py-2">
            {day}
          </div>
        ))}
        
        {monthDays.map(day => {
          const dateKey = format(day, 'yyyy-MM-dd');
          const dayWorkouts = workoutsByDate.get(dateKey) || [];
          const intensity = getIntensityForDate(day);
          const hasWorkout = dayWorkouts.length > 0;

          return (
            <motion.button
              key={dateKey}
              onClick={() => onDayClick?.(day, dayWorkouts)}
              className={`
                relative aspect-square rounded-lg p-2 text-sm transition-all
                ${getIntensityColor(intensity)}
                ${hasWorkout ? 'border-2 border-accent' : 'border border-border/50'}
                hover:scale-105
              `}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <div className="text-txt font-medium">{format(day, 'd')}</div>
              {hasWorkout && (
                <div className="absolute bottom-1 right-1">
                  <Flame className="w-3 h-3 text-accent" />
                </div>
              )}
              {dayWorkouts.length > 1 && (
                <div className="absolute top-1 right-1 w-2 h-2 rounded-full bg-accent" />
              )}
            </motion.button>
          );
        })}
      </div>

      {/* Legend */}
      <div className="flex items-center gap-4 text-xs text-txt-3">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded bg-green-500/30" />
          <span>Leve</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded bg-yellow-500/30" />
          <span>Moderado</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded bg-red-500/30" />
          <span>Intenso</span>
        </div>
      </div>
    </div>
  );
}