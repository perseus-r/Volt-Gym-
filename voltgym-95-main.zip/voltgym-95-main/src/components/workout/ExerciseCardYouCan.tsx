import { motion } from 'framer-motion';
import { Sparkles, Play } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { VoltCard } from '@/components/VoltCard';
import { LucideIcon } from 'lucide-react';
import { Exercise } from '@/types/exercise';

interface ExerciseCardYouCanProps {
  exercise: Exercise;
  categoryIcon: LucideIcon;
  difficultyText: string;
  difficultyColor: string;
  onSelect: () => void;
  index: number;
}

const itemVariants = {
  hidden: { opacity: 0, y: 20, scale: 0.95 },
  visible: { 
    opacity: 1, 
    y: 0, 
    scale: 1,
    transition: {
      type: "spring" as const,
      stiffness: 100,
      damping: 15
    }
  }
};

export function ExerciseCardYouCan({ 
  exercise, 
  categoryIcon: IconComponent,
  difficultyText,
  difficultyColor,
  onSelect,
  index
}: ExerciseCardYouCanProps) {
  return (
    <motion.div
      variants={itemVariants}
      custom={index}
    >
      <VoltCard
        interactive
        hover
        ambient="accent"
        glowIntensity="low"
        depth={2}
        onClick={onSelect}
        className="group h-full"
      >
        {/* Badge 3D flutuante */}
        {exercise.model_3d_url && (
          <motion.div 
            className="absolute top-3 right-3 z-10"
            whileHover={{ scale: 1.1, rotate: 5 }}
            transition={{ type: "spring", stiffness: 300 }}
          >
            <Badge className="glass-ultra border border-accent/30 text-accent shadow-lg">
              <Sparkles className="w-3 h-3 mr-1" />
              3D
            </Badge>
          </motion.div>
        )}

        {/* Thumbnail com gradient overlay - Usa YouTube thumbnail automática */}
        <div className="relative h-40 rounded-xl overflow-hidden mb-4 bg-surface/50">
          {(() => {
            // Prioridade: youtube_video_id > thumbnail_url > fallback
            const thumbnailUrl = exercise.youtube_video_id
              ? `https://img.youtube.com/vi/${exercise.youtube_video_id}/mqdefault.jpg`
              : exercise.thumbnail_url;
            
            return thumbnailUrl ? (
              <>
                <img 
                  src={thumbnailUrl} 
                  alt={exercise.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-bg/80 via-bg/20 to-transparent" />
              </>
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <IconComponent className="w-16 h-16 text-accent/30" />
              </div>
            );
          })()}
        </div>

        {/* Content */}
        <div className="space-y-3">
          {/* Header com categoria e dificuldade */}
          <div className="flex items-center justify-between gap-2">
            <Badge className="glass-button text-xs border border-line/30">
              <IconComponent className="w-3 h-3 mr-1" />
              <span className="line-clamp-1">{exercise.exercise_categories?.name || 'Geral'}</span>
            </Badge>
            <Badge className={`${difficultyColor} text-xs whitespace-nowrap`}>
              {difficultyText}
            </Badge>
          </div>

          {/* Título */}
          <h3 className="text-lg font-bold text-txt line-clamp-2 min-h-[3.5rem]">
            {exercise.name}
          </h3>

          {/* Músculos */}
          {exercise.primary_muscles && exercise.primary_muscles.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {exercise.primary_muscles.slice(0, 2).map((muscle, idx) => (
                <Badge 
                  key={idx} 
                  variant="outline" 
                  className="text-xs border-accent/30 text-accent bg-accent/5"
                >
                  {muscle}
                </Badge>
              ))}
              {exercise.primary_muscles.length > 2 && (
                <Badge 
                  variant="outline" 
                  className="text-xs border-accent/30 text-accent bg-accent/5"
                >
                  +{exercise.primary_muscles.length - 2}
                </Badge>
              )}
            </div>
          )}

          {/* CTA Button */}
          <Button 
            className="w-full bg-gradient-to-r from-accent to-accent hover:shadow-hover hover:scale-105 transition-all duration-300 font-semibold"
            size="lg"
            onClick={(e) => {
              e.stopPropagation();
              onSelect();
            }}
          >
            <Play className="w-4 h-4 mr-2" />
            {exercise.model_3d_url ? 'Ver em 3D' : 'Ver Detalhes'}
          </Button>
        </div>
      </VoltCard>
    </motion.div>
  );
}