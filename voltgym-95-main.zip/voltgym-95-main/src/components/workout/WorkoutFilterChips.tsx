import { motion } from 'framer-motion';
import { WorkoutFilter } from '@/hooks/useWorkoutFilters';
import { useVibration } from '@/hooks/useVibration';
import { cn } from '@/lib/utils';

interface WorkoutFilterChipsProps {
  activeFilter: WorkoutFilter;
  onFilterChange: (filter: WorkoutFilter) => void;
  counts?: Record<WorkoutFilter, number>;
}

export function WorkoutFilterChips({ activeFilter, onFilterChange, counts }: WorkoutFilterChipsProps) {
  const { vibrateClick } = useVibration();

  const filters: Array<{ id: WorkoutFilter; label: string; emoji?: string }> = [
    { id: 'all', label: 'Todos' },
    { id: 'upper', label: 'Superior', emoji: '💪' },
    { id: 'lower', label: 'Inferior', emoji: '🦵' },
    { id: 'fullbody', label: 'Full Body', emoji: '🔥' },
    { id: 'recent', label: 'Recentes', emoji: '⏱️' },
    { id: 'favorites', label: 'Favoritos', emoji: '⭐' },
  ];

  return (
    <div className="flex gap-2 overflow-x-auto scrollbar-none py-1.5 -mx-1 px-1">
      {filters.map((filter, index) => {
        const isActive = activeFilter === filter.id;
        const count = counts?.[filter.id];

        return (
          <motion.button
            key={filter.id}
            initial={{ opacity: 0, scale: 0.9, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ 
              delay: index * 0.05, 
              type: 'spring', 
              stiffness: 400, 
              damping: 25 
            }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => {
              vibrateClick();
              onFilterChange(filter.id);
            }}
            className={cn(
              // Base pill style
              'px-4 py-2.5 rounded-full text-sm font-medium',
              'whitespace-nowrap transition-all duration-200',
              'touch-manipulation flex items-center gap-1.5',
              'border backdrop-blur-xl',
              
              // Active state - iOS style
              isActive ? [
                'bg-gradient-to-br from-accent to-accent-2',
                'text-accent-ink',
                'border-accent/50',
                'shadow-lg shadow-accent/30',
              ] : [
                'bg-white/[0.08]',
                'text-txt-2',
                'border-white/10',
                'hover:bg-white/[0.12]',
                'hover:text-txt',
                'hover:border-white/20',
              ]
            )}
          >
            {filter.emoji && (
              <span className="text-sm">{filter.emoji}</span>
            )}
            <span>{filter.label}</span>
            {count !== undefined && count > 0 && (
              <span className={cn(
                "ml-1 text-xs px-1.5 py-0.5 rounded-full",
                isActive 
                  ? "bg-white/20 text-accent-ink" 
                  : "bg-white/10 text-txt-3"
              )}>
                {count}
              </span>
            )}
          </motion.button>
        );
      })}
    </div>
  );
}
