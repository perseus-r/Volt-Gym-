import { useState } from 'react';
import { 
  MoreVertical, 
  Star, 
  Share2, 
  Trash2,
  Pencil,
  Play,
  CalendarPlus
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { motion } from 'framer-motion';

interface WorkoutCardActionsProps {
  workoutId: string;
  isFavorite?: boolean;
  onStart?: () => void;
  onRename?: () => void;
  onDuplicate?: () => void;
  onToggleFavorite?: () => void;
  onShare?: () => void;
  onDelete?: () => void;
}

export function WorkoutCardActions({
  workoutId,
  isFavorite = false,
  onStart,
  onRename,
  onDuplicate,
  onToggleFavorite,
  onShare,
  onDelete,
}: WorkoutCardActionsProps) {
  const [open, setOpen] = useState(false);

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className="p-2 rounded-lg bg-surface/50 hover:bg-surface transition-colors"
          onClick={(e) => e.stopPropagation()}
        >
          <MoreVertical className="w-4 h-4 text-txt-2" />
        </motion.button>
      </DropdownMenuTrigger>

      <DropdownMenuContent align="end" className="w-48">
        {onStart && (
          <>
            <DropdownMenuItem onClick={onStart}>
              <Play className="w-4 h-4 mr-2" />
              Iniciar Treino
            </DropdownMenuItem>
            <DropdownMenuSeparator />
          </>
        )}

        {onToggleFavorite && (
          <DropdownMenuItem onClick={onToggleFavorite}>
            <Star className={`w-4 h-4 mr-2 ${isFavorite ? 'fill-yellow-500 text-yellow-500' : ''}`} />
            {isFavorite ? 'Remover dos Favoritos' : 'Adicionar aos Favoritos'}
          </DropdownMenuItem>
        )}

        {onRename && (
          <DropdownMenuItem onClick={onRename}>
            <Pencil className="w-4 h-4 mr-2" />
            Renomear
          </DropdownMenuItem>
        )}

        {onDuplicate && (
          <DropdownMenuItem onClick={onDuplicate}>
            <CalendarPlus className="w-4 h-4 mr-2" />
            Adicionar à Rotina
          </DropdownMenuItem>
        )}

        {onShare && (
          <DropdownMenuItem onClick={onShare}>
            <Share2 className="w-4 h-4 mr-2" />
            Compartilhar
          </DropdownMenuItem>
        )}

        {onDelete && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={onDelete} className="text-red-500 focus:text-red-500">
              <Trash2 className="w-4 h-4 mr-2" />
              Excluir
            </DropdownMenuItem>
          </>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}