import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { 
  Link, 
  Tag, 
  Plus, 
  X, 
  Video, 
  Youtube,
  ExternalLink,
  Info,
  Upload,
  Loader2,
  Check as CheckIcon
} from 'lucide-react';
import { toast } from 'sonner';
import { motion } from 'framer-motion';
import { useVideoUpload } from '@/hooks/useVideoUpload';
import { WorkoutVideoPlayer } from './WorkoutVideoPlayer';
import { cn } from '@/lib/utils';

interface WorkoutStepMetadataProps {
  metadata: {
    videoUrl: string;
    tags: string[];
    source: string;
    additionalNotes: string;
  };
  setMetadata: (metadata: any) => void;
  onNext: () => void;
  onPrev: () => void;
}

export function WorkoutStepMetadata({ 
  metadata, 
  setMetadata, 
  onNext, 
  onPrev 
}: WorkoutStepMetadataProps) {
  const [tagInput, setTagInput] = useState('');
  const [urlPreview, setUrlPreview] = useState<{
    valid: boolean;
    platform?: string;
  }>({ valid: false });
  const [uploadMode, setUploadMode] = useState<'url' | 'upload'>('url');
  const { uploadVideo, uploading, progress } = useVideoUpload();

  useEffect(() => {
    if (!metadata.videoUrl) {
      setUrlPreview({ valid: false });
      return;
    }

    try {
      const url = new URL(metadata.videoUrl);
      const hostname = url.hostname.toLowerCase();
      
      if (hostname.includes('youtube.com') || hostname.includes('youtu.be')) {
        setUrlPreview({ valid: true, platform: 'YouTube' });
      } else if (hostname.includes('vimeo.com')) {
        setUrlPreview({ valid: true, platform: 'Vimeo' });
      } else if (hostname.includes('instagram.com')) {
        setUrlPreview({ valid: true, platform: 'Instagram' });
      } else {
        setUrlPreview({ valid: true, platform: 'Web' });
      }
    } catch {
      setUrlPreview({ valid: false });
    }
  }, [metadata.videoUrl]);

  const addTag = () => {
    if (!tagInput.trim()) return;
    
    if (metadata.tags.includes(tagInput.toLowerCase())) {
      toast.error('Tag já adicionada');
      return;
    }

    setMetadata({
      ...metadata,
      tags: [...metadata.tags, tagInput.toLowerCase()]
    });
    setTagInput('');
  };

  const removeTag = (tagToRemove: string) => {
    setMetadata({
      ...metadata,
      tags: metadata.tags.filter(tag => tag !== tagToRemove)
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const videoUrl = await uploadVideo(file);
      setMetadata({ ...metadata, videoUrl });
      toast.success('Vídeo enviado com sucesso!');
    } catch (error: any) {
      toast.error(error.message || 'Erro ao enviar vídeo');
    }
  };

  const suggestedTags = [
    'hipertrofia', 'força', 'resistência', 'iniciante', 
    'intermediário', 'avançado', 'casa', 'academia',
    'funcional', 'mobilidade', 'cardio', 'core'
  ];

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-bold text-txt mb-2">
          Metadados e Recursos Externos
        </h3>
        <p className="text-sm text-txt-2">
          Adicione links, tags e informações extras para enriquecer o treino
        </p>
      </div>

      {/* Link de Vídeo */}
      <Card className="glass-card p-6 space-y-4">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Video className="w-5 h-5 text-accent" />
            <Label className="text-base font-semibold text-txt">
              Vídeo do Treino
            </Label>
          </div>
          
          {/* Toggle entre URL e Upload */}
          <div className="flex gap-2">
            <Button
              type="button"
              size="sm"
              variant={uploadMode === 'url' ? 'default' : 'outline'}
              onClick={() => setUploadMode('url')}
              className="text-xs"
            >
              <Link className="w-3 h-3 mr-1" />
              Link
            </Button>
            <Button
              type="button"
              size="sm"
              variant={uploadMode === 'upload' ? 'default' : 'outline'}
              onClick={() => setUploadMode('upload')}
              className="text-xs"
            >
              <Upload className="w-3 h-3 mr-1" />
              Upload
            </Button>
          </div>
        </div>
        
        <div className="space-y-3">
          {uploadMode === 'url' ? (
            <Input
              placeholder="https://youtube.com/watch?v=... ou outro link"
              value={metadata.videoUrl}
              onChange={(e) => setMetadata({ ...metadata, videoUrl: e.target.value })}
              className="font-mono text-sm"
            />
          ) : (
            <div className="space-y-3">
              <div className="relative">
                <input
                  type="file"
                  accept="video/mp4,video/webm,video/quicktime"
                  onChange={handleFileUpload}
                  disabled={uploading}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
                  id="video-upload"
                />
                <label
                  htmlFor="video-upload"
                  className={cn(
                    "flex flex-col items-center justify-center p-6 border-2 border-dashed rounded-lg transition-colors cursor-pointer",
                    uploading ? "border-accent/50 bg-accent/5 cursor-not-allowed" : "border-line hover:border-accent/50 hover:bg-accent/5"
                  )}
                >
                  {uploading ? (
                    <>
                      <Loader2 className="w-8 h-8 text-accent animate-spin mb-2" />
                      <p className="text-sm text-txt-2">Enviando vídeo... {progress}%</p>
                    </>
                  ) : metadata.videoUrl ? (
                    <>
                      <CheckIcon className="w-8 h-8 text-success mb-2" />
                      <p className="text-sm text-success font-medium">Vídeo enviado!</p>
                      <p className="text-xs text-txt-3 mt-1">Clique para substituir</p>
                    </>
                  ) : (
                    <>
                      <Upload className="w-8 h-8 text-txt-3 mb-2" />
                      <p className="text-sm text-txt-2">Clique ou arraste para enviar</p>
                      <p className="text-xs text-txt-3 mt-1">MP4, WebM ou MOV (max 50MB)</p>
                    </>
                  )}
                </label>
              </div>
            </div>
          )}
          
          {/* Preview do Link */}
          {metadata.videoUrl && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`p-3 rounded-lg border-2 ${
                urlPreview.valid 
                  ? 'bg-success/10 border-success/30 text-success' 
                  : 'bg-error/10 border-error/30 text-error'
              }`}
            >
              <div className="flex items-center gap-2">
                {urlPreview.valid ? (
                  <>
                    <ExternalLink className="w-4 h-4" />
                    <span className="text-sm font-medium">
                      Link válido{urlPreview.platform && ` - ${urlPreview.platform}`}
                    </span>
                  </>
                ) : (
                  <>
                    <Info className="w-4 h-4" />
                    <span className="text-sm font-medium">
                      URL inválida - verifique o formato
                    </span>
                  </>
                )}
              </div>
            </motion.div>
          )}

          <p className="text-xs text-txt-3 flex items-start gap-2">
            <Youtube className="w-4 h-4 mt-0.5 flex-shrink-0" />
            <span>
              {uploadMode === 'url' 
                ? 'Suporta YouTube, Vimeo, Instagram e qualquer URL de vídeo.'
                : 'Envie um vídeo de até 50MB nos formatos MP4, WebM ou MOV.'}
            </span>
          </p>

          {/* Preview do vídeo */}
          {metadata.videoUrl && (
            <div className="mt-4">
              <p className="text-xs text-txt-3 mb-2">Preview:</p>
              <WorkoutVideoPlayer 
                videoUrl={metadata.videoUrl} 
                className="rounded-lg overflow-hidden"
              />
            </div>
          )}
        </div>
      </Card>

      {/* Tags/Etiquetas */}
      <Card className="glass-card p-6 space-y-4">
        <div className="flex items-center gap-2 mb-2">
          <Tag className="w-5 h-5 text-accent" />
          <Label className="text-base font-semibold text-txt">
            Tags/Etiquetas
          </Label>
        </div>

        {/* Input de Tag */}
        <div className="flex gap-2">
          <Input
            placeholder="Digite uma tag (ex: hipertrofia)"
            value={tagInput}
            onChange={(e) => setTagInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
          />
          <Button 
            onClick={addTag}
            variant="outline"
            className="flex-shrink-0"
          >
            <Plus className="w-4 h-4" />
          </Button>
        </div>

        {/* Tags Adicionadas */}
        {metadata.tags.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {metadata.tags.map((tag) => (
              <Badge 
                key={tag}
                variant="outline"
                className="px-3 py-1 text-sm bg-accent/10 border-accent/30 text-accent"
              >
                {tag}
                <button
                  onClick={() => removeTag(tag)}
                  className="ml-2 hover:text-error transition-colors"
                >
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
          </div>
        )}

        {/* Tags Sugeridas */}
        <div>
          <p className="text-xs text-txt-3 mb-2">Tags sugeridas:</p>
          <div className="flex flex-wrap gap-2">
            {suggestedTags
              .filter(tag => !metadata.tags.includes(tag))
              .slice(0, 6)
              .map((tag) => (
                <Badge
                  key={tag}
                  variant="outline"
                  className="cursor-pointer hover:bg-accent/20 hover:border-accent/50 transition-colors"
                  onClick={() => setMetadata({
                    ...metadata,
                    tags: [...metadata.tags, tag]
                  })}
                >
                  <Plus className="w-3 h-3 mr-1" />
                  {tag}
                </Badge>
              ))}
          </div>
        </div>
      </Card>

      {/* Fonte/Autor */}
      <Card className="glass-card p-6 space-y-4">
        <Label className="text-base font-semibold text-txt">
          Fonte/Autor (opcional)
        </Label>
        <Input
          placeholder="Ex: Canal XYZ no YouTube, Treino do Atleta ABC"
          value={metadata.source}
          onChange={(e) => setMetadata({ ...metadata, source: e.target.value })}
        />
        <p className="text-xs text-txt-3">
          Credite a fonte original do treino, se aplicável
        </p>
      </Card>

      {/* Notas Adicionais */}
      <Card className="glass-card p-6 space-y-4">
        <Label className="text-base font-semibold text-txt">
          Notas Adicionais (opcional)
        </Label>
        <Textarea
          placeholder="Contexto, observações, dicas de execução..."
          value={metadata.additionalNotes}
          onChange={(e) => setMetadata({ ...metadata, additionalNotes: e.target.value })}
          rows={4}
        />
      </Card>

      {/* Navegação */}
      <div className="flex gap-3 pt-6">
        <Button
          onClick={onPrev}
          variant="outline"
          className="flex-1"
        >
          Voltar
        </Button>
        <Button
          onClick={onNext}
          className="flex-1 bg-accent text-accent-ink hover:bg-accent/90"
        >
          Revisar Treino
        </Button>
      </div>
    </div>
  );
}