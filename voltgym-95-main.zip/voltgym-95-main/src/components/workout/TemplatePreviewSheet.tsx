import { motion } from 'framer-motion';
import { X, Play, Save, Target, Clock, TrendingUp } from 'lucide-react';
import { UserWorkoutData } from '@/hooks/useUserWorkouts';
import { RippleButton } from '@/components/interactions/RippleButton';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';

interface TemplatePreviewSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  template: UserWorkoutData | null;
  onStart: () => void;
  onAddToRoutine?: () => void;
  onSaveAsTemplate?: () => void;
}

export function TemplatePreviewSheet({
  open,
  onOpenChange,
  template,
  onStart,
  onAddToRoutine,
  onSaveAsTemplate,
}: TemplatePreviewSheetProps) {
  if (!template) return null;

  const getDifficultyLevel = () => {
    const totalSets = template.exercises.reduce((sum, ex) => sum + (ex.sets || 3), 0);
    if (totalSets < 12) return { label: 'Fácil', color: 'text-green-500' };
    if (totalSets < 20) return { label: 'Médio', color: 'text-yellow-500' };
    return { label: 'Difícil', color: 'text-red-500' };
  };

  const difficulty = getDifficultyLevel();
  const estimatedTime = template.exercises.length * 8; // ~8min por exercício

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="h-[85vh] rounded-t-3xl bg-surface border-t border-border/50">
        <SheetHeader className="mb-6">
          <SheetTitle className="text-2xl font-bold text-txt">{template.name}</SheetTitle>
        </SheetHeader>

        <div className="space-y-6 overflow-y-auto max-h-[calc(85vh-180px)]">
          {/* Stats Grid */}
          <div className="grid grid-cols-3 gap-3">
            <div className="p-4 rounded-xl bg-surface/50 border border-border/50">
              <Target className="w-5 h-5 text-accent mb-2" />
              <div className="text-xs text-txt-3">Exercícios</div>
              <div className="text-lg font-bold text-txt">{template.exercises.length}</div>
            </div>
            <div className="p-4 rounded-xl bg-surface/50 border border-border/50">
              <Clock className="w-5 h-5 text-accent mb-2" />
              <div className="text-xs text-txt-3">Duração</div>
              <div className="text-lg font-bold text-txt">~{estimatedTime}min</div>
            </div>
            <div className="p-4 rounded-xl bg-surface/50 border border-border/50">
              <TrendingUp className="w-5 h-5 text-accent mb-2" />
              <div className="text-xs text-txt-3">Nível</div>
              <div className={`text-lg font-bold ${difficulty.color}`}>{difficulty.label}</div>
            </div>
          </div>

          {/* Focus */}
          <div>
            <h4 className="text-sm font-semibold text-txt mb-2">Foco do Treino</h4>
            <div className="px-3 py-2 rounded-lg bg-accent/10 border border-accent/20">
              <p className="text-sm text-accent font-medium">{template.focus}</p>
            </div>
          </div>

          {/* Exercise List */}
          <div>
            <h4 className="text-sm font-semibold text-txt mb-3">Exercícios</h4>
            <div className="space-y-2">
              {template.exercises.map((ex, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className="p-3 rounded-lg bg-surface/50 border border-border/50"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <p className="font-medium text-txt">{ex.name}</p>
                      <p className="text-xs text-txt-3 mt-0.5">
                        {ex.sets || 3} séries × {ex.reps} reps
                        {ex.weight && ex.weight > 0 && ` • ${ex.weight}kg`}
                      </p>
                    </div>
                    <div className="text-xs text-txt-3 ml-2">
                      {ex.rest || 90}s
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="absolute bottom-0 left-0 right-0 p-6 bg-surface/95 backdrop-blur-xl border-t border-border/50">
          <div className="flex gap-3">
            <RippleButton
              variant="primary"
              onClick={() => {
                onStart();
                onOpenChange(false);
              }}
              className="flex-1"
            >
              <Play className="w-4 h-4 mr-2" />
              Iniciar Agora
            </RippleButton>

            {onAddToRoutine && (
              <RippleButton
                variant="secondary"
                onClick={() => {
                  onAddToRoutine();
                  onOpenChange(false);
                }}
                className="flex-1"
              >
                Adicionar à Rotina
              </RippleButton>
            )}
            
            {onSaveAsTemplate && (
              <RippleButton
                variant="secondary"
                onClick={() => {
                  onSaveAsTemplate();
                  onOpenChange(false);
                }}
              >
                <Save className="w-4 h-4" />
              </RippleButton>
            )}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}