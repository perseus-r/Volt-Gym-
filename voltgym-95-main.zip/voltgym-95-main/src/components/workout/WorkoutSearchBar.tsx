import { Search, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';

interface WorkoutSearchBarProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

export function WorkoutSearchBar({ value, onChange, placeholder = "Buscar treinos..." }: WorkoutSearchBarProps) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ type: 'spring', stiffness: 400, damping: 30 }}
      className="relative w-full"
    >
      {/* iOS style search bar */}
      <div className={cn(
        "relative flex items-center",
        "bg-gradient-to-br from-white/[0.1] to-white/[0.04]",
        "backdrop-blur-2xl",
        "border border-white/15",
        "rounded-2xl",
        "shadow-lg shadow-black/10",
        "overflow-hidden",
        "transition-all duration-200",
        "focus-within:border-accent/40 focus-within:shadow-accent/10"
      )}>
        {/* Shine effect */}
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
        
        {/* Search icon */}
        <div className="pl-4 pr-2">
          <Search className="w-5 h-5 text-txt-3" />
        </div>
        
        {/* Input */}
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className={cn(
            "flex-1 py-3.5 pr-4",
            "bg-transparent",
            "text-txt placeholder:text-txt-3",
            "text-base font-medium",
            "focus:outline-none",
            "transition-all duration-200"
          )}
        />
        
        {/* Clear button */}
        <AnimatePresence>
          {value && (
            <motion.button
              initial={{ opacity: 0, scale: 0.5, rotate: -90 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              exit={{ opacity: 0, scale: 0.5, rotate: 90 }}
              transition={{ type: 'spring', stiffness: 500, damping: 25 }}
              onClick={() => onChange('')}
              className={cn(
                "mr-3 p-1.5 rounded-full",
                "bg-white/10 hover:bg-white/20",
                "text-txt-3 hover:text-txt",
                "transition-colors duration-150",
                "touch-manipulation"
              )}
            >
              <X className="w-4 h-4" />
            </motion.button>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
