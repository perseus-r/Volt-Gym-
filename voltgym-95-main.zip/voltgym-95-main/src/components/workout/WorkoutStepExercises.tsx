import { useState } from 'react';
import { VoltButton } from '@/components/VoltButton';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ExerciseCard } from './ExerciseCard';
import { Search, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { Stagger, Item } from '@/components/animations/Stagger';
import { useExercisesLibrary, LibraryExercise } from '@/hooks/useExercisesLibrary';
import { WorkoutExercise } from '@/types/workout.unified';

interface WorkoutStepExercisesProps {
  selectedExercises: WorkoutExercise[];
  setSelectedExercises: (exercises: WorkoutExercise[]) => void;
  onNext: () => void;
  onPrev: () => void;
}

export function WorkoutStepExercises({
  selectedExercises,
  setSelectedExercises,
  onNext,
  onPrev,
}: WorkoutStepExercisesProps) {
  const [selectedGroup, setSelectedGroup] = useState('peito');
  const [searchQuery, setSearchQuery] = useState('');
  
  const { 
    muscleGroups, 
    searchExercises, 
    getVideoUrl, 
    getThumbnailUrl,
    loading, 
    error 
  } = useExercisesLibrary();

  // Filtrar exercícios pelo grupo selecionado e busca
  const filteredExercises = searchExercises(searchQuery, selectedGroup);

  const addExercise = (exercise: LibraryExercise) => {
    const newExercise: WorkoutExercise = {
      id: `workout_${Date.now()}_${exercise.id}`,
      exercise_id: exercise.id, // Referência ao banco!
      name: exercise.name,
      group: exercise.category_name || '',
      sets: 3,
      reps: '8-12',
      weight: 0,
      rest: 90,
      notes: '',
      // Dados de vídeo
      video_url: getVideoUrl(exercise) || undefined,
      youtube_url: exercise.youtube_url || undefined,
      youtube_video_id: exercise.youtube_video_id || undefined,
      demo_video_url: exercise.demo_video_url || undefined,
      thumbnail_url: getThumbnailUrl(exercise) || undefined,
      // Instruções
      instructions: exercise.instructions || undefined,
      form_tips: exercise.form_tips || undefined,
    };

    setSelectedExercises([...selectedExercises, newExercise]);
    toast.success(`${newExercise.name} adicionado!`);
  };

  const toggleExercise = (exercise: LibraryExercise) => {
    if (isSelected(exercise.name)) {
      removeExercise(selectedExercises.find((ex) => ex.name === exercise.name)?.id || '');
    } else {
      addExercise(exercise);
    }
  };

  const removeExercise = (id: string) => {
    setSelectedExercises(selectedExercises.filter((ex) => ex.id !== id));
    toast.info('Exercício removido');
  };

  const isSelected = (exerciseName: string) =>
    selectedExercises.some((ex) => ex.name === exerciseName);

  // Estado de loading
  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-12 space-y-4">
        <Loader2 className="w-8 h-8 text-accent animate-spin" />
        <p className="text-txt-2">Carregando exercícios...</p>
      </div>
    );
  }

  // Estado de erro
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center py-12 space-y-4">
        <p className="text-destructive">{error}</p>
        <VoltButton variant="ghost" onClick={onPrev}>
          Voltar
        </VoltButton>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-2xl font-bold text-foreground mb-2">Selecione os Exercícios</h3>
        <p className="text-muted-foreground">Escolha os exercícios para o seu treino</p>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <input
          type="text"
          placeholder="Buscar exercícios..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-3 bg-secondary border border-border rounded-xl text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
        />
      </div>

      {/* Selected Count Badge */}
      {selectedExercises.length > 0 && (
        <Badge className="bg-primary/20 text-primary border-primary/50">
          {selectedExercises.length} exercício(s) selecionado(s)
        </Badge>
      )}

      {/* Muscle Group Tabs */}
      <ScrollArea className="w-full">
        <div className="flex gap-2 pb-2">
          {muscleGroups.length > 0 ? (
            muscleGroups.map((group) => (
              <button
                key={group.id}
                onClick={() => setSelectedGroup(group.id)}
                className={`px-4 py-2 rounded-lg whitespace-nowrap font-medium transition-all ${
                  selectedGroup === group.id
                    ? 'bg-primary text-primary-foreground shadow-lg'
                    : 'bg-secondary border border-border text-muted-foreground hover:bg-secondary/80'
                }`}
              >
                {group.name} ({group.count})
              </button>
            ))
          ) : (
            <p className="text-muted-foreground text-sm">Nenhum grupo muscular encontrado</p>
          )}
        </div>
      </ScrollArea>

      {/* Exercise Grid with Premium Cards */}
      {filteredExercises.length > 0 ? (
        <Stagger className="grid grid-cols-1 md:grid-cols-2 gap-3" delay={0.05}>
          {filteredExercises.map((exercise, index) => {
            const selected = isSelected(exercise.name);
            const thumbnail = getThumbnailUrl(exercise);
            return (
              <Item key={exercise.id}>
                <ExerciseCard
                  name={exercise.name}
                  group={exercise.category_name || ''}
                  isSelected={selected}
                  onToggle={() => toggleExercise(exercise)}
                  index={index}
                  thumbnailUrl={thumbnail || undefined}
                />
              </Item>
            );
          })}
        </Stagger>
      ) : (
        <div className="text-center py-8">
          <p className="text-muted-foreground">
            {searchQuery 
              ? 'Nenhum exercício encontrado para esta busca'
              : 'Nenhum exercício cadastrado neste grupo muscular'}
          </p>
        </div>
      )}

      {/* Navigation */}
      <div className="flex gap-3 pt-4">
        <VoltButton variant="ghost" onClick={onPrev} className="flex-1">
          Voltar
        </VoltButton>
        <VoltButton
          variant="primary"
          onClick={onNext}
          disabled={selectedExercises.length === 0}
          className="flex-1"
        >
          Próximo →
        </VoltButton>
      </div>
    </div>
  );
}
