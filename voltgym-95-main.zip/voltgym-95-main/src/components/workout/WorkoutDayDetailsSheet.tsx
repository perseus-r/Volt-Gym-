import React, { useState } from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { motion, AnimatePresence } from 'framer-motion';
import { Dumbbell, Clock, TrendingUp, Share2, Play, ChevronDown, X } from 'lucide-react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { RippleButton } from '@/components/interactions/RippleButton';
import { StravaStyleShareCard } from '@/components/share/StravaStyleShareCard';

interface UserWorkoutData {
  id: string;
  name: string;
  focus?: string;
  exercises: any[];
  completedAt?: Date;
  duration?: number;
  totalVolume?: number;
  averageRPE?: number;
}

interface WorkoutDayDetailsSheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  date: Date;
  workouts: UserWorkoutData[];
  onStartWorkout: (workout: UserWorkoutData) => void;
  onShareWorkout: (workout: UserWorkoutData) => void;
}

export const WorkoutDayDetailsSheet: React.FC<WorkoutDayDetailsSheetProps> = ({
  open,
  onOpenChange,
  date,
  workouts,
  onStartWorkout,
  onShareWorkout,
}) => {
  const [expandedWorkoutId, setExpandedWorkoutId] = useState<string | null>(null);
  const [shareCardOpen, setShareCardOpen] = useState(false);
  const [selectedWorkout, setSelectedWorkout] = useState<UserWorkoutData | null>(null);

  const handleShareClick = (workout: UserWorkoutData) => {
    setSelectedWorkout(workout);
    setShareCardOpen(true);
  };

  const formattedDate = format(date, "d 'de' MMMM", { locale: ptBR });

  const getIntensityColor = (rpe?: number): string => {
    if (!rpe) return 'bg-muted';
    if (rpe >= 8) return 'bg-destructive/20 border-destructive/40';
    if (rpe >= 6) return 'bg-warning/20 border-warning/40';
    return 'bg-success/20 border-success/40';
  };

  const getIntensityLabel = (rpe?: number): string => {
    if (!rpe) return 'N/A';
    if (rpe >= 8) return 'Alta';
    if (rpe >= 6) return 'Moderada';
    return 'Leve';
  };

  return (
    <>
      <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="h-[80vh] p-0">
        <SheetHeader className="p-6 pb-4 border-b border-border/50">
          <div className="flex items-center justify-between">
            <div>
              <SheetTitle className="text-2xl font-bold">Treinos de {formattedDate}</SheetTitle>
              <Badge variant="secondary" className="mt-2">
                {workouts.length} {workouts.length === 1 ? 'treino' : 'treinos'} realizados
              </Badge>
            </div>
          </div>
        </SheetHeader>

        <ScrollArea className="h-[calc(80vh-100px)] px-6 py-4">
          <div className="space-y-4">
            <AnimatePresence mode="popLayout">
              {workouts.map((workout, index) => {
                const isExpanded = expandedWorkoutId === workout.id;
                const completedExercises = workout.exercises.filter(ex => ex.completed).length;
                const totalExercises = workout.exercises.length;

                return (
                  <motion.div
                    key={workout.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <Collapsible
                      open={isExpanded}
                      onOpenChange={(open) => setExpandedWorkoutId(open ? workout.id : null)}
                    >
                      <div className={`glassmorphism-card p-5 border-2 ${getIntensityColor(workout.averageRPE)}`}>
                        <CollapsibleTrigger asChild>
                          <button className="w-full text-left">
                            <div className="flex items-start justify-between mb-4">
                              <div className="flex-1">
                                <h4 className="font-bold text-lg text-txt flex items-center gap-2 mb-1">
                                  <Dumbbell className="w-5 h-5" />
                                  {workout.name}
                                </h4>
                                {workout.focus && (
                                  <p className="text-sm text-txt-3 ml-7">{workout.focus}</p>
                                )}
                              </div>
                              <ChevronDown 
                                className={`w-5 h-5 text-txt-3 transition-transform ${isExpanded ? 'rotate-180' : ''}`}
                              />
                            </div>

                            <div className="grid grid-cols-2 gap-3 text-sm ml-7">
                              <div className="flex items-center gap-2 text-txt-2">
                                <Clock className="w-4 h-4" />
                                <span>
                                  {workout.completedAt 
                                    ? format(new Date(workout.completedAt), 'HH:mm', { locale: ptBR })
                                    : 'N/A'}
                                </span>
                              </div>
                              <div className="flex items-center gap-2 text-txt-2">
                                <Dumbbell className="w-4 h-4" />
                                <span>{completedExercises}/{totalExercises} exercícios</span>
                              </div>
                              <div className="flex items-center gap-2 text-txt-2">
                                <TrendingUp className="w-4 h-4" />
                                <span>
                                  RPE: {workout.averageRPE?.toFixed(1) || 'N/A'} ({getIntensityLabel(workout.averageRPE)})
                                </span>
                              </div>
                              <div className="flex items-center gap-2 text-txt-2">
                                <Dumbbell className="w-4 h-4" />
                                <span>
                                  {workout.totalVolume 
                                    ? `${(workout.totalVolume / 1000).toFixed(1)}k kg` 
                                    : 'N/A'}
                                </span>
                              </div>
                            </div>
                          </button>
                        </CollapsibleTrigger>

                        <CollapsibleContent>
                          <div className="mt-4 pt-4 border-t border-border/30">
                            <h5 className="text-sm font-semibold text-txt mb-3">Exercícios realizados:</h5>
                            <div className="space-y-2 mb-4">
                              {workout.exercises.map((exercise, idx) => (
                                <div 
                                  key={idx} 
                                  className="text-sm text-txt-2 flex items-center gap-2 p-2 rounded bg-background/50"
                                >
                                  <div className={`w-2 h-2 rounded-full ${exercise.completed ? 'bg-success' : 'bg-muted'}`} />
                                  <span>{exercise.name || 'Exercício sem nome'}</span>
                                  {exercise.sets && (
                                    <span className="text-txt-3 text-xs ml-auto">
                                      {exercise.sets.length} séries
                                    </span>
                                  )}
                                </div>
                              ))}
                            </div>

                            <div className="flex gap-2">
                              <RippleButton 
                                variant="secondary" 
                                size="sm" 
                                onClick={() => onStartWorkout(workout)}
                                className="flex-1"
                              >
                                <Play className="w-4 h-4 mr-2" />
                                Repetir
                              </RippleButton>
                              <RippleButton 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => handleShareClick(workout)}
                                className="flex-1"
                              >
                                <Share2 className="w-4 h-4 mr-2" />
                                Compartilhar
                              </RippleButton>
                            </div>
                          </div>
                        </CollapsibleContent>
                      </div>
                    </Collapsible>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        </ScrollArea>
      </SheetContent>
    </Sheet>

      {shareCardOpen && selectedWorkout && (
        <StravaStyleShareCard 
          workout={{
            name: selectedWorkout.name,
            focus: selectedWorkout.focus || 'Treino',
            duration_minutes: selectedWorkout.duration || Math.round((selectedWorkout.exercises?.length || 0) * 4),
            total_volume: selectedWorkout.totalVolume || 0,
            exercises: selectedWorkout.exercises || [],
            completed_at: selectedWorkout.completedAt?.toISOString() || new Date().toISOString(),
          }}
          onClose={() => {
            setShareCardOpen(false);
            setSelectedWorkout(null);
          }}
        />
      )}
    </>
  );
};
