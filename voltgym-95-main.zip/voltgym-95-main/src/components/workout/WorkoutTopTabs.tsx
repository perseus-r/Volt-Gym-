import { motion } from 'framer-motion';
import { LayoutGrid, Dumbbell, Zap, TrendingUp, Calendar, CalendarDays } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useIsMobile } from '@/hooks/use-mobile';

interface WorkoutTopTabsProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  badges?: {
    overview?: number;
    myWorkouts?: number;
    routine?: number;
    templates?: number;
    analytics?: number;
    calendar?: number;
  };
}

export function WorkoutTopTabs({ activeTab, onTabChange, badges }: WorkoutTopTabsProps) {
  const isMobile = useIsMobile();
  
  // Don't render on mobile - use MobileSegmentedControl instead
  if (isMobile) return null;

  const tabs = [
    { id: 'overview', label: 'Visão Geral', icon: LayoutGrid, badge: badges?.overview },
    { id: 'workouts', label: 'Meus Treinos', icon: Dumbbell, badge: badges?.myWorkouts },
    { id: 'routine', label: 'Rotina', icon: CalendarDays, badge: badges?.routine },
    { id: 'templates', label: 'Templates', icon: Zap, badge: badges?.templates },
    { id: 'analytics', label: 'Análise', icon: TrendingUp, badge: badges?.analytics },
    { id: 'calendar', label: 'Calendário', icon: Calendar, badge: badges?.calendar },
  ];

  return (
    <div className="sticky top-0 z-40 bg-surface/80 backdrop-blur-2xl border-b border-border/50">
      <Tabs value={activeTab} onValueChange={onTabChange} className="w-full">
        <TabsList className="w-full h-14 justify-start gap-1 bg-transparent p-2 overflow-x-auto scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            
            return (
              <TabsTrigger
                key={tab.id}
                value={tab.id}
                className="relative min-w-[120px] h-10 px-4 data-[state=active]:bg-transparent data-[state=active]:text-accent data-[state=active]:shadow-none"
              >
                <div className="flex items-center gap-2">
                  <Icon className="w-4 h-4" />
                  <span className="text-sm font-medium hidden sm:inline">{tab.label}</span>
                  {tab.badge !== undefined && tab.badge > 0 && (
                    <span className="ml-1 px-1.5 py-0.5 text-xs font-bold bg-accent/20 text-accent rounded-full">
                      {tab.badge}
                    </span>
                  )}
                </div>
                
                {isActive && (
                  <motion.div
                    layoutId="activeTabIndicator"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-accent"
                    initial={false}
                    transition={{
                      type: "spring",
                      stiffness: 500,
                      damping: 30
                    }}
                  />
                )}
              </TabsTrigger>
            );
          })}
        </TabsList>
      </Tabs>
    </div>
  );
}