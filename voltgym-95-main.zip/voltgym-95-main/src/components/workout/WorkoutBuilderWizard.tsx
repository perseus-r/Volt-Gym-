import { useState } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { motion, AnimatePresence } from 'framer-motion';
import { WorkoutStepInfo } from './WorkoutStepInfo';
import { WorkoutStepExercises } from './WorkoutStepExercises';
import { WorkoutStepAdjust } from './WorkoutStepAdjust';
import { WorkoutStepMetadata } from './WorkoutStepMetadata';
import { WorkoutStepConfirm } from './WorkoutStepConfirm';
import { WorkoutPreviewBar } from './WorkoutPreviewBar';
import { X, Check } from 'lucide-react';
import { cn } from '@/lib/utils';
import { WorkoutExercise } from '@/types/workout.unified';

interface WorkoutBuilderWizardProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (workout: any) => void;
}

export function WorkoutBuilderWizard({ isOpen, onClose, onSave }: WorkoutBuilderWizardProps) {
  const [step, setStep] = useState(1);
  const [workoutInfo, setWorkoutInfo] = useState({
    name: '',
    type: '',
    goal: ''
  });
  const [selectedExercises, setSelectedExercises] = useState<WorkoutExercise[]>([]);
  const [workoutMetadata, setWorkoutMetadata] = useState({
    videoUrl: '',
    tags: [] as string[],
    source: '',
    additionalNotes: ''
  });

  const totalSteps = 5;
  
  const steps = [
    { number: 1, title: "Informações", subtitle: "Tipo e objetivo" },
    { number: 2, title: "Exercícios", subtitle: "Selecione os exercícios" },
    { number: 3, title: "Ajustes", subtitle: "Séries e repetições" },
    { number: 4, title: "Metadados", subtitle: "Link e tags" },
    { number: 5, title: "Confirmar", subtitle: "Revisar e salvar" }
  ];

  const handleNext = () => {
    if (step < totalSteps) setStep(step + 1);
  };

  const handlePrev = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleSave = (startNow: boolean = false) => {
    console.log('🎬 Creating workout with video:', workoutMetadata.videoUrl);
    
    const workoutData = {
      name: workoutInfo.name || 'Treino Personalizado',
      description: workoutMetadata.additionalNotes || null,
      focus: `${workoutInfo.type} - ${workoutInfo.goal}`,
      video_url: workoutMetadata.videoUrl?.trim() || null,
      tags: workoutMetadata.tags,
      source: workoutMetadata.source || 'Admin - Treino Manual',
      metadata: {
        createdVia: 'admin-panel',
        difficulty: workoutInfo.goal,
        targetAudience: workoutInfo.type
      },
      exercises: selectedExercises.map(ex => ({
        exercise_id: ex.exercise_id, // Referência ao banco!
        name: ex.name,
        sets: ex.sets,
        reps: ex.reps,
        weight: ex.weight || 0,
        rest: ex.rest || 90,
        notes: ex.notes || '',
        rpe: 7,
        video_url: ex.video_url,
        youtube_url: ex.youtube_url,
        instructions: ex.instructions,
        form_tips: ex.form_tips,
      }))
    };

    console.log('📤 Workout data to save:', workoutData);
    
    onSave(workoutData);
    onClose();
    
    // Reset
    setStep(1);
    setWorkoutInfo({ name: '', type: '', goal: '' });
    setSelectedExercises([]);
    setWorkoutMetadata({ videoUrl: '', tags: [], source: '', additionalNotes: '' });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-hidden p-0 bg-gradient-to-br from-bg to-surface border-line/50">
        {/* Header Premium */}
        <div className="relative px-6 py-6 border-b border-line bg-gradient-to-r from-accent/10 via-accent-2/10 to-transparent">
          <button
            onClick={onClose}
            className="absolute right-4 top-4 p-2 rounded-xl hover:bg-surface/80 transition-colors group"
          >
            <X className="w-5 h-5 text-txt-2 group-hover:text-txt" />
          </button>
          
          <h2 className="text-2xl md:text-3xl font-bold text-txt mb-6">Criar Treino Personalizado</h2>
          
          {/* Step Indicator Premium */}
          <div className="flex items-center gap-3 md:gap-4 overflow-x-auto pb-2">
            {steps.map((s, i) => (
              <div key={s.number} className="flex items-center gap-3 flex-shrink-0">
                <div className="flex items-center gap-2">
                  {/* Step Circle */}
                  <motion.div
                    animate={{
                      scale: step === s.number ? [1, 1.1, 1] : 1,
                      boxShadow: step === s.number 
                        ? ['0 0 0 rgba(0,191,255,0.4)', '0 0 20px rgba(0,191,255,0.6)', '0 0 0 rgba(0,191,255,0.4)']
                        : '0 0 0 rgba(0,191,255,0)'
                    }}
                    transition={{
                      duration: 2,
                      repeat: step === s.number ? Infinity : 0
                    }}
                    className={cn(
                      "w-10 h-10 md:w-12 md:h-12 rounded-xl flex items-center justify-center font-bold transition-all duration-300",
                      step === s.number
                        ? "bg-accent text-accent-ink"
                        : step > s.number
                        ? "bg-green-500 text-white"
                        : "bg-surface text-txt-3 border-2 border-line"
                    )}
                  >
                    {step > s.number ? (
                      <Check className="w-5 h-5 md:w-6 md:h-6" />
                    ) : (
                      s.number
                    )}
                  </motion.div>
                  
                  {/* Step Text */}
                  <div className="hidden md:block">
                    <p className="text-xs text-txt-3 uppercase tracking-wide">{s.subtitle}</p>
                    <p className={cn(
                      "font-semibold transition-colors",
                      step === s.number ? "text-accent" : "text-txt"
                    )}>
                      {s.title}
                    </p>
                  </div>
                </div>
                
                {/* Connector Line */}
                {i < steps.length - 1 && (
                  <div className={cn(
                    "hidden md:block w-12 lg:w-16 h-1 rounded-full transition-all duration-300",
                    step > s.number ? "bg-accent/50" : "bg-line"
                  )} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="overflow-y-auto" style={{ maxHeight: 'calc(90vh - 180px)' }}>
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="p-6"
            >
              {step === 1 && (
                <WorkoutStepInfo
                  workoutInfo={workoutInfo}
                  setWorkoutInfo={setWorkoutInfo}
                  onNext={handleNext}
                />
              )}
              
              {step === 2 && (
                <WorkoutStepExercises
                  selectedExercises={selectedExercises}
                  setSelectedExercises={setSelectedExercises}
                  onNext={handleNext}
                  onPrev={handlePrev}
                />
              )}
              
              {step === 3 && (
                <WorkoutStepAdjust
                  selectedExercises={selectedExercises}
                  setSelectedExercises={setSelectedExercises}
                  onNext={handleNext}
                  onPrev={handlePrev}
                />
              )}
              
              {step === 4 && (
                <WorkoutStepMetadata
                  metadata={workoutMetadata}
                  setMetadata={setWorkoutMetadata}
                  onNext={handleNext}
                  onPrev={handlePrev}
                />
              )}
              
              {step === 5 && (
                <WorkoutStepConfirm
                  workoutInfo={workoutInfo}
                  selectedExercises={selectedExercises}
                  metadata={workoutMetadata}
                  onSave={handleSave}
                  onPrev={handlePrev}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Preview Bar */}
        {step >= 2 && (
          <WorkoutPreviewBar
            exercisesCount={selectedExercises.length}
            estimatedDuration={selectedExercises.length * 4}
          />
        )}
      </DialogContent>
    </Dialog>
  );
}
