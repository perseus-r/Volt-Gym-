import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { ExerciseDetailModal } from './ExerciseDetailModal';
import { Exercise } from '@/types/exercise';
import { Play, ChevronRight, Dumbbell, VideoOff } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';

interface ExerciseLibraryProps {
  searchQuery?: string;
}

interface Category {
  id: string;
  name: string;
  icon: string | null;
}

const categoryIcons: Record<string, string> = {
  'Peito': '💪',
  'Costas': '🔙',
  'Ombros': '🏋️',
  'Bíceps': '💪',
  'Tríceps': '💪',
  'Pernas': '🦵',
  'Braços': '💪',
  'Abdômen': '🧘',
  'Core': '🔥',
  'Glúteos': '🍑',
  'Cardio': '❤️',
  'Corpo Inteiro': '🏃',
};

const categoryOrder = ['Peito', 'Costas', 'Ombros', 'Bíceps', 'Tríceps', 'Braços', 'Pernas', 'Core', 'Abdômen', 'Glúteos', 'Cardio', 'Corpo Inteiro'];

export const ExerciseLibrary = ({ searchQuery = '' }: ExerciseLibraryProps) => {
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [exercisesRes, categoriesRes] = await Promise.all([
        supabase
          .from('exercises')
          .select(`*, exercise_categories (id, name, icon)`)
          .order('name'),
        supabase
          .from('exercise_categories')
          .select('*')
          .order('name')
      ]);

      if (exercisesRes.error) throw exercisesRes.error;
      if (categoriesRes.error) throw categoriesRes.error;

      setExercises(exercisesRes.data || []);
      setCategories(categoriesRes.data || []);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      toast.error('Erro ao carregar exercícios');
    } finally {
      setLoading(false);
    }
  };

  const exercisesByCategory = useMemo(() => {
    const filtered = searchQuery
      ? exercises.filter(ex =>
          ex.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          ex.primary_muscles?.some(m => m.toLowerCase().includes(searchQuery.toLowerCase()))
        )
      : exercises;

    const grouped: Record<string, Exercise[]> = {};
    filtered.forEach(exercise => {
      const categoryName = exercise.exercise_categories?.name || 'Outros';
      if (!grouped[categoryName]) grouped[categoryName] = [];
      grouped[categoryName].push(exercise);
    });

    return grouped;
  }, [exercises, searchQuery]);

  const sortedCategories = useMemo(() => {
    return Object.keys(exercisesByCategory).sort((a, b) => {
      const indexA = categoryOrder.indexOf(a);
      const indexB = categoryOrder.indexOf(b);
      if (indexA === -1 && indexB === -1) return a.localeCompare(b);
      if (indexA === -1) return 1;
      if (indexB === -1) return -1;
      return indexA - indexB;
    });
  }, [exercisesByCategory]);

  if (loading) {
    return (
      <div className="space-y-6">
        {[1, 2, 3].map(i => (
          <div key={i} className="space-y-3">
            <Skeleton className="h-6 w-32" />
            <div className="flex gap-3 overflow-hidden">
              {[1, 2, 3].map(j => (
                <Skeleton key={j} className="w-36 h-48 rounded-xl flex-shrink-0" />
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (sortedCategories.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <div className="w-16 h-16 rounded-2xl bg-muted/50 flex items-center justify-center mb-4">
          <Dumbbell className="w-8 h-8 text-muted-foreground" />
        </div>
        <h3 className="text-lg font-medium text-foreground mb-2">
          Nenhum exercício encontrado
        </h3>
        <p className="text-sm text-muted-foreground">
          {searchQuery ? 'Tente uma busca diferente' : 'Nenhum exercício cadastrado'}
        </p>
      </div>
    );
  }

  return (
    <>
      <ExerciseDetailModal
        exercise={selectedExercise}
        isOpen={!!selectedExercise}
        onClose={() => setSelectedExercise(null)}
      />

      <div className="space-y-6">
        {sortedCategories.map((categoryName, categoryIndex) => (
          <motion.section
            key={categoryName}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: categoryIndex * 0.08, duration: 0.4 }}
            className="space-y-3"
          >
            {/* Category Header */}
            <div className="flex items-center justify-between px-1">
              <div className="flex items-center gap-2">
                <span className="text-lg">{categoryIcons[categoryName] || '💪'}</span>
                <h2 className="font-semibold text-foreground">{categoryName}</h2>
                <span className="text-xs text-muted-foreground bg-muted/50 px-2 py-0.5 rounded-full">
                  {exercisesByCategory[categoryName].length}
                </span>
                {/* Video counter */}
                {(() => {
                  const withVideo = exercisesByCategory[categoryName].filter(
                    ex => ex.youtube_url || ex.youtube_video_id || ex.demo_video_url
                  ).length;
                  const total = exercisesByCategory[categoryName].length;
                  return (
                    <span className={cn(
                      "text-xs px-2 py-0.5 rounded-full flex items-center gap-1",
                      withVideo === total ? "bg-green-500/20 text-green-500" : "bg-orange-500/20 text-orange-500"
                    )}>
                      🎬 {withVideo}/{total}
                    </span>
                  );
                })()}
              </div>
              <ChevronRight className="w-4 h-4 text-muted-foreground" />
            </div>

            {/* Horizontal Scroll */}
            <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide -mx-1 px-1">
              {exercisesByCategory[categoryName].map((exercise, index) => (
                <ExerciseCard
                  key={exercise.id}
                  exercise={exercise}
                  onSelect={() => setSelectedExercise(exercise)}
                  index={index}
                />
              ))}
            </div>
          </motion.section>
        ))}
      </div>
    </>
  );
};

interface ExerciseCardProps {
  exercise: Exercise;
  onSelect: () => void;
  index: number;
}

function ExerciseCard({ exercise, onSelect, index }: ExerciseCardProps) {
  // Prioridade: thumbnail específico > YouTube ID > demo_video_url (sem thumbnail)
  const thumbnailUrl = exercise.thumbnail_url && !exercise.thumbnail_url.includes('example.com')
    ? exercise.thumbnail_url
    : exercise.youtube_video_id
      ? `https://img.youtube.com/vi/${exercise.youtube_video_id}/mqdefault.jpg`
      : null;

  const hasVideo = !!(exercise.youtube_url || exercise.youtube_video_id || exercise.demo_video_url);

  return (
    <motion.button
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: index * 0.04, duration: 0.3 }}
      onClick={onSelect}
      className={cn(
        "flex-shrink-0 w-36 group",
        "focus:outline-none focus-visible:ring-2 focus-visible:ring-primary rounded-xl"
      )}
    >
      {/* Thumbnail */}
      <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-muted/50 mb-2">
        {thumbnailUrl && !thumbnailUrl.includes('example.com') ? (
          <img
            src={thumbnailUrl}
            alt={exercise.name}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-muted to-muted/50">
            <span className="text-3xl opacity-50">💪</span>
          </div>
        )}

        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

        {/* Video indicator */}
        {hasVideo ? (
          <div className="absolute top-2 right-2 w-7 h-7 rounded-full bg-primary/90 flex items-center justify-center shadow-lg">
            <Play className="w-3.5 h-3.5 text-primary-foreground fill-current ml-0.5" />
          </div>
        ) : (
          <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-orange-500/90 flex items-center gap-1 shadow-lg">
            <VideoOff className="w-3 h-3 text-white" />
            <span className="text-[10px] text-white font-medium">Sem vídeo</span>
          </div>
        )}

        {/* Difficulty badge */}
        {exercise.difficulty_level && (
          <div className="absolute bottom-2 left-2">
            <span className={cn(
              "text-[10px] font-medium px-2 py-0.5 rounded-full",
              exercise.difficulty_level === 1 && "bg-green-500/90 text-white",
              exercise.difficulty_level === 2 && "bg-yellow-500/90 text-white",
              exercise.difficulty_level === 3 && "bg-red-500/90 text-white"
            )}>
              {exercise.difficulty_level === 1 ? 'Fácil' : exercise.difficulty_level === 2 ? 'Médio' : 'Difícil'}
            </span>
          </div>
        )}
      </div>

      {/* Info */}
      <div className="text-left px-1">
        <h3 className="text-sm font-medium text-foreground line-clamp-2 leading-tight">
          {exercise.name}
        </h3>
        {exercise.primary_muscles && exercise.primary_muscles.length > 0 && (
          <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">
            {exercise.primary_muscles.slice(0, 2).join(', ')}
          </p>
        )}
      </div>
    </motion.button>
  );
}