import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { LucideIcon, Eye, EyeOff } from 'lucide-react';
import { cn } from '@/lib/utils';

interface PremiumInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'prefix'> {
  label?: string;
  error?: string;
  hint?: string;
  icon?: LucideIcon;
  iconLeft?: LucideIcon;
  iconRight?: LucideIcon;
  iconPosition?: 'left' | 'right';
  variant?: 'default' | 'glass' | 'minimal';
  success?: boolean;
}

export function PremiumInput({
  label,
  error,
  hint,
  icon: Icon,
  iconLeft: IconLeft,
  iconRight: IconRight,
  iconPosition = 'left',
  variant = 'default',
  success = false,
  type = 'text',
  className,
  disabled,
  ...props
}: PremiumInputProps) {
  const [isFocused, setIsFocused] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  
  const LeftIcon = IconLeft || (iconPosition === 'left' ? Icon : undefined);
  const RightIcon = IconRight || (iconPosition === 'right' ? Icon : undefined);
  const isPassword = type === 'password';
  const inputType = isPassword && showPassword ? 'text' : type;

  const variantStyles = {
    default: cn(
      'bg-input-bg border-input-border',
      'focus:border-accent focus:ring-2 focus:ring-accent/20'
    ),
    glass: cn(
      'glass-subtle border-white/10',
      'focus:border-accent/50 focus:ring-2 focus:ring-accent/20',
      'backdrop-blur-xl'
    ),
    minimal: cn(
      'bg-transparent border-b-2 border-line rounded-none',
      'focus:border-accent px-0'
    ),
  };

  return (
    <div className="space-y-2">
      {/* Label */}
      {label && (
        <motion.label
          initial={false}
          animate={{
            color: error ? 'hsl(var(--error))' : success ? 'hsl(var(--success))' : 'hsl(var(--txt-2))'
          }}
          className="text-label block"
        >
          {label}
        </motion.label>
      )}

      {/* Input Container */}
      <div className="relative">
        {/* Left Icon */}
        {LeftIcon && (
          <div className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none">
            <LeftIcon className={cn(
              'w-5 h-5 transition-colors duration-200',
              error ? 'text-error' : success ? 'text-success' : isFocused ? 'text-accent' : 'text-txt-3'
            )} />
          </div>
        )}

        {/* Input */}
        <input
          {...props}
          type={inputType}
          disabled={disabled}
          onFocus={(e) => {
            setIsFocused(true);
            props.onFocus?.(e);
          }}
          onBlur={(e) => {
            setIsFocused(false);
            props.onBlur?.(e);
          }}
          className={cn(
            // Base styles
            'w-full px-4 py-3 rounded-xl',
            'text-body-premium text-txt',
            'border transition-all duration-200',
            'placeholder:text-txt-3',
            'disabled:opacity-50 disabled:cursor-not-allowed',
            
            // Icon padding
            LeftIcon && 'pl-12',
            RightIcon && 'pr-12',
            isPassword && 'pr-12',
            
            // Variant styles
            variantStyles[variant],
            
            // State styles
            error && 'border-error focus:ring-error/20',
            success && 'border-success focus:ring-success/20',
            
            className
          )}
        />

        {/* Right Icon or Password Toggle */}
        {RightIcon || isPassword ? (
          <div className="absolute right-4 top-1/2 -translate-y-1/2">
            {isPassword ? (
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="p-1 rounded-lg hover:bg-white/10 transition-colors"
              >
                {showPassword ? (
                  <EyeOff className="w-5 h-5 text-txt-3" />
                ) : (
                  <Eye className="w-5 h-5 text-txt-3" />
                )}
              </button>
            ) : RightIcon ? (
              <RightIcon className={cn(
                'w-5 h-5 transition-colors duration-200',
                error ? 'text-error' : success ? 'text-success' : isFocused ? 'text-accent' : 'text-txt-3'
              )} />
            ) : null}
          </div>
        ) : null}

        {/* Focus ring animation */}
        {isFocused && variant !== 'minimal' && (
          <motion.div
            layoutId="input-focus"
            className={cn(
              'absolute inset-0 rounded-xl pointer-events-none',
              'ring-2',
              error ? 'ring-error/20' : success ? 'ring-success/20' : 'ring-accent/20'
            )}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />
        )}
      </div>

      {/* Error or Hint */}
      {(error || hint) && (
        <motion.p
          initial={{ opacity: 0, y: -5 }}
          animate={{ opacity: 1, y: 0 }}
          className={cn(
            'text-caption',
            error ? 'text-error' : 'text-txt-3'
          )}
        >
          {error || hint}
        </motion.p>
      )}
    </div>
  );
}
