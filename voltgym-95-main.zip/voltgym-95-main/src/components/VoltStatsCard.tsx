import React from 'react';
import { motion } from 'framer-motion';
import { LucideIcon, TrendingUp, TrendingDown } from 'lucide-react';
import { cn } from '@/lib/utils';

interface VoltStatsCardProps {
  value: string | number;
  label: string;
  icon: LucideIcon;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
  color?: 'accent' | 'green' | 'purple' | 'orange';
  className?: string;
  animated?: boolean;
}

export function VoltStatsCard({
  value,
  label,
  icon: Icon,
  trend = 'neutral',
  trendValue,
  color = 'accent',
  className,
  animated = true
}: VoltStatsCardProps) {
  const colorClasses = {
    accent: 'text-accent shadow-accent/20',
    green: 'text-green-500 shadow-green-500/20',
    purple: 'text-purple-500 shadow-purple-500/20',
    orange: 'text-orange-500 shadow-orange-500/20',
  };

  const trendColors = {
    up: 'text-green-500',
    down: 'text-red-500',
    neutral: 'text-txt-2',
  };

  return (
    <motion.div
      initial={animated ? { opacity: 0, y: 20 } : {}}
      animate={animated ? { opacity: 1, y: 0 } : {}}
      whileHover={{ scale: 1.02, y: -2 }}
      transition={{ duration: 0.2 }}
      className={cn(
        "backdrop-blur-xl border border-white/10 rounded-2xl p-6",
        "bg-gradient-to-br from-white/5 to-white/[0.02]",
        "shadow-xl hover:shadow-2xl transition-all duration-300",
        className
      )}
    >
      <div className="flex items-start justify-between mb-4">
        <motion.div
          className={cn("p-3 rounded-xl backdrop-blur-sm", colorClasses[color])}
          animate={animated ? { 
            boxShadow: [
              '0 0 20px rgba(0, 191, 255, 0.2)',
              '0 0 30px rgba(0, 191, 255, 0.4)',
              '0 0 20px rgba(0, 191, 255, 0.2)',
            ]
          } : {}}
          transition={{ duration: 3, repeat: Infinity }}
        >
          <Icon className="w-6 h-6" />
        </motion.div>

        {trend !== 'neutral' && trendValue && (
          <div className={cn("flex items-center gap-1 text-sm font-medium", trendColors[trend])}>
            {trend === 'up' ? (
              <TrendingUp className="w-4 h-4" />
            ) : (
              <TrendingDown className="w-4 h-4" />
            )}
            <span>{trendValue}</span>
          </div>
        )}
      </div>

      <motion.div
        initial={animated ? { opacity: 0, scale: 0.8 } : {}}
        animate={animated ? { opacity: 1, scale: 1 } : {}}
        transition={{ delay: 0.2, duration: 0.4 }}
        className="space-y-1"
      >
        <h3 className="text-3xl font-bold text-txt">{value}</h3>
        <p className="text-sm text-txt-2">{label}</p>
      </motion.div>
    </motion.div>
  );
}
