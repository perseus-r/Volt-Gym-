import React, { useState, useEffect } from 'react';
import { Award, Trophy, Star, Flame, Target, Filter, Sparkles } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AchievementService, Achievement, AchievementCategory, AchievementRarity } from '@/services/AchievementService';
import { AchievementCard } from '@/components/achievements/AchievementCard';
import { AchievementUnlockModal } from '@/components/achievements/AchievementUnlockModal';
import { motion, AnimatePresence } from 'framer-motion';

type StatusFilter = 'all' | 'unlocked' | 'in-progress' | 'secret';

const categoryLabels: Record<AchievementCategory | 'all', string> = {
  all: 'Todas',
  streak: 'Sequência',
  volume: 'Volume',
  consistency: 'Consistência',
  milestone: 'Marcos',
  special: 'Especial',
  strength: 'Força',
  social: 'Social',
  nutrition: 'Nutrição',
  secret: 'Secreto'
};

const statusLabels: Record<StatusFilter, string> = {
  all: 'Todas',
  unlocked: 'Desbloqueadas',
  'in-progress': 'Em Progresso',
  secret: 'Secretas'
};

const rarityOrder: Record<AchievementRarity, number> = {
  legendary: 4,
  epic: 3,
  rare: 2,
  common: 1
};

export function AchievementsSection() {
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(true);
  const [categoryFilter, setCategoryFilter] = useState<AchievementCategory | 'all'>('all');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [selectedAchievement, setSelectedAchievement] = useState<Achievement | null>(null);

  useEffect(() => {
    loadAchievements();
  }, []);

  const loadAchievements = async () => {
    try {
      const data = await AchievementService.getAllAchievements();
      setAchievements(data);
    } catch (error) {
      console.error('Error loading achievements:', error);
    } finally {
      setLoading(false);
    }
  };

  // Filter logic
  const filteredAchievements = achievements.filter(a => {
    if (categoryFilter !== 'all' && a.category !== categoryFilter) return false;
    if (statusFilter === 'unlocked' && !a.isUnlocked) return false;
    if (statusFilter === 'in-progress' && (a.isUnlocked || a.isSecret)) return false;
    if (statusFilter === 'secret' && !a.isSecret) return false;
    return true;
  }).sort((a, b) => {
    // Unlocked first, then by rarity, then by progress %
    if (a.isUnlocked !== b.isUnlocked) return a.isUnlocked ? -1 : 1;
    if (rarityOrder[a.rarity] !== rarityOrder[b.rarity]) {
      return rarityOrder[b.rarity] - rarityOrder[a.rarity];
    }
    return (b.progress / b.maxProgress) - (a.progress / a.maxProgress);
  });

  // Almost there section (80%+ progress, not unlocked)
  const almostThere = achievements
    .filter(a => !a.isUnlocked && !a.isSecret && (a.progress / a.maxProgress) >= 0.8)
    .sort((a, b) => (b.progress / b.maxProgress) - (a.progress / a.maxProgress))
    .slice(0, 3);

  // Stats
  const earnedAchievements = achievements.filter(a => a.isUnlocked);
  const totalXP = earnedAchievements.reduce((sum, a) => sum + a.xpReward, 0);
  const epicLegendary = earnedAchievements.filter(a => a.rarity === 'legendary' || a.rarity === 'epic').length;
  const completionPercent = achievements.length > 0 
    ? Math.round((earnedAchievements.length / achievements.length) * 100) 
    : 0;

  const handleAchievementClick = (achievement: Achievement) => {
    if (achievement.isUnlocked) {
      setSelectedAchievement(achievement);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <Card key={i} className="glass animate-pulse">
              <CardContent className="p-4 h-24" />
            </Card>
          ))}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <Card key={i} className="glass animate-pulse">
              <CardContent className="p-4 h-32" />
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
        <Card className="glass text-center">
          <CardContent className="p-3 md:p-4">
            <Trophy className="w-6 h-6 md:w-8 md:h-8 text-accent mx-auto mb-2" />
            <div className="text-xl md:text-2xl font-bold text-txt mb-1">{earnedAchievements.length}</div>
            <div className="text-[10px] md:text-xs text-txt-2">Conquistas</div>
          </CardContent>
        </Card>
        
        <Card className="glass text-center">
          <CardContent className="p-3 md:p-4">
            <Star className="w-6 h-6 md:w-8 md:h-8 text-yellow-400 mx-auto mb-2" />
            <div className="text-xl md:text-2xl font-bold text-txt mb-1">{totalXP.toLocaleString()}</div>
            <div className="text-[10px] md:text-xs text-txt-2">XP Total</div>
          </CardContent>
        </Card>
        
        <Card className="glass text-center">
          <CardContent className="p-3 md:p-4">
            <Award className="w-6 h-6 md:w-8 md:h-8 text-purple-400 mx-auto mb-2" />
            <div className="text-xl md:text-2xl font-bold text-txt mb-1">{epicLegendary}</div>
            <div className="text-[10px] md:text-xs text-txt-2">Épicas/Lendárias</div>
          </CardContent>
        </Card>
        
        <Card className="glass text-center">
          <CardContent className="p-3 md:p-4">
            <Flame className="w-6 h-6 md:w-8 md:h-8 text-orange-400 mx-auto mb-2" />
            <div className="text-xl md:text-2xl font-bold text-txt mb-1">{completionPercent}%</div>
            <div className="text-[10px] md:text-xs text-txt-2">Completude</div>
          </CardContent>
        </Card>
      </div>

      {/* Almost There Section */}
      {almostThere.length > 0 && (
        <Card className="glass border-accent/30 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-accent/5 via-transparent to-accent/5 pointer-events-none" />
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-txt text-base md:text-lg">
              <Sparkles className="w-5 h-5 text-accent animate-pulse" />
              Quase Lá!
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {almostThere.map((achievement, index) => (
                <motion.div
                  key={achievement.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <AchievementCard
                    achievement={achievement}
                    showProgress
                    compact
                    onClick={() => handleAchievementClick(achievement)}
                  />
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Filters */}
      <div className="space-y-3">
        {/* Status Filter */}
        <Tabs value={statusFilter} onValueChange={(v) => setStatusFilter(v as StatusFilter)}>
          <TabsList className="w-full grid grid-cols-4 h-auto">
            {(Object.keys(statusLabels) as StatusFilter[]).map(status => (
              <TabsTrigger 
                key={status} 
                value={status}
                className="text-xs md:text-sm py-2"
              >
                {statusLabels[status]}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>

        {/* Category Filter */}
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {(Object.keys(categoryLabels) as (AchievementCategory | 'all')[]).map(category => (
            <Badge
              key={category}
              variant={categoryFilter === category ? 'default' : 'outline'}
              className={`cursor-pointer whitespace-nowrap shrink-0 transition-all ${
                categoryFilter === category 
                  ? 'bg-accent text-accent-foreground' 
                  : 'hover:bg-accent/20'
              }`}
              onClick={() => setCategoryFilter(category)}
            >
              {categoryLabels[category]}
            </Badge>
          ))}
        </div>
      </div>

      {/* Achievements Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
        <AnimatePresence mode="popLayout">
          {filteredAchievements.map((achievement, index) => (
            <motion.div
              key={achievement.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ delay: Math.min(index * 0.03, 0.3) }}
            >
              <AchievementCard
                achievement={achievement}
                showProgress={!achievement.isUnlocked}
                onClick={() => handleAchievementClick(achievement)}
              />
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Empty State */}
      {filteredAchievements.length === 0 && (
        <Card className="glass">
          <CardContent className="p-8 text-center">
            <Filter className="w-12 h-12 text-txt-3 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-txt mb-2">
              Nenhuma conquista encontrada
            </h3>
            <p className="text-sm text-txt-2">
              Tente ajustar os filtros para ver mais conquistas.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Achievement Modal */}
      <AchievementUnlockModal
        achievement={selectedAchievement}
        onClose={() => setSelectedAchievement(null)}
      />
    </div>
  );
}
