import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Flame, Dumbbell, Medal, TrendingUp } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useWeeklyCompetitions, CompetitionEntry } from '@/hooks/useWeeklyCompetitions';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export function WeeklyLeaderboard() {
  const { volumeLeaderboard, workoutsLeaderboard, loading } = useWeeklyCompetitions();

  if (loading) {
    return (
      <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
        <CardContent className="p-6">
          <div className="flex items-center justify-center h-40">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-border/50 bg-card/50 backdrop-blur-sm overflow-hidden">
      <CardHeader className="pb-2 bg-gradient-to-r from-primary/10 to-transparent">
        <CardTitle className="flex items-center gap-2">
          <Trophy className="h-5 w-5 text-primary" />
          Ranking Semanal
        </CardTitle>
        {volumeLeaderboard?.competition && (
          <p className="text-xs text-muted-foreground">
            {format(new Date(volumeLeaderboard.competition.weekStart), "dd 'de' MMMM", { locale: ptBR })} - {format(new Date(volumeLeaderboard.competition.weekEnd), "dd 'de' MMMM", { locale: ptBR })}
          </p>
        )}
      </CardHeader>
      
      <CardContent className="p-4">
        <Tabs defaultValue="volume" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="volume" className="gap-1.5 text-xs">
              <Dumbbell className="h-3.5 w-3.5" />
              Volume
            </TabsTrigger>
            <TabsTrigger value="workouts" className="gap-1.5 text-xs">
              <Flame className="h-3.5 w-3.5" />
              Treinos
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="volume" className="mt-0">
            <LeaderboardList 
              entries={volumeLeaderboard?.entries || []}
              myEntry={volumeLeaderboard?.myEntry}
              friendsEntries={volumeLeaderboard?.friendsEntries || []}
              formatScore={(score) => `${(score / 1000).toFixed(1)}k kg`}
            />
          </TabsContent>
          
          <TabsContent value="workouts" className="mt-0">
            <LeaderboardList 
              entries={workoutsLeaderboard?.entries || []}
              myEntry={workoutsLeaderboard?.myEntry}
              friendsEntries={workoutsLeaderboard?.friendsEntries || []}
              formatScore={(score) => `${score} treinos`}
            />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

interface LeaderboardListProps {
  entries: CompetitionEntry[];
  myEntry: CompetitionEntry | null;
  friendsEntries: CompetitionEntry[];
  formatScore: (score: number) => string;
}

function LeaderboardList({ entries, myEntry, friendsEntries, formatScore }: LeaderboardListProps) {
  // Show friends ranking if available, otherwise show global
  const displayEntries = friendsEntries.length > 1 ? friendsEntries : entries.slice(0, 10);
  const showingFriends = friendsEntries.length > 1;

  if (entries.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <TrendingUp className="h-10 w-10 mx-auto mb-2 opacity-50" />
        <p>Nenhum dado ainda esta semana</p>
        <p className="text-sm">Treine para aparecer no ranking!</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* My position highlight */}
      {myEntry && myEntry.rankPosition && myEntry.rankPosition > 3 && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-3 rounded-lg bg-primary/10 border border-primary/20"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Badge variant="secondary" className="font-bold">
                #{myEntry.rankPosition}
              </Badge>
              <span className="font-medium">Sua posição</span>
            </div>
            <span className="font-semibold text-primary">{formatScore(myEntry.score)}</span>
          </div>
        </motion.div>
      )}
      
      {/* Toggle indicator */}
      {showingFriends && (
        <Badge variant="outline" className="text-xs gap-1">
          <Medal className="h-3 w-3" />
          Ranking entre amigos
        </Badge>
      )}
      
      {/* Leaderboard */}
      <ScrollArea className="h-[250px] pr-2">
        <div className="space-y-2">
          {displayEntries.map((entry, index) => (
            <LeaderboardRow 
              key={entry.id} 
              entry={entry} 
              index={index}
              formatScore={formatScore}
            />
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}

interface LeaderboardRowProps {
  entry: CompetitionEntry;
  index: number;
  formatScore: (score: number) => string;
}

function LeaderboardRow({ entry, index, formatScore }: LeaderboardRowProps) {
  const rank = entry.rankPosition || index + 1;
  
  const rankStyles = {
    1: 'bg-gradient-to-r from-yellow-500/20 to-transparent border-yellow-500/30',
    2: 'bg-gradient-to-r from-gray-400/20 to-transparent border-gray-400/30',
    3: 'bg-gradient-to-r from-amber-600/20 to-transparent border-amber-600/30',
  };
  
  const rankColors = {
    1: 'text-yellow-500',
    2: 'text-gray-400',
    3: 'text-amber-600',
  };
  
  const isTopThree = rank <= 3;
  const style = isTopThree ? rankStyles[rank as keyof typeof rankStyles] : '';
  const rankColor = isTopThree ? rankColors[rank as keyof typeof rankColors] : 'text-muted-foreground';

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05 }}
      className={`flex items-center justify-between p-3 rounded-lg border transition-colors
        ${entry.isCurrentUser ? 'ring-2 ring-primary/50 bg-primary/5' : 'bg-background/50 hover:bg-background/80'}
        ${style}
      `}
    >
      <div className="flex items-center gap-3">
        {/* Rank */}
        <div className={`w-8 text-center font-bold ${rankColor}`}>
          {rank === 1 ? (
            <Trophy className="h-5 w-5 mx-auto text-yellow-500" />
          ) : rank === 2 ? (
            <Medal className="h-5 w-5 mx-auto text-gray-400" />
          ) : rank === 3 ? (
            <Medal className="h-5 w-5 mx-auto text-amber-600" />
          ) : (
            `#${rank}`
          )}
        </div>
        
        {/* Avatar */}
        <Avatar className={`h-9 w-9 ${isTopThree ? 'ring-2' : ''} ${
          rank === 1 ? 'ring-yellow-500' : rank === 2 ? 'ring-gray-400' : rank === 3 ? 'ring-amber-600' : ''
        }`}>
          <AvatarImage src={entry.avatarUrl || undefined} />
          <AvatarFallback className="text-xs">
            {entry.displayName.slice(0, 2).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        
        {/* Name */}
        <div className="flex flex-col">
          <span className={`font-medium text-sm ${entry.isCurrentUser ? 'text-primary' : ''}`}>
            {entry.isCurrentUser ? 'Você' : entry.displayName}
          </span>
          {entry.isFriend && !entry.isCurrentUser && (
            <span className="text-xs text-muted-foreground">Amigo</span>
          )}
        </div>
      </div>
      
      {/* Score */}
      <span className={`font-semibold ${isTopThree ? rankColor : entry.isCurrentUser ? 'text-primary' : ''}`}>
        {formatScore(entry.score)}
      </span>
    </motion.div>
  );
}
