import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Plus, Flame, Dumbbell, Calendar, Trophy,
  Users, Clock, Zap, ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useFriendships } from '@/hooks/useFriendships';
import { useChallenges, CreateChallengeData, ChallengeType, StakeType } from '@/hooks/useChallenges';
import { addDays, format } from 'date-fns';

interface CreateChallengeModalProps {
  trigger?: React.ReactNode;
  onCreated?: () => void;
}

export function CreateChallengeModal({ trigger, onCreated }: CreateChallengeModalProps) {
  const { friends } = useFriendships();
  const { createChallenge } = useChallenges();
  
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(1);
  const [isCreating, setIsCreating] = useState(false);
  
  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [challengeType, setChallengeType] = useState<ChallengeType>('volume');
  const [duration, setDuration] = useState('7');
  const [stakeType, setStakeType] = useState<StakeType>('xp');
  const [stakeValue, setStakeValue] = useState('100');
  const [selectedFriends, setSelectedFriends] = useState<string[]>([]);

  const resetForm = () => {
    setStep(1);
    setTitle('');
    setDescription('');
    setChallengeType('volume');
    setDuration('7');
    setStakeType('xp');
    setStakeValue('100');
    setSelectedFriends([]);
  };

  const handleCreate = async () => {
    if (selectedFriends.length === 0) return;
    
    setIsCreating(true);
    
    const startDate = new Date();
    const endDate = addDays(startDate, parseInt(duration));
    
    const data: CreateChallengeData = {
      title: title || getDefaultTitle(),
      description,
      challengeType,
      startDate,
      endDate,
      stakeType,
      stakeValue: parseInt(stakeValue) || 0,
      visibility: 'friends',
      participantIds: selectedFriends,
    };
    
    const result = await createChallenge(data);
    
    setIsCreating(false);
    
    if (result.success) {
      setOpen(false);
      resetForm();
      onCreated?.();
    }
  };

  const getDefaultTitle = () => {
    const titles = {
      streak: 'Duelo de Streak',
      volume: 'Desafio de Volume',
      workouts: 'Maratona de Treinos',
      custom: 'Desafio Personalizado',
    };
    return titles[challengeType];
  };

  const toggleFriend = (friendId: string) => {
    setSelectedFriends(prev => 
      prev.includes(friendId) 
        ? prev.filter(id => id !== friendId)
        : [...prev, friendId]
    );
  };

  const typeOptions = [
    { value: 'volume', label: 'Volume Total', icon: Dumbbell, description: 'Quem levantar mais peso total' },
    { value: 'workouts', label: 'Qtd. Treinos', icon: Calendar, description: 'Quem fizer mais treinos' },
    { value: 'streak', label: 'Streak', icon: Flame, description: 'Quem mantiver o maior streak' },
  ];

  const durationOptions = [
    { value: '7', label: '1 Semana' },
    { value: '14', label: '2 Semanas' },
    { value: '30', label: '1 Mês' },
  ];

  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) resetForm(); }}>
      <DialogTrigger asChild>
        {trigger || (
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Criar Desafio
          </Button>
        )}
      </DialogTrigger>
      
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-primary" />
            Criar Desafio
          </DialogTitle>
        </DialogHeader>
        
        <div className="pt-4">
          {/* Step indicators */}
          <div className="flex items-center justify-center gap-2 mb-6">
            {[1, 2, 3].map((s) => (
              <div
                key={s}
                className={`h-2 w-8 rounded-full transition-colors ${
                  s === step ? 'bg-primary' : s < step ? 'bg-primary/50' : 'bg-muted'
                }`}
              />
            ))}
          </div>
          
          <AnimatePresence mode="wait">
            {/* Step 1: Choose Type */}
            {step === 1 && (
              <motion.div
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
              >
                <div>
                  <Label className="text-base font-medium">Tipo de Desafio</Label>
                  <p className="text-sm text-muted-foreground mb-3">
                    Como vocês vão competir?
                  </p>
                  
                  <div className="space-y-2">
                    {typeOptions.map((option) => {
                      const Icon = option.icon;
                      const isSelected = challengeType === option.value;
                      
                      return (
                        <div
                          key={option.value}
                          onClick={() => setChallengeType(option.value as ChallengeType)}
                          className={`p-3 rounded-lg border-2 cursor-pointer transition-all flex items-center gap-3
                            ${isSelected 
                              ? 'border-primary bg-primary/5' 
                              : 'border-border hover:border-primary/50'
                            }
                          `}
                        >
                          <div className={`p-2 rounded-lg ${isSelected ? 'bg-primary/10' : 'bg-muted'}`}>
                            <Icon className={`h-5 w-5 ${isSelected ? 'text-primary' : 'text-muted-foreground'}`} />
                          </div>
                          <div className="flex-1">
                            <p className="font-medium text-sm">{option.label}</p>
                            <p className="text-xs text-muted-foreground">{option.description}</p>
                          </div>
                          <ChevronRight className={`h-4 w-4 ${isSelected ? 'text-primary' : 'text-muted-foreground'}`} />
                        </div>
                      );
                    })}
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label>Duração</Label>
                    <Select value={duration} onValueChange={setDuration}>
                      <SelectTrigger className="mt-1.5">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {durationOptions.map((opt) => (
                          <SelectItem key={opt.value} value={opt.value}>
                            {opt.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label>Aposta (XP)</Label>
                    <Input
                      type="number"
                      value={stakeValue}
                      onChange={(e) => setStakeValue(e.target.value)}
                      className="mt-1.5"
                      min="0"
                      max="1000"
                    />
                  </div>
                </div>
                
                <Button 
                  className="w-full" 
                  onClick={() => setStep(2)}
                >
                  Próximo
                  <ChevronRight className="h-4 w-4 ml-1" />
                </Button>
              </motion.div>
            )}
            
            {/* Step 2: Select Friends */}
            {step === 2 && (
              <motion.div
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
              >
                <div>
                  <Label className="text-base font-medium flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Convidar Amigos
                  </Label>
                  <p className="text-sm text-muted-foreground mb-3">
                    Selecione quem você quer desafiar
                  </p>
                  
                  {friends.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Users className="h-10 w-10 mx-auto mb-2 opacity-50" />
                      <p>Você ainda não tem amigos.</p>
                      <p className="text-sm">Adicione amigos para criar desafios!</p>
                    </div>
                  ) : (
                    <ScrollArea className="h-[200px] pr-2">
                      <div className="space-y-2">
                        {friends.map((friend) => {
                          const isSelected = selectedFriends.includes(friend.friendId);
                          
                          return (
                            <div
                              key={friend.id}
                              onClick={() => toggleFriend(friend.friendId)}
                              className={`p-3 rounded-lg border-2 cursor-pointer transition-all flex items-center gap-3
                                ${isSelected 
                                  ? 'border-primary bg-primary/5' 
                                  : 'border-border hover:border-primary/50'
                                }
                              `}
                            >
                              <Checkbox checked={isSelected} />
                              <Avatar className="h-9 w-9">
                                <AvatarImage src={friend.avatarUrl || undefined} />
                                <AvatarFallback>
                                  {friend.displayName.slice(0, 2).toUpperCase()}
                                </AvatarFallback>
                              </Avatar>
                              <div className="flex-1">
                                <p className="font-medium text-sm">{friend.displayName}</p>
                                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                  <Flame className="h-3 w-3 text-orange-500" />
                                  {friend.streakDays}
                                  <Dumbbell className="h-3 w-3 text-blue-500 ml-1" />
                                  {friend.totalWorkouts}
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </ScrollArea>
                  )}
                </div>
                
                {selectedFriends.length > 0 && (
                  <Badge variant="secondary" className="gap-1">
                    <Users className="h-3 w-3" />
                    {selectedFriends.length} selecionado(s)
                  </Badge>
                )}
                
                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1" onClick={() => setStep(1)}>
                    Voltar
                  </Button>
                  <Button 
                    className="flex-1" 
                    onClick={() => setStep(3)}
                    disabled={selectedFriends.length === 0}
                  >
                    Próximo
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </Button>
                </div>
              </motion.div>
            )}
            
            {/* Step 3: Customize */}
            {step === 3 && (
              <motion.div
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
              >
                <div>
                  <Label>Título do Desafio</Label>
                  <Input
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder={getDefaultTitle()}
                    className="mt-1.5"
                  />
                </div>
                
                <div>
                  <Label>Descrição (opcional)</Label>
                  <Textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Adicione regras ou motivação..."
                    className="mt-1.5 h-20 resize-none"
                  />
                </div>
                
                {/* Summary */}
                <div className="p-4 rounded-lg bg-muted/50 space-y-2">
                  <h4 className="font-medium text-sm">Resumo do Desafio</h4>
                  
                  <div className="flex items-center gap-2 text-sm">
                    <Trophy className="h-4 w-4 text-primary" />
                    <span>{typeOptions.find(t => t.value === challengeType)?.label}</span>
                  </div>
                  
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span>{durationOptions.find(d => d.value === duration)?.label}</span>
                    <span className="text-muted-foreground">
                      ({format(new Date(), 'dd/MM')} - {format(addDays(new Date(), parseInt(duration)), 'dd/MM')})
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-2 text-sm">
                    <Zap className="h-4 w-4 text-yellow-500" />
                    <span>{stakeValue} XP em jogo</span>
                  </div>
                  
                  <div className="flex items-center gap-2 text-sm">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <span>{selectedFriends.length + 1} participantes</span>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1" onClick={() => setStep(2)}>
                    Voltar
                  </Button>
                  <Button 
                    className="flex-1" 
                    onClick={handleCreate}
                    disabled={isCreating}
                  >
                    {isCreating ? 'Criando...' : 'Criar Desafio'}
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </DialogContent>
    </Dialog>
  );
}
