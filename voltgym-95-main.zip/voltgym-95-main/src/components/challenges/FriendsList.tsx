import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Users, Search, UserPlus, Check, X, 
  Trophy, Flame, Dumbbell, MoreVertical,
  MessageCircle
} from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { useFriendships, Friend, FriendRequest } from '@/hooks/useFriendships';

export function FriendsList() {
  const { 
    friends, 
    pendingRequests, 
    sentRequests,
    loading, 
    sendFriendRequest,
    acceptRequest,
    declineRequest,
    removeFriend,
    searchUsers,
  } = useFriendships();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [addFriendOpen, setAddFriendOpen] = useState(false);
  const [emailInput, setEmailInput] = useState('');

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    if (query.length >= 2) {
      setIsSearching(true);
      const results = await searchUsers(query);
      setSearchResults(results);
      setIsSearching(false);
    } else {
      setSearchResults([]);
    }
  };

  const handleSendRequest = async () => {
    if (!emailInput.trim()) return;
    const result = await sendFriendRequest(emailInput.trim());
    if (result.success) {
      setEmailInput('');
      setAddFriendOpen(false);
    }
  };

  const filteredFriends = friends.filter(f =>
    f.displayName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Users className="h-5 w-5 text-primary" />
            Amigos
            <Badge variant="secondary" className="ml-1">
              {friends.length}
            </Badge>
          </CardTitle>
          
          <Dialog open={addFriendOpen} onOpenChange={setAddFriendOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-1.5">
                <UserPlus className="h-4 w-4" />
                Adicionar
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Adicionar Amigo</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div>
                  <label className="text-sm text-muted-foreground mb-2 block">
                    Email do amigo
                  </label>
                  <Input
                    placeholder="email@exemplo.com"
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendRequest()}
                  />
                </div>
                <Button 
                  className="w-full" 
                  onClick={handleSendRequest}
                  disabled={!emailInput.trim()}
                >
                  Enviar Solicitação
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
        
        {/* Pending requests notification */}
        {pendingRequests.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-3 p-3 rounded-lg bg-primary/10 border border-primary/20"
          >
            <p className="text-sm font-medium text-primary mb-2">
              {pendingRequests.length} solicitação(ões) pendente(s)
            </p>
            <div className="space-y-2">
              {pendingRequests.map((request) => (
                <div 
                  key={request.id}
                  className="flex items-center justify-between p-2 rounded-md bg-background/50"
                >
                  <div className="flex items-center gap-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={request.avatarUrl || undefined} />
                      <AvatarFallback className="text-xs">
                        {request.displayName.slice(0, 2).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-sm font-medium">{request.displayName}</span>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-7 w-7 text-green-500 hover:text-green-600 hover:bg-green-500/10"
                      onClick={() => acceptRequest(request.id)}
                    >
                      <Check className="h-4 w-4" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-7 w-7 text-destructive hover:text-destructive hover:bg-destructive/10"
                      onClick={() => declineRequest(request.id)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </CardHeader>
      
      <CardContent className="pt-0">
        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar amigos..."
            className="pl-9"
            value={searchQuery}
            onChange={(e) => handleSearch(e.target.value)}
          />
        </div>
        
        {/* Friends list */}
        <ScrollArea className="h-[300px] pr-2">
          {loading ? (
            <div className="flex items-center justify-center h-20">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary" />
            </div>
          ) : filteredFriends.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              {friends.length === 0 
                ? 'Você ainda não tem amigos. Adicione para competir!'
                : 'Nenhum amigo encontrado'
              }
            </div>
          ) : (
            <div className="space-y-2">
              <AnimatePresence>
                {filteredFriends.map((friend, index) => (
                  <FriendCard 
                    key={friend.id} 
                    friend={friend} 
                    index={index}
                    onRemove={() => removeFriend(friend.id)}
                  />
                ))}
              </AnimatePresence>
            </div>
          )}
        </ScrollArea>
        
        {/* Sent requests */}
        {sentRequests.length > 0 && (
          <div className="mt-4 pt-4 border-t border-border/50">
            <p className="text-xs text-muted-foreground mb-2">
              Solicitações enviadas ({sentRequests.length})
            </p>
            <div className="flex flex-wrap gap-2">
              {sentRequests.map((request) => (
                <Badge key={request.id} variant="outline" className="gap-1.5">
                  {request.displayName}
                  <span className="text-muted-foreground">• Pendente</span>
                </Badge>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

interface FriendCardProps {
  friend: Friend;
  index: number;
  onRemove: () => void;
}

function FriendCard({ friend, index, onRemove }: FriendCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      transition={{ delay: index * 0.05 }}
      className="flex items-center justify-between p-3 rounded-lg bg-background/50 hover:bg-background/80 transition-colors"
    >
      <div className="flex items-center gap-3">
        <Avatar className="h-10 w-10 border-2 border-primary/20">
          <AvatarImage src={friend.avatarUrl || undefined} />
          <AvatarFallback className="bg-primary/10 text-primary">
            {friend.displayName.slice(0, 2).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        
        <div>
          <p className="font-medium text-sm">{friend.displayName}</p>
          <div className="flex items-center gap-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Flame className="h-3 w-3 text-orange-500" />
              {friend.streakDays}
            </span>
            <span className="flex items-center gap-1">
              <Dumbbell className="h-3 w-3 text-blue-500" />
              {friend.totalWorkouts}
            </span>
            <span className="flex items-center gap-1">
              <Trophy className="h-3 w-3 text-yellow-500" />
              {friend.currentXp} XP
            </span>
          </div>
        </div>
      </div>
      
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <MoreVertical className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem className="gap-2">
            <MessageCircle className="h-4 w-4" />
            Enviar mensagem
          </DropdownMenuItem>
          <DropdownMenuItem className="gap-2">
            <Trophy className="h-4 w-4" />
            Desafiar
          </DropdownMenuItem>
          <DropdownMenuItem 
            className="gap-2 text-destructive focus:text-destructive"
            onClick={onRemove}
          >
            <X className="h-4 w-4" />
            Remover amigo
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </motion.div>
  );
}
