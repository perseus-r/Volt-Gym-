import React from 'react';
import { motion } from 'framer-motion';
import { 
  Trophy, Flame, Dumbbell, Calendar, 
  Clock, Users, Award, ChevronRight,
  Check, X, Zap
} from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Challenge, ChallengeParticipant } from '@/hooks/useChallenges';
import { formatDistanceToNow, differenceInDays, format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface ChallengeCardProps {
  challenge: Challenge;
  onAccept?: () => void;
  onDecline?: () => void;
  onClick?: () => void;
  isInvitation?: boolean;
}

export function ChallengeCard({ 
  challenge, 
  onAccept, 
  onDecline, 
  onClick,
  isInvitation = false 
}: ChallengeCardProps) {
  const daysLeft = differenceInDays(new Date(challenge.endDate), new Date());
  const totalDays = differenceInDays(new Date(challenge.endDate), new Date(challenge.startDate));
  const daysElapsed = totalDays - daysLeft;
  const progressPercent = Math.min(100, Math.max(0, (daysElapsed / totalDays) * 100));
  
  const typeConfig = {
    streak: { icon: Flame, color: 'text-orange-500', bgColor: 'bg-orange-500/10', label: 'Streak' },
    volume: { icon: Dumbbell, color: 'text-blue-500', bgColor: 'bg-blue-500/10', label: 'Volume' },
    workouts: { icon: Calendar, color: 'text-green-500', bgColor: 'bg-green-500/10', label: 'Treinos' },
    custom: { icon: Trophy, color: 'text-purple-500', bgColor: 'bg-purple-500/10', label: 'Custom' },
  };
  
  const config = typeConfig[challenge.challengeType];
  const TypeIcon = config.icon;
  
  // Sort participants by progress
  const sortedParticipants = [...challenge.participants]
    .filter(p => p.status === 'accepted')
    .sort((a, b) => b.currentProgress - a.currentProgress);
  
  const leader = sortedParticipants[0];
  const isWinner = challenge.status === 'completed' && challenge.winnerId;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ scale: 1.01 }}
      whileTap={{ scale: 0.99 }}
    >
      <Card 
        className={`border-border/50 bg-card/50 backdrop-blur-sm overflow-hidden cursor-pointer transition-all
          ${isInvitation ? 'ring-2 ring-primary/50' : ''}
          ${isWinner ? 'ring-2 ring-yellow-500/50' : ''}
        `}
        onClick={onClick}
      >
        {/* Header with type badge */}
        <div className={`px-4 py-2 ${config.bgColor} border-b border-border/30`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <TypeIcon className={`h-4 w-4 ${config.color}`} />
              <span className={`text-xs font-medium ${config.color}`}>{config.label}</span>
            </div>
            
            <div className="flex items-center gap-2">
              {challenge.stakeValue > 0 && (
                <Badge variant="secondary" className="gap-1 text-xs">
                  <Zap className="h-3 w-3 text-yellow-500" />
                  {challenge.stakeValue} XP
                </Badge>
              )}
              
              {challenge.status === 'active' && (
                <Badge variant="outline" className="text-xs">
                  <Clock className="h-3 w-3 mr-1" />
                  {daysLeft > 0 ? `${daysLeft}d restantes` : 'Último dia!'}
                </Badge>
              )}
              
              {challenge.status === 'completed' && (
                <Badge className="bg-green-500/20 text-green-500 border-green-500/30 text-xs">
                  <Check className="h-3 w-3 mr-1" />
                  Finalizado
                </Badge>
              )}
              
              {isInvitation && (
                <Badge className="bg-primary/20 text-primary border-primary/30 text-xs animate-pulse">
                  Convite
                </Badge>
              )}
            </div>
          </div>
        </div>
        
        <CardContent className="p-4">
          {/* Title and creator */}
          <div className="mb-3">
            <h3 className="font-semibold text-base">{challenge.title}</h3>
            <p className="text-xs text-muted-foreground">
              Criado por {challenge.creatorName} • {formatDistanceToNow(new Date(challenge.createdAt), { addSuffix: true, locale: ptBR })}
            </p>
          </div>
          
          {/* Progress bar for active challenges */}
          {challenge.status === 'active' && (
            <div className="mb-4">
              <div className="flex justify-between text-xs text-muted-foreground mb-1">
                <span>{format(new Date(challenge.startDate), 'dd/MM')}</span>
                <span>{format(new Date(challenge.endDate), 'dd/MM')}</span>
              </div>
              <Progress value={progressPercent} className="h-1.5" />
            </div>
          )}
          
          {/* Participants ranking */}
          <div className="space-y-2">
            {sortedParticipants.slice(0, 3).map((participant, index) => (
              <ParticipantRow 
                key={participant.id} 
                participant={participant} 
                rank={index + 1}
                challengeType={challenge.challengeType}
                isWinner={challenge.status === 'completed' && participant.odisplayUserId === challenge.winnerId}
              />
            ))}
            
            {sortedParticipants.length > 3 && (
              <div className="text-xs text-muted-foreground text-center pt-1">
                +{sortedParticipants.length - 3} participantes
              </div>
            )}
          </div>
          
          {/* Invitation actions */}
          {isInvitation && (
            <div className="flex gap-2 mt-4 pt-4 border-t border-border/30">
              <Button 
                className="flex-1 gap-1.5" 
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  onAccept?.();
                }}
              >
                <Check className="h-4 w-4" />
                Aceitar
              </Button>
              <Button 
                variant="outline" 
                className="flex-1 gap-1.5" 
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  onDecline?.();
                }}
              >
                <X className="h-4 w-4" />
                Recusar
              </Button>
            </div>
          )}
          
          {/* View details hint */}
          {!isInvitation && (
            <div className="flex items-center justify-end mt-3 text-xs text-muted-foreground">
              Ver detalhes
              <ChevronRight className="h-3 w-3 ml-1" />
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}

interface ParticipantRowProps {
  participant: ChallengeParticipant;
  rank: number;
  challengeType: string;
  isWinner?: boolean;
}

function ParticipantRow({ participant, rank, challengeType, isWinner }: ParticipantRowProps) {
  const formatProgress = (value: number) => {
    if (challengeType === 'volume') {
      return `${(value / 1000).toFixed(1)}k kg`;
    }
    if (challengeType === 'workouts') {
      return `${value} treinos`;
    }
    if (challengeType === 'streak') {
      return `${value} dias`;
    }
    return value.toString();
  };
  
  const rankColors = {
    1: 'text-yellow-500',
    2: 'text-gray-400',
    3: 'text-amber-600',
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, x: -10 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: rank * 0.1 }}
      className={`flex items-center justify-between p-2 rounded-lg transition-colors
        ${isWinner ? 'bg-yellow-500/10 ring-1 ring-yellow-500/30' : 'bg-background/50'}
      `}
    >
      <div className="flex items-center gap-2">
        {/* Rank */}
        <div className={`w-5 text-center font-bold text-sm ${rankColors[rank as keyof typeof rankColors] || 'text-muted-foreground'}`}>
          {rank === 1 && isWinner ? <Trophy className="h-4 w-4 mx-auto" /> : `#${rank}`}
        </div>
        
        {/* Avatar */}
        <Avatar className="h-7 w-7">
          <AvatarImage src={participant.avatarUrl || undefined} />
          <AvatarFallback className="text-xs">
            {participant.displayName.slice(0, 2).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        
        {/* Name */}
        <span className={`text-sm font-medium truncate max-w-[100px] ${isWinner ? 'text-yellow-500' : ''}`}>
          {participant.displayName}
        </span>
      </div>
      
      {/* Progress */}
      <span className={`text-sm font-semibold ${isWinner ? 'text-yellow-500' : 'text-primary'}`}>
        {formatProgress(participant.currentProgress)}
      </span>
    </motion.div>
  );
}
