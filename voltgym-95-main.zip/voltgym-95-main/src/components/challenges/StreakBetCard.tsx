import React from 'react';
import { motion } from 'framer-motion';
import { Flame, Zap, Trophy, Clock, Check, X, Swords } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { StreakBet } from '@/hooks/useStreakBets';
import { differenceInDays, format } from 'date-fns';

interface StreakBetCardProps {
  bet: StreakBet;
  onAccept?: () => void;
  onDecline?: () => void;
  isPending?: boolean;
}

export function StreakBetCard({ bet, onAccept, onDecline, isPending = false }: StreakBetCardProps) {
  const daysLeft = differenceInDays(new Date(bet.endDate), new Date());
  const totalDays = differenceInDays(new Date(bet.endDate), new Date(bet.startDate));
  const progressPercent = Math.min(100, Math.max(0, ((totalDays - daysLeft) / totalDays) * 100));
  
  const myProgress = (bet.myStreak / bet.targetStreak) * 100;
  const opponentProgress = (bet.opponentStreak / bet.targetStreak) * 100;
  
  const isWinning = bet.myStreak > bet.opponentStreak;
  const isTied = bet.myStreak === bet.opponentStreak;
  
  const opponentName = bet.isChallenger ? bet.challengedName : bet.challengerName;
  const opponentAvatar = bet.isChallenger ? bet.challengedAvatar : bet.challengerAvatar;
  
  const isCompleted = bet.status === 'completed';
  const didWin = isCompleted && bet.winnerId === (bet.isChallenger ? bet.challengerId : bet.challengedId);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: 1.02 }}
      className="relative"
    >
      <Card className={`border-border/50 bg-card/50 backdrop-blur-sm overflow-hidden
        ${isPending ? 'ring-2 ring-orange-500/50' : ''}
        ${isCompleted && didWin ? 'ring-2 ring-yellow-500/50' : ''}
      `}>
        {/* Animated battle background */}
        {bet.status === 'active' && (
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-orange-500/5 via-transparent to-orange-500/5"
              animate={{ x: ['-100%', '100%'] }}
              transition={{ duration: 3, repeat: Infinity, ease: 'linear' }}
            />
          </div>
        )}
        
        {/* Header */}
        <div className="px-4 py-2 bg-orange-500/10 border-b border-border/30 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Swords className="h-4 w-4 text-orange-500" />
            <span className="text-xs font-medium text-orange-500">Duelo de Streak</span>
          </div>
          
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="gap-1 text-xs">
              <Zap className="h-3 w-3 text-yellow-500" />
              {bet.xpStake} XP
            </Badge>
            
            {bet.status === 'active' && (
              <Badge variant="outline" className="text-xs">
                <Clock className="h-3 w-3 mr-1" />
                {daysLeft > 0 ? `${daysLeft}d` : 'Hoje!'}
              </Badge>
            )}
            
            {isCompleted && (
              <Badge className={`text-xs ${didWin ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500'}`}>
                {didWin ? 'Vitória!' : 'Derrota'}
              </Badge>
            )}
            
            {isPending && (
              <Badge className="bg-orange-500/20 text-orange-500 border-orange-500/30 text-xs animate-pulse">
                Convite
              </Badge>
            )}
          </div>
        </div>
        
        <CardContent className="p-4">
          {/* VS Layout */}
          <div className="flex items-center justify-between mb-4">
            {/* You */}
            <div className="flex flex-col items-center">
              <div className={`relative ${isWinning && !isTied ? 'ring-2 ring-green-500 rounded-full' : ''}`}>
                <Avatar className="h-14 w-14 border-2 border-orange-500/30">
                  <AvatarFallback className="bg-primary/10 text-primary text-lg">
                    EU
                  </AvatarFallback>
                </Avatar>
                {isWinning && !isTied && bet.status === 'active' && (
                  <motion.div
                    className="absolute -top-1 -right-1 bg-green-500 rounded-full p-0.5"
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 1, repeat: Infinity }}
                  >
                    <Trophy className="h-3 w-3 text-white" />
                  </motion.div>
                )}
              </div>
              <span className="text-xs font-medium mt-1">Você</span>
              <div className="flex items-center gap-1 mt-0.5">
                <Flame className="h-4 w-4 text-orange-500" />
                <span className="text-lg font-bold">{bet.myStreak}</span>
              </div>
            </div>
            
            {/* VS */}
            <div className="flex flex-col items-center">
              <motion.div
                className="text-2xl font-black text-muted-foreground/50"
                animate={bet.status === 'active' ? { scale: [1, 1.1, 1] } : {}}
                transition={{ duration: 2, repeat: Infinity }}
              >
                VS
              </motion.div>
              <div className="text-xs text-muted-foreground mt-1">
                Meta: {bet.targetStreak} dias
              </div>
            </div>
            
            {/* Opponent */}
            <div className="flex flex-col items-center">
              <div className={`relative ${!isWinning && !isTied ? 'ring-2 ring-green-500 rounded-full' : ''}`}>
                <Avatar className="h-14 w-14 border-2 border-orange-500/30">
                  <AvatarImage src={opponentAvatar || undefined} />
                  <AvatarFallback className="bg-destructive/10 text-destructive text-lg">
                    {opponentName.slice(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                {!isWinning && !isTied && bet.status === 'active' && (
                  <motion.div
                    className="absolute -top-1 -right-1 bg-green-500 rounded-full p-0.5"
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 1, repeat: Infinity }}
                  >
                    <Trophy className="h-3 w-3 text-white" />
                  </motion.div>
                )}
              </div>
              <span className="text-xs font-medium mt-1 truncate max-w-[80px]">{opponentName}</span>
              <div className="flex items-center gap-1 mt-0.5">
                <Flame className="h-4 w-4 text-orange-500" />
                <span className="text-lg font-bold">{bet.opponentStreak}</span>
              </div>
            </div>
          </div>
          
          {/* Progress comparison */}
          {bet.status === 'active' && (
            <div className="space-y-2 mb-4">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-muted-foreground">Seu progresso</span>
                  <span className="font-medium">{Math.round(myProgress)}%</span>
                </div>
                <Progress value={myProgress} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-muted-foreground">{opponentName}</span>
                  <span className="font-medium">{Math.round(opponentProgress)}%</span>
                </div>
                <Progress value={opponentProgress} className="h-2 [&>div]:bg-destructive" />
              </div>
            </div>
          )}
          
          {/* Status message */}
          {bet.status === 'active' && (
            <div className={`text-center text-sm font-medium p-2 rounded-lg ${
              isWinning ? 'bg-green-500/10 text-green-500' : 
              isTied ? 'bg-yellow-500/10 text-yellow-500' : 
              'bg-red-500/10 text-red-500'
            }`}>
              {isWinning ? '🔥 Você está vencendo!' : 
               isTied ? '⚔️ Empate! Continue treinando!' : 
               '😤 Você está perdendo! Treine hoje!'}
            </div>
          )}
          
          {/* Pending actions */}
          {isPending && (
            <div className="flex gap-2 mt-4 pt-4 border-t border-border/30">
              <Button 
                className="flex-1 gap-1.5 bg-orange-500 hover:bg-orange-600" 
                size="sm"
                onClick={onAccept}
              >
                <Check className="h-4 w-4" />
                Aceitar Duelo
              </Button>
              <Button 
                variant="outline" 
                className="flex-1 gap-1.5" 
                size="sm"
                onClick={onDecline}
              >
                <X className="h-4 w-4" />
                Recusar
              </Button>
            </div>
          )}
          
          {/* Date info */}
          <div className="text-xs text-muted-foreground text-center mt-3">
            {format(new Date(bet.startDate), 'dd/MM')} - {format(new Date(bet.endDate), 'dd/MM')}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
