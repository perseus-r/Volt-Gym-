import React from 'react';
import { motion } from 'framer-motion';
import { Bell, User } from 'lucide-react';
import { VoltButton } from './VoltButton';
import { cn } from '@/lib/utils';
import { VoltBadge } from './VoltBadge';

interface VoltHeaderProps {
  title?: string;
  showNotifications?: boolean;
  showProfile?: boolean;
  className?: string;
}

export function VoltHeader({ 
  title = "VOLTGYM", 
  showNotifications = true, 
  showProfile = true,
  className 
}: VoltHeaderProps) {
  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.25, 0.46, 0.45, 0.94] }}
      className={cn(
        "fixed top-0 left-0 right-0 z-50",
        "bg-gradient-to-b from-black/95 via-black/90 to-transparent",
        "backdrop-blur-2xl border-b border-white/10",
        "shadow-2xl shadow-black/50",
        "safe-area-top",
        "min-h-[60px] md:min-h-[64px]",
        className
      )}
    >
      <div className="flex items-center justify-between px-6 py-3 md:py-4">
        {/* Logo com animação */}
        <motion.div
          className="flex items-center gap-3"
          whileHover={{ scale: 1.02 }}
          transition={{ duration: 0.2 }}
        >
          <motion.div
            animate={{ 
              scale: [1, 1.05, 1]
            }}
            transition={{ 
              duration: 2,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <VoltBadge size="md" showGlow />
          </motion.div>
          
          <div>
            <motion.h1 
              className="text-xl font-bold text-white tracking-wide"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2, duration: 0.4 }}
            >
              {title}
            </motion.h1>
          </div>
        </motion.div>

        {/* Actions */}
        <div className="flex items-center gap-3">
          {showNotifications && (
            <motion.div
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              transition={{ duration: 0.15 }}
            >
              <VoltButton
                variant="ghost"
                size="sm"
                className="relative p-2 rounded-xl"
              >
                <Bell className="w-5 h-5" />
                
                {/* Notification badge */}
                <motion.div
                  className="absolute -top-1 -right-1 w-3 h-3 bg-accent rounded-full"
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
              </VoltButton>
            </motion.div>
          )}

          {showProfile && (
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              transition={{ duration: 0.15 }}
            >
              <VoltButton
                variant="ghost"
                size="sm"
                className="p-2 rounded-xl border border-accent/20"
              >
                <User className="w-5 h-5" />
              </VoltButton>
            </motion.div>
          )}
        </div>
      </div>
    </motion.header>
  );
}