import React from 'react';
import { motion } from 'framer-motion';
import { LucideIcon, TrendingUp, TrendingDown } from 'lucide-react';
import { VoltCard } from './VoltCard';
import { CounterAnimation } from './CounterAnimation';
import { cn } from '@/lib/utils';

interface StatsCardPremiumProps {
  icon: LucideIcon;
  label: string;
  value: number | string;
  suffix?: string;
  prefix?: string;
  trend?: {
    value: number;
    label?: string;
    isPositive?: boolean;
  };
  variant?: 'default' | 'premium' | 'success' | 'accent' | 'warning' | 'purple';
  compact?: boolean;
  className?: string;
}

export function StatsCardPremium({
  icon: Icon,
  label,
  value,
  suffix = '',
  prefix = '',
  trend,
  variant = 'default',
  compact = false,
  className
}: StatsCardPremiumProps) {
  const cardVariant = variant === 'accent' || variant === 'purple' || variant === 'warning' 
    ? variant 
    : (variant === 'default' ? 'default' : variant as any);

  return (
    <VoltCard
      variant={cardVariant}
      hover
      glow={variant === 'premium' || variant === 'accent'}
      className={cn(compact ? 'p-4' : 'p-6', className)}
    >
      <div className="space-y-3">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className={cn(
            'p-2.5 rounded-xl glass-subtle',
            variant === 'premium' && 'bg-accent/10 text-accent',
            variant === 'success' && 'bg-success/10 text-success'
          )}>
            <Icon className="w-5 h-5" strokeWidth={2} />
          </div>

          {/* Trend indicator */}
          {trend && (
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.3, type: 'spring', stiffness: 200 }}
              className={cn(
                'flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-bold',
                (trend.isPositive !== false) 
                  ? 'bg-success/10 text-success' 
                  : 'bg-error/10 text-error'
              )}
            >
              {(trend.isPositive !== false) ? (
                <TrendingUp className="w-3 h-3" />
              ) : (
                <TrendingDown className="w-3 h-3" />
              )}
              <span>{trend.label || `${Math.abs(trend.value)}%`}</span>
            </motion.div>
          )}
        </div>

        {/* Label */}
        <p className="text-label text-txt-3">
          {label}
        </p>

        {/* Value with counter animation */}
        {typeof value === 'number' ? (
          <CounterAnimation
            value={value}
            prefix={prefix}
            suffix={suffix}
            format="compact"
            decimals={0}
            className="text-stat"
          />
        ) : (
          <div className="text-stat-md font-bold text-txt">
            {prefix}{value}{suffix}
          </div>
        )}
      </div>
    </VoltCard>
  );
}