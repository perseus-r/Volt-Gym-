import React from 'react';
import { motion } from 'framer-motion';
import { Clock, Flame, Zap, TrendingUp } from 'lucide-react';
import { VoltCard } from './VoltCard';
import { HapticFeedback } from './HapticFeedback';
import { cn } from '@/lib/utils';

interface WorkoutCardPremiumProps {
  title: string;
  duration: number;
  difficulty: 'easy' | 'medium' | 'hard';
  calories?: number;
  progress?: number;
  muscleGroups?: string[];
  image?: string;
  onClick?: () => void;
  className?: string;
}

export function WorkoutCardPremium({
  title,
  duration,
  difficulty,
  calories,
  progress = 0,
  muscleGroups = [],
  image,
  onClick,
  className
}: WorkoutCardPremiumProps) {
  const difficultyConfig = {
    easy: { color: 'text-success', bgColor: 'bg-success/10', label: 'Fácil' },
    medium: { color: 'text-warning', bgColor: 'bg-warning/10', label: 'Médio' },
    hard: { color: 'text-error', bgColor: 'bg-error/10', label: 'Difícil' }
  };

  const config = difficultyConfig[difficulty];

  return (
    <HapticFeedback hapticType="click" onClick={onClick}>
      <VoltCard
        hover
        glow={progress > 0}
        className={cn('overflow-hidden cursor-pointer', className)}
      >
        {/* Image with gradient overlay */}
        {image && (
          <div className="relative h-40 overflow-hidden">
            <img 
              src={image} 
              alt={title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/80 to-transparent" />
            
            {/* Difficulty badge */}
            <div className={cn(
              'absolute top-3 right-3 px-3 py-1 rounded-full text-xs font-bold glass-intense',
              config.color
            )}>
              {config.label}
            </div>
          </div>
        )}

        <div className="p-5 space-y-4">
          {/* Title */}
          <h3 className="text-card-title line-clamp-2">{title}</h3>

          {/* Stats */}
          <div className="flex items-center gap-4 text-txt-3">
            <div className="flex items-center gap-1.5">
              <Clock className="w-4 h-4" />
              <span className="text-sm font-medium">{duration} min</span>
            </div>

            {calories && (
              <div className="flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-warning" />
                <span className="text-sm font-medium">{calories} kcal</span>
              </div>
            )}

            <div className="flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-accent" />
              <span className="text-sm font-medium capitalize">{config.label}</span>
            </div>
          </div>

          {/* Muscle groups tags */}
          {muscleGroups.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {muscleGroups.slice(0, 3).map((muscle, idx) => (
                <span
                  key={idx}
                  className="px-2 py-1 rounded-lg glass-subtle text-xs font-semibold text-txt-2"
                >
                  {muscle}
                </span>
              ))}
              {muscleGroups.length > 3 && (
                <span className="px-2 py-1 rounded-lg glass-subtle text-xs font-semibold text-txt-3">
                  +{muscleGroups.length - 3}
                </span>
              )}
            </div>
          )}

          {/* Progress bar */}
          {progress > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-txt-3 font-medium">Progresso</span>
                <span className="text-accent font-bold">{progress}%</span>
              </div>
              <div className="h-1.5 bg-white/10 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-accent to-accent-2"
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 1, ease: [0.4, 0, 0.2, 1] }}
                />
              </div>
            </div>
          )}
        </div>
      </VoltCard>
    </HapticFeedback>
  );
}