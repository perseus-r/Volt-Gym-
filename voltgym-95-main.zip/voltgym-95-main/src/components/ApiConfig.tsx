import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Settings, Server, Database, Shield } from 'lucide-react';

interface ApiConfigProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ApiConfig({ open, onOpenChange }: ApiConfigProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Configurações Administrativas
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="p-4 rounded-lg bg-accent/20 border border-accent/30">
            <div className="flex items-center gap-3 mb-2">
              <Server className="w-5 h-5 text-primary" />
              <h3 className="font-medium">Status do Sistema</h3>
            </div>
            <p className="text-sm text-muted-foreground">
              Todos os serviços estão operando normalmente.
            </p>
          </div>

          <div className="p-4 rounded-lg bg-accent/20 border border-accent/30">
            <div className="flex items-center gap-3 mb-2">
              <Database className="w-5 h-5 text-primary" />
              <h3 className="font-medium">Banco de Dados</h3>
            </div>
            <p className="text-sm text-muted-foreground">
              Supabase conectado e funcionando.
            </p>
          </div>

          <div className="p-4 rounded-lg bg-accent/20 border border-accent/30">
            <div className="flex items-center gap-3 mb-2">
              <Shield className="w-5 h-5 text-primary" />
              <h3 className="font-medium">Segurança</h3>
            </div>
            <p className="text-sm text-muted-foreground">
              RLS ativo em todas as tabelas.
            </p>
          </div>
        </div>

        <div className="flex justify-end">
          <Button onClick={() => onOpenChange(false)}>
            Fechar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default ApiConfig;
