import { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ImmersiveChatInterface } from '@/components/chat/ImmersiveChatInterface';
import { IPhoneCard } from '@/components/ui/iphone-card';
import { IPhoneButton } from '@/components/ui/iphone-button';
import { FullScreenPortal } from '@/components/ui/FullScreenPortal';
import { 
  Camera, 
  ChefHat,
  Sparkles,
  Image,
  Apple,
  X,
  Loader2
} from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface Message {
  id: string;
  text: string;
  isAI: boolean;
  timestamp: string;
  analysisType?: string;
  hasImage?: boolean;
}

interface NutritionAIChatProps {
  className?: string;
  fullScreen?: boolean;
  onBack?: () => void;
}

const NutritionAIChat = ({ className = '', fullScreen = false, onBack }: NutritionAIChatProps) => {
  const { user, loading: authLoading } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Safety timeout - force exit loading after 8s
  useEffect(() => {
    if (!isLoading) return;
    const safetyTimeout = setTimeout(() => {
      if (isLoading) {
        console.warn('Nutri Coach: Loading timeout - forcing render');
        setIsLoading(false);
        setMessages(prev => prev.length === 0 ? [{
          id: 'welcome',
          text: `Olá! 👋 Sou seu nutricionista IA pessoal. Como posso te ajudar hoje?`,
          isAI: true,
          timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
          analysisType: 'welcome'
        }] : prev);
      }
    }, 8000);
    return () => clearTimeout(safetyTimeout);
  }, [isLoading]);

  // Initialize conversation and load persistent memory - wait for auth
  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      setIsLoading(false);
      return;
    }

    const init = async () => {
      try {
        await loadConversationHistory();
        // Only initialize new conversation if no history loaded
        if (messages.length === 0) {
          await initializeConversation();
        }
      } catch (error) {
        console.error('Error initializing Nutri:', error);
        setMessages([{
          id: 'welcome',
          text: `Olá! 👋 Sou seu nutricionista IA. Houve um problema ao carregar, mas estou pronto para ajudar!`,
          isAI: true,
          timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
          analysisType: 'welcome'
        }]);
      } finally {
        setIsLoading(false);
      }
    };
    
    init();
  }, [user, authLoading]);

  const loadConversationHistory = async () => {
    if (!user) return;
    
    try {
      // Buscar conversas existentes de nutrição (separadas do Coach)
      const { data: conversations } = await supabase
        .from('ai_conversations')
        .select('id, title, created_at')
        .eq('user_id', user.id)
        .or('title.ilike.%Nutricional%,title.ilike.%Nutri%')
        .order('created_at', { ascending: false })
        .limit(1);

      if (conversations && conversations.length > 0) {
        const lastConversation = conversations[0];
        setConversationId(lastConversation.id);
        
        // Carregar mensagens da última conversa
        // Carregar TODA a conversa para memória completa
        const { data: lastMessages } = await supabase
          .from('ai_messages')
          .select('content, role, created_at')
          .eq('conversation_id', lastConversation.id)
          .order('created_at', { ascending: true })
          .limit(100); // Memória expandida para 100 mensagens

        if (lastMessages && lastMessages.length > 1) { // Mais de uma mensagem (não só boas-vindas)
          const formattedMessages = lastMessages.map((msg, index) => ({
            id: `history_${index}`,
            text: msg.content,
            isAI: msg.role === 'assistant',
            timestamp: new Date(msg.created_at).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
          }));

          setMessages(formattedMessages);
          return;
        }
      }
    } catch (error) {
      console.error('Error loading conversation history:', error);
    }
  };

  const initializeConversation = async () => {
    if (!user) return;
    
    try {
      // Buscar perfil do usuário para personalizar mensagem
      const { data: profile } = await supabase
        .from('profiles')
        .select('display_name, goal, age, weight, height, sexo')
        .eq('user_id', user.id)
        .maybeSingle();

      // Create new nutrition conversation (distinct from Coach)
      const { data: conversation, error } = await supabase
        .from('ai_conversations')
        .insert({
          user_id: user.id,
          title: 'Dr. Nutri IA - ' + new Date().toLocaleDateString('pt-BR')
        })
        .select()
        .single();

      if (error) throw error;

      setConversationId(conversation.id);
      
      // Add personalized welcome message
      const userName = profile?.display_name || 'Atleta';
      const welcomeMessage: Message = {
        id: 'welcome',
        text: `Olá, **${userName}**! 👋 

Sou seu nutricionista IA pessoal e vou te ajudar a criar um plano alimentar perfeito para seus objetivos.

Antes de começar, preciso conhecer você:

1. **Qual seu objetivo nutricional?** (Emagrecimento, ganho de massa, manutenção, performance)
2. **Idade, peso, altura e sexo?**
3. **Nível de atividade física?** (Sedentário, leve, moderado, intenso)
4. **Tem alguma restrição alimentar?** (Vegetariano, vegano, intolerâncias, alergias)
5. **Quantas refeições por dia você consegue fazer?**

Com essas informações, vou criar um plano nutricional totalmente personalizado e calcular seus macros ideais! 🥗`,
        isAI: true,
        timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
        analysisType: 'welcome'
      };

      // Only set welcome if no history was loaded
      if (messages.length === 0) {
        setMessages([welcomeMessage]);
      }
      
    } catch (error) {
      console.error('Error initializing conversation:', error);
      // Set generic welcome if there's an error
      if (messages.length === 0) {
        setMessages([{
          id: 'welcome',
          text: `Olá! 👋 Sou seu nutricionista IA pessoal. Como posso te ajudar hoje?`,
          isAI: true,
          timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
          analysisType: 'welcome'
        }]);
      }
    }
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      toast.error('Imagem muito grande. Máximo 10MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      setSelectedImage(e.target?.result as string);
      toast.success('Imagem carregada! Digite sua pergunta e envie.');
    };
    reader.readAsDataURL(file);
  };

  const handleSendMessage = async (message: string) => {
    if (!message.trim() && !selectedImage) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: message || 'Análise de foto de refeição',
      isAI: false,
      timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      hasImage: !!selectedImage
    };

    setMessages(prev => [...prev, userMessage]);
    setIsTyping(true);

      try {
        const analysisType = selectedImage ? 'photo_analysis' : 'chat';
      
      // Prepare image data
      let imageBase64 = null;
      if (selectedImage) {
        imageBase64 = selectedImage.split(',')[1]; // Remove data:image/jpeg;base64, prefix
      }

      console.log('🤖 Calling nutrition AI with:', { message, analysisType, hasImage: !!imageBase64 });
      
      const { data, error } = await supabase.functions.invoke('nutrition-ai-chat', {
        body: {
          message: message,
          conversationId,
          imageBase64,
          analysisType
        }
      });

      if (error) throw error;

      if (data.success) {
        const aiMessage: Message = {
          id: (Date.now() + 1).toString(),
          text: data.response,
          isAI: true,
          timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
          analysisType
        };

        setMessages(prev => [...prev, aiMessage]);
        
        // Salvar resposta da IA na conversa
        if (conversationId) {
          await supabase
            .from('ai_messages')
            .insert({
              conversation_id: conversationId,
              role: 'assistant',
              content: data.response,
              analysis_type: analysisType
            });
        }
        
        if (selectedImage) {
          toast.success('Análise da refeição concluída!');
        }
      } else {
        throw new Error(data.error || 'Erro na resposta da IA');
      }

    } catch (error) {
      console.error('Error sending message:', error);
      const friendly = error instanceof Error ? error.message : 'Desculpe, ocorreu um erro. Tente novamente.';
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: friendly,
        isAI: true,
        timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, errorMessage]);
      toast.error(friendly);
    } finally {
      setSelectedImage(null);
      setIsTyping(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const quickQuestions = [
    'Calcular macros para ganho de massa',
    'Plano alimentar 1800 calorias',  
    'Receita rica em proteínas',
    'Análise nutricional completa'
  ];

  // Loading state while waiting for auth/data
  if (authLoading || isLoading) {
    return (
      <div className={`flex items-center justify-center ${fullScreen ? 'fixed inset-0 bg-background' : 'min-h-[400px]'}`}>
        <div className="flex flex-col items-center gap-3">
          <Loader2 className="w-8 h-8 text-green-500 animate-spin" />
          <span className="text-sm text-muted-foreground">Carregando Nutri Coach...</span>
        </div>
      </div>
    );
  }

  // Full screen iOS immersive mode via Portal
  if (fullScreen) {
    return (
      <FullScreenPortal>
        <div className="flex flex-col h-full min-h-0">
          {/* iOS Style Header */}
          <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-b from-background via-background/98 to-background/95 backdrop-blur-2xl border-b border-white/10 flex-shrink-0 safe-area-top">
          <div className="flex items-center gap-3">
            {/* Avatar with green gradient border */}
            <div className="relative">
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-green-400 via-emerald-500 to-green-600 blur-sm opacity-60" />
              <div className="relative w-11 h-11 rounded-full bg-gradient-to-br from-green-400 to-emerald-600 flex items-center justify-center shadow-lg shadow-green-500/30 border border-white/20">
                <Apple className="w-5 h-5 text-white" />
              </div>
            </div>
            <div>
              <h1 className="font-semibold text-foreground text-base">Nutri Coach</h1>
              <div className="flex items-center gap-2">
                <span className="flex items-center gap-1 text-xs text-green-400 font-medium">
                  <Sparkles className="w-3 h-3" />
                  Online
                </span>
              </div>
            </div>
          </div>
          
          {/* Camera button */}
          <div className="flex items-center gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleImageUpload}
              className="hidden"
            />
            <IPhoneButton
              variant="glass"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              disabled={isTyping}
              className="rounded-full"
            >
              <Camera className="w-4 h-4" />
            </IPhoneButton>
            {onBack && (
              <IPhoneButton
                variant="ghost"
                size="sm"
                onClick={onBack}
                className="rounded-full"
              >
                <X className="w-5 h-5" />
              </IPhoneButton>
            )}
          </div>
        </div>

        {/* Image preview banner */}
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="px-4 py-2 bg-green-500/10 border-b border-green-500/20"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Image className="w-4 h-4 text-green-400" />
                <span className="text-sm text-green-400">Imagem pronta para análise</span>
              </div>
              <button
                onClick={() => setSelectedImage(null)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}

          {/* Chat Interface - Full Screen */}
          <div className="flex-1 overflow-hidden min-h-0">
            <ImmersiveChatInterface
              messages={messages}
              onSendMessage={handleSendMessage}
              isTyping={isTyping}
              placeholder="Pergunte ao Nutri Coach..."
              suggestions={quickQuestions}
              onSuggestionClick={handleSendMessage}
              showSuggestions={!messages.some(msg => !msg.isAI && msg.id !== 'welcome')}
            />
          </div>
        </div>
      </FullScreenPortal>
    );
  }

  // Compact mode for inline usage
  return (
    <div className={`max-w-4xl mx-auto ${className}`}>
      {/* Header Card - iOS Style */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.5 }}
        className="mb-4"
      >
        <IPhoneCard variant="glass" className="p-4 text-center">
          <div className="flex items-center justify-center gap-3 mb-3">
            <div className="relative">
              <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-green-400 to-emerald-600 blur-sm opacity-50" />
              <div className="relative w-10 h-10 bg-gradient-to-br from-green-400 to-emerald-600 rounded-xl flex items-center justify-center">
                <ChefHat className="w-5 h-5 text-white" />
              </div>
            </div>
            <h1 className="text-lg font-bold text-foreground">Dr. Nutri IA</h1>
          </div>
          <p className="text-muted-foreground text-sm mb-3">
            Seu nutricionista pessoal inteligente
          </p>
          
          <div className="flex justify-center">
            <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-green-500/10 border border-green-500/20 text-green-400 text-xs font-medium">
              <Sparkles className="w-3 h-3" />
              Online
            </span>
          </div>
        </IPhoneCard>
      </motion.div>

      {/* Image Upload Section */}
      {selectedImage && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-3"
        >
          <IPhoneCard variant="glass" className="p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Image className="w-4 h-4 text-green-400" />
                <span className="text-sm text-green-400">Imagem para análise</span>
              </div>
              <button
                onClick={() => setSelectedImage(null)}
                className="text-muted-foreground hover:text-foreground h-8 w-8 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </IPhoneCard>
        </motion.div>
      )}

      {/* Image Upload Section */}
      {selectedImage && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-3"
        >
          <IPhoneCard variant="glass" className="p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Image className="w-4 h-4 text-green-400" />
                <span className="text-sm text-green-400">Imagem para análise</span>
              </div>
              <button
                onClick={() => setSelectedImage(null)}
                className="text-muted-foreground hover:text-foreground h-8 w-8 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </IPhoneCard>
        </motion.div>
      )}

      {/* Chat Interface */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.6 }}
        className="relative"
      >
        {/* Camera Upload Button */}
        <div className="absolute top-2 right-2 z-10">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handleImageUpload}
            className="hidden"
          />
          <IPhoneButton
            variant="glass"
            size="sm"
            onClick={() => fileInputRef.current?.click()}
            disabled={isTyping}
          >
            <Camera className="w-4 h-4 mr-1" />
            Foto
          </IPhoneButton>
        </div>

        <ImmersiveChatInterface
          messages={messages}
          onSendMessage={handleSendMessage}
          isTyping={isTyping}
          placeholder="Pergunte ao Nutri Coach..."
          suggestions={quickQuestions}
          onSuggestionClick={handleSendMessage}
          showSuggestions={!messages.some(msg => !msg.isAI && msg.id !== 'welcome')}
        />
      </motion.div>
    </div>
  );
};

export default NutritionAIChat;