import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { VoltCard } from '@/components/VoltCard';
import { LineChart, Line, PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, Calendar, Award } from 'lucide-react';
import { format, subDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export function NutritionAnalytics() {
  const [weeklyData, setWeeklyData] = useState<any[]>([]);
  const [macroDistribution, setMacroDistribution] = useState<any[]>([]);
  const [streak, setStreak] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = subDays(new Date(), 6 - i);
      return format(date, 'yyyy-MM-dd');
    });

    const { data: logs } = await supabase
      .from('nutrition_logs')
      .select('*')
      .eq('user_id', user.id)
      .gte('date', last7Days[0])
      .lte('date', last7Days[6]);

    if (logs) {
      const dailyTotals = last7Days.map(date => {
        const dayLogs = logs.filter(log => log.date === date);
        return {
          date: format(new Date(date), 'EEE', { locale: ptBR }),
          calories: dayLogs.reduce((sum, log) => sum + log.calories, 0),
          protein: dayLogs.reduce((sum, log) => sum + log.protein, 0),
          carbs: dayLogs.reduce((sum, log) => sum + log.carbs, 0),
          fat: dayLogs.reduce((sum, log) => sum + log.fat, 0)
        };
      });

      setWeeklyData(dailyTotals);

      const totalProtein = dailyTotals.reduce((sum, day) => sum + day.protein, 0);
      const totalCarbs = dailyTotals.reduce((sum, day) => sum + day.carbs, 0);
      const totalFat = dailyTotals.reduce((sum, day) => sum + day.fat, 0);

      setMacroDistribution([
        { name: 'Proteína', value: totalProtein, color: '#ef4444' },
        { name: 'Carboidrato', value: totalCarbs, color: '#eab308' },
        { name: 'Gordura', value: totalFat, color: '#22c55e' }
      ]);

      let currentStreak = 0;
      const uniqueDates = [...new Set(logs.map(log => log.date))].sort().reverse();
      for (let i = 0; i < uniqueDates.length; i++) {
        const expectedDate = format(subDays(new Date(), i), 'yyyy-MM-dd');
        if (uniqueDates[i] === expectedDate) {
          currentStreak++;
        } else {
          break;
        }
      }
      setStreak(currentStreak);
    }

    setLoading(false);
  };

  if (loading) {
    return <div className="text-center py-8 text-txt-3">Carregando estatísticas...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <VoltCard className="p-4" glow>
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-full bg-accent/20">
              <Award className="w-6 h-6 text-accent" />
            </div>
            <div>
              <p className="text-xs text-txt-3">Sequência Atual</p>
              <p className="text-2xl font-bold">{streak} dias</p>
            </div>
          </div>
        </VoltCard>

        <VoltCard className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-full bg-green-500/20">
              <TrendingUp className="w-6 h-6 text-green-400" />
            </div>
            <div>
              <p className="text-xs text-txt-3">Média Semanal</p>
              <p className="text-2xl font-bold">
                {Math.round(weeklyData.reduce((sum, day) => sum + day.calories, 0) / 7)} kcal
              </p>
            </div>
          </div>
        </VoltCard>

        <VoltCard className="p-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-full bg-blue-500/20">
              <Calendar className="w-6 h-6 text-blue-400" />
            </div>
            <div>
              <p className="text-xs text-txt-3">Dias Logados</p>
              <p className="text-2xl font-bold">{weeklyData.filter(d => d.calories > 0).length}/7</p>
            </div>
          </div>
        </VoltCard>
      </div>

      <VoltCard className="p-4">
        <h3 className="font-semibold mb-4">Calorias Semanais</h3>
        <ResponsiveContainer width="100%" height={250}>
          <LineChart data={weeklyData}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
            <XAxis dataKey="date" stroke="rgba(255,255,255,0.5)" />
            <YAxis stroke="rgba(255,255,255,0.5)" />
            <Tooltip
              contentStyle={{
                backgroundColor: 'rgba(0,0,0,0.8)',
                border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: '8px'
              }}
            />
            <Line
              type="monotone"
              dataKey="calories"
              stroke="#a855f7"
              strokeWidth={3}
              dot={{ fill: '#a855f7', r: 4 }}
              activeDot={{ r: 6 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </VoltCard>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <VoltCard className="p-4">
          <h3 className="font-semibold mb-4">Distribuição de Macros (Semana)</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={macroDistribution}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
                label={(entry) => `${entry.name}: ${Math.round(entry.value)}g`}
              >
                {macroDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </VoltCard>

        <VoltCard className="p-4">
          <h3 className="font-semibold mb-4">Macros por Dia</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={weeklyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis dataKey="date" stroke="rgba(255,255,255,0.5)" />
              <YAxis stroke="rgba(255,255,255,0.5)" />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(0,0,0,0.8)',
                  border: '1px solid rgba(255,255,255,0.1)',
                  borderRadius: '8px'
                }}
              />
              <Legend />
              <Bar dataKey="protein" fill="#ef4444" name="Proteína" />
              <Bar dataKey="carbs" fill="#eab308" name="Carboidrato" />
              <Bar dataKey="fat" fill="#22c55e" name="Gordura" />
            </BarChart>
          </ResponsiveContainer>
        </VoltCard>
      </div>
    </div>
  );
}
