import { motion, AnimatePresence } from 'framer-motion';
import { RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePWA } from '@/hooks/usePWA';

export function UpdatePrompt() {
  const { updateAvailable, updateApp } = usePWA();

  return (
    <AnimatePresence>
      {updateAvailable && (
        <motion.div
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -50, opacity: 0 }}
          className="fixed top-0 left-0 right-0 z-[100] bg-primary/90 backdrop-blur-sm py-2 px-4"
        >
          <div className="flex items-center justify-center gap-4">
            <span className="text-sm text-white">Nova versão disponível!</span>
            <Button
              size="sm"
              variant="secondary"
              onClick={updateApp}
              className="h-7 px-3 text-xs"
            >
              <RefreshCw className="w-3 h-3 mr-1" />
              Atualizar
            </Button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
