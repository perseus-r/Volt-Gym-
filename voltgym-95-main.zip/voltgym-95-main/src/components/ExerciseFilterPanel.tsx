import { VoltCard } from './VoltCard';
import { PremiumBadge } from './PremiumBadge';
import { Badge } from './ui/badge';
import { Slider } from './ui/slider';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { 
  Dumbbell, Zap, TrendingUp, Heart, 
  Target, Activity, Flame, BarChart2 
} from 'lucide-react';
import { motion } from 'framer-motion';

interface ExerciseFilters {
  muscleGroups: string[];
  difficulty: number[];
  equipment: string[];
  complexity: number[];
  lowRiskOnly: boolean;
}

interface ExerciseFilterPanelProps {
  filters: ExerciseFilters;
  onChange: (filters: ExerciseFilters) => void;
}

const muscleGroupsData = [
  { id: 'peito', name: 'Peito', icon: Heart, color: 'from-red-500 to-pink-500' },
  { id: 'costas', name: 'Costas', icon: Target, color: 'from-blue-500 to-cyan-500' },
  { id: 'ombros', name: 'Ombros', icon: Zap, color: 'from-yellow-500 to-orange-500' },
  { id: 'quadriceps', name: 'Quadríceps', icon: TrendingUp, color: 'from-green-500 to-emerald-500' },
  { id: 'isquiotibiais', name: 'Posteriores', icon: Flame, color: 'from-purple-500 to-pink-500' },
  { id: 'biceps', name: 'Bíceps', icon: Activity, color: 'from-indigo-500 to-blue-500' },
  { id: 'triceps', name: 'Tríceps', icon: Dumbbell, color: 'from-orange-500 to-red-500' },
  { id: 'core', name: 'Core', icon: BarChart2, color: 'from-teal-500 to-cyan-500' },
];

const equipmentOptions = [
  'Barra',
  'Halter',
  'Cabo',
  'Máquina',
  'Peso Corporal',
  'Elástico'
];

const difficultyLevels = [
  { value: 1, label: 'Iniciante', color: 'success' },
  { value: 2, label: 'Intermediário', color: 'info' },
  { value: 3, label: 'Avançado', color: 'warning' },
  { value: 4, label: 'Expert', color: 'error' }
];

export function ExerciseFilterPanel({ filters, onChange }: ExerciseFilterPanelProps) {
  const toggleMuscleGroup = (group: string) => {
    const newGroups = filters.muscleGroups.includes(group)
      ? filters.muscleGroups.filter(g => g !== group)
      : [...filters.muscleGroups, group];
    onChange({ ...filters, muscleGroups: newGroups });
  };

  const toggleDifficulty = (level: number) => {
    const newDifficulty = filters.difficulty.includes(level)
      ? filters.difficulty.filter(d => d !== level)
      : [...filters.difficulty, level];
    onChange({ ...filters, difficulty: newDifficulty });
  };

  const toggleEquipment = (equip: string) => {
    const newEquipment = filters.equipment.includes(equip)
      ? filters.equipment.filter(e => e !== equip)
      : [...filters.equipment, equip];
    onChange({ ...filters, equipment: newEquipment });
  };

  return (
    <div className="space-y-stack-lg">
      {/* Muscle Groups */}
      <VoltCard variant="glass" className="card-padding-md">
        <h3 className="text-subsection mb-stack-sm">Grupos Musculares</h3>
        <div className="grid grid-cols-2 gap-3">
          {muscleGroupsData.map((group) => {
            const Icon = group.icon;
            const isSelected = filters.muscleGroups.includes(group.id);
            
            return (
              <motion.button
                key={group.id}
                whileTap={{ scale: 0.95 }}
                onClick={() => toggleMuscleGroup(group.id)}
                className={`
                  p-3 rounded-xl transition-all border-2
                  ${isSelected 
                    ? 'border-accent bg-accent/10 shadow-accent/30' 
                    : 'border-line/30 glass-subtle hover:border-accent/50'
                  }
                `}
              >
                <div className={`w-10 h-10 rounded-lg bg-gradient-to-r ${group.color} flex items-center justify-center mb-2 mx-auto`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <p className={`text-label ${isSelected ? 'text-accent' : 'text-txt'}`}>
                  {group.name}
                </p>
              </motion.button>
            );
          })}
        </div>
      </VoltCard>

      {/* Difficulty */}
      <VoltCard variant="glass" className="card-padding-md">
        <h3 className="text-subsection mb-stack-sm">Nível de Dificuldade</h3>
        <div className="flex flex-wrap gap-2">
          {difficultyLevels.map((level) => {
            const isSelected = filters.difficulty.includes(level.value);
            
            return (
              <PremiumBadge
                key={level.value}
                variant={isSelected ? level.color as any : 'default'}
                onClick={() => toggleDifficulty(level.value)}
                className="cursor-pointer hover-scale"
              >
                {level.label}
              </PremiumBadge>
            );
          })}
        </div>
      </VoltCard>

      {/* Equipment */}
      <VoltCard variant="glass" className="card-padding-md">
        <h3 className="text-subsection mb-stack-sm">Equipamento</h3>
        <div className="flex flex-wrap gap-2">
          {equipmentOptions.map((equip) => {
            const isSelected = filters.equipment.includes(equip);
            
            return (
              <Badge
                key={equip}
                variant={isSelected ? 'default' : 'outline'}
                onClick={() => toggleEquipment(equip)}
                className={`cursor-pointer transition-all ${
                  isSelected 
                    ? 'bg-accent text-accent-ink' 
                    : 'hover:bg-surface/50'
                }`}
              >
                <Dumbbell className="w-3 h-3 mr-1" />
                {equip}
              </Badge>
            );
          })}
        </div>
      </VoltCard>

      {/* Complexity Slider */}
      <VoltCard variant="glass" className="card-padding-md">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-subsection">Complexidade de Execução</h3>
            <Badge variant="outline" className="text-label">
              {filters.complexity[0]} - {filters.complexity[1]}
            </Badge>
          </div>
          <Slider
            min={1}
            max={5}
            step={1}
            value={filters.complexity}
            onValueChange={(value) => onChange({ ...filters, complexity: value })}
            className="w-full"
          />
          <div className="flex justify-between text-caption text-txt-3">
            <span>Simples</span>
            <span>Complexo</span>
          </div>
        </div>
      </VoltCard>

      {/* Risk Toggle */}
      <VoltCard variant="glass" className="card-padding-md">
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="low-risk" className="text-body-premium cursor-pointer">
              Apenas Baixo Risco de Lesão
            </Label>
            <p className="text-caption text-txt-3 mt-1">
              Mostrar apenas exercícios mais seguros
            </p>
          </div>
          <Switch
            id="low-risk"
            checked={filters.lowRiskOnly}
            onCheckedChange={(checked) => onChange({ ...filters, lowRiskOnly: checked })}
          />
        </div>
      </VoltCard>
    </div>
  );
}