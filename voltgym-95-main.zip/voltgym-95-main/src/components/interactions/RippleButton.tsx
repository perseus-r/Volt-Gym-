import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import { easings, durations } from '@/utils/animations';

interface RippleButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  rippleColor?: string;
}

interface Ripple {
  x: number;
  y: number;
  size: number;
  id: number;
}

export function RippleButton({
  children,
  variant = 'primary',
  size = 'md',
  rippleColor = 'rgba(255, 255, 255, 0.6)',
  className,
  onClick,
  disabled,
  ...props
}: RippleButtonProps) {
  const [ripples, setRipples] = useState<Ripple[]>();
  const buttonRef = useRef<HTMLButtonElement>(null);

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (disabled) return;

    const button = buttonRef.current;
    if (!button) return;

    const rect = button.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = e.clientX - rect.left - size / 2;
    const y = e.clientY - rect.top - size / 2;

    const newRipple: Ripple = {
      x,
      y,
      size,
      id: Date.now(),
    };

    setRipples((prev) => [...(prev || []), newRipple]);

    // Remove ripple after animation
    setTimeout(() => {
      setRipples((prev) => prev?.filter((r) => r.id !== newRipple.id));
    }, 600);

    // Haptic feedback simulation
    if (navigator.vibrate) {
      navigator.vibrate(5);
    }

    onClick?.(e);
  };

  const variantStyles = {
    primary: 'bg-gradient-to-r from-accent to-accent-2 text-accent-ink shadow-lg shadow-accent/30 hover:shadow-xl hover:shadow-accent/40',
    secondary: 'bg-surface/80 backdrop-blur-md text-txt border border-line hover:border-accent/50',
    ghost: 'bg-transparent text-txt-2 hover:text-txt hover:bg-white/5',
  };

  const sizeStyles = {
    sm: 'px-4 py-2 text-sm rounded-lg',
    md: 'px-6 py-3 text-base rounded-xl',
    lg: 'px-8 py-4 text-lg rounded-2xl',
  };

  // Extract motion-specific props
  const { onAnimationStart, onDrag, onDragStart, onDragEnd, ...buttonProps } = props;

  return (
    <motion.button
      ref={buttonRef}
      onClick={handleClick}
      disabled={disabled}
      whileHover={{ scale: disabled ? 1 : 1.02 }}
      whileTap={{ scale: disabled ? 1 : 0.98 }}
      transition={{
        duration: durations.fast,
        ease: easings.snappy,
      }}
      className={cn(
        'relative overflow-hidden font-semibold transition-all',
        'touch-manipulation select-none',
        'disabled:opacity-50 disabled:cursor-not-allowed',
        variantStyles[variant],
        sizeStyles[size],
        className
      )}
      style={{
        WebkitTapHighlightColor: 'transparent',
      }}
    >
      {/* Content */}
      <span className="relative z-10 flex items-center justify-center gap-2">
        {children}
      </span>

      {/* Ripple effects */}
      <AnimatePresence>
        {ripples?.map((ripple) => (
          <motion.span
            key={ripple.id}
            className="absolute rounded-full pointer-events-none"
            style={{
              left: ripple.x,
              top: ripple.y,
              width: ripple.size,
              height: ripple.size,
              backgroundColor: rippleColor,
            }}
            initial={{ scale: 0, opacity: 1 }}
            animate={{ scale: 4, opacity: 0 }}
            exit={{ opacity: 0 }}
            transition={{
              duration: 0.6,
              ease: easings.smooth,
            }}
          />
        ))}
      </AnimatePresence>

      {/* Shimmer effect for primary variant */}
      {variant === 'primary' && !disabled && (
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
          initial={{ x: '-100%' }}
          animate={{ x: '100%' }}
          transition={{
            duration: 2,
            repeat: Infinity,
            repeatDelay: 3,
            ease: 'linear',
          }}
        />
      )}
    </motion.button>
  );
}
