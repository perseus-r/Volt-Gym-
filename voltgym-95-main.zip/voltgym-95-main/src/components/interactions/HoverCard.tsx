import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { easings, durations } from '@/utils/animations';

interface HoverCardProps {
  children: React.ReactNode;
  className?: string;
  depth?: 1 | 2 | 3;
  glow?: boolean;
  onClick?: () => void;
}

export function HoverCard({
  children,
  className,
  depth = 2,
  glow = false,
  onClick,
}: HoverCardProps) {
  const depthStyles = {
    1: 'bg-surface/60 border-white/5 shadow-none',
    2: 'bg-surface/80 border-white/8 shadow-lg shadow-black/20',
    3: 'bg-surface/95 border-white/12 shadow-2xl shadow-black/40',
  };

  const Component = onClick ? motion.button : motion.div;

  return (
    <Component
      onClick={onClick}
      className={cn(
        'relative rounded-2xl border backdrop-blur-xl transition-all',
        'touch-manipulation select-none',
        depthStyles[depth],
        onClick && 'cursor-pointer',
        className
      )}
      whileHover={{
        scale: 1.02,
        y: -4,
        boxShadow: glow 
          ? '0 20px 40px rgba(0, 0, 0, 0.3), 0 0 30px rgba(55, 160, 244, 0.3)'
          : '0 20px 40px rgba(0, 0, 0, 0.3)',
      }}
      whileTap={onClick ? { scale: 0.98, y: 0 } : undefined}
      transition={{
        duration: durations.normal,
        ease: easings.apple,
      }}
      style={{
        willChange: 'transform',
        backfaceVisibility: 'hidden',
        WebkitTapHighlightColor: 'transparent',
      }}
    >
      {/* Inner glow effect */}
      {glow && (
        <div className="absolute inset-0 rounded-2xl overflow-hidden pointer-events-none">
          <motion.div
            className="absolute inset-0 bg-gradient-to-br from-accent/10 via-transparent to-accent/5"
            animate={{
              opacity: [0.3, 0.6, 0.3],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        </div>
      )}

      {/* Border gradient */}
      <div className="absolute inset-0 rounded-2xl overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-br from-white/10 via-transparent to-transparent opacity-50" />
      </div>

      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>
    </Component>
  );
}

interface InteractiveCardProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
  href?: string;
}

export function InteractiveCard({
  children,
  className,
  onClick,
  href,
}: InteractiveCardProps) {
  const Component = href ? motion.a : motion.div;
  const props = href ? { href } : { onClick };

  return (
    <Component
      {...props}
      className={cn(
        'relative block p-6 rounded-2xl border border-white/8',
        'bg-surface/80 backdrop-blur-xl',
        'transition-all cursor-pointer',
        'touch-manipulation select-none',
        className
      )}
      whileHover={{
        scale: 1.02,
        y: -2,
        borderColor: 'rgba(55, 160, 244, 0.3)',
      }}
      whileTap={{ scale: 0.98 }}
      transition={{
        duration: durations.fast,
        ease: easings.snappy,
      }}
      style={{
        WebkitTapHighlightColor: 'transparent',
      }}
    >
      {/* Hover gradient overlay */}
      <motion.div
        className="absolute inset-0 rounded-2xl bg-gradient-to-br from-accent/10 via-transparent to-transparent opacity-0 pointer-events-none"
        whileHover={{ opacity: 1 }}
        transition={{
          duration: durations.normal,
          ease: easings.smooth,
        }}
      />

      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>
    </Component>
  );
}
