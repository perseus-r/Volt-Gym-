import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { Slider } from '@/components/ui/slider';
import { unifiedDataService } from '@/services/UnifiedDataService';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { 
  Play, 
  Pause, 
  Square, 
  Plus, 
  Minus, 
  Clock, 
  Target, 
  Zap, 
  Save,
  SkipForward,
  Volume2,
  VolumeX,
  Timer,
  CheckCircle,
  TrendingUp,
  Flame,
  Trophy,
  Dumbbell,
  Activity,
  ChevronRight,
  ChevronLeft,
  RotateCcw,
  Share2
} from 'lucide-react';

interface Exercise {
  name: string;
  sets?: number;
  reps?: number | string;
  weight?: number;
  rest?: number;
  rpe?: number;
  notes?: string;
}

interface WorkoutSet {
  setNumber: number;
  reps: number;
  weight: number;
  rpe: number;
  completed: boolean;
  restTime?: number;
  timestamp?: number;
}

interface ExerciseLog {
  exercise: Exercise;
  sets: WorkoutSet[];
  notes: string;
  completed: boolean;
}

interface PremiumWorkoutSessionProps {
  workout: {
    id: string;
    name?: string;
    focus: string;
    exercises: Exercise[];
  };
  onClose: () => void;
  onComplete: () => void;
}

export function PremiumWorkoutSession({ workout, onClose, onComplete }: PremiumWorkoutSessionProps) {
  const { user } = useAuth();
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);
  const [exerciseLogs, setExerciseLogs] = useState<ExerciseLog[]>([]);
  const [isResting, setIsResting] = useState(false);
  const [restTimer, setRestTimer] = useState(0);
  const [sessionStartTime] = useState(new Date());
  const [sessionDuration, setSessionDuration] = useState(0);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [autoRest, setAutoRest] = useState(true);
  const [showNotes, setShowNotes] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const durationIntervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const initialLogs: ExerciseLog[] = workout.exercises.map((exercise) => ({
      exercise,
      sets: Array.from({ length: exercise.sets || 3 }, (_, index) => ({
        setNumber: index + 1,
        reps: typeof exercise.reps === 'number' ? exercise.reps : 10,
        weight: exercise.weight || 0,
        rpe: exercise.rpe || 7,
        completed: false,
        restTime: exercise.rest || 90,
        timestamp: 0
      })),
      notes: exercise.notes || '',
      completed: false
    }));
    
    setExerciseLogs(initialLogs);

    durationIntervalRef.current = setInterval(() => {
      setSessionDuration(Math.floor((Date.now() - sessionStartTime.getTime()) / 1000));
    }, 1000);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (durationIntervalRef.current) clearInterval(durationIntervalRef.current);
    };
  }, [workout.exercises, sessionStartTime]);

  useEffect(() => {
    if (isResting && restTimer > 0) {
      intervalRef.current = setInterval(() => {
        setRestTimer((prev) => {
          if (prev <= 1) {
            setIsResting(false);
            if (soundEnabled) playNotificationSound();
            toast.success('⏰ Descanso terminado! Vamos lá! 💪');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isResting, restTimer, soundEnabled]);

  const playNotificationSound = () => {
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gain = audioContext.createGain();
      
      oscillator.connect(gain);
      gain.connect(audioContext.destination);
      
      oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
      gain.gain.setValueAtTime(0.1, audioContext.currentTime);
      
      oscillator.start();
      oscillator.stop(audioContext.currentTime + 0.2);
    } catch (error) {
      console.log('Não foi possível tocar o som');
    }
  };

  const updateSet = (exerciseIndex: number, setIndex: number, field: keyof WorkoutSet, value: any) => {
    setExerciseLogs(prev => {
      const updated = [...prev];
      updated[exerciseIndex].sets[setIndex] = {
        ...updated[exerciseIndex].sets[setIndex],
        [field]: value
      };
      return updated;
    });
  };

  const completeSet = (exerciseIndex: number, setIndex: number) => {
    updateSet(exerciseIndex, setIndex, 'completed', true);
    updateSet(exerciseIndex, setIndex, 'timestamp', Date.now());
    
    const exerciseLog = exerciseLogs[exerciseIndex];
    const set = exerciseLog.sets[setIndex];
    
    if (autoRest && set.restTime && set.restTime > 0 && setIndex < exerciseLog.sets.length - 1) {
      setRestTimer(set.restTime);
      setIsResting(true);
      toast.success(`🔥 Série ${setIndex + 1} concluída! Descanse ${set.restTime}s`);
    } else {
      toast.success(`✅ Série ${setIndex + 1} concluída!`);
    }

    const allSetsCompleted = exerciseLog.sets.every(s => s.completed);
    if (allSetsCompleted) {
      completeExercise(exerciseIndex);
    }
  };

  const completeExercise = (exerciseIndex: number) => {
    setExerciseLogs(prev => {
      const updated = [...prev];
      updated[exerciseIndex].completed = true;
      return updated;
    });

    toast.success(`🎯 ${exerciseLogs[exerciseIndex].exercise.name} concluído!`, {
      duration: 3000,
    });

    if (exerciseIndex < exerciseLogs.length - 1) {
      setTimeout(() => setCurrentExerciseIndex(exerciseIndex + 1), 1000);
    }
  };

  const addExtraSet = (exerciseIndex: number) => {
    setExerciseLogs(prev => {
      const updated = [...prev];
      const lastSet = updated[exerciseIndex].sets[updated[exerciseIndex].sets.length - 1];
      const newSet: WorkoutSet = {
        setNumber: updated[exerciseIndex].sets.length + 1,
        reps: lastSet.reps,
        weight: lastSet.weight,
        rpe: lastSet.rpe,
        completed: false,
        restTime: lastSet.restTime,
        timestamp: 0
      };
      updated[exerciseIndex].sets.push(newSet);
      return updated;
    });
    
    toast.success('➕ Série extra adicionada!');
  };

  const skipRest = () => {
    setIsResting(false);
    setRestTimer(0);
    toast.info('⏭️ Descanso pulado');
  };

  const finishWorkout = async () => {
    try {
      const completedExercises = exerciseLogs.filter(log => 
        log.sets.some(s => s.completed)
      );

      if (completedExercises.length === 0) {
        toast.error('Complete pelo menos um exercício antes de finalizar');
        return;
      }

      const sessionData = {
        name: workout.name || workout.focus,
        focus: workout.focus,
        exercises: completedExercises.map(log => ({
          name: log.exercise.name,
          weight: log.sets.reduce((sum, set) => sum + (set.completed ? set.weight : 0), 0) / log.sets.filter(s => s.completed).length || 0,
          reps: log.sets.reduce((sum, set) => sum + (set.completed ? set.reps : 0), 0) / log.sets.filter(s => s.completed).length || 0,
          rpe: log.sets.reduce((sum, set) => sum + (set.completed ? set.rpe : 0), 0) / log.sets.filter(s => s.completed).length || 0,
          notes: log.notes,
          sets: log.sets.filter(s => s.completed).length
        })),
        duration_minutes: Math.floor(sessionDuration / 60)
      };

      await unifiedDataService.saveWorkout(sessionData);
      
      toast.success('🎉 Treino finalizado e salvo com sucesso!', {
        duration: 4000,
      });
      
      onComplete();
      onClose();
      
    } catch (error) {
      console.error('Erro ao finalizar treino:', error);
      toast.error('Erro ao salvar treino. Tente novamente.');
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const currentExercise = exerciseLogs[currentExerciseIndex];
  const progressPercentage = (exerciseLogs.filter(log => log.completed).length / exerciseLogs.length) * 100;
  const completedSets = exerciseLogs.reduce((total, log) => total + log.sets.filter(s => s.completed).length, 0);
  const totalSets = exerciseLogs.reduce((total, log) => total + log.sets.length, 0);
  const totalVolume = exerciseLogs.reduce((total, log) => 
    total + log.sets.filter(s => s.completed).reduce((sum, set) => sum + (set.weight * set.reps), 0), 0
  );

  // Tela de descanso
  if (isResting) {
    return (
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="fixed inset-0 bg-gradient-to-br from-black via-accent/20 to-black z-50 flex items-center justify-center p-3"
      >
        <Card className="p-6 text-center max-w-sm w-full bg-surface/95 backdrop-blur-xl border border-accent/30 shadow-2xl">
          <motion.div
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-20 h-20 mx-auto bg-gradient-to-br from-accent to-accent-2 rounded-full flex items-center justify-center mb-4 shadow-lg shadow-accent/50"
          >
            <Timer className="w-10 h-10 text-accent-ink" />
          </motion.div>
          
          <h3 className="text-xl font-black text-txt mb-2">Descansando</h3>
          <p className="text-txt-2 mb-4 text-sm">Prepare-se para a próxima série 💪</p>
          
          <div className="text-5xl font-black text-accent mb-4 drop-shadow-lg">
            {formatTime(restTimer)}
          </div>
          
          <Progress value={((90 - restTimer) / 90) * 100} className="h-3 mb-4" />
          
          <div className="flex gap-3">
            <Button 
              onClick={skipRest} 
              variant="outline" 
              size="default"
              className="flex-1 h-11 text-base font-bold border"
            >
              <SkipForward className="w-4 h-4 mr-2" />
              Pular
            </Button>
            <Button 
              onClick={onClose} 
              variant="ghost" 
              size="default"
              className="flex-1 h-11 text-base"
            >
              <Pause className="w-4 h-4 mr-2" />
              Pausar
            </Button>
          </div>
        </Card>
      </motion.div>
    );
  }

  return (
    <div className="fixed inset-0 bg-bg z-50 overflow-y-auto">
      <div className="min-h-screen pb-32">
        {/* Header Fixo */}
        <div className="sticky top-0 bg-gradient-to-r from-accent/20 via-accent/10 to-accent/20 backdrop-blur-xl border-b border-accent/30 z-10 shadow-md">
          <div className="max-w-3xl mx-auto p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex-1">
                <h1 className="text-xl font-black text-txt">{workout.name || workout.focus}</h1>
                {workout.name && workout.name !== workout.focus && (
                  <p className="text-txt-2 text-xs font-medium">{workout.focus}</p>
                )}
              </div>
              <div className="text-right">
                <div className="text-xl font-black text-accent">{formatTime(sessionDuration)}</div>
                <div className="text-xs text-txt-2 font-semibold">Duração</div>
              </div>
            </div>

            {/* Stats rápidas */}
            <div className="grid grid-cols-3 gap-2 mb-3">
              <Card className="p-2 bg-surface/50 border-accent/20 text-center">
                <div className="text-lg font-black text-accent">{completedSets}/{totalSets}</div>
                <div className="text-[10px] text-txt-2 font-semibold">Séries</div>
              </Card>
              <Card className="p-2 bg-surface/50 border-accent/20 text-center">
                <div className="text-lg font-black text-accent">{Math.round(totalVolume)}kg</div>
                <div className="text-[10px] text-txt-2 font-semibold">Volume</div>
              </Card>
              <Card className="p-2 bg-surface/50 border-accent/20 text-center">
                <div className="text-lg font-black text-accent">{currentExerciseIndex + 1}/{exerciseLogs.length}</div>
                <div className="text-[10px] text-txt-2 font-semibold">Exercício</div>
              </Card>
            </div>

            <Progress value={progressPercentage} className="h-2 mb-3" />

            {/* Controles */}
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setSoundEnabled(!soundEnabled)}
                className="gap-2 font-semibold"
              >
                {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
                {soundEnabled ? 'Som On' : 'Som Off'}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setAutoRest(!autoRest)}
                className="gap-2 font-semibold"
              >
                <Timer className="w-4 h-4" />
                {autoRest ? 'Auto' : 'Manual'}
              </Button>
              <div className="flex-1" />
              <Button
                variant="outline"
                size="sm"
                onClick={onClose}
                className="text-red-400 hover:text-red-300 font-semibold border-red-400/30"
              >
                <Square className="w-4 h-4 mr-2" />
                Parar
              </Button>
            </div>
          </div>
        </div>

        {/* Conteúdo Principal */}
        <div className="max-w-3xl mx-auto p-4 space-y-4">
          {/* Exercício Atual */}
          {currentExercise && (
            <motion.div
              key={currentExerciseIndex}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="p-4 bg-gradient-to-br from-accent/10 via-surface to-surface border border-accent/30 shadow-lg">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-accent to-accent-2 rounded-xl flex items-center justify-center shadow-md">
                      <Dumbbell className="w-6 h-6 text-accent-ink" />
                    </div>
                    <div>
                      <h2 className="text-lg font-black text-txt flex items-center gap-2">
                        {currentExercise.exercise.name}
                      </h2>
                      <p className="text-txt-2 text-xs font-semibold">
                        Exercício {currentExerciseIndex + 1} de {exerciseLogs.length}
                      </p>
                    </div>
                  </div>
                  {currentExercise.completed && (
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/50 px-2 py-1 text-xs font-bold">
                      <CheckCircle className="w-4 h-4 mr-1" />
                      OK
                    </Badge>
                  )}
                </div>

                {/* Séries */}
                <div className="space-y-2 mb-4">
                  <AnimatePresence mode="wait">
                    {currentExercise.sets.map((set, setIndex) => (
                      <motion.div
                        key={setIndex}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ delay: setIndex * 0.05 }}
                      >
                        <Card className={`p-3 transition-all ${
                          set.completed 
                            ? 'bg-green-500/15 border border-green-500/40 shadow-md shadow-green-500/20' 
                            : 'bg-surface/70 border border-line/20 hover:border-accent/40'
                        }`}>
                          <div className="flex items-center gap-2">
                            <div className={`font-bold text-sm min-w-[50px] ${
                              set.completed ? 'text-green-400' : 'text-txt'
                            }`}>
                              S{set.setNumber}
                            </div>
                            
                            <div className="flex items-center gap-2 flex-1 flex-wrap">
                              <div className="flex items-center gap-1">
                                <span className="text-xs text-txt-2 font-semibold">R:</span>
                                <Input
                                  type="number"
                                  value={set.reps}
                                  onChange={(e) => updateSet(currentExerciseIndex, setIndex, 'reps', parseInt(e.target.value) || 0)}
                                  className="w-14 h-8 text-center text-sm font-bold"
                                  disabled={set.completed}
                                />
                              </div>

                              <div className="flex items-center gap-1">
                                <Button
                                  variant="outline"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => updateSet(currentExerciseIndex, setIndex, 'weight', Math.max(0, set.weight - 2.5))}
                                  disabled={set.completed}
                                >
                                  <Minus className="w-3 h-3" />
                                </Button>
                                <div className="flex items-center gap-0.5">
                                  <Input
                                    type="number"
                                    value={set.weight}
                                    onChange={(e) => updateSet(currentExerciseIndex, setIndex, 'weight', parseFloat(e.target.value) || 0)}
                                    className="w-16 h-8 text-center text-sm font-bold"
                                    disabled={set.completed}
                                    step="0.5"
                                  />
                                  <span className="text-[10px] text-txt-3 font-bold">kg</span>
                                </div>
                                <Button
                                  variant="outline"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => updateSet(currentExerciseIndex, setIndex, 'weight', set.weight + 2.5)}
                                  disabled={set.completed}
                                >
                                  <Plus className="w-3 h-3" />
                                </Button>
                              </div>

                              <div className="flex items-center gap-1">
                                <span className="text-xs text-txt-2 font-semibold">RPE:</span>
                                <Input
                                  type="number"
                                  value={set.rpe}
                                  onChange={(e) => updateSet(currentExerciseIndex, setIndex, 'rpe', Math.min(10, Math.max(1, parseInt(e.target.value) || 7)))}
                                  className="w-12 h-8 text-center text-sm font-bold"
                                  disabled={set.completed}
                                  min="1"
                                  max="10"
                                />
                              </div>
                            </div>

                            {!set.completed ? (
                              <Button
                                onClick={() => completeSet(currentExerciseIndex, setIndex)}
                                size="sm"
                                className="bg-gradient-to-r from-accent to-accent-2 text-accent-ink hover:scale-105 transition-transform font-bold h-10 px-4"
                              >
                                <CheckCircle className="w-4 h-4 mr-1" />
                                OK
                              </Button>
                            ) : (
                              <div className="text-green-400">
                                <CheckCircle className="w-6 h-6" />
                              </div>
                            )}
                          </div>
                        </Card>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>

                {/* Ações do Exercício */}
                <div className="flex flex-wrap gap-2">
                  <Button
                    onClick={() => addExtraSet(currentExerciseIndex)}
                    variant="outline"
                    size="sm"
                    className="gap-1.5 font-bold h-10 border text-xs"
                  >
                    <Plus className="w-4 h-4" />
                    +Série
                  </Button>
                  
                  <Button
                    onClick={() => setShowNotes(!showNotes)}
                    variant="outline"
                    size="sm"
                    className="gap-1.5 font-bold h-10 border text-xs"
                  >
                    <Activity className="w-4 h-4" />
                    Notas
                  </Button>
                  
                  {!currentExercise.completed && currentExercise.sets.some(s => s.completed) && (
                    <Button
                      onClick={() => completeExercise(currentExerciseIndex)}
                      size="sm"
                      className="bg-gradient-to-r from-accent to-accent-2 text-accent-ink hover:scale-105 transition-transform gap-1.5 font-bold h-10 px-4 text-xs"
                    >
                      <CheckCircle className="w-4 h-4" />
                      Concluir
                    </Button>
                  )}

                  <div className="flex-1" />

                  {currentExerciseIndex > 0 && (
                    <Button
                      onClick={() => setCurrentExerciseIndex(currentExerciseIndex - 1)}
                      variant="outline"
                      size="sm"
                      className="gap-1 font-bold h-10"
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                  )}

                  {currentExerciseIndex < exerciseLogs.length - 1 && (
                    <Button
                      onClick={() => setCurrentExerciseIndex(currentExerciseIndex + 1)}
                      variant="outline"
                      size="sm"
                      className="gap-1 font-bold h-10"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  )}
                </div>

                {/* Notas */}
                <AnimatePresence>
                  {showNotes && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-6"
                    >
                      <label className="text-sm text-txt-2 font-semibold mb-2 block">Notas do exercício:</label>
                      <Textarea
                        value={currentExercise.notes}
                        onChange={(e) => {
                          setExerciseLogs(prev => {
                            const updated = [...prev];
                            updated[currentExerciseIndex].notes = e.target.value;
                            return updated;
                          });
                        }}
                        placeholder="Adicione observações sobre forma, sensações, ajustes..."
                        className="min-h-[80px] font-medium"
                      />
                    </motion.div>
                  )}
                </AnimatePresence>
              </Card>
            </motion.div>
          )}

          {/* Resumo Final */}
          <Card className="p-4 bg-gradient-to-br from-surface to-accent/5 border border-accent/20">
            <h3 className="text-lg font-black text-txt mb-3 flex items-center gap-2">
              <Trophy className="w-5 h-5 text-accent" />
              Resumo
            </h3>
            
            <div className="grid grid-cols-4 gap-2 mb-4">
              <div className="text-center p-2 bg-surface/50 rounded-lg border border-line/20">
                <div className="text-xl font-black text-accent">{completedSets}</div>
                <div className="text-[10px] text-txt-2 font-semibold">Séries</div>
              </div>
              <div className="text-center p-2 bg-surface/50 rounded-lg border border-line/20">
                <div className="text-xl font-black text-accent">{Math.round(totalVolume)}</div>
                <div className="text-[10px] text-txt-2 font-semibold">Vol(kg)</div>
              </div>
              <div className="text-center p-2 bg-surface/50 rounded-lg border border-line/20">
                <div className="text-xl font-black text-accent">{exerciseLogs.filter(e => e.completed).length}</div>
                <div className="text-[10px] text-txt-2 font-semibold">Exerc.</div>
              </div>
              <div className="text-center p-2 bg-surface/50 rounded-lg border border-line/20">
                <div className="text-xl font-black text-accent">{formatTime(sessionDuration)}</div>
                <div className="text-[10px] text-txt-2 font-semibold">Tempo</div>
              </div>
            </div>

            <Button
              onClick={finishWorkout}
              disabled={completedSets === 0}
              size="default"
              className="w-full bg-gradient-to-r from-accent to-accent-2 text-accent-ink hover:scale-105 transition-transform font-black h-12 text-base"
            >
              <Trophy className="w-5 h-5 mr-2" />
              Finalizar Treino
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
}
