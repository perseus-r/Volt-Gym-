import { cn } from '@/lib/utils';

/**
 * Dashboard Skeleton - Shows immediately while content loads
 * CSS-first approach for instant rendering
 */
export function DashboardSkeleton() {
  return (
    <div className="min-h-screen bg-background pb-28 animate-in fade-in duration-150">
      {/* Header skeleton */}
      <div className="px-4 pt-4 pb-2">
        <div className="flex justify-end mb-2">
          <Skeleton className="w-10 h-10 rounded-full" />
        </div>
        <Skeleton className="h-32 rounded-2xl" />
      </div>

      {/* Content skeleton */}
      <div className="space-y-4 mt-4">
        {/* Insights */}
        <div className="px-4">
          <Skeleton className="h-24 rounded-xl" />
        </div>

        {/* Workouts grid */}
        <div className="px-4">
          <Skeleton className="h-4 w-24 mb-2" />
          <div className="grid grid-cols-2 gap-3">
            <Skeleton className="h-28 rounded-xl" />
            <Skeleton className="h-28 rounded-xl" />
          </div>
        </div>

        {/* Goals */}
        <div className="px-4">
          <Skeleton className="h-4 w-24 mb-2" />
          <Skeleton className="h-20 rounded-xl" />
        </div>

        {/* Progress grid */}
        <div className="px-4">
          <Skeleton className="h-4 w-28 mb-2" />
          <div className="grid grid-cols-2 gap-3">
            <Skeleton className="h-32 rounded-xl" />
            <Skeleton className="h-32 rounded-xl" />
          </div>
        </div>
      </div>
    </div>
  );
}

/**
 * Workouts page skeleton
 */
export function WorkoutsSkeleton() {
  return (
    <div className="min-h-screen bg-background pb-28 animate-in fade-in duration-150">
      <div className="px-4 pt-4 space-y-4">
        <Skeleton className="h-10 rounded-lg" />
        {[1, 2, 3].map(i => (
          <Skeleton key={i} className="h-24 rounded-xl" />
        ))}
      </div>
    </div>
  );
}

/**
 * Generic skeleton component
 */
function Skeleton({ className }: { className?: string }) {
  return (
    <div 
      className={cn(
        "bg-muted/50 animate-pulse rounded",
        className
      )}
    />
  );
}

export { Skeleton };
