import React, { useState, useEffect } from 'react';
import { TrendingUp, Target, Flame, BarChart3, Calendar, Zap } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useAuth } from '@/contexts/AuthContext';
import { unifiedDataService } from '@/services/UnifiedDataService';
import { WeeklyRing } from '@/components/WeeklyRing';
import MiniChart from '@/components/MiniChart';

export function ProgressOverview() {
  const { user } = useAuth();
  const [stats, setStats] = useState({
    level: 1,
    xp: 0,
    nextLevelXP: 100,
    streak: 0,
    workoutsThisWeek: 0,
    completedWorkouts: 0,
    weeklyGoal: 4,
    totalVolume: 0
  });
  const [workoutHistory, setWorkoutHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProgressData();
  }, [user?.id]);

  const loadProgressData = async () => {
    try {
      setLoading(true);
      
      if (user) {
        // Load real data from unified service
        const [userStats, history] = await Promise.all([
          unifiedDataService.getUserStats(),
          unifiedDataService.getWorkoutHistory(30)
        ]);
        
        const level = Math.floor(userStats.currentXP / 100) + 1;
        const nextLevelXP = level * 100;
        
        setStats({
          level,
          xp: userStats.currentXP,
          nextLevelXP,
          streak: userStats.streak,
          workoutsThisWeek: userStats.weeklyWorkouts,
          completedWorkouts: userStats.totalWorkouts,
          weeklyGoal: 4,
          totalVolume: userStats.totalVolume
        });
        setWorkoutHistory(history);
      } else {
        // Demo data for non-logged users
        setStats({
          level: 1,
          xp: 0,
          nextLevelXP: 100,
          streak: 0,
          workoutsThisWeek: 0,
          completedWorkouts: 0,
          weeklyGoal: 4,
          totalVolume: 0
        });
        setWorkoutHistory([]);
      }
    } catch (error) {
      console.error('Error loading progress data:', error);
    } finally {
      setLoading(false);
    }
  };

  const currentLevelProgress = ((stats.xp % 100) / 100) * 100;

  // Calculate volume progression for chart
  const volumeData = workoutHistory.slice(-7).map((workout, index) => ({
    name: `T${index + 1}`,
    value: workout.total_volume || 0
  }));

  const mainMetrics = [
    {
      icon: TrendingUp,
      title: "Volume Total",
      value: `${(stats.totalVolume / 1000).toFixed(1)}t`,
      description: "Peso total movimentado",
      change: stats.totalVolume > 0 ? "+100%" : "0%",
      changeType: "positive"
    },
    {
      icon: Target,
      title: "Treinos Realizados",
      value: stats.completedWorkouts,
      description: "Total de treinos completos",
      change: stats.workoutsThisWeek > 0 ? `${stats.workoutsThisWeek} esta semana` : "Nenhum esta semana",
      changeType: stats.workoutsThisWeek > 0 ? "positive" : "neutral"
    },
    {
      icon: Flame,
      title: "Streak Atual",
      value: `${stats.streak} dias`,
      description: "Sequência de treinos",
      change: "Continue assim!",
      changeType: "positive"
    },
    {
      icon: BarChart3,
      title: "Nível Atual",
      value: stats.level,
      description: `${stats.xp} XP total`,
      change: `${100 - (stats.xp % 100)} XP para próximo nível`,
      changeType: "neutral"
    }
  ];

  const weeklyGoals = [
    { name: "Treinos", current: stats.workoutsThisWeek, target: 4, color: "hsl(var(--accent))" },
    { name: "Volume", current: stats.totalVolume, target: 15000, color: "hsl(var(--accent-2))" },
    { name: "XP", current: stats.xp % 100, target: 100, color: "hsl(var(--success))" }
  ];

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="glass animate-pulse">
              <CardContent className="p-4">
                <div className="h-16 bg-surface/50 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Level Card - Compact */}
      <Card className="glass border-accent/20">
        <CardHeader className="pb-2 md:pb-3 pt-3 md:pt-4 px-3 md:px-4">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg md:text-xl text-txt">Nível {stats.level}</CardTitle>
              <p className="text-txt-2 text-xs">
                {stats.completedWorkouts === 0 ? 'Iniciante' : 
                 stats.completedWorkouts < 10 ? 'Novato' :
                 stats.completedWorkouts < 25 ? 'Guerreiro' :
                 stats.completedWorkouts < 50 ? 'Veterano' : 'Lenda'}
              </p>
            </div>
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-lg bg-accent/20 flex items-center justify-center">
              <div className="w-5 h-5 md:w-6 md:h-6 rounded bg-gradient-to-br from-accent to-accent-2"></div>
            </div>
          </div>
        </CardHeader>
        <CardContent className="px-3 md:px-4 pb-3 md:pb-4 pt-0">
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="text-txt-2">Progresso para Nível {stats.level + 1}</span>
              <span className="text-txt">{stats.xp % 100} / 100 XP</span>
            </div>
            <Progress value={currentLevelProgress} className="h-2" />
          </div>
        </CardContent>
      </Card>

      {/* Main Metrics Grid - 2 cols on mobile */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 md:gap-3">
        {mainMetrics.map((metric) => {
          const Icon = metric.icon;
          return (
            <Card key={metric.title} className="glass hover:bg-white/5 transition-all cursor-pointer group">
              <CardContent className="p-3 md:p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="p-1.5 md:p-2 rounded-md bg-accent/20 group-hover:scale-110 transition-transform">
                    <Icon className="w-3 h-3 md:w-4 md:h-4 text-accent" />
                  </div>
                  <span className="text-xs font-medium text-txt-2 flex-1 truncate">
                    {metric.title}
                  </span>
                </div>
                
                <div className="space-y-0.5">
                  <div className="text-lg md:text-2xl font-bold text-accent">
                    {metric.value}
                  </div>
                  <p className="text-[10px] md:text-xs text-txt-2 line-clamp-1">
                    {metric.description}
                  </p>
                  <Badge 
                    className={`text-[10px] md:text-xs px-1.5 py-0 ${
                      metric.changeType === 'positive' 
                        ? 'bg-success/20 text-success' 
                        : metric.changeType === 'negative'
                          ? 'bg-error/20 text-error'
                          : 'bg-accent/20 text-accent'
                    }`}
                  >
                    {metric.change}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Progress Analysis */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Goals */}
        <Card className="glass">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-txt">
              <Calendar className="w-5 h-5 text-accent" />
              Metas Semanais
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <WeeklyRing />
            
            <div className="space-y-3">
              {weeklyGoals.map((goal) => (
                <div key={goal.name} className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-txt-2">{goal.name}</span>
                    <span className="text-txt">
                      {goal.name === 'Volume' 
                        ? `${(goal.current / 1000).toFixed(1)}k / ${(goal.target / 1000).toFixed(1)}k kg`
                        : `${goal.current} / ${goal.target}${goal.name === 'XP' ? ' XP' : ''}`
                      }
                    </span>
                  </div>
                  <Progress 
                    value={Math.min((goal.current / goal.target) * 100, 100)} 
                    className="h-2"
                  />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Volume Progress */}
        <Card className="glass">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-txt">
              <Zap className="w-5 h-5 text-accent" />
              Evolução de Volume
            </CardTitle>
          </CardHeader>
          <CardContent>
            {volumeData.length > 0 ? (
              <MiniChart
                series={[{
                  name: "Volume",
                  data: volumeData.map(d => d.value)
                }]}
              />
            ) : (
              <div className="h-32 flex items-center justify-center text-txt-2">
                Complete treinos para ver sua evolução
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick Stats - Compact */}
      <div className="grid grid-cols-4 gap-2 md:gap-3">
        <Card className="glass text-center">
          <CardContent className="p-2.5 md:p-4">
            <div className="text-lg md:text-2xl font-bold text-accent">{stats.workoutsThisWeek}</div>
            <div className="text-[10px] md:text-xs text-txt-2">Semana</div>
          </CardContent>
        </Card>
        
        <Card className="glass text-center">
          <CardContent className="p-2.5 md:p-4">
            <div className="text-lg md:text-2xl font-bold text-accent">
              {stats.completedWorkouts > 0 ? Math.round((stats.workoutsThisWeek / 7) * 100) : 0}%
            </div>
            <div className="text-[10px] md:text-xs text-txt-2">Consist.</div>
          </CardContent>
        </Card>
        
        <Card className="glass text-center">
          <CardContent className="p-2.5 md:p-4">
            <div className="text-lg md:text-2xl font-bold text-accent">{stats.xp}</div>
            <div className="text-[10px] md:text-xs text-txt-2">XP</div>
          </CardContent>
        </Card>
        
        <Card className="glass text-center">
          <CardContent className="p-2.5 md:p-4">
            <div className="text-lg md:text-2xl font-bold text-accent">
              {workoutHistory.length > 0 ? workoutHistory.length : 0}
            </div>
            <div className="text-[10px] md:text-xs text-txt-2">Histórico</div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}