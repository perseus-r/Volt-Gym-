import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Calendar, CheckCircle2, Circle, PlayCircle, Trophy, TrendingUp } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";

interface Program {
  id: string;
  name: string;
  goal: string;
  current_day: number;
  start_date: string;
  end_date: string;
  config: any;
}

interface DailyWorkout {
  id: string;
  day_number: number;
  name: string;
  focus: string;
  completed: boolean;
  workout_data: any;
}

export function ProgramView28Days() {
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [program, setProgram] = useState<Program | null>(null);
  const [dailyWorkouts, setDailyWorkouts] = useState<DailyWorkout[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    loadProgram();
  }, [user]);

  const loadProgram = async () => {
    try {
      const { data: activeProgram, error: progError } = await supabase
        .from('workout_programs')
        .select('*')
        .eq('user_id', user!.id)
        .eq('status', 'active')
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      if (progError) throw progError;

      if (activeProgram) {
        setProgram(activeProgram);

        const { data: workouts, error: workoutsError } = await supabase
          .from('program_daily_workouts')
          .select('*')
          .eq('program_id', activeProgram.id)
          .order('day_number', { ascending: true });

        if (workoutsError) throw workoutsError;
        setDailyWorkouts(workouts || []);
      }
    } catch (error) {
      console.error('Error loading program:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleStartWorkout = (workout: DailyWorkout) => {
    toast({
      title: "Iniciando treino do programa",
      description: `Dia ${workout.day_number}: ${workout.name}`,
    });
    // TODO: Navigate to workout session with program workout data
    navigate('/treinos');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-accent" />
      </div>
    );
  }

  if (!program) {
    return (
      <Card className="p-6 bg-surface border-border">
        <div className="text-center space-y-4">
          <div className="p-4 rounded-full bg-accent/10 w-16 h-16 mx-auto flex items-center justify-center">
            <Calendar className="h-8 w-8 text-accent" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-2">
              Nenhum Programa Ativo
            </h3>
            <p className="text-sm text-muted-foreground mb-4">
              Crie um programa de 28 dias personalizado com IA
            </p>
            <Button className="bg-gradient-to-r from-accent to-accent-2">
              <TrendingUp className="h-4 w-4 mr-2" />
              Gerar Programa com IA
            </Button>
          </div>
        </div>
      </Card>
    );
  }

  const currentWeek = Math.ceil(program.current_day / 7);
  const todayWorkout = dailyWorkouts.find(w => w.day_number === program.current_day);
  const nextWorkouts = dailyWorkouts.filter(w => 
    w.day_number > program.current_day && w.day_number <= program.current_day + 3
  );
  
  const completedDays = dailyWorkouts.filter(w => w.completed).length;
  const progressPercent = (program.current_day / 28) * 100;

  const weekPhase = program.config?.weeks?.find((w: any) => w.weekNumber === currentWeek);

  return (
    <div className="space-y-4">
      {/* Header Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-xl bg-gradient-to-br from-accent via-accent-2 to-accent p-6 text-white shadow-xl"
      >
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
            backgroundSize: '32px 32px'
          }} />
        </div>

        <div className="relative space-y-4">
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                  Semana {currentWeek}/4
                </Badge>
                {weekPhase && (
                  <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                    {weekPhase.focus}
                  </Badge>
                )}
              </div>
              <h2 className="text-2xl font-bold mb-1">{program.name}</h2>
              <p className="text-white/90 text-sm">
                {program.goal === 'strength' && 'Foco em Força Máxima'}
                {program.goal === 'hypertrophy' && 'Foco em Hipertrofia'}
                {program.goal === 'endurance' && 'Foco em Resistência'}
              </p>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold">
                {program.current_day}<span className="text-xl opacity-75">/28</span>
              </div>
              <div className="text-xs opacity-75">dias</div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span>Progresso Geral</span>
              <span>{progressPercent.toFixed(0)}%</span>
            </div>
            <div className="h-2 bg-white/20 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${progressPercent}%` }}
                className="h-full bg-white rounded-full"
                transition={{ duration: 1, ease: "easeOut" }}
              />
            </div>
            <div className="flex justify-between text-xs opacity-75">
              <span>Semana 1</span>
              <span>Semana 2</span>
              <span>Semana 3</span>
              <span>Semana 4</span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Today's Workout */}
      {todayWorkout && (
        <Card className="p-6 bg-surface/50 border-border">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-xl bg-gradient-to-br from-accent to-accent-2">
              <PlayCircle className="h-6 w-6 text-white" />
            </div>
            <div className="flex-1">
              <Badge variant="outline" className="mb-2">
                Treino de Hoje
              </Badge>
              <h3 className="text-xl font-bold text-foreground mb-1">
                {todayWorkout.name}
              </h3>
              <p className="text-sm text-muted-foreground mb-4">
                {todayWorkout.focus}
              </p>
              <Button 
                onClick={() => handleStartWorkout(todayWorkout)}
                className="bg-gradient-to-r from-accent to-accent-2 hover:opacity-90"
              >
                <PlayCircle className="h-4 w-4 mr-2" />
                Começar Treino
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* Next Workouts Preview */}
      {nextWorkouts.length > 0 && (
        <Card className="p-6 bg-surface/50 border-border">
          <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
            <Calendar className="h-4 w-4 text-accent" />
            Próximos Treinos
          </h3>
          <div className="space-y-3">
            {nextWorkouts.map((workout) => (
              <div
                key={workout.id}
                className="flex items-center gap-3 p-3 rounded-lg bg-background/50 border border-border/50"
              >
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-muted text-muted-foreground text-sm font-semibold">
                  {workout.day_number}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-foreground truncate">
                    {workout.name}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {workout.focus}
                  </div>
                </div>
                {workout.completed ? (
                  <CheckCircle2 className="h-5 w-5 text-accent flex-shrink-0" />
                ) : (
                  <Circle className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                )}
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <Card className="p-4 bg-surface/50 border-border text-center">
          <div className="text-2xl font-bold text-accent mb-1">
            {completedDays}
          </div>
          <div className="text-xs text-muted-foreground">
            Treinos Completos
          </div>
        </Card>
        <Card className="p-4 bg-surface/50 border-border text-center">
          <div className="text-2xl font-bold text-accent mb-1">
            {28 - program.current_day}
          </div>
          <div className="text-xs text-muted-foreground">
            Dias Restantes
          </div>
        </Card>
        <Card className="p-4 bg-surface/50 border-border text-center">
          <div className="text-2xl font-bold text-accent mb-1">
            {currentWeek}
          </div>
          <div className="text-xs text-muted-foreground">
            Semana Atual
          </div>
        </Card>
      </div>
    </div>
  );
}