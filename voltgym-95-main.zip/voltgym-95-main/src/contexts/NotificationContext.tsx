import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import { getStorage, setStorage } from '@/lib/storage';

export type NotificationType = 'achievement' | 'reminder' | 'social' | 'tip' | 'system' | 'workout';

export interface AppNotification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  icon?: string;
  isRead: boolean;
  createdAt: string;
  action?: {
    label: string;
    route?: string;
    callback?: () => void;
  };
  metadata?: Record<string, any>;
}

interface NotificationContextType {
  notifications: AppNotification[];
  unreadCount: number;
  addNotification: (notification: Omit<AppNotification, 'id' | 'isRead' | 'createdAt'>) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  removeNotification: (id: string) => void;
  clearAll: () => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

const STORAGE_KEY = 'bora_notifications_v1';
const MAX_NOTIFICATIONS = 50;

export function NotificationProvider({ children }: { children: ReactNode }) {
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  // Load notifications from storage on mount
  useEffect(() => {
    const saved = getStorage<AppNotification[]>(STORAGE_KEY, []);
    setNotifications(saved);
  }, []);

  // Save to storage whenever notifications change
  const saveNotifications = useCallback((newNotifications: AppNotification[]) => {
    // Limit to MAX_NOTIFICATIONS
    const limited = newNotifications.slice(0, MAX_NOTIFICATIONS);
    setNotifications(limited);
    setStorage(STORAGE_KEY, limited);
  }, []);

  const addNotification = useCallback((notification: Omit<AppNotification, 'id' | 'isRead' | 'createdAt'>) => {
    const newNotification: AppNotification = {
      ...notification,
      id: `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      isRead: false,
      createdAt: new Date().toISOString()
    };

    setNotifications(prev => {
      const updated = [newNotification, ...prev];
      setStorage(STORAGE_KEY, updated.slice(0, MAX_NOTIFICATIONS));
      return updated.slice(0, MAX_NOTIFICATIONS);
    });
  }, []);

  const markAsRead = useCallback((id: string) => {
    setNotifications(prev => {
      const updated = prev.map(n => 
        n.id === id ? { ...n, isRead: true } : n
      );
      setStorage(STORAGE_KEY, updated);
      return updated;
    });
  }, []);

  const markAllAsRead = useCallback(() => {
    setNotifications(prev => {
      const updated = prev.map(n => ({ ...n, isRead: true }));
      setStorage(STORAGE_KEY, updated);
      return updated;
    });
  }, []);

  const removeNotification = useCallback((id: string) => {
    setNotifications(prev => {
      const updated = prev.filter(n => n.id !== id);
      setStorage(STORAGE_KEY, updated);
      return updated;
    });
  }, []);

  const clearAll = useCallback(() => {
    setNotifications([]);
    setStorage(STORAGE_KEY, []);
  }, []);

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <NotificationContext.Provider 
      value={{
        notifications,
        unreadCount,
        addNotification,
        markAsRead,
        markAllAsRead,
        removeNotification,
        clearAll
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
}

// Helper function to create achievement notification
export function createAchievementNotification(achievementTitle: string, xpReward: number, icon?: string) {
  return {
    type: 'achievement' as NotificationType,
    title: 'Nova Conquista!',
    message: `Você desbloqueou "${achievementTitle}" e ganhou +${xpReward} XP!`,
    icon: icon || '🏆'
  };
}

// Helper function to create workout reminder
export function createWorkoutReminder(workoutName: string) {
  return {
    type: 'reminder' as NotificationType,
    title: 'Hora de Treinar!',
    message: `Seu treino "${workoutName}" está esperando por você.`,
    icon: '💪',
    action: {
      label: 'Iniciar Treino',
      route: '/treino'
    }
  };
}

// Helper function to create tip notification
export function createTipNotification(tip: string) {
  return {
    type: 'tip' as NotificationType,
    title: 'Dica do Coach IA',
    message: tip,
    icon: '💡'
  };
}
