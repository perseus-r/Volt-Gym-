import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import { useLocation } from 'react-router-dom';

export interface PageTheme {
  name: string;
  primary: string;
  accent: string;
  glow: string;
  gradient: string;
  gradientSubtle: string;
  iconColor: string;
}

const pageThemes: Record<string, PageTheme> = {
  // Treinos - Azul Intenso (energia, foco, determinação)
  '/treinos': {
    name: 'treinos',
    primary: '217 91% 60%',
    accent: '221 83% 53%',
    glow: 'rgba(59, 130, 246, 0.6)',
    gradient: 'linear-gradient(135deg, #2563eb, #3b82f6)',
    gradientSubtle: 'radial-gradient(ellipse at top, rgba(59, 130, 246, 0.25) 0%, transparent 55%)',
    iconColor: 'text-blue-500',
  },
  '/ia-coach': {
    name: 'coach',
    primary: '217 91% 60%',
    accent: '221 83% 53%',
    glow: 'rgba(59, 130, 246, 0.6)',
    gradient: 'linear-gradient(135deg, #2563eb, #3b82f6)',
    gradientSubtle: 'radial-gradient(ellipse at top, rgba(59, 130, 246, 0.25) 0%, transparent 55%)',
    iconColor: 'text-blue-500',
  },
  '/exercicios': {
    name: 'exercicios',
    primary: '217 91% 60%',
    accent: '221 83% 53%',
    glow: 'rgba(59, 130, 246, 0.6)',
    gradient: 'linear-gradient(135deg, #2563eb, #3b82f6)',
    gradientSubtle: 'radial-gradient(ellipse at top, rgba(59, 130, 246, 0.25) 0%, transparent 55%)',
    iconColor: 'text-blue-500',
  },

  // Nutrição - Verde Esmeralda Intenso (saúde, crescimento, equilíbrio)
  '/nutricao': {
    name: 'nutricao',
    primary: '152 76% 40%',
    accent: '160 84% 39%',
    glow: 'rgba(16, 185, 129, 0.6)',
    gradient: 'linear-gradient(135deg, #059669, #10b981)',
    gradientSubtle: 'radial-gradient(ellipse at top, rgba(16, 185, 129, 0.3) 0%, transparent 55%)',
    iconColor: 'text-emerald-500',
  },

  // Progresso - Roxo Vibrante (conquista, evolução, premium)
  '/progresso': {
    name: 'progresso',
    primary: '263 70% 58%',
    accent: '280 87% 65%',
    glow: 'rgba(139, 92, 246, 0.6)',
    gradient: 'linear-gradient(135deg, #7c3aed, #a855f7)',
    gradientSubtle: 'radial-gradient(ellipse at top, rgba(139, 92, 246, 0.3) 0%, transparent 55%)',
    iconColor: 'text-violet-500',
  },

  // Dashboard - Dourado (energia, motivação)
  '/dashboard': {
    name: 'dashboard',
    primary: '38 92% 50%',
    accent: '32 95% 44%',
    glow: 'rgba(245, 158, 11, 0.4)',
    gradient: 'linear-gradient(135deg, #f59e0b, #fbbf24)',
    gradientSubtle: 'radial-gradient(ellipse at top, rgba(245, 158, 11, 0.15) 0%, transparent 60%)',
    iconColor: 'text-amber-500',
  },

  // Perfil - Ciano Brilhante (pessoal, identidade)
  '/perfil': {
    name: 'perfil',
    primary: '186 94% 50%',
    accent: '192 91% 40%',
    glow: 'rgba(6, 182, 212, 0.6)',
    gradient: 'linear-gradient(135deg, #0891b2, #22d3ee)',
    gradientSubtle: 'radial-gradient(ellipse at top, rgba(6, 182, 212, 0.3) 0%, transparent 55%)',
    iconColor: 'text-cyan-500',
  },

  // Loja - Rosa/Magenta Intenso (premium, exclusivo)
  '/loja': {
    name: 'loja',
    primary: '330 81% 60%',
    accent: '338 76% 55%',
    glow: 'rgba(236, 72, 153, 0.6)',
    gradient: 'linear-gradient(135deg, #db2777, #f472b6)',
    gradientSubtle: 'radial-gradient(ellipse at top, rgba(236, 72, 153, 0.3) 0%, transparent 55%)',
    iconColor: 'text-pink-500',
  },

  // Comunidade - Laranja (social, energia)
  '/comunidade': {
    name: 'comunidade',
    primary: '24 95% 53%',
    accent: '20 90% 48%',
    glow: 'rgba(249, 115, 22, 0.4)',
    gradient: 'linear-gradient(135deg, #ea580c, #f97316)',
    gradientSubtle: 'radial-gradient(ellipse at top, rgba(249, 115, 22, 0.15) 0%, transparent 60%)',
    iconColor: 'text-orange-500',
  },

  // Default - Azul elétrico original
  default: {
    name: 'default',
    primary: '213 94% 68%',
    accent: '217 91% 60%',
    glow: 'rgba(55, 160, 244, 0.4)',
    gradient: 'linear-gradient(135deg, #3b82f6, #60a5fa)',
    gradientSubtle: 'radial-gradient(ellipse at top, rgba(55, 160, 244, 0.1) 0%, transparent 60%)',
    iconColor: 'text-blue-500',
  },
};

interface PageThemeContextValue {
  theme: PageTheme;
  isTransitioning: boolean;
  setThemeOverride: (theme: PageTheme | null) => void;
}

const PageThemeContext = createContext<PageThemeContextValue | undefined>(undefined);

export function PageThemeProvider({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [themeOverride, setThemeOverride] = useState<PageTheme | null>(null);

  // Find matching theme for current route
  const currentTheme = useMemo(() => {
    if (themeOverride) return themeOverride;
    
    // Exact match first
    if (pageThemes[location.pathname]) {
      return pageThemes[location.pathname];
    }
    
    // Partial match for nested routes
    const basePath = '/' + location.pathname.split('/')[1];
    if (pageThemes[basePath]) {
      return pageThemes[basePath];
    }
    
    return pageThemes.default;
  }, [location.pathname, themeOverride]);

  // Apply CSS variables when theme changes
  useEffect(() => {
    setIsTransitioning(true);
    
    const root = document.documentElement;
    root.style.setProperty('--page-primary', currentTheme.primary);
    root.style.setProperty('--page-accent', currentTheme.accent);
    root.style.setProperty('--page-glow', currentTheme.glow);
    root.style.setProperty('--page-gradient', currentTheme.gradient);
    root.style.setProperty('--page-gradient-subtle', currentTheme.gradientSubtle);
    
    // Add transitioning class for CSS animations
    root.classList.add('theme-transitioning');
    
    const timeout = setTimeout(() => {
      setIsTransitioning(false);
      root.classList.remove('theme-transitioning');
    }, 400);

    return () => clearTimeout(timeout);
  }, [currentTheme]);

  return (
    <PageThemeContext.Provider value={{ theme: currentTheme, isTransitioning, setThemeOverride }}>
      {children}
    </PageThemeContext.Provider>
  );
}

export function usePageThemeContext() {
  const context = useContext(PageThemeContext);
  if (!context) {
    throw new Error('usePageThemeContext must be used within PageThemeProvider');
  }
  return context;
}

// Export themes for external use
export { pageThemes };
