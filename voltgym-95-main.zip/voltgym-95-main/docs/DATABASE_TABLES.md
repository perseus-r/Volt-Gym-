# Database Tables Documentation

This document maps the active and deprecated tables in the Supabase database.

## ✅ Active Tables (Core Functionality)

### User & Auth
| Table | Purpose | Status |
|-------|---------|--------|
| `profiles` | User profile data (age, weight, goals, etc.) | **Active** |
| `subscribers` | Subscription status and plan info | **Active** |
| `admin_controls` | Admin-granted free access | **Active** |

### Workouts & Training
| Table | Purpose | Status |
|-------|---------|--------|
| `workout_sessions` | Main workout session records | **Active** |
| `exercise_logs` | Exercises performed in each session | **Active** |
| `set_logs` | Individual sets with weight/reps | **Active** |
| `exercises` | Exercise library (name, muscles, instructions) | **Active** |
| `exercise_categories` | Exercise categorization | **Active** |
| `exercise_aliases` | Alternative names for exercises | **Active** |
| `exercise_stats` | Aggregated exercise statistics per user | **Active** |
| `personal_records` | User PRs (personal records) | **Active** |
| `pr_records` | Alternative PR tracking | **Active** |

### Training Plans
| Table | Purpose | Status |
|-------|---------|--------|
| `plans` | User training plans | **Active** |
| `plan_days` | Days within a plan | **Active** |
| `plan_day_exercises` | Exercises for each plan day | **Active** |
| `workout_programs` | 28-day program definitions | **Active** |
| `program_daily_workouts` | Daily workouts in programs | **Active** |

### Personal Trainer System
| Table | Purpose | Status |
|-------|---------|--------|
| `personal_trainer_profiles` | PT account data | **Active** |
| `athlete_assigned_workouts` | Workouts assigned by PT | **Active** |
| `athlete_checkins` | Athlete check-in data | **Active** |
| `athlete_documents` | Documents uploaded by athletes | **Active** |
| `athlete_invite_links` | PT invite links for athletes | **Active** |
| `athlete_progress_tracking` | Progress analytics per athlete | **Active** |
| `workout_templates_pt` | PT workout templates | **Active** |
| `pt_athlete_chats` | Chat conversations | **Active** |
| `pt_athlete_chat_messages` | Chat messages | **Active** |

### Nutrition
| Table | Purpose | Status |
|-------|---------|--------|
| `nutrition_logs` | Daily food/nutrition logs | **Active** |
| `nutrition_foods` | Food database | **Active** |

### Body Metrics
| Table | Purpose | Status |
|-------|---------|--------|
| `body_metrics` | Weight, body fat, measurements | **Active** |

### AI & Chat
| Table | Purpose | Status |
|-------|---------|--------|
| `ai_conversations` | AI chat conversations | **Active** |
| `ai_messages` | Messages in AI chats | **Active** |
| `ai_feed_content` | AI-generated feed content | **Active** |

### Social Features
| Table | Purpose | Status |
|-------|---------|--------|
| `social_posts` | Community posts | **Active** |
| `social_comments` | Post comments | **Active** |
| `social_likes` | Likes on posts/comments | **Active** |
| `social_follows` | Follow relationships | **Active** |
| `social_shares` | Shared posts | **Active** |
| `social_stories` | User stories | **Active** |
| `story_views` | Story view tracking | **Active** |

### Appointments & Professionals
| Table | Purpose | Status |
|-------|---------|--------|
| `professionals` | Professional profiles (nutritionists, etc.) | **Active** |
| `appointments` | Scheduled appointments | **Active** |
| `professional_messages` | Appointment messages | **Active** |
| `professional_reviews` | Reviews for professionals | **Active** |

### E-commerce
| Table | Purpose | Status |
|-------|---------|--------|
| `products` | Store products | **Active** |
| `orders` | Customer orders | **Active** |

### System & Infrastructure
| Table | Purpose | Status |
|-------|---------|--------|
| `push_tokens` | Push notification tokens | **Active** |
| `reminders` | User reminders | **Active** |
| `short_links` | URL shortener | **Active** |
| `jobs` | Background job queue | **Active** |
| `media_uploads` | User uploaded media | **Active** |

### Audit & Analytics
| Table | Purpose | Status |
|-------|---------|--------|
| `audit_events` | System audit trail | **Active** |
| `admin_actions` | Admin action logs | **Active** |
| `profile_audit_log` | Profile change logs | **Active** |
| `progress_rankings` | User progress rankings | **Active** |

### Caching
| Table | Purpose | Status |
|-------|---------|--------|
| `embedding_cache` | AI embedding cache | **Active** |
| `rag_query_cache` | RAG query cache | **Active** |

### Reference Data
| Table | Purpose | Status |
|-------|---------|--------|
| `muscles` | Muscle reference data | **Active** |

---

## ⚠️ Tables Requiring Review

| Table | Concern | Recommendation |
|-------|---------|----------------|
| `workout_sessions_detailed` | Duplicate of `workout_sessions` | Migrate data, then deprecate |
| `session_sets` | Duplicate of `set_logs` | Migrate data, then deprecate |

---

## 📊 Table Count Summary

- **Active Tables**: 55+
- **Pending Review**: 2
- **Deprecated**: 0 (pending cleanup)

---

## 🔐 Security Notes

1. **profiles** - RLS needs review (currently too permissive)
2. **embedding_cache** - Should be service-role only
3. **subscribers** - RLS has weak condition allowing null auth

See Phase 1 security recommendations for fixes.
